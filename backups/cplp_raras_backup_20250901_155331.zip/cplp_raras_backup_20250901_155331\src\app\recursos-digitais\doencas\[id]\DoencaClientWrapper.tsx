'use client';

import { useState } from 'react';
import Link from 'next/link';
import { 
  ChevronRightIcon, 
  PrinterIcon, 
  ShareIcon,
  BookOpenIcon,
  BeakerIcon,
  HeartIcon,
  UserGroupIcon,
  DocumentTextIcon,
  CalendarIcon,
  MapPinIcon,
  ExclamationTriangleIcon
} from '@heroicons/react/24/outline';
import TopShare from '@/components/TopShare';

interface DiseaseDetail {
  id: string;
  gard_br_id: string;
  name_pt: string;
  name_en: string;
  synonyms: string[];
  category: string;
  orpha_code?: string;
  icd10_code?: string;
  prevalence: string;
  inheritance_pattern?: string;
  age_of_onset?: string;
  last_updated: string;
  
  // Conteúdo principal
  summary: string;
  symptoms: string[];
  causes: string;
  diagnosis: string;
  treatment: string;
  prognosis: string;
  
  // Recursos adicionais
  support_organizations: any[];
  clinical_trials: any[];
  recent_articles: any[];
  patient_resources: any[];
  expert_reviewers: string[];
  sources: string[];
}

interface Props {
  disease: DiseaseDetail;
}

export default function DoencaClientWrapper({ disease }: Props) {
  const [activeTab, setActiveTab] = useState('resumo');

  const handlePrint = () => {
    window.print();
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: disease.name_pt,
        text: `Informações sobre ${disease.name_pt} - GARD Brasileiro`,
        url: window.location.href
      });
    }
  };

  const tabs = [
    { id: 'resumo', name: 'Resumo', icon: BookOpenIcon },
    { id: 'sintomas', name: 'Sintomas', icon: HeartIcon },
    { id: 'causa', name: 'Causa', icon: BeakerIcon },
    { id: 'diagnostico', name: 'Diagnóstico', icon: DocumentTextIcon },
    { id: 'tratamento', name: 'Tratamento', icon: HeartIcon },
    { id: 'prognostico', name: 'Prognóstico', icon: CalendarIcon }
  ];

  return (
    <div className="min-h-screen bg-white">
      <TopShare 
        title={`${disease.name_pt} - GARD Brasileiro`}
        description={`Informações médicas detalhadas sobre ${disease.name_pt}. Sintomas, diagnóstico, tratamento e recursos para pacientes.`}
      />

      {/* Breadcrumb Navigation */}
      <div className="bg-gray-50 border-b">
        <div className="max-w-7xl mx-auto px-4 py-3 sm:px-6 lg:px-8">
          <nav className="flex items-center space-x-2 text-sm">
            <Link href="/" className="text-blue-600 hover:text-blue-800">
              Início
            </Link>
            <ChevronRightIcon className="h-4 w-4 text-gray-400" />
            <Link href="/recursos-digitais" className="text-blue-600 hover:text-blue-800">
              Recursos Digitais
            </Link>
            <ChevronRightIcon className="h-4 w-4 text-gray-400" />
            <Link href="/recursos-digitais/doencas" className="text-blue-600 hover:text-blue-800">
              Doenças Raras
            </Link>
            <ChevronRightIcon className="h-4 w-4 text-gray-400" />
            <span className="text-gray-500 truncate">{disease.name_pt}</span>
          </nav>
        </div>
      </div>

      {/* Cabeçalho da Doença */}
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between">
            <div className="flex-1 mb-6 lg:mb-0">
              <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                {disease.name_pt}
              </h1>
              
              {disease.synonyms.length > 0 && (
                <div className="mb-4">
                  <h2 className="text-lg font-medium text-gray-700 mb-2">Outros nomes:</h2>
                  <p className="text-gray-600">{disease.synonyms.join(', ')}</p>
                </div>
              )}

              <div className="flex flex-wrap gap-2 mb-4">
                <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                  {disease.category}
                </span>
                <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                  ID: {disease.gard_br_id}
                </span>
                {disease.orpha_code && (
                  <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                    ORPHA: {disease.orpha_code}
                  </span>
                )}
                {disease.icd10_code && (
                  <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-purple-100 text-purple-800">
                    CID-10: {disease.icd10_code}
                  </span>
                )}
              </div>
            </div>

            {/* Botões de Ação */}
            <div className="flex flex-col sm:flex-row gap-3">
              <button
                onClick={handlePrint}
                className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
              >
                <PrinterIcon className="h-4 w-4 mr-2" />
                Imprimir
              </button>
              <button
                onClick={handleShare}
                className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
              >
                <ShareIcon className="h-4 w-4 mr-2" />
                Partilhar
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Conteúdo Principal */}
      <div className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        <div className="lg:grid lg:grid-cols-4 lg:gap-8">
          {/* Conteúdo Principal */}
          <div className="lg:col-span-3">
            {/* Tabs Navigation */}
            <div className="border-b border-gray-200 mb-8">
              <nav className="-mb-px flex space-x-8 overflow-x-auto">
                {tabs.map((tab) => {
                  const Icon = tab.icon;
                  return (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id)}
                      className={`whitespace-nowrap pb-4 px-1 border-b-2 font-medium text-sm flex items-center transition-colors ${
                        activeTab === tab.id
                          ? 'border-blue-500 text-blue-600'
                          : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                      }`}
                    >
                      <Icon className="h-4 w-4 mr-2" />
                      {tab.name}
                    </button>
                  );
                })}
              </nav>
            </div>

            {/* Conteúdo das Tabs */}
            <div className="prose max-w-none">
              {activeTab === 'resumo' && (
                <div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-4">Resumo</h3>
                  <p className="text-gray-700 leading-relaxed">{disease.summary}</p>
                </div>
              )}

              {activeTab === 'sintomas' && (
                <div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-4">Sintomas e Sinais</h3>
                  <p className="text-gray-600 mb-4">
                    Os seguintes sinais e sintomas podem estar presentes na {disease.name_pt}:
                  </p>
                  <ul className="list-disc list-inside space-y-2 text-gray-700">
                    {disease.symptoms.map((symptom: string, index: number) => (
                      <li key={index}>{symptom}</li>
                    ))}
                  </ul>
                  <div className="mt-6 p-4 bg-amber-50 border border-amber-200 rounded-lg">
                    <div className="flex items-start">
                      <ExclamationTriangleIcon className="h-5 w-5 text-amber-400 mt-0.5 mr-3 flex-shrink-0" />
                      <div className="text-sm text-amber-800">
                        <p className="font-medium">Nota Importante:</p>
                        <p>
                          Nem todos os sintomas listados estão presentes em todos os pacientes. 
                          A gravidade e combinação de sintomas pode variar significativamente.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'causa' && (
                <div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-4">Causa</h3>
                  <p className="text-gray-700 leading-relaxed">{disease.causes}</p>
                </div>
              )}

              {activeTab === 'diagnostico' && (
                <div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-4">Diagnóstico</h3>
                  <p className="text-gray-700 leading-relaxed">{disease.diagnosis}</p>
                </div>
              )}

              {activeTab === 'tratamento' && (
                <div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-4">Tratamento</h3>
                  <p className="text-gray-700 leading-relaxed">{disease.treatment}</p>
                </div>
              )}

              {activeTab === 'prognostico' && (
                <div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-4">Prognóstico</h3>
                  <p className="text-gray-700 leading-relaxed">{disease.prognosis}</p>
                </div>
              )}
            </div>
          </div>

          {/* Sidebar Informativa */}
          <div className="mt-8 lg:mt-0 lg:col-span-1">
            <div className="bg-gray-50 rounded-lg p-6 sticky top-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Informações Rápidas</h3>
              
              <div className="space-y-4">
                <div>
                  <h4 className="text-sm font-medium text-gray-700 mb-1">Prevalência</h4>
                  <p className="text-sm text-gray-600">{disease.prevalence}</p>
                </div>

                {disease.inheritance_pattern && (
                  <div>
                    <h4 className="text-sm font-medium text-gray-700 mb-1">Padrão de Herança</h4>
                    <p className="text-sm text-gray-600">{disease.inheritance_pattern}</p>
                  </div>
                )}

                {disease.age_of_onset && (
                  <div>
                    <h4 className="text-sm font-medium text-gray-700 mb-1">Idade de Início</h4>
                    <p className="text-sm text-gray-600">{disease.age_of_onset}</p>
                  </div>
                )}

                <div className="pt-4 border-t border-gray-200">
                  <h4 className="text-sm font-medium text-gray-700 mb-2">Códigos</h4>
                  <div className="space-y-1">
                    <p className="text-sm text-gray-600">GARD-BR: {disease.gard_br_id}</p>
                    {disease.orpha_code && (
                      <p className="text-sm text-gray-600">ORPHA: {disease.orpha_code}</p>
                    )}
                    {disease.icd10_code && (
                      <p className="text-sm text-gray-600">CID-10: {disease.icd10_code}</p>
                    )}
                  </div>
                </div>

                <div className="pt-4 border-t border-gray-200">
                  <h4 className="text-sm font-medium text-gray-700 mb-2">Recursos Externos</h4>
                  <div className="space-y-2">
                    <a
                      href={`https://www.orpha.net/consor/cgi-bin/Disease_Search.php?lng=EN&data_id=${disease.orpha_code}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="block text-sm text-blue-600 hover:text-blue-800"
                    >
                      Orphanet
                    </a>
                    <a
                      href={`https://www.ncbi.nlm.nih.gov/books/NBK1335/`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="block text-sm text-blue-600 hover:text-blue-800"
                    >
                      GeneReviews
                    </a>
                    <a
                      href={`https://rarediseases.info.nih.gov/diseases`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="block text-sm text-blue-600 hover:text-blue-800"
                    >
                      GARD Original (NIH)
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Disclaimer e Links */}
        <div className="mt-12 pt-8 border-t border-gray-200">
          <div className="text-center">
            <p className="text-sm text-gray-500 mb-4">
              <strong>GARD Brasileiro</strong> - Centro de Informação sobre Doenças Genéticas e Raras
            </p>
            <div className="space-x-6 text-xs text-gray-400">
              <Link href="/recursos-digitais/doencas" className="hover:text-gray-600">
                ← Voltar à Lista de Doenças
              </Link>
              <Link href="/sobre" className="hover:text-gray-600">
                Sobre o GARD
              </Link>
              <Link href="/contato" className="hover:text-gray-600">
                Contacto
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
