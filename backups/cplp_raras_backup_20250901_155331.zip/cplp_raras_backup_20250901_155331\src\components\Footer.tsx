import Link from 'next/link';

export default function Footer() {
  return (
    <footer className="bg-gradient-to-br from-gray-900 via-purple-900 to-pink-900 text-white relative overflow-hidden">
      {/* Background pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-pink-500/20 to-transparent transform -skew-y-12"></div>
      </div>
      
      <div className="relative mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Logo and description */}
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center space-x-3 mb-6">
              <div className="w-12 h-12 bg-gradient-to-br from-pink-500 to-purple-600 rounded-full flex items-center justify-center shadow-lg">
                <span className="text-white font-bold text-xl">🦓</span>
              </div>
              <div>
                <h3 className="text-xl font-bold bg-gradient-to-r from-pink-300 to-purple-300 bg-clip-text text-transparent">
                  CPLP-Raras
                </h3>
                <p className="text-sm text-pink-200">Doenças Raras</p>
              </div>
            </div>
            <p className="text-gray-300 text-sm max-w-md leading-relaxed">
              Fortalecer a resposta dos países da CPLP às doenças raras por meio do mapeamento 
              informacional, do uso de tecnologias em saúde digital e da promoção de cooperação 
              científica, educacional e clínica.
            </p>
            
            {/* Zebra pattern - symbol of rare diseases */}
            <div className="mt-6 flex items-center space-x-2 text-pink-300">
              <span className="text-xl">🦓</span>
              <span className="text-xs">Símbolo das Doenças Raras</span>
            </div>
          </div>
          
          {/* Navigation links */}
          <div>
            <h4 className="text-sm font-semibold text-pink-300 uppercase tracking-wider mb-4">
              Navegação
            </h4>
            <ul className="space-y-3">
              <li>
                <Link href="/sobre" className="text-gray-300 hover:text-pink-300 text-sm transition-colors duration-200 flex items-center space-x-2 group">
                  <span className="w-1 h-1 bg-pink-500 rounded-full group-hover:bg-pink-300 transition-colors"></span>
                  <span>Sobre</span>
                </Link>
              </li>
              <li>
                <Link href="/grupos-trabalho" className="text-gray-300 hover:text-pink-300 text-sm transition-colors duration-200 flex items-center space-x-2 group">
                  <span className="w-1 h-1 bg-pink-500 rounded-full group-hover:bg-pink-300 transition-colors"></span>
                  <span>Grupos de Trabalho</span>
                </Link>
              </li>
              <li>
                <Link href="/equipe" className="text-gray-300 hover:text-pink-300 text-sm transition-colors duration-200 flex items-center space-x-2 group">
                  <span className="w-1 h-1 bg-pink-500 rounded-full group-hover:bg-pink-300 transition-colors"></span>
                  <span>Equipe</span>
                </Link>
              </li>
              <li>
                <Link href="/publicacoes" className="text-gray-300 hover:text-pink-300 text-sm transition-colors duration-200 flex items-center space-x-2 group">
                  <span className="w-1 h-1 bg-pink-500 rounded-full group-hover:bg-pink-300 transition-colors"></span>
                  <span>Publicações</span>
                </Link>
              </li>
            </ul>
          </div>
          
          {/* Contact info */}
          <div>
            <h4 className="text-sm font-semibold text-pink-300 uppercase tracking-wider mb-4">
              Contato
            </h4>
            <div className="space-y-3">
              <p className="text-gray-300 text-sm">
                Para mais informações sobre o projeto
              </p>
              <Link 
                href="/contato" 
                className="inline-flex items-center text-pink-400 hover:text-pink-300 text-sm transition-colors duration-200 group"
              >
                <span className="w-1 h-1 bg-pink-500 rounded-full group-hover:bg-pink-300 transition-colors mr-2"></span>
                Entre em contato
              </Link>
              
              {/* Social Media */}
              <div className="pt-2">
                <h5 className="text-xs font-semibold text-pink-300 uppercase tracking-wider mb-3">
                  Redes Sociais
                </h5>
                <div className="flex space-x-3">
                  <a
                    href="https://instagram.com/rarasporti"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="group flex items-center justify-center w-8 h-8 bg-gradient-to-br from-pink-500 to-purple-600 rounded-lg hover:from-pink-600 hover:to-purple-700 transition-all duration-200 transform hover:scale-110"
                    title="Instagram @rarasporti"
                  >
                    <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M12.017 0C5.396 0 .029 5.367.029 11.987c0 6.621 5.367 11.988 11.988 11.988s11.987-5.367 11.987-11.988C24.004 5.367 18.637.001 12.017.001zM8.449 16.988c-1.297 0-2.448-.611-3.197-1.559-.326-.414-.518-.937-.518-1.507 0-1.347 1.094-2.441 2.441-2.441s2.441 1.094 2.441 2.441c0 .57-.192 1.093-.518 1.507-.749.948-1.9 1.559-3.197 1.559zm7.138 0c-1.297 0-2.448-.611-3.197-1.559-.326-.414-.518-.937-.518-1.507 0-1.347 1.094-2.441 2.441-2.441s2.441 1.094 2.441 2.441c0 .57-.192 1.093-.518 1.507-.749.948-1.9 1.559-3.197 1.559z"/>
                    </svg>
                  </a>
                  <a
                    href="https://www.facebook.com/profile.php?id=61578726425301"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="group flex items-center justify-center w-8 h-8 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg hover:from-blue-600 hover:to-blue-700 transition-all duration-200 transform hover:scale-110"
                    title="Facebook CPLP-Raras"
                  >
                    <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                    </svg>
                  </a>
                </div>
                <p className="text-xs text-gray-400 mt-2">
                  @rarasporti
                </p>
              </div>
            </div>
          </div>
          
          {/* Countries */}
          <div>
            <h4 className="text-sm font-semibold text-pink-300 uppercase tracking-wider mb-4">
              Países CPLP
            </h4>
            <div className="grid grid-cols-2 gap-1 text-xs text-gray-400">
              <span>🇦🇴 Angola</span>
              <span>🇧🇷 Brasil</span>
              <span>🇨🇻 Cabo Verde</span>
              <span>🇬🇼 Guiné-Bissau</span>
              <span>🇬🇶 Guiné Equatorial</span>
              <span>🇲🇿 Moçambique</span>
              <span>🇵🇹 Portugal</span>
              <span>🇸🇹 São Tomé e Príncipe</span>
              <span className="col-span-2">🇹🇱 Timor-Leste</span>
            </div>
          </div>
        </div>
        
        <div className="mt-8 pt-8 border-t border-pink-800/30">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex flex-col md:flex-row items-center space-y-2 md:space-y-0 md:space-x-4">
              <p className="text-gray-400 text-sm">
                © {new Date().getFullYear()} CPLP-Raras. Todos os direitos reservados.
              </p>
              <Link 
                href="/politica-privacidade" 
                className="text-pink-400 hover:text-pink-300 text-sm transition-colors duration-200"
                aria-label="Acessar política de privacidade do site"
              >
                Política de Privacidade
              </Link>
              <span className="text-pink-600 mx-2" aria-hidden="true">|</span>
              <Link 
                href="/acessibilidade" 
                className="text-pink-400 hover:text-pink-300 text-sm transition-colors duration-200 flex items-center"
                aria-label="Informações sobre acessibilidade do site"
              >
                <span role="img" aria-label="Acessibilidade" className="mr-1">♿</span>
                Acessibilidade
              </Link>
            </div>
            <div className="flex items-center space-x-4 mt-4 md:mt-0">
              <span className="text-xs text-gray-500">Apoio:</span>
              <div className="flex items-center space-x-2">
                <div className="mr-1 from-blue-500 to-green-500 rounded flex items-center justify-center">
                  <span className="text-white text-xs font-bold">Conselho Nacional de Desenvolvimento e Pesquisa (CNPq) - Brasil</span>
                </div>
              
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
