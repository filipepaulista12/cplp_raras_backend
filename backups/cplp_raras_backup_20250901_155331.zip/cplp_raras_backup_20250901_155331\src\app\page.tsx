import Hero from '@/components/Hero';
import Mission from '@/components/Mission';
import WorkingGroups from '@/components/WorkingGroups';
import FAQ from '@/components/FAQ';
//import News from '@/components/News';
//import Support from '@/components/Support';
import Contact from '@/components/Contact';
import MapeamentoFormulario from '@/components/MapeamentoFormulario';
import TopShare from '@/components/TopShare';

export default function Home() {
  return (
    <div className="min-h-screen">
      {/* Deploy Incremental: V2.0 - Sistema Funcionando! */}
      <MapeamentoFormulario />
      
      <Hero />
      <Mission />
      <WorkingGroups />
      <FAQ />
    {/* <News />*/}
      {/* <Support /> */}
      <Contact />
    </div>
  );
}
