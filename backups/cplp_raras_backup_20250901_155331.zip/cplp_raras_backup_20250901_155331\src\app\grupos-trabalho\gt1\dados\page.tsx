'use client';

import Link from 'next/link';
import { useState } from 'react';

// Mock data structure - será substituído pela API do REDCap
const mockStats = {
  totalEntries: 0,
  countries: [],
  centers: 0,
  professionals: 0,
  diagnosticResources: 0,
  therapies: 0,
  maturityAssessments: 0,
  integratedData: 0
};

export default function GT1Dados() {
  const [selectedCountry, setSelectedCountry] = useState('todos');
  const [selectedActivity, setSelectedActivity] = useState('todas');
  const [dateRange, setDateRange] = useState('todos');
  const [showDetails, setShowDetails] = useState(false);

  // Países da CPLP
  const cplpCountries = [
    'Brasil', 'Portugal', 'Angola', 'Moçambique', 
    'Cabo Verde', 'Guiné-Bissau', 'São Tomé e Príncipe', 'Timor-Leste'
  ];

  const activities = [
    { id: 1, name: 'Centros Especializados', color: 'blue' },
    { id: 2, name: 'Profissionais', color: 'green' },
    { id: 3, name: 'Recursos Diagnósticos', color: 'purple' },
    { id: 4, name: 'Terapias e Tratamentos', color: 'orange' },
    { id: 5, name: 'Avaliação de Maturidade', color: 'pink' },
    { id: 6, name: 'Base de Dados Integrada', color: 'teal' }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Breadcrumb */}
      <div className="bg-white border-b">
        <div className="mx-auto max-w-7xl px-4 py-4 sm:px-6 lg:px-8">
          <nav className="flex" aria-label="Breadcrumb">
            <ol className="inline-flex items-center space-x-1 md:space-x-3">
              <li className="inline-flex items-center">
                <Link href="/" className="text-blue-600 hover:text-blue-800">
                  Início
                </Link>
              </li>
              <li>
                <div className="flex items-center">
                  <span className="mx-2 text-gray-400">/</span>
                  <Link href="/grupos-trabalho" className="text-blue-600 hover:text-blue-800">
                    Grupos de Trabalho
                  </Link>
                </div>
              </li>
              <li>
                <div className="flex items-center">
                  <span className="mx-2 text-gray-400">/</span>
                  <Link href="/grupos-trabalho/gt1" className="text-blue-600 hover:text-blue-800">
                    GT1 - Mapeamento de Recursos
                  </Link>
                </div>
              </li>
              <li aria-current="page">
                <div className="flex items-center">
                  <span className="mx-2 text-gray-400">/</span>
                  <span className="text-gray-500">Dados Coletados</span>
                </div>
              </li>
            </ol>
          </nav>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="mb-8">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 mb-2">
                Dashboard de Dados - GT1
              </h1>
              <p className="text-lg text-gray-600">
                Visualização e análise dos dados coletados no mapeamento de recursos
              </p>
            </div>
            <div className="mt-4 sm:mt-0">
              <button
                onClick={() => setShowDetails(!showDetails)}
                className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-medium transition-colors"
              >
                {showDetails ? 'Ocultar Detalhes' : 'Ver Detalhes'}
              </button>
            </div>
          </div>
        </div>

        {/* Status Geral */}
        <div className="bg-white rounded-xl shadow-sm p-6 mb-8">
          <div className="text-center mb-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-2">Status da Coleta de Dados</h2>
            <div className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-orange-100 text-orange-800">
              🔄 Coleta em Andamento
            </div>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600 mb-2">{mockStats.totalEntries}</div>
              <div className="text-sm text-gray-600">Registros Totais</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-green-600 mb-2">{cplpCountries.length}</div>
              <div className="text-sm text-gray-600">Países CPLP</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-purple-600 mb-2">6</div>
              <div className="text-sm text-gray-600">Atividades</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-orange-600 mb-2">REDCap</div>
              <div className="text-sm text-gray-600">Plataforma</div>
            </div>
          </div>
        </div>

        {/* Filtros */}
        <div className="bg-white rounded-xl shadow-sm p-6 mb-8">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Filtros de Análise</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Filtro por País */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">País</label>
              <select
                value={selectedCountry}
                onChange={(e) => setSelectedCountry(e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="todos">Todos os Países</option>
                {cplpCountries.map((country) => (
                  <option key={country} value={country.toLowerCase()}>
                    {country}
                  </option>
                ))}
              </select>
            </div>

            {/* Filtro por Atividade */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Atividade</label>
              <select
                value={selectedActivity}
                onChange={(e) => setSelectedActivity(e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="todas">Todas as Atividades</option>
                {activities.map((activity) => (
                  <option key={activity.id} value={activity.id}>
                    Atividade {activity.id} - {activity.name}
                  </option>
                ))}
              </select>
            </div>

            {/* Filtro por Período */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Período</label>
              <select
                value={dateRange}
                onChange={(e) => setDateRange(e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="todos">Todos os Períodos</option>
                <option value="7dias">Últimos 7 dias</option>
                <option value="30dias">Últimos 30 dias</option>
                <option value="3meses">Últimos 3 meses</option>
                <option value="6meses">Últimos 6 meses</option>
                <option value="1ano">Último ano</option>
              </select>
            </div>
          </div>

          <div className="mt-4 flex flex-col sm:flex-row gap-3">
            <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-medium transition-colors">
              Aplicar Filtros
            </button>
            <button 
              onClick={() => {
                setSelectedCountry('todos');
                setSelectedActivity('todas');
                setDateRange('todos');
              }}
              className="bg-gray-100 hover:bg-gray-200 text-gray-700 px-4 py-2 rounded-lg font-medium transition-colors"
            >
              Limpar Filtros
            </button>
          </div>
        </div>

        {/* Resumo das Atividades */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {activities.map((activity) => (
            <div key={activity.id} className="bg-white rounded-xl shadow-sm p-6 hover:shadow-md transition-shadow">
              <div className="flex items-center mb-4">
                <div className={`bg-${activity.color}-600 text-white rounded-full w-8 h-8 flex items-center justify-center text-sm font-bold mr-3`}>
                  {activity.id}
                </div>
                <h3 className="font-semibold text-gray-900 text-sm">{activity.name}</h3>
              </div>
              
              <div className="space-y-3 mb-4">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Registros:</span>
                  <span className="font-semibold text-gray-900">
                    {mockStats.totalEntries > 0 ? mockStats.totalEntries : 'Em coleta'}
                  </span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Países:</span>
                  <span className="font-semibold text-gray-900">
                    {mockStats.countries.length > 0 ? `${mockStats.countries.length}/8` : 'Em andamento'}
                  </span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Status:</span>
                  <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-orange-100 text-orange-800">
                    🔄 Ativo
                  </span>
                </div>
              </div>
              
              <div className="text-center">
                <button className="w-full px-3 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg text-xs font-medium transition-colors">
                  📊 Dados em Breve
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Seção de Dados Detalhados (condicional) */}
        {showDetails && (
          <div className="bg-white rounded-xl shadow-sm p-6 mb-8">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Análise Detalhada por País</h3>
            
            {mockStats.totalEntries === 0 ? (
              <div className="text-center py-12">
                <div className="text-6xl mb-4">📊</div>
                <h4 className="text-xl font-semibold text-gray-900 mb-2">
                  Dados em Coleta
                </h4>
                <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
                  Os dados estão sendo coletados através do REDCap. Assim que houver 
                  informações suficientes, esta seção exibirá análises detalhadas por país, 
                  gráficos comparativos e estatísticas descritivas.
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 max-w-4xl mx-auto">
                  {cplpCountries.map((country) => (
                    <div key={country} className="p-4 bg-gray-50 rounded-lg">
                      <div className="text-sm font-medium text-gray-900">{country}</div>
                      <div className="text-xs text-gray-500 mt-1">Aguardando dados</div>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Aqui virão os gráficos e análises quando houver dados */}
                <div className="p-6 bg-gray-50 rounded-lg">
                  <h4 className="font-medium text-gray-900 mb-2">Distribuição por País</h4>
                  <div className="text-sm text-gray-600">Gráfico será exibido quando houver dados</div>
                </div>
                
                <div className="p-6 bg-gray-50 rounded-lg">
                  <h4 className="font-medium text-gray-900 mb-2">Recursos por Categoria</h4>
                  <div className="text-sm text-gray-600">Gráfico será exibido quando houver dados</div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Acesso Direto aos Dados */}
        <div className="bg-white rounded-xl shadow-sm p-8 mb-8">
          <div className="text-center">
            <h2 className="text-2xl font-semibold text-gray-900 mb-4">
              Acesso aos Dados Completos
            </h2>
            <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
              Todos os dados são gerenciados através da plataforma REDCap, garantindo 
              segurança, integridade e controle de acesso às informações coletadas.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
              <div className="text-center p-6 bg-blue-50 rounded-xl">
                <div className="text-3xl mb-4">📊</div>
                <h3 className="font-semibold text-gray-900 mb-2">Dashboard de Dados</h3>
                <p className="text-sm text-gray-600 mb-4">
                  Visualizações interativas serão disponibilizadas quando houver dados suficientes
                </p>
                <button className="inline-block bg-gray-400 text-white px-4 py-2 rounded-lg text-sm font-medium cursor-not-allowed">
                  Em Desenvolvimento
                </button>
              </div>
              
              <div className="text-center p-6 bg-green-50 rounded-xl">
                <div className="text-3xl mb-4">�</div>
                <h3 className="font-semibold text-gray-900 mb-2">Relatórios Analíticos</h3>
                <p className="text-sm text-gray-600 mb-4">
                  Relatórios estatísticos e comparativos por país
                </p>
                <button className="inline-block bg-gray-400 text-white px-4 py-2 rounded-lg text-sm font-medium cursor-not-allowed">
                  Em Breve
                </button>
              </div>

              <div className="text-center p-6 bg-purple-50 rounded-xl">
                <div className="text-3xl mb-4">�</div>
                <h3 className="font-semibold text-gray-900 mb-2">Exportar</h3>
                <p className="text-sm text-gray-600 mb-4">
                  Download dos dados em diversos formatos
                </p>
                <Link
                  href="https://redcap.link/cplpDR"
                  target="_blank"
                  className="inline-block bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors"
                >
                  Exportar Dados
                </Link>
              </div>
            </div>
          </div>
        </div>

        {/* Informações do Projeto */}
        <div className="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-xl p-8 text-white text-center">
          <h2 className="text-2xl font-bold mb-4">Projeto em Desenvolvimento Ativo</h2>
          <p className="text-lg opacity-90 mb-6">
            Este dashboard será atualizado automaticamente conforme os dados forem 
            coletados. Em breve, implementaremos integração direta com a API do REDCap 
            para visualizações em tempo real.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              href="/grupos-trabalho/gt1"
              className="bg-white text-blue-600 px-6 py-3 rounded-lg font-semibold hover:bg-blue-50 transition-colors"
            >
              Voltar ao GT1
            </Link>
            <Link
              href="https://redcap.link/cplpDR"
              target="_blank"
              className="bg-blue-500 hover:bg-blue-400 text-white px-6 py-3 rounded-lg font-semibold transition-colors"
            >
              Contribuir com Dados
            </Link>
          </div>
        </div>

      </div>
    </div>
  );
}
