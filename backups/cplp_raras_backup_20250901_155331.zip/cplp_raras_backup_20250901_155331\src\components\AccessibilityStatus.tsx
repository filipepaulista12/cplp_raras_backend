'use client';

import { useState, useEffect } from 'react';

export default function AccessibilityStatus() {
  const [isVisible, setIsVisible] = useState(true);
  const [currentAnnouncement, setCurrentAnnouncement] = useState('');

  // Função para anunciar para leitores de tela
  const announce = (message: string) => {
    setCurrentAnnouncement(message);
    setTimeout(() => setCurrentAnnouncement(''), 1000);
  };

  // Detectar mudanças de foco para navegação por teclado
  useEffect(() => {
    const handleFocusChange = (e: FocusEvent) => {
      const target = e.target as HTMLElement;
      if (target?.tagName === 'A' || target?.tagName === 'BUTTON') {
        const label = target.getAttribute('aria-label') || target.textContent || '';
        if (label) {
          announce(`Navegando para: ${label}`);
        }
      }
    };

    document.addEventListener('focusin', handleFocusChange);
    return () => document.removeEventListener('focusin', handleFocusChange);
  }, []);

  // Detectar atalhos de teclado
  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      // Skip link
      if (e.key === 'Tab' && !e.shiftKey && e.target === document.body) {
        announce('Use Tab para navegar pelos elementos da página');
      }
      
      // Atalhos de acessibilidade
      if (e.ctrlKey) {
        switch (e.key) {
          case '+':
          case '=':
            e.preventDefault();
            announce('Aumentando tamanho da fonte');
            document.documentElement.style.fontSize = 'larger';
            break;
          case '-':
            e.preventDefault();
            announce('Diminuindo tamanho da fonte');
            document.documentElement.style.fontSize = 'smaller';
            break;
          case '0':
            e.preventDefault();
            announce('Restaurando tamanho padrão da fonte');
            document.documentElement.style.fontSize = '';
            break;
        }
      }
      
      // Esc para fechar modais/painéis
      if (e.key === 'Escape') {
        announce('Fechando painel ou modal');
      }
    };

    document.addEventListener('keydown', handleKeyPress);
    return () => document.removeEventListener('keydown', handleKeyPress);
  }, []);

  if (!isVisible) return null;

  return (
    <>
      {/* Região para anúncios de leitores de tela */}
      <div
        aria-live="polite"
        aria-atomic="true"
        className="sr-only"
        role="status"
      >
        {currentAnnouncement}
      </div>

      {/* Barra de status de acessibilidade */}
      <div className="fixed bottom-0 left-0 right-0 bg-gradient-to-r from-blue-600 to-purple-600 text-white text-sm py-2 px-4 z-40 border-t-4 border-yellow-400">
        <div className="flex items-center justify-between max-w-7xl mx-auto">
          <div className="flex items-center space-x-4">
            <span className="flex items-center">
              <span role="img" aria-label="Acessibilidade" className="mr-2">♿</span>
              Site Acessível WCAG 2.1 AA
            </span>
            
            <div className="hidden md:flex items-center space-x-4 text-xs">
              <span className="flex items-center">
                <kbd className="px-1 py-0.5 bg-white bg-opacity-20 rounded text-xs mr-1">Tab</kbd>
                Navegar
              </span>
              <span className="flex items-center">
                <kbd className="px-1 py-0.5 bg-white bg-opacity-20 rounded text-xs mr-1">Ctrl + +</kbd>
                Aumentar fonte
              </span>
              <span className="flex items-center">
                <kbd className="px-1 py-0.5 bg-white bg-opacity-20 rounded text-xs mr-1">Esc</kbd>
                Fechar
              </span>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <span className="text-xs opacity-90">Recursos de acessibilidade ativados</span>
            <button
              onClick={() => setIsVisible(false)}
              className="ml-2 text-white hover:text-yellow-200 focus:outline-none focus:ring-2 focus:ring-yellow-400 rounded-sm"
              aria-label="Fechar barra de status de acessibilidade"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        </div>
      </div>
    </>
  );
}
