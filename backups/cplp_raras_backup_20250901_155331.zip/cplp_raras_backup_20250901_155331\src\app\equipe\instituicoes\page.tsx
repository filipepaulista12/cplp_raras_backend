import Link from 'next/link';
import Image from 'next/image';
import { ArrowLeftIcon } from '@heroicons/react/24/outline';
import { getImageSrc } from '@/lib/imageUtils';
import TopShare from '@/components/TopShare';

const institutions = [
  {
    name: 'Universidade de São Paulo (USP)',
    country: 'Brasil',
    flag: '🇧🇷',
    logo: '/images/logo-usp.png',
    website: 'https://www.usp.br',
    type: 'Universidade Pública',
    founded: '1934',
    description: 'A Universidade de São Paulo é uma das mais prestigiadas instituições de ensino superior do Brasil e da América Latina. Reconhecida internacionalmente por sua excelência em pesquisa, ensino e extensão universitária.',
    relevantDepartments: [
      'Faculdade de Medicina de Ribeirão Preto (FMRP)',
      'Laboratório de Inteligência em Saúde (LIS)',
      'Departamento de Genética - Hospital das Clínicas de Ribeirão Preto de Ribeirão Preto Preto'
    ],
    researchAreas: ['Genética Médica', 'Bioinformática', 'Saúde Digital', 'Medicina Translacional'],
    stats: {
      students: '109.000+',
      faculty: '6.000+',
      publications: '20.000+ por ano'
    }
  },
  {
    name: 'Universidade Federal do Rio Grande do Sul (UFRGS)',
    country: 'Brasil',
    flag: '🇧🇷',
    logo: '/images/logo-ufrgs.png',
    website: 'https://www.ufrgs.br',
    type: 'Universidade Pública Federal',
    founded: '1934',
    description: 'A UFRGS é uma das principais universidades do sul do Brasil, reconhecida por sua excelência em ensino, pesquisa e extensão. Destaca-se especialmente nas áreas de saúde e ciências biológicas.',
    relevantDepartments: [
      'Faculdade de Medicina',
      'Instituto de Ciências Básicas da Saúde',
      'Programa de Pós-Graduação em Genética e Biologia Molecular'
    ],
    researchAreas: ['Genética Médica', 'Doenças Raras', 'Metabolismo', 'Pediatria'],
    stats: {
      students: '65.000+',
      faculty: '2.600+',
      publications: '8.000+ por ano'
    }
  },
   {
    name: 'Universidade de Brasília (UnB)',
    country: 'Brasil',
    flag: '🇧🇷',
    logo: '/images/logo-unb.svg',
    website: 'https://www.unb.br/',
    type: 'Universidade Pública',
    founded: '1962',
    description: 'A  UnB é uma instituição pública de ensino superior brasileira localizada em Brasília, no Distrito Federal. Fundada em 1962, a UnB é conhecida por sua excelência acadêmica, inovação e compromisso com a sociedade. Oferece uma ampla gama de cursos de graduação e pós-graduação em diversas áreas do conhecimento, além de desenvolver pesquisas e projetos de extensão que contribuem para o desenvolvimento do país.',
    relevantDepartments: [
      'Departamento de Saúde Coletiva',
    ],
    researchAreas: ['Epidemiologia', 'Saúde Coletiva', 'Biologia Molecular', 'Bioética'],
    stats: {
      students: '65.000+',
      faculty: '2.600+',
      publications: '8.000+ por ano'
    }
  },
  {
    name: 'Universidade do Porto (UP)',
    country: 'Portugal',
    flag: '🇵🇹',
    logo: '/images/Logofmup.jpg',
    website: 'https://www.up.pt',
    type: 'Universidade Pública',
    founded: '1911',
    description: 'A Universidade do Porto é uma das mais prestigiadas universidades portuguesas, reconhecida pela qualidade do ensino e investigação. A Faculdade de Medicina da UP tem tradição centenária na formação médica.',
    relevantDepartments: [
      'Faculdade de Medicina (FMUP)',
      'CINTESIS - Centro de Investigação em Tecnologias e Serviços de Saúde',
      'RISE - Rede de Investigação em Saúde'
    ],
    researchAreas: ['Medicina Clínica', 'Saúde Pública', 'Tecnologias em Saúde', 'Ciência de Dados'],
    stats: {
      students: '32.000+',
      faculty: '2.300+',
      publications: '6.000+ por ano'
    }
  },
  {
  "name": "Instituto de Engenharia de Sistemas e Computadores de Coimbra",
  "country": "Portugal",
  "flag": "🇵🇹",
  "logo": "/images/inescc.png",
  "website": "https://www.inescc.pt/",
  "type": "Unidade de I&D / Instituto privado sem fins lucrativos",
  "founded": "2002 (origem em Coimbra desde 1986 através de protocolo com INESC)",
  "description": "O INESC Coimbra é uma instituição privada sem fins lucrativos reconhecida de utilidade pública, afiliada à Universidade de Coimbra, ao INESC Holding e ao Instituto Politécnico de Leiria. Desenvolve investigação científica interdisciplinar, desenvolvimento tecnológico e transferência de conhecimento científico e técnico à sociedade, com foco em problemas complexos através de uma abordagem de sistemas de engenharia.",
  "relevantDepartments": [
    "Departamento de Engenharia Electrotécnica e Computadores (DEC)",
    "Departamento de Engenharia Civil (DCE)",
    "Departamento de Matemática",
    "Faculdade de Economia da Universidade de Coimbra"
  ],
  "researchAreas": [
   "Planeamento e Gestão de Redes de Comunicação",
    "Informação Geoespacial e Análise de Dados",
    "Ciência de Dados e Inteligência Artificial"],
  "stats": {
    "researchers": "100+ (incl. 59 investigadores integrados e 30 doutorandos)",
    "publications": "Centenas por ano",
    "projects": "Diversos projetos nacionais e internacionais em áreas interdisciplinares"
  }
},

  {
    name: 'Instituto Politécnico de Leiria',
    country: 'Portugal',
    flag: '🇵🇹',
    logo: '/images/logo-ipl.png',
    website: 'https://www.ipleiria.pt',
    type: 'Instituto Politécnico',
    founded: '1980',
    description: 'O Instituto Politécnico de Leiria é uma instituição de ensino superior público português, reconhecida pela qualidade do ensino e pela forte ligação ao tecido empresarial e à comunidade.',
    relevantDepartments: [
      'Escola Superior de Tecnologia e Gestão',
      'Centro de Investigação em Informática e Comunicações',
      'Laboratório de Sistemas de Informação'
    ],
    researchAreas: ['Sistemas de Informação', 'Tecnologias da Saúde', 'Gestão de Projetos', 'Engenharia de Software'],
    stats: {
      students: '12.000+',
      faculty: '700+',
      publications: '1.000+ por ano'
    }
  },
  {
  name: 'Instituto Superior de Engenharia do Porto (ISEP)',
  country: 'Portugal',
  flag: '🇵🇹',
  logo: '/images/Isep-logo.png',
  website: 'https://www.isep.ipp.pt',
  type: 'Instituto Politécnico',
  founded: '1852',
  description: 'O Instituto Superior de Engenharia do Porto é uma das mais prestigiadas escolas de engenharia de Portugal, integrando o Politécnico do Porto e destacando-se pela excelência no ensino, na investigação aplicada e na cooperação com a indústria.',
  relevantDepartments: [
    'Departamento de Engenharia Informática',
    'Departamento de Engenharia Eletrotécnica'
  ],
  researchAreas: ['Engenharia Informática', 'Robótica e Sistemas Autónomos', 'Ciência de Dados', 'Sistemas Ciberfísicos', 'Indústria 4.0'],
  stats: {
    students: '6.500+',
    faculty: '400+',
    publications: '500+ por ano'
  }
},

  {
    name: 'Universidade Mandume Ya Ndemufayo',
    country: 'Angola',
    flag: '🇦🇴',
    logo: '/images/logo-umn.jpg',
    website: 'https://umn.edu.ao/umn/',
    type: 'Universidade Pública',
    founded: '1974',
    description: 'A Universidade Mandume ya Ndemufayo (UMN) é uma universidade pública angolana, multicampi, sediada na cidade de Lubango. A universidade surgiu do desmembramento do campus Lubango da Universidade Agostinho Neto em meio as reformas no ensino superior angolano. Desempenha um papel fundamental na formação de recursos humanos qualificados para o desenvolvimento do país.',
    relevantDepartments: [
      'Faculdade de Medicina'
    ],
    researchAreas: ['Medicina Tropical', 'Saúde Pública', 'Informática Médica', 'Epidemiologia'],
    stats: {
      students: '40.000+',
      faculty: '1.500+',
      publications: '500+ por ano'
    }
  },
  {
  name: 'Ministério da Saúde Pública da Guiné-Bissau',
  country: 'Guiné-Bissau',
  flag: '🇬🇼',
  logo: '/images/logo-pnds-gb.jpg', 
  website: 'https://gov.gw/',
  type: 'Órgão Governamental',
  founded: '2000', 
  description: 'A Célula de Gestão do PNDS é o órgão central do Ministério da Saúde Pública da Guiné-Bissau responsável pelo planeamento, monitoramento e avaliação das políticas nacionais de saúde, com foco na integração de tecnologias digitais e melhoria da qualidade dos dados em saúde.',
  relevantDepartments: [
    'Sistema Nacional de Informação Sanitária',
    'Programa Nacional de Luta contra a Tuberculose',
    'Célula de Gestão do Plano Nacional de Desenvolvimento Sanitário (PNDS)'
  ],
  researchAreas: ['Gestão de Dados em Saúde', 'Planeamento Sanitário', 'Saúde Pública', 'Saúde Digital'],
  stats: {
    staff: '50+',
    projects: '10+ em andamento',}
},
   {
    name: 'Hospital Central de Maputo',
    country: 'Moçambique',
    flag: '🇲🇿',
    logo: '/images/logo-hcm.png',
    website: '#',
    type: 'Hospital de Referência',
    founded: '1976',
    description: 'O Hospital Central de Maputo é o principal hospital de referência de Moçambique, pioneiro na implementação de serviços especializados, incluindo o primeiro Serviço de Genética Médica do país.',
    relevantDepartments: [
      'Serviço de Genética Médica',
      'Serviço de Pediatria',
      'Departamento de Medicina Interna'
    ],
    researchAreas: ['Genética Médica', 'Pediatria Especializada', 'Medicina Interna', 'Cuidados Terciários'],
    stats: {
      beds: '1.500+',
      staff: '3.000+',
      patients: '500.000+ por ano'
    }
  },
  {
  name: 'Instituto Nacional de Estatística (INE)',
  country: 'Moçambique',
  flag: '🇲🇿',
  logo: '/images/logo-ine-mz.png', // sugestão: inserir ou criar logotipo baseado no site oficial
  website: 'https://www.ine.gov.mz/',
  type: 'Instituto Público de Estatística',
  founded: '1996',
  description: 'O Instituto Nacional de Estatística de Moçambique é o órgão responsável pela produção, análise e disseminação de estatísticas oficiais do país. Atua de forma transversal em diversas áreas, incluindo saúde, demografia, economia e educação, sendo essencial para o planejamento e a formulação de políticas públicas baseadas em evidências.',
  relevantDepartments: [
    'Direção de Estatísticas Demográficas, Vitais e Sociais',
    'Direção de Estatísticas Económicas',
    'Direção de Censos e Inquéritos'
  ],
  researchAreas: ['Demografia', 'Saúde Pública', 'Desenvolvimento Social', 'Ciência de Dados Estatísticos'],
  stats: {
    beds: 'N/A',
    staff: '400+',
    patients: 'População nacional abrangida por censos e inquéritos'
  }
}
];

const institutionTypes = [
  {
    type: 'Universidades Públicas',
    icon: '🏛️',
    count: institutions.filter(i => i.type.includes('Universidade')).length,
    description: 'Principais centros de ensino superior e pesquisa'
  },
  {
    type: 'Centros de Pesquisa',
    icon: '🔬',
    count: 3,
    description: 'Laboratórios e institutos especializados'
  },
  {
    type: 'Hospitais de Referência',
    icon: '🏥',
    count: institutions.filter(i => i.type.includes('Hospital')).length,
    description: 'Instituições de cuidado clínico especializado'
  },
  {
    type: 'Países Representados',
    icon: '🌍',
    count: [...new Set(institutions.map(i => i.country))].length,
    description: 'Países da CPLP com instituições parceiras'
  }
];

export default function Instituicoes() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Breadcrumb */}
      <div className="bg-white border-b">
        <div className="mx-auto max-w-7xl px-4 py-4 sm:px-6 lg:px-8">
          <div className="flex items-center space-x-2 text-sm">
            <Link 
              href="/"
              className="text-blue-600 hover:text-blue-800 transition-colors"
            >
              Início
            </Link>
            <span className="text-gray-400">/</span>
            <Link 
              href="/equipe"
              className="text-blue-600 hover:text-blue-800 transition-colors"
            >
              Equipe
            </Link>
            <span className="text-gray-400">/</span>
            <span className="text-gray-600">Instituições</span>
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        
        {/* Compartilhamento no topo */}
        <TopShare 
          title="Instituições CPLP-Raras"
          description="Instituições acadêmicas e de pesquisa participantes do projeto CPLP-Raras"
        />
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            🏛️ Instituições Parceiras
          </h1>
          <div className="w-32 h-1 bg-gradient-to-r from-orange-600 to-amber-600 mx-auto mb-8"></div>
          <p className="text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed">
            A rede CPLP-Raras é formada por instituições de excelência dos países de língua portuguesa. 
            Universidades, centros de pesquisa e hospitais de referência que juntos constituem uma 
            infraestrutura robusta para o avanço da pesquisa e cuidado em doenças raras.
          </p>
        </div>

        {/* Botão de Voltar */}
        <div className="mb-8">
          <Link 
            href="/equipe"
            className="inline-flex items-center text-orange-600 hover:text-orange-800 transition-colors font-medium"
          >
            <ArrowLeftIcon className="h-4 w-4 mr-2" />
            Voltar para Equipe Principal
          </Link>
        </div>

        {/* Estatísticas das Instituições */}
        <section className="mb-16">
          <div className="bg-white rounded-2xl shadow-lg p-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-8 text-center">
              📊 Nossa Rede Institucional
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {institutionTypes.map((item, index) => (
                <div key={index} className="bg-gradient-to-br from-orange-50 to-amber-100 border border-orange-200 rounded-xl p-6 text-center">
                  <div className="text-4xl mb-3">{item.icon}</div>
                  <div className="text-3xl font-bold text-orange-600 mb-2">{item.count}</div>
                  <h3 className="font-semibold text-gray-900 mb-2">{item.type}</h3>
                  <p className="text-sm text-gray-600">{item.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Lista de Instituições */}
        <section className="mb-16">
          <div className="space-y-8">
            {institutions.map((institution, index) => (
              <div key={index} className="bg-white rounded-2xl shadow-lg p-8 hover:shadow-xl transition-shadow">
                <div className="flex flex-col lg:flex-row lg:items-start lg:space-x-8">
                  {/* Logo e Informações Básicas */}
                  <div className="lg:w-1/3 mb-6 lg:mb-0">
                    <div className="flex items-center space-x-4 mb-4">
                      <div className="w-32 h-32 bg-gray-100 rounded-lg p-2 border-2 border-orange-200 flex items-center justify-center">
                        <Image 
                          src={getImageSrc(institution.logo)} 
                          alt={`Logo ${institution.name}`}
                          width={48}
                          height={48}
                          className="w-full h-full object-contain"
                        />
                      </div>
                      <div>
                        <div className="flex items-center space-x-2 mb-1">
                          <span className="text-2xl">{institution.flag}</span>
                          <span className="text-sm text-gray-500 bg-orange-100 px-2 py-1 rounded">{institution.type}</span>
                        </div>
                        <h3 className="text-xl font-bold text-gray-900">{institution.name}</h3>
                        <p className="text-sm text-gray-600">Fundada em {institution.founded}</p>
                      </div>
                    </div>
                    
                    <div className="space-y-3">
                      {Object.entries(institution.stats).map(([key, value]) => (
                        <div key={key} className="flex justify-between text-sm">
                          <span className="text-gray-600 capitalize">{key}:</span>
                          <span className="font-semibold text-orange-600">{value}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Descrição e Detalhes */}
                  <div className="lg:w-2/3">
                    <p className="text-gray-700 leading-relaxed mb-6">{institution.description}</p>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <h4 className="font-semibold text-gray-900 mb-3">Departamentos representados:</h4>
                        <ul className="space-y-2">
                          {institution.relevantDepartments.map((dept, i) => (
                            <li key={i} className="text-sm text-gray-600 flex items-start">
                              <span className="w-2 h-2 bg-orange-400 rounded-full mt-2 mr-2 flex-shrink-0"></span>
                              {dept}
                            </li>
                          ))}
                        </ul>
                      </div>
                      
                      <div>
                        <h4 className="font-semibold text-gray-900 mb-3">Áreas de Pesquisa:</h4>
                        <div className="flex flex-wrap gap-2">
                          {institution.researchAreas.map((area, i) => (
                            <span key={i} className="text-xs bg-orange-100 text-orange-700 px-2 py-1 rounded">
                              {area}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                    
                    {institution.website !== '#' && (
                      <div className="mt-6">
                        <a 
                          href={institution.website}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center text-orange-600 hover:text-orange-800 font-medium"
                        >
                          Visitar site oficial →
                        </a>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Call to Action */}
        <section>
          <div className="bg-gradient-to-r from-orange-600 to-amber-600 rounded-2xl p-8 text-white text-center">
            <h2 className="text-2xl md:text-3xl font-bold mb-4">
              🎓 Sua instituição quer participar?
            </h2>
            <p className="text-xl mb-2 opacity-90">
              Amplie a rede de colaboração científica em doenças raras
            </p>
            <p className="text-lg mb-6 opacity-90">
              Conecte sua universidade ou centro de pesquisa à rede CPLP-Raras.
            </p>
            <Link
              href="/contato"
              className="inline-block bg-white text-orange-600 px-8 py-3 rounded-lg font-semibold hover:bg-orange-50 transition-colors"
            >
              Converse conosco sobre adesão institucional
            </Link>
          </div>
        </section>
      </div>
    </div>
  );
}
