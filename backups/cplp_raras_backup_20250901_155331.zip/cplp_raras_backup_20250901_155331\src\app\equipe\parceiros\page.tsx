import Link from 'next/link';
import Image from 'next/image';
import { ArrowLeftIcon } from '@heroicons/react/24/outline';
import { getImageSrc } from '@/lib/imageUtils';
import TopShare from '@/components/TopShare';

const partners = [
  {
    name: 'Rede RARAS',
    type: 'Rede Nacional',
    country: 'Brasil',
    flag: '🇧🇷',
    logo: '/images/logoRaras.png',
    website: 'https://raras.org.br',
    description: 'Rede nacional de informações sobre doenças raras, que conecta pacientes, familiares, pesquisadores e profissionais de saúde no Brasil.',
    focus: ['Pesquisa colaborativa', 'Informações sobre doenças raras', 'Apoio a pacientes e famílias']
  },
  {
  name: 'Instituto Nacional de Doenças Raras (InRaRas)',
  type: 'Instituto Nacional de Ciência e Tecnologia',
  country: 'Brasil',
  flag: '🇧🇷',
  logo: '/images/inraras.webp',
  website: 'https://inraras.org.br/',
  description: 'O InRaRas é um instituto de referência criado para integrar e fortalecer ações de pesquisa, diagnóstico, formação e políticas públicas voltadas às doenças raras no Brasil, promovendo equidade no acesso ao cuidado e ao conhecimento.',
  focus: ['Pesquisa em doenças raras', 'Integração de redes de atenção', 'Formação de profissionais de saúde', 'Desenvolvimento de políticas públicas']
},
  {
    name: 'CINTESIS - Centro de Investigação em Tecnologias e Serviços de Saúde',
    type: 'Centro de Pesquisa',
    country: 'Portugal',
    flag: '🇵🇹',
    logo: '/images/cintesis-logo.png',
    website: 'https://cintesis.eu',
    description: 'Centro de investigação dedicado ao desenvolvimento de tecnologias e serviços de saúde inovadores.',
    focus: ['Tecnologias em saúde', 'Ciência de dados', 'Sistemas de informação']
  },
  {
    name: 'LIS - Laboratório de Inteligência em Saúde',
    type: 'Laboratório de Pesquisa',
    country: 'Brasil',
    flag: '🇧🇷',
    logo: '/images/logo-lis.svg',
    website: 'http://dgp.cnpq.br/dgp/espelhogrupo/794752',
    description: 'Laboratório da USP especializado em inteligência artificial aplicada à saúde e análise de dados biomédicos.',
    focus: ['Inteligência artificial', 'Análise de dados', 'Saúde digital']
  },
  {
    name: 'Ministério da Saúde do Brasil',
    type: 'Órgão Governamental',
    country: 'Brasil',
    flag: '🇧🇷',
    logo: '/images/logo-ms.svg',
    website: 'https://www.gov.br/saude',
    description: 'Órgão responsável pelas políticas públicas de saúde no Brasil, incluindo as diretrizes para doenças raras.',
    focus: ['Políticas públicas', 'Regulamentação', 'Saúde pública']
  }
];

const partnershipAreas = [
  {
    title: 'Pesquisa Colaborativa',
    icon: '🔬',
    description: 'Desenvolvimento conjunto de estudos e projetos de pesquisa em doenças raras'
  },
  {
    title: 'Capacitação',
    icon: '📚',
    description: 'Programas de formação e treinamento para profissionais de saúde'
  },
  {
    title: 'Políticas Públicas',
    icon: '🏛️',
    description: 'Elaboração de diretrizes e recomendações para políticas de saúde'
  },
  {
    title: 'Tecnologia',
    icon: '💻',
    description: 'Desenvolvimento de soluções tecnológicas e plataformas digitais'
  },
  {
    title: 'Intercâmbio',
    icon: '🌍',
    description: 'Programas de intercâmbio acadêmico e profissional entre países'
  },
  {
    title: 'Divulgação',
    icon: '📢',
    description: 'Ações de conscientização e divulgação científica sobre doenças raras'
  }
];

export default function Parceiros() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Breadcrumb */}
      <div className="bg-white border-b">
        <div className="mx-auto max-w-7xl px-4 py-4 sm:px-6 lg:px-8">
          <div className="flex items-center space-x-2 text-sm">
            <Link 
              href="/"
              className="text-blue-600 hover:text-blue-800 transition-colors"
            >
              Início
            </Link>
            <span className="text-gray-400">/</span>
            <Link 
              href="/equipe"
              className="text-blue-600 hover:text-blue-800 transition-colors"
            >
              Equipe
            </Link>
            <span className="text-gray-400">/</span>
            <span className="text-gray-600">Parceiros</span>
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        
        {/* Compartilhamento no topo */}
        <TopShare 
          title="Parceiros CPLP-Raras"
          description="Organizações parceiras e colaboradores do projeto CPLP-Raras"
        />
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            🏢 Parceiros Estratégicos
          </h1>
          <div className="w-32 h-1 bg-gradient-to-r from-purple-600 to-violet-600 mx-auto mb-8"></div>
          <p className="text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed">
            A CPLP-Raras conta com uma rede robusta de parceiros estratégicos que incluem instituições de ensino, 
            centros de pesquisa, sociedades científicas e órgãos governamentais. Juntos, trabalhamos para 
            fortalecer a pesquisa e o cuidado em doenças raras nos países de língua portuguesa.
          </p>
        </div>

        {/* Botão de Voltar */}
        <div className="mb-8">
          <Link 
            href="/equipe"
            className="inline-flex items-center text-purple-600 hover:text-purple-800 transition-colors font-medium"
          >
            <ArrowLeftIcon className="h-4 w-4 mr-2" />
            Voltar para Equipe Principal
          </Link>
        </div>

        {/* Lista de Parceiros */}
        <section className="mb-16">
          <div className="bg-white rounded-2xl shadow-lg p-8 md:p-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-8 text-center">
              Nossos Parceiros Principais
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {partners.map((partner, index) => (
                <div key={index} className="bg-gradient-to-br from-purple-50 to-violet-100 border border-purple-200 rounded-xl p-6 hover:shadow-lg transition-all duration-200">
                  <div className="flex items-start space-x-4 mb-4">
                    <div className="w-16 h-16 bg-white rounded-lg p-2 border-2 border-purple-200 flex items-center justify-center flex-shrink-0">
                      <Image 
                        src={getImageSrc(partner.logo)} 
                        alt={`Logo ${partner.name}`}
                        width={48}
                        height={48}
                        className="w-full h-full object-contain"
                      />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-2">
                        <span className="text-xl">{partner.flag}</span>
                        <span className="text-xs text-gray-500 bg-white px-2 py-1 rounded">{partner.type}</span>
                      </div>
                      <h3 className="font-bold text-gray-900 mb-1">{partner.name}</h3>
                      <p className="text-sm text-gray-600 mb-3">{partner.description}</p>
                      
                      <div className="mb-3">
                        <h4 className="text-xs font-semibold text-purple-600 mb-1">Áreas de Foco:</h4>
                        <div className="flex flex-wrap gap-1">
                          {partner.focus.map((area, i) => (
                            <span key={i} className="text-xs bg-purple-100 text-purple-600 px-2 py-1 rounded">
                              {area}
                            </span>
                          ))}
                        </div>
                      </div>
                      
                      <a 
                        href={partner.website}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center text-xs text-purple-600 hover:text-purple-800 font-medium"
                      >
                        Visitar site →
                      </a>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Áreas de Parceria */}
        <section className="mb-16">
          <div className="bg-white rounded-2xl shadow-lg p-8 md:p-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-8 text-center">
              🤝 Áreas de Colaboração
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {partnershipAreas.map((area, index) => (
                <div key={index} className="bg-gradient-to-br from-blue-50 to-purple-50 border border-blue-200 rounded-xl p-6 text-center hover:shadow-md transition-shadow">
                  <div className="text-4xl mb-4">{area.icon}</div>
                  <h3 className="font-semibold text-gray-900 mb-2">{area.title}</h3>
                  <p className="text-sm text-gray-600">{area.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Call to Action para Parcerias */}
        <section>
          <div className="bg-gradient-to-r from-purple-600 to-violet-600 rounded-2xl p-8 text-white text-center">
            <h2 className="text-2xl md:text-3xl font-bold mb-4">
              🌟 Interessado em se tornar um parceiro?
            </h2>
            <p className="text-xl mb-2 opacity-90">
              Sua instituição quer fazer parte da rede CPLP-Raras?
            </p>
            <p className="text-lg mb-6 opacity-90">
              Estabeleça conosco uma parceria estratégica para o avanço da pesquisa em doenças raras.
            </p>
            <Link
              href="/contato"
              className="inline-block bg-white text-purple-600 px-8 py-3 rounded-lg font-semibold hover:bg-purple-50 transition-colors"
            >
              Fale conosco sobre parcerias
            </Link>
          </div>
        </section>
      </div>
    </div>
  );
}
