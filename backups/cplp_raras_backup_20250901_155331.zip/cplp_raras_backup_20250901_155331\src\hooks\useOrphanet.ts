/**
 * 🪝 HOOKS ORPHANET - CPLP RARAS
 * 
 * Hooks personalizados para integrar dados Orphanet
 * com componentes React
 */

import { useState, useEffect, useCallback, useMemo } from 'react';
import {
  OrphanetDisease,
  DiseaseSearchParams,
  DiseaseSearchResult,
  DiseaseDetails,
  OrphanetStats,
  MedicalSpecialty,
  ApiResponse,
  ApiError
} from '../types/orphanet';

// Tipos para estados de loading
interface LoadingState {
  loading: boolean;
  error: string | null;
  success: boolean;
}

interface UseOrphanetSearchResult extends LoadingState {
  diseases: OrphanetDisease[];
  total: number;
  page: number;
  limit: number;
  hasNext: boolean;
  hasPrevious: boolean;
  search: (params: DiseaseSearchParams) => Promise<void>;
  reset: () => void;
}

interface UseDiseasDetailsResult extends LoadingState {
  disease: DiseaseDetails | null;
  refetch: () => Promise<void>;
}

interface UseOrphanetStatsResult extends LoadingState {
  stats: OrphanetStats | null;
  refetch: () => Promise<void>;
}

interface UseSpecialtiesResult extends LoadingState {
  specialties: MedicalSpecialty[];
  refetch: () => Promise<void>;
}

/**
 * Hook para busca de doenças Orphanet
 */
export function useOrphanetSearch(initialParams?: DiseaseSearchParams): UseOrphanetSearchResult {
  const [state, setState] = useState<LoadingState & DiseaseSearchResult>({
    loading: false,
    error: null,
    success: false,
    diseases: [],
    total: 0,
    page: 1,
    limit: 20,
    has_next: false,
    has_previous: false
  });

  const search = useCallback(async (params: DiseaseSearchParams) => {
    setState(prev => ({ ...prev, loading: true, error: null }));
    
    try {
      const searchParams = new URLSearchParams();
      
      // Adicionar parâmetros de busca
      Object.entries(params).forEach(([key, value]) => {
        if (value !== undefined && value !== null) {
          searchParams.append(key, value.toString());
        }
      });

      const response = await fetch(`/api/orphanet/diseases?${searchParams}`);
      const data: ApiResponse<DiseaseSearchResult> | ApiError = await response.json();

      if (!response.ok || !data.success) {
        throw new Error('error' in data ? data.error : 'Erro na busca de doenças');
      }

      if ('data' in data) {
        setState(prev => ({
          ...prev,
          loading: false,
          success: true,
          ...data.data,
          hasNext: data.data.has_next,
          hasPrevious: data.data.has_previous
        }));
      }

    } catch (error) {
      console.error('Erro na busca de doenças:', error);
      setState(prev => ({
        ...prev,
        loading: false,
        error: error instanceof Error ? error.message : 'Erro desconhecido',
        success: false
      }));
    }
  }, []);

  const reset = useCallback(() => {
    setState({
      loading: false,
      error: null,
      success: false,
      diseases: [],
      total: 0,
      page: 1,
      limit: 20,
      has_next: false,
      has_previous: false
    });
  }, []);

  // Busca inicial se parâmetros fornecidos
  useEffect(() => {
    if (initialParams) {
      search(initialParams);
    }
  }, [search, initialParams]);

  return {
    loading: state.loading,
    error: state.error,
    success: state.success,
    diseases: state.diseases,
    total: state.total,
    page: state.page,
    limit: state.limit,
    hasNext: state.has_next,
    hasPrevious: state.has_previous,
    search,
    reset
  };
}

/**
 * Hook para detalhes de uma doença específica
 */
export function useDiseaseDetails(orpha_code: number | null, language: 'en' | 'pt' = 'pt'): UseDiseasDetailsResult {
  const [state, setState] = useState<LoadingState & { disease: DiseaseDetails | null }>({
    loading: false,
    error: null,
    success: false,
    disease: null
  });

  const fetchDisease = useCallback(async () => {
    if (!orpha_code) return;

    setState(prev => ({ ...prev, loading: true, error: null }));

    try {
      const response = await fetch(`/api/orphanet/diseases/${orpha_code}?language=${language}`);
      const data: ApiResponse<DiseaseDetails> | ApiError = await response.json();

      if (!response.ok || !data.success) {
        throw new Error('error' in data ? data.error : 'Erro ao buscar detalhes da doença');
      }

      if ('data' in data) {
        setState(prev => ({
          ...prev,
          loading: false,
          success: true,
          disease: data.data
        }));
      }

    } catch (error) {
      console.error('Erro ao buscar detalhes da doença:', error);
      setState(prev => ({
        ...prev,
        loading: false,
        error: error instanceof Error ? error.message : 'Erro desconhecido',
        success: false
      }));
    }
  }, [orpha_code, language]);

  useEffect(() => {
    if (orpha_code) {
      fetchDisease();
    } else {
      setState({
        loading: false,
        error: null,
        success: false,
        disease: null
      });
    }
  }, [fetchDisease]);

  return {
    loading: state.loading,
    error: state.error,
    success: state.success,
    disease: state.disease,
    refetch: fetchDisease
  };
}

/**
 * Hook para estatísticas gerais Orphanet
 */
export function useOrphanetStats(): UseOrphanetStatsResult {
  const [state, setState] = useState<LoadingState & { stats: OrphanetStats | null }>({
    loading: false,
    error: null,
    success: false,
    stats: null
  });

  const fetchStats = useCallback(async () => {
    setState(prev => ({ ...prev, loading: true, error: null }));

    try {
      const response = await fetch('/api/orphanet/stats');
      const data: ApiResponse<OrphanetStats> | ApiError = await response.json();

      if (!response.ok || !data.success) {
        throw new Error('error' in data ? data.error : 'Erro ao buscar estatísticas');
      }

      if ('data' in data) {
        setState(prev => ({
          ...prev,
          loading: false,
          success: true,
          stats: data.data
        }));
      }

    } catch (error) {
      console.error('Erro ao buscar estatísticas:', error);
      setState(prev => ({
        ...prev,
        loading: false,
        error: error instanceof Error ? error.message : 'Erro desconhecido',
        success: false
      }));
    }
  }, []);

  useEffect(() => {
    fetchStats();
  }, [fetchStats]);

  return {
    loading: state.loading,
    error: state.error,
    success: state.success,
    stats: state.stats,
    refetch: fetchStats
  };
}

/**
 * Hook para especialidades médicas
 */
export function useSpecialties(language: 'en' | 'pt' = 'pt'): UseSpecialtiesResult {
  const [state, setState] = useState<LoadingState & { specialties: MedicalSpecialty[] }>({
    loading: false,
    error: null,
    success: false,
    specialties: []
  });

  const fetchSpecialties = useCallback(async () => {
    setState(prev => ({ ...prev, loading: true, error: null }));

    try {
      const response = await fetch(`/api/orphanet/specialties?language=${language}`);
      const data: ApiResponse<MedicalSpecialty[]> | ApiError = await response.json();

      if (!response.ok || !data.success) {
        throw new Error('error' in data ? data.error : 'Erro ao buscar especialidades');
      }

      if ('data' in data) {
        setState(prev => ({
          ...prev,
          loading: false,
          success: true,
          specialties: data.data
        }));
      }

    } catch (error) {
      console.error('Erro ao buscar especialidades:', error);
      setState(prev => ({
        ...prev,
        loading: false,
        error: error instanceof Error ? error.message : 'Erro desconhecido',
        success: false
      }));
    }
  }, [language]);

  useEffect(() => {
    fetchSpecialties();
  }, [fetchSpecialties]);

  return {
    loading: state.loading,
    error: state.error,
    success: state.success,
    specialties: state.specialties,
    refetch: fetchSpecialties
  };
}

/**
 * Hook para busca de texto com debounce
 */
export function useDebouncedOrphanetSearch(
  debounceMs: number = 500,
  defaultParams?: Partial<DiseaseSearchParams>
) {
  const [query, setQuery] = useState<string>('');
  const [debouncedQuery, setDebouncedQuery] = useState<string>('');

  // Debounce do termo de busca
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedQuery(query);
    }, debounceMs);

    return () => clearTimeout(timer);
  }, [query, debounceMs]);

  // Parâmetros de busca combinados
  const searchParams = useMemo(() => ({
    ...defaultParams,
    query: debouncedQuery.trim() || undefined
  }), [debouncedQuery, defaultParams]);

  // Hook de busca
  const searchResult = useOrphanetSearch(
    debouncedQuery.trim() ? searchParams : undefined
  );

  return {
    query,
    setQuery,
    debouncedQuery,
    ...searchResult
  };
}
