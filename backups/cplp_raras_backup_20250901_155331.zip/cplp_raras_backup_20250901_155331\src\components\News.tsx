export default function News() {
    /* 
  return (
   <section className="bg-gray-50 py-16">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            📰 Notícias
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-blue-600 to-green-600 mx-auto mb-8"></div>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Acompanhe as últimas novidades e atualizações do projeto CPLP-Raras.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-white rounded-lg p-6 shadow-md hover:shadow-lg transition-shadow">
            <div className="text-blue-600 text-sm font-semibold mb-2">
              PROJETO
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-3">
              Lançamento Oficial do CPLP-Raras
            </h3>
            <p className="text-gray-600 mb-4">
              O projeto CPLP-Raras foi oficialmente lançado com o objetivo de fortalecer 
              a cooperação entre os países lusófonos na área de doenças raras.
            </p>
            <Link
              href="/noticias"
              className="text-blue-600 font-semibold hover:text-blue-800 transition-colors"
            >
              Leia mais →
            </Link>
          </div>
          
          <div className="bg-white rounded-lg p-6 shadow-md hover:shadow-lg transition-shadow">
            <div className="text-green-600 text-sm font-semibold mb-2">
              PESQUISA
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-3">
              Primeiros Resultados do Mapeamento
            </h3>
            <p className="text-gray-600 mb-4">
              O GT1 apresenta os primeiros resultados do mapeamento de recursos e 
              iniciativas sobre doenças raras nos países da CPLP.
            </p>
            <Link
              href="/noticias"
              className="text-green-600 font-semibold hover:text-green-800 transition-colors"
            >
              Leia mais →
            </Link>
          </div>
          
          <div className="bg-white rounded-lg p-6 shadow-md hover:shadow-lg transition-shadow">
            <div className="text-purple-600 text-sm font-semibold mb-2">
              EVENTO
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-3">
              Webinar sobre Cooperação Científica
            </h3>
            <p className="text-gray-600 mb-4">
              Participe do webinar sobre cooperação científica em doenças raras 
              nos países da CPLP. Inscrições abertas.
            </p>
            <Link
              href="/eventos"
              className="text-purple-600 font-semibold hover:text-purple-800 transition-colors"
            >
              Saiba mais →
            </Link>
          </div>
        </div>
        
        <div className="text-center mt-12">
          <Link
            href="/noticias"
            className="bg-gradient-to-r from-blue-600 to-green-600 text-white px-8 py-3 rounded-lg font-semibold hover:opacity-90 transition-opacity"
          >
            Ver Todas as Notícias
          </Link>
        </div>
      </div>
    </section> 
  );
   */
}
