import Link from 'next/link';
import TopShare from '@/components/TopShare';

export default function Methodology() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Breadcrumb */}
      <div className="bg-white border-b">
        <div className="mx-auto max-w-7xl px-4 py-4 sm:px-6 lg:px-8">
          <nav className="flex" aria-label="Breadcrumb">
            <ol className="inline-flex items-center space-x-1 md:space-x-3">
              <li className="inline-flex items-center">
                <Link href="/" className="text-blue-600 hover:text-blue-800">
                  Início
                </Link>
              </li>
              <li>
                <div className="flex items-center">
                  <span className="mx-2 text-gray-400">/</span>
                  <Link href="/sobre" className="text-blue-600 hover:text-blue-800">
                    Sobre
                  </Link>
                </div>
              </li>
              <li aria-current="page">
                <div className="flex items-center">
                  <span className="mx-2 text-gray-400">/</span>
                  <span className="text-gray-500">Metodologia</span>
                </div>
              </li>
            </ol>
          </nav>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        
        {/* Compartilhamento no topo */}
        <TopShare 
          title="Metodologia CPLP-Raras"
          description="Metodologia de trabalho e abordagem científica do projeto CPLP-Raras"
        />
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            🔬 Metodologia e Abordagem
          </h1>
          <div className="w-32 h-1 bg-gradient-to-r from-blue-600 to-green-600 mx-auto mb-8"></div>
          <p className="text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed">
            O projeto adota uma abordagem de pesquisa-ação participativa, combinando rigor científico 
            com aplicabilidade prática.
          </p>
        </div>

        {/* Metodologia Principal */}
        <section className="mb-16">
          <div className="bg-white rounded-2xl shadow-lg p-8 md:p-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-8">
              📐 Abordagem Metodológica
            </h2>
            
            <div className="bg-blue-50 border-l-4 border-blue-600 p-6 mb-8">
              <p className="text-lg text-gray-700 leading-relaxed">
                O projeto adota uma abordagem de <strong>pesquisa-ação participativa</strong>, 
                combinando rigor científico com aplicabilidade prática. A metodologia integra 
                ferramentas tecnológicas avançadas e princípios de ciência aberta para maximizar 
                o impacto e a sustentabilidade dos resultados.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="bg-blue-100 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-4">
                  <span className="text-3xl">🔍</span>
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">Pesquisa-Ação</h3>
                <p className="text-gray-600">
                  Abordagem participativa que combina investigação científica com implementação prática.
                </p>
              </div>

              <div className="text-center">
                <div className="bg-green-100 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-4">
                  <span className="text-3xl">💻</span>
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">Tecnologia Avançada</h3>
                <p className="text-gray-600">
                  Utilização de ferramentas digitais modernas e plataformas colaborativas.
                </p>
              </div>

              <div className="text-center">
                <div className="bg-purple-100 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-4">
                  <span className="text-3xl">🌐</span>
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">Ciência Aberta</h3>
                <p className="text-gray-600">
                  Princípios FAIR para garantir findabilidade, acessibilidade e reutilização dos dados.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Fases do Projeto */}
        <section className="mb-16">
          <div className="bg-white rounded-2xl shadow-lg p-8 md:p-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-8">
              📊 Fases de Implementação
            </h2>
            
            <div className="space-y-8">
              <div className="flex items-start space-x-4">
                <div className="bg-blue-600 text-white rounded-full w-10 h-10 flex items-center justify-center font-bold flex-shrink-0">
                  1
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">Mapeamento e Diagnóstico</h3>
                  <p className="text-gray-600">
                    Levantamento sistemático de recursos, iniciativas e capacidades existentes 
                    nos países da CPLP relacionados às doenças raras.
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="bg-green-600 text-white rounded-full w-10 h-10 flex items-center justify-center font-bold flex-shrink-0">
                  2
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">Desenvolvimento de Plataformas</h3>
                  <p className="text-gray-600">
                    Criação e implementação de ferramentas digitais, incluindo sistemas REDCap 
                    e repositórios de dados seguindo padrões FAIR.
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="bg-purple-600 text-white rounded-full w-10 h-10 flex items-center justify-center font-bold flex-shrink-0">
                  3
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">Rede Colaborativa</h3>
                  <p className="text-gray-600">
                    Estabelecimento de conexões entre pesquisadores, instituições e profissionais 
                    de saúde para fortalecer a colaboração científica.
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="bg-orange-600 text-white rounded-full w-10 h-10 flex items-center justify-center font-bold flex-shrink-0">
                  4
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">Protocolos e Algoritmos</h3>
                  <p className="text-gray-600">
                    Desenvolvimento de diretrizes, protocolos de coleta de dados e algoritmos 
                    de análise baseados em evidências regionais.
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="bg-pink-600 text-white rounded-full w-10 h-10 flex items-center justify-center font-bold flex-shrink-0">
                  5
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">Conscientização e Capacitação</h3>
                  <p className="text-gray-600">
                    Ações educativas direcionadas a profissionais de saúde, população 
                    e comunidade acadêmica sobre doenças raras.
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="bg-teal-600 text-white rounded-full w-10 h-10 flex items-center justify-center font-bold flex-shrink-0">
                  6
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">Disseminação e Sustentabilidade</h3>
                  <p className="text-gray-600">
                    Comunicação de resultados, mobilização social e desenvolvimento de 
                    estratégias para continuidade das ações.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Princípios FAIR */}
        <section className="mb-16">
          <div className="bg-white rounded-2xl shadow-lg p-8 md:p-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-8">
              🎯 Princípios FAIR
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="text-center p-6 bg-blue-50 rounded-xl">
                <h3 className="text-xl font-semibold text-blue-900 mb-3">
                  <span className="block text-3xl mb-2">🔍</span>
                  Findable
                </h3>
                <p className="text-blue-700 text-sm">
                  Dados facilmente localizáveis através de metadados ricos e identificadores únicos.
                </p>
              </div>

              <div className="text-center p-6 bg-green-50 rounded-xl">
                <h3 className="text-xl font-semibold text-green-900 mb-3">
                  <span className="block text-3xl mb-2">🚪</span>
                  Accessible
                </h3>
                <p className="text-green-700 text-sm">
                  Acesso aberto aos dados através de protocolos padronizados e autenticação clara.
                </p>
              </div>

              <div className="text-center p-6 bg-purple-50 rounded-xl">
                <h3 className="text-xl font-semibold text-purple-900 mb-3">
                  <span className="block text-3xl mb-2">🔄</span>
                  Interoperable
                </h3>
                <p className="text-purple-700 text-sm">
                  Integração com outros dados através de vocabulários e formatos padronizados.
                </p>
              </div>

              <div className="text-center p-6 bg-orange-50 rounded-xl">
                <h3 className="text-xl font-semibold text-orange-900 mb-3">
                  <span className="block text-3xl mb-2">♻️</span>
                  Reusable
                </h3>
                <p className="text-orange-700 text-sm">
                  Dados bem documentados com licenças claras para reutilização futura.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Call to Action */}
        <section className="text-center">
          <div className="bg-gradient-to-r from-blue-600 to-green-600 rounded-2xl p-8 text-white">
            <h2 className="text-2xl font-bold mb-4">Colabore com Nossa Metodologia</h2>
            <p className="text-xl mb-6 opacity-90">
              Tem sugestões para aprimorar nossa abordagem metodológica?
            </p>
            <Link
              href="/contato"
              className="inline-block bg-white text-blue-600 px-8 py-3 rounded-lg font-semibold hover:bg-blue-50 transition-colors"
            >
              Entre em Contato
            </Link>
          </div>
        </section>
      </div>
    </div>
  );
}
