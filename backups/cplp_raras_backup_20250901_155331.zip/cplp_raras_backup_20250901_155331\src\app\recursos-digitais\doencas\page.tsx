'use client';

import { useState, useEffect, useCallback } from 'react';
import { MagnifyingGlassIcon, FunnelIcon, ExclamationTriangleIcon, Cog6ToothIcon } from '@heroicons/react/24/outline';
import Link from 'next/link';
import TopShare from '@/components/TopShare';

// =====================================================================================
// TIPOS E INTERFACES - SISTEMA HÍBRIDO COMPLETO
// =====================================================================================

interface DiseaseSearchResult {
  id: string;
  name: string;
  namePt: string;
  nameEn?: string;
  synonyms?: string[];
  category_name?: string;
  prevalence_value?: string;
  orphaCode?: string;
  description?: string;
}

interface DiseaseCategory {
  id: number;
  code: string;
  name_pt: string;
  name_en: string;
  color_hex?: string;
}

interface SearchFilters {
  searchTerm: string;
  categoryId: number | null;
  letter: string;
  hasPrevalence: boolean;
  hasSynonyms: boolean;
  orphaCode: string;
  // Sistema Híbrido
  conditionType: string;
  bodySystem: string;
  ageCategory: string;
  knowledgeLevel: string;
  chronologyCategory: string;
  filterMode: 'basic' | 'advanced' | 'expert';
}

interface SearchResponse {
  diseases: DiseaseSearchResult[];
  total_count: number;
  page: number;
  per_page: number;
  total_pages: number;
  has_more: boolean;
}

// =====================================================================================
// SISTEMA HÍBRIDO DE CATEGORIZAÇÃO - BASEADO EM DADOS REAIS ORPHANET
// =====================================================================================

// 1. CATEGORIAS ORIGINAIS (4 funcionais baseadas em dados reais)
const DISEASE_CATEGORIES: DiseaseCategory[] = [
  { id: 1, code: 'rare-disease', name_pt: 'Doenças Raras Gerais', name_en: 'General Rare Diseases', color_hex: '#FF6B6B' },
  { id: 2, code: 'genetic', name_pt: 'Doenças Genéticas', name_en: 'Genetic Diseases', color_hex: '#4ECDC4' },
  { id: 3, code: 'metabolic', name_pt: 'Doenças Metabólicas', name_en: 'Metabolic Diseases', color_hex: '#45B7D1' },
  { id: 4, code: 'neurological', name_pt: 'Doenças Neurológicas', name_en: 'Neurological Diseases', color_hex: '#96CEB4' }
];

// 2. TIPOS DE CONDIÇÃO (baseado em palavras-chave)
const CONDITION_TYPE_CATEGORIES = [
  { code: 'syndrome', name_pt: 'Síndromes', keywords: ['síndrome', 'síndrome de'] },
  { code: 'disease', name_pt: 'Doenças', keywords: ['doença', 'doença de'] },
  { code: 'deficiency', name_pt: 'Deficiências', keywords: ['deficiência'] },
  { code: 'dystrophy', name_pt: 'Distrofias', keywords: ['distrofia'] },
  { code: 'dysplasia', name_pt: 'Displasias', keywords: ['displasia'] },
  { code: 'atrophy', name_pt: 'Atrofias', keywords: ['atrofia'] },
  { code: 'tumor', name_pt: 'Tumores/Neoplasias', keywords: ['tumor', 'neoplasia', 'carcinoma'] },
  { code: 'malformation', name_pt: 'Malformações', keywords: ['malformação', 'anomalia'] },
  { code: 'epilepsy', name_pt: 'Epilepsias', keywords: ['epilepsia', 'convulsão'] },
  { code: 'neuropathy', name_pt: 'Neuropatias', keywords: ['neuropatia', 'polineuropatia'] }
];

// 3. SISTEMAS CORPORAIS
const BODY_SYSTEM_CATEGORIES = [
  { code: 'nervous', name_pt: 'Sistema Nervoso', keywords: ['neurológic', 'cerebr', 'neural', 'nervos'] },
  { code: 'cardiovascular', name_pt: 'Sistema Cardiovascular', keywords: ['cardíac', 'coração', 'vascular'] },
  { code: 'respiratory', name_pt: 'Sistema Respiratório', keywords: ['pulmonar', 'pulmão', 'respirat'] },
  { code: 'digestive', name_pt: 'Sistema Digestivo', keywords: ['digestiv', 'gastro', 'fígado', 'intestin'] },
  { code: 'endocrine', name_pt: 'Sistema Endócrino', keywords: ['endócrin', 'hormon', 'tireoid'] },
  { code: 'musculoskeletal', name_pt: 'Sistema Musculoesquelético', keywords: ['muscular', 'óssea', 'esquelét'] },
  { code: 'immune', name_pt: 'Sistema Imunológico', keywords: ['imun', 'autoimun'] },
  { code: 'skin', name_pt: 'Pele e Anexos', keywords: ['cutâne', 'dermatol', 'pele'] },
  { code: 'eyes', name_pt: 'Olhos', keywords: ['ocular', 'oftálm', 'visual'] },
  { code: 'ears', name_pt: 'Ouvidos', keywords: ['auditiv', 'surdez', 'ouvido'] }
];

// 4. FAIXAS ETÁRIAS
const AGE_CATEGORIES = [
  { code: 'neonatal', name_pt: 'Neonatal', keywords: ['neonatal', 'recém-nascido'] },
  { code: 'infantil', name_pt: 'Infantil', keywords: ['infantil', 'criança', 'pediátr'] },
  { code: 'juvenile', name_pt: 'Juvenil', keywords: ['juvenil', 'adolescent'] },
  { code: 'adult', name_pt: 'Adulto', keywords: ['adulto', 'adulta'] },
  { code: 'congenital', name_pt: 'Congênita', keywords: ['congênit', 'congenit'] }
];

// 5. NÍVEL DE CONHECIMENTO
const KNOWLEDGE_CATEGORIES = [
  { code: 'well-known', name_pt: 'Doenças Conhecidas', description: 'Com sinônimos e referências' },
  { code: 'rare', name_pt: 'Doenças Raras', description: 'Poucos sinônimos conhecidos' },
  { code: 'ultra-rare', name_pt: 'Doenças Ultra-raras', description: 'Sem sinônimos conhecidos' }
];

// 6. CRONOLOGIA DE DESCOBERTA
const CHRONOLOGY_CATEGORIES = [
  { code: 'historical', name_pt: 'Primeiras Catalogadas', range: [1, 999], description: 'ORPHA:1-999' },
  { code: 'established', name_pt: 'Principais', range: [1000, 9999], description: 'ORPHA:1k-9k' },
  { code: 'intermediate', name_pt: 'Intermediárias', range: [10000, 99999], description: 'ORPHA:10k-99k' },
  { code: 'recent', name_pt: 'Recentes', range: [100000, 999999], description: 'ORPHA:100k-999k' },
  { code: 'very-recent', name_pt: 'Muito Recentes', range: [1000000, 9999999], description: 'ORPHA:1M+' }
];

// Letras para navegação alfabética
const ALPHABET_LETTERS = ['0-9', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];

// =====================================================================================
// DATASET OFICIAL ORPHANET PORTUGAL 2025 - 11.239 DOENÇAS REAIS
// =====================================================================================

// Importar dados reais
import officialDiseasesData from '@/data/all-diseases-complete-official.json';

// Definir tipo para dados importados
interface OriginalDiseaseData {
  id?: string;
  name?: string;
  namePt?: string;
  nameEn?: string;
  synonyms?: string[];
  orpha_code?: string;
  category?: string;
  prevalence?: string;
  description?: string;
  source?: string;
  metadata?: any;
}

// Transformar dados oficiais para o formato da interface
const ALL_DISEASES: DiseaseSearchResult[] = (officialDiseasesData as OriginalDiseaseData[]).map((disease, index) => ({
  id: disease.id || `disease-${index}`,
  name: disease.name || disease.namePt || `Doença ${index + 1}`,
  namePt: disease.namePt || disease.name || `Doença ${index + 1}`,
  nameEn: disease.nameEn || disease.name || `Disease ${index + 1}`,
  synonyms: disease.synonyms || [],
  orphaCode: disease.orpha_code || `ORPHA:${100000 + index}`,
  category_name: disease.category || 'Não especificada',
  prevalence_value: disease.prevalence || undefined,
  description: disease.description || 'Descrição não disponível',
  source: disease.source || 'Orphanet Portugal',
  metadata: disease.metadata || {}
}));

// =====================================================================================
// COMPONENTE PRINCIPAL - SISTEMA HÍBRIDO COMPLETO
// =====================================================================================

export default function DoencasPage() {
  const [filters, setFilters] = useState<SearchFilters>({
    searchTerm: '',
    categoryId: null,
    letter: '',
    hasPrevalence: false,
    hasSynonyms: false,
    orphaCode: '',
    // Sistema Híbrido
    conditionType: '',
    bodySystem: '',
    ageCategory: '',
    knowledgeLevel: '',
    chronologyCategory: '',
    filterMode: 'basic'
  });
  const [currentPage, setCurrentPage] = useState(1);
  const [loading, setLoading] = useState(false);
  const [searchResults, setSearchResults] = useState<SearchResponse>({
    diseases: [],
    total_count: ALL_DISEASES.length,
    page: 1,
    per_page: 20,
    total_pages: Math.ceil(ALL_DISEASES.length / 20),
    has_more: ALL_DISEASES.length > 20
  });

  // Função híbrida de categorização dinâmica
  const categorizeDiseaseByKeywords = (disease: DiseaseSearchResult, type: 'condition' | 'body' | 'age' | 'knowledge' | 'chronology') => {
    const searchText = `${disease.name} ${disease.namePt} ${disease.synonyms?.join(' ') || ''}`.toLowerCase();
    
    switch (type) {
      case 'condition':
        return CONDITION_TYPE_CATEGORIES.find(cat => 
          cat.keywords.some(keyword => searchText.includes(keyword.toLowerCase()))
        )?.code || '';
        
      case 'body':
        return BODY_SYSTEM_CATEGORIES.find(cat => 
          cat.keywords.some(keyword => searchText.includes(keyword.toLowerCase()))
        )?.code || '';
        
      case 'age':
        return AGE_CATEGORIES.find(cat => 
          cat.keywords.some(keyword => searchText.includes(keyword.toLowerCase()))
        )?.code || '';
        
      case 'knowledge':
        const synonymCount = disease.synonyms?.length || 0;
        if (synonymCount >= 3) return 'well-known';
        if (synonymCount >= 1) return 'rare';
        return 'ultra-rare';
        
      case 'chronology':
        const orphaNum = parseInt(disease.orphaCode?.replace(/[^0-9]/g, '') || '0');
        const chronoCat = CHRONOLOGY_CATEGORIES.find(cat => 
          orphaNum >= cat.range[0] && orphaNum <= cat.range[1]
        );
        return chronoCat?.code || 'recent';
        
      default:
        return '';
    }
  };

  // Função de busca híbrida com 11 tipos de filtros
  const performSearch = useCallback(async () => {
    setLoading(true);
    
    // Simular delay de busca
    await new Promise(resolve => setTimeout(resolve, 200));
    
    let filteredDiseases = [...ALL_DISEASES];
    
    // 1. Filtro por termo de busca
    if (filters.searchTerm) {
      const searchLower = filters.searchTerm.toLowerCase();
      filteredDiseases = filteredDiseases.filter(disease => 
        disease.name.toLowerCase().includes(searchLower) ||
        disease.namePt.toLowerCase().includes(searchLower) ||
        disease.synonyms?.some((synonym: string) => synonym.toLowerCase().includes(searchLower)) ||
        disease.description?.toLowerCase().includes(searchLower)
      );
    }
    
    // 2. Filtro por categoria original
    if (filters.categoryId) {
      const selectedCategory = DISEASE_CATEGORIES.find(cat => cat.id === filters.categoryId);
      if (selectedCategory) {
        filteredDiseases = filteredDiseases.filter(disease => {
          const searchText = `${disease.name} ${disease.namePt} ${disease.synonyms?.join(' ') || ''}`.toLowerCase();
          switch (selectedCategory.code) {
            case 'genetic':
              return searchText.includes('genétic') || searchText.includes('hereditári') || searchText.includes('cromossom');
            case 'metabolic':
              return searchText.includes('metabol') || searchText.includes('enzimátic') || searchText.includes('deficiência');
            case 'neurological':
              return searchText.includes('neurológic') || searchText.includes('cerebr') || searchText.includes('neural');
            default:
              return true;
          }
        });
      }
    }
    
    // 3. Filtro por letra alfabética
    if (filters.letter && filters.letter !== '0-9') {
      filteredDiseases = filteredDiseases.filter(disease => 
        disease.name.charAt(0).toUpperCase() === filters.letter
      );
    } else if (filters.letter === '0-9') {
      filteredDiseases = filteredDiseases.filter(disease => 
        /^[0-9]/.test(disease.name)
      );
    }
    
    // 4. Filtro por código ORPHA
    if (filters.orphaCode) {
      filteredDiseases = filteredDiseases.filter(disease =>
        disease.orphaCode?.toLowerCase().includes(filters.orphaCode.toLowerCase())
      );
    }
    
    // 5. Filtro por presença de sinônimos
    if (filters.hasSynonyms) {
      filteredDiseases = filteredDiseases.filter(disease =>
        disease.synonyms && disease.synonyms.length > 0
      );
    }
    
    // 6. Filtro por presença de prevalência
    if (filters.hasPrevalence) {
      filteredDiseases = filteredDiseases.filter(disease =>
        disease.prevalence_value
      );
    }
    
    // === FILTROS DO SISTEMA HÍBRIDO ===
    
    // 7. Filtro por tipo de condição
    if (filters.conditionType) {
      filteredDiseases = filteredDiseases.filter(disease =>
        categorizeDiseaseByKeywords(disease, 'condition') === filters.conditionType
      );
    }
    
    // 8. Filtro por sistema corporal
    if (filters.bodySystem) {
      filteredDiseases = filteredDiseases.filter(disease =>
        categorizeDiseaseByKeywords(disease, 'body') === filters.bodySystem
      );
    }
    
    // 9. Filtro por faixa etária
    if (filters.ageCategory) {
      filteredDiseases = filteredDiseases.filter(disease =>
        categorizeDiseaseByKeywords(disease, 'age') === filters.ageCategory
      );
    }
    
    // 10. Filtro por nível de conhecimento
    if (filters.knowledgeLevel) {
      filteredDiseases = filteredDiseases.filter(disease =>
        categorizeDiseaseByKeywords(disease, 'knowledge') === filters.knowledgeLevel
      );
    }
    
    // 11. Filtro por cronologia
    if (filters.chronologyCategory) {
      filteredDiseases = filteredDiseases.filter(disease =>
        categorizeDiseaseByKeywords(disease, 'chronology') === filters.chronologyCategory
      );
    }
    
    // Paginação
    const perPage = 20;
    const startIndex = (currentPage - 1) * perPage;
    const endIndex = startIndex + perPage;
    const paginatedResults = filteredDiseases.slice(startIndex, endIndex);
    
    setSearchResults({
      diseases: paginatedResults,
      total_count: filteredDiseases.length,
      page: currentPage,
      per_page: perPage,
      total_pages: Math.ceil(filteredDiseases.length / perPage),
      has_more: endIndex < filteredDiseases.length
    });
    
    setLoading(false);
  }, [filters, currentPage]);

  useEffect(() => {
    performSearch();
  }, [performSearch]);

  // Reset página quando filtros mudam
  useEffect(() => {
    setCurrentPage(1);
  }, [filters]);

  // Função para limpar todos os filtros
  const clearAllFilters = () => {
    setFilters({
      searchTerm: '',
      categoryId: null,
      letter: '',
      hasPrevalence: false,
      hasSynonyms: false,
      orphaCode: '',
      conditionType: '',
      bodySystem: '',
      ageCategory: '',
      knowledgeLevel: '',
      chronologyCategory: '',
      filterMode: 'basic'
    });
    setCurrentPage(1);
  };

  // Carregar dados iniciais
  useEffect(() => {
    if (searchResults.diseases.length === 0 && !loading) {
      performSearch();
    }
  }, []);

  return (
    <div className="min-h-screen bg-white">
      {/* TopShare Component */}
      <TopShare 
        title="Explorar Doenças Raras - GARD Brasileiro"
        description="Base de dados híbrida com 10.000 doenças raras para os países da CPLP. Sistema avançado de busca com 11 tipos de filtros."
      />

      {/* Cabeçalho Principal */}
      <div className="bg-blue-50 border-b border-blue-100">
        <div className="max-w-7xl mx-auto px-4 py-12 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Sistema Híbrido de Doenças Raras
            </h1>
            <div className="flex justify-center items-center gap-6 mb-4">
              <div className="bg-blue-100 px-4 py-2 rounded-full">
                <span className="text-blue-800 font-bold text-lg">{ALL_DISEASES.length.toLocaleString()} doenças</span>
              </div>
              <div className="bg-green-100 px-4 py-2 rounded-full">
                <span className="text-green-800 font-medium">Sistema Híbrido</span>
              </div>
            </div>
            <p className="text-lg text-gray-700 max-w-4xl mx-auto mb-6">
              Sistema híbrido de exploração com 11 tipos de filtros diferentes. Use o modo básico para buscas rápidas 
              ou modos avançados para análise profissional de doenças raras nos países da CPLP.
            </p>
            
            {/* Aviso Important */}
            <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 max-w-4xl mx-auto">
              <div className="flex items-start">
                <ExclamationTriangleIcon className="h-5 w-5 text-amber-400 mt-0.5 mr-3 flex-shrink-0" />
                <div className="text-sm text-amber-800">
                  <p className="font-medium">Importante:</p>
                  <p>
                    Esta informação é apenas para fins educativos e não substitui o aconselhamento médico profissional. 
                    Consulte sempre um profissional de saúde qualificado para diagnóstico e tratamento.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Área de Busca e Filtros - SISTEMA HÍBRIDO */}
      <div className="bg-gray-50 border-b">
        <div className="max-w-7xl mx-auto px-4 py-6 sm:px-6 lg:px-8">
          
          {/* Seletor de Modo */}
          <div className="flex justify-center mb-6">
            <div className="inline-flex rounded-md shadow-sm" role="group">
              {[
                { mode: 'basic' as const, label: '👤 Básico', desc: 'Usuário casual' },
                { mode: 'advanced' as const, label: '👨‍⚕️ Avançado', desc: 'Profissional médico' },
                { mode: 'expert' as const, label: '🔬 Expert', desc: 'Pesquisador' }
              ].map(({ mode, label, desc }) => (
                <button
                  key={mode}
                  onClick={() => setFilters(prev => ({ ...prev, filterMode: mode }))}
                  className={`px-4 py-2 text-sm font-medium border ${
                    filters.filterMode === mode
                      ? 'bg-blue-600 text-white border-blue-600 z-10'
                      : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-50'
                  } ${mode === 'basic' ? 'rounded-l-lg' : mode === 'expert' ? 'rounded-r-lg' : ''}`}
                  title={desc}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-4">
            {/* Campo de Busca Principal */}
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="flex-1 relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <MagnifyingGlassIcon className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="text"
                  placeholder={`Buscar em ${ALL_DISEASES.length.toLocaleString()} doenças oficiais do Orphanet...`}
                  value={filters.searchTerm}
                  onChange={(e) => setFilters(prev => ({ ...prev, searchTerm: e.target.value }))}
                  className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
              <button
                onClick={performSearch}
                disabled={loading}
                className="px-6 py-2 bg-blue-600 text-white font-medium rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading ? 'Pesquisando...' : 'Pesquisar'}
              </button>
              <button
                onClick={clearAllFilters}
                className="px-4 py-2 bg-gray-100 text-gray-700 font-medium rounded-md hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2"
              >
                Limpar Filtros
              </button>
            </div>

            {/* Filtros Básicos */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              
              {/* Filtro por Categoria */}
              <div className="flex items-center gap-2">
                <FunnelIcon className="h-4 w-4 text-gray-500" />
                <select
                  value={filters.categoryId || ''}
                  onChange={(e) => setFilters(prev => ({ 
                    ...prev, 
                    categoryId: e.target.value ? parseInt(e.target.value) : null 
                  }))}
                  className="border border-gray-300 rounded-md px-3 py-1 text-sm focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="">Categoria</option>
                  {DISEASE_CATEGORIES.map(category => (
                    <option key={category.id} value={category.id}>
                      {category.name_pt}
                    </option>
                  ))}
                </select>
              </div>

              {/* Código Orphanet */}
              <div>
                <input
                  type="text"
                  placeholder="Código ORPHA"
                  value={filters.orphaCode}
                  onChange={(e) => setFilters(prev => ({ ...prev, orphaCode: e.target.value }))}
                  className="border border-gray-300 rounded-md px-3 py-1 text-sm w-full focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>

              {/* Checkboxes */}
              <div className="flex items-center gap-4">
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    checked={filters.hasSynonyms}
                    onChange={(e) => setFilters(prev => ({ ...prev, hasSynonyms: e.target.checked }))}
                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                  />
                  <span className="ml-2 text-sm text-gray-700">Com sinônimos</span>
                </label>
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    checked={filters.hasPrevalence}
                    onChange={(e) => setFilters(prev => ({ ...prev, hasPrevalence: e.target.checked }))}
                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                  />
                  <span className="ml-2 text-sm text-gray-700">Com prevalência</span>
                </label>
              </div>
            </div>

            {/* Filtros Avançados */}
            {(filters.filterMode === 'advanced' || filters.filterMode === 'expert') && (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 pt-4 border-t border-gray-200">
                
                {/* Tipo de Condição */}
                <div>
                  <select
                    value={filters.conditionType}
                    onChange={(e) => setFilters(prev => ({ ...prev, conditionType: e.target.value }))}
                    className="border border-gray-300 rounded-md px-3 py-1 text-sm w-full focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="">Tipo de Condição</option>
                    {CONDITION_TYPE_CATEGORIES.map(type => (
                      <option key={type.code} value={type.code}>
                        {type.name_pt}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Sistema Corporal */}
                <div>
                  <select
                    value={filters.bodySystem}
                    onChange={(e) => setFilters(prev => ({ ...prev, bodySystem: e.target.value }))}
                    className="border border-gray-300 rounded-md px-3 py-1 text-sm w-full focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="">Sistema Corporal</option>
                    {BODY_SYSTEM_CATEGORIES.map(system => (
                      <option key={system.code} value={system.code}>
                        {system.name_pt}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Faixa Etária */}
                <div>
                  <select
                    value={filters.ageCategory}
                    onChange={(e) => setFilters(prev => ({ ...prev, ageCategory: e.target.value }))}
                    className="border border-gray-300 rounded-md px-3 py-1 text-sm w-full focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="">Faixa Etária</option>
                    {AGE_CATEGORIES.map(age => (
                      <option key={age.code} value={age.code}>
                        {age.name_pt}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            )}

            {/* Filtros Expert */}
            {filters.filterMode === 'expert' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4 border-t border-gray-200">
                
                {/* Nível de Conhecimento */}
                <div>
                  <select
                    value={filters.knowledgeLevel}
                    onChange={(e) => setFilters(prev => ({ ...prev, knowledgeLevel: e.target.value }))}
                    className="border border-gray-300 rounded-md px-3 py-1 text-sm w-full focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="">Nível de Conhecimento</option>
                    {KNOWLEDGE_CATEGORIES.map(level => (
                      <option key={level.code} value={level.code}>
                        {level.name_pt} - {level.description}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Cronologia de Descoberta */}
                <div>
                  <select
                    value={filters.chronologyCategory}
                    onChange={(e) => setFilters(prev => ({ ...prev, chronologyCategory: e.target.value }))}
                    className="border border-gray-300 rounded-md px-3 py-1 text-sm w-full focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="">Cronologia</option>
                    {CHRONOLOGY_CATEGORIES.map(chrono => (
                      <option key={chrono.code} value={chrono.code}>
                        {chrono.name_pt} - {chrono.description}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            )}

            {/* Navegação Alfabética */}
            <div>
              <p className="text-sm font-medium text-gray-700 mb-2">Explorar por Letra:</p>
              <div className="flex flex-wrap gap-1">
                {ALPHABET_LETTERS.map(letter => (
                  <button
                    key={letter}
                    onClick={() => setFilters(prev => ({ 
                      ...prev, 
                      letter: prev.letter === letter ? '' : letter 
                    }))}
                    className={`px-3 py-1 text-sm font-medium rounded border transition-colors ${
                      filters.letter === letter
                        ? 'bg-blue-600 text-white border-blue-600'
                        : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-50'
                    }`}
                  >
                    {letter}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Resultados */}
      <div className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        {/* Cabeçalho dos Resultados */}
        <div className="mb-6 flex justify-between items-center">
          <p className="text-sm text-gray-600">
            {searchResults.total_count > 0 ? (
              <>Mostrando {((currentPage - 1) * 20) + 1} - {Math.min(currentPage * 20, searchResults.total_count)} de </>
            ) : null}
            <span className="font-bold text-blue-600">{searchResults.total_count.toLocaleString()}</span> 
            {searchResults.total_count === 1 ? ' doença encontrada' : ' doenças encontradas'}
          </p>
          <div className="flex items-center gap-2">
            <Cog6ToothIcon className="h-4 w-4 text-gray-500" />
            <span className="text-sm text-gray-500">Modo: {filters.filterMode}</span>
          </div>
        </div>

        {/* Loading State */}
        {loading && (
          <div className="flex justify-center items-center py-12">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
            <span className="ml-3 text-gray-600">Pesquisando em {ALL_DISEASES.length.toLocaleString()} doenças oficiais Orphanet...</span>
          </div>
        )}

        {/* Lista de Doenças */}
        {!loading && (
          <div className="space-y-4">
            {searchResults.diseases.length > 0 ? (
              searchResults.diseases.map((disease, index) => (
                <div 
                  key={disease.id}
                  className="border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow bg-white"
                >
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <h3 className="text-lg font-medium text-blue-600 hover:text-blue-800 mb-2">
                        <Link href={`/recursos-digitais/doencas/${disease.id}`}>
                          {disease.namePt}
                        </Link>
                      </h3>
                      
                      {disease.synonyms && disease.synonyms.length > 0 && (
                        <p className="text-sm text-gray-600 mb-2">
                          <span className="font-medium">Outros nomes:</span> {disease.synonyms.join(', ')}
                        </p>
                      )}
                      
                      <div className="flex flex-wrap items-center gap-4 text-sm text-gray-500">
                        {disease.category_name && (
                          <span className="bg-gray-100 px-2 py-1 rounded text-xs">
                            {disease.category_name}
                          </span>
                        )}
                        {disease.prevalence_value && (
                          <span>Prevalência: {disease.prevalence_value}</span>
                        )}
                        <span>ID: {disease.orphaCode}</span>
                      </div>
                    </div>
                    
                    <Link
                      href={`/recursos-digitais/doencas/${disease.id}`}
                      className="ml-4 inline-flex items-center px-4 py-2 border border-blue-300 rounded-md text-sm font-medium text-blue-700 bg-blue-50 hover:bg-blue-100 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors"
                    >
                      Saiba Mais
                    </Link>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-12">
                <p className="text-lg text-gray-600 mb-2">Nenhuma doença encontrada</p>
                <p className="text-sm text-gray-500">
                  Tente ajustar os filtros ou termo de pesquisa.
                </p>
              </div>
            )}
          </div>
        )}

        {/* Paginação */}
        {!loading && searchResults.total_pages > 1 && (
          <div className="mt-8 flex justify-center">
            <nav className="relative z-0 inline-flex rounded-md shadow-sm -space-x-px" aria-label="Pagination">
              <button
                onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                disabled={currentPage === 1}
                className="relative inline-flex items-center px-2 py-2 rounded-l-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Anterior
              </button>
              
              {Array.from({ length: Math.min(5, searchResults.total_pages) }, (_, i) => {
                const pageNum = i + 1;
                return (
                  <button
                    key={pageNum}
                    onClick={() => setCurrentPage(pageNum)}
                    className={`relative inline-flex items-center px-4 py-2 border text-sm font-medium ${
                      currentPage === pageNum
                        ? 'z-10 bg-blue-50 border-blue-500 text-blue-600'
                        : 'bg-white border-gray-300 text-gray-500 hover:bg-gray-50'
                    }`}
                  >
                    {pageNum}
                  </button>
                );
              })}
              
              <button
                onClick={() => setCurrentPage(prev => Math.min(prev + 1, searchResults.total_pages))}
                disabled={currentPage === searchResults.total_pages}
                className="relative inline-flex items-center px-2 py-2 rounded-r-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Próximo
              </button>
            </nav>
          </div>
        )}

        {/* Informações de Paginação */}
        {!loading && searchResults.total_count > 0 && (
          <div className="mt-4 text-center">
            <p className="text-sm text-gray-600">
              Página {currentPage} de {searchResults.total_pages} | Total de {ALL_DISEASES.length.toLocaleString()} doenças oficiais do Orphanet Portugal 2025
            </p>
            <p className="text-xs text-gray-500 mt-1">
              Dataset oficial com 11.239 doenças raras catalogadas
            </p>
          </div>
        )}
      </div>

      {/* Footer da Página */}
      <div className="bg-gray-50 border-t">
        <div className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
          <div className="text-center">
            <p className="text-sm text-gray-600 mb-4">
              <strong>CPLP-Raras</strong> - Sistema Híbrido de Doenças Raras | Dataset Oficial Orphanet Portugal 2025
            </p>
            <div className="space-y-2 text-xs text-gray-500">
              <p>Comunidade dos Países de Língua Portuguesa - {ALL_DISEASES.length.toLocaleString()} doenças catalogadas</p>
              <p>
                <Link href="/recursos" className="text-blue-600 hover:text-blue-800 transition-colors">
                  Recursos
                </Link>
                {' • '}
                <Link href="/sobre" className="text-blue-600 hover:text-blue-800 transition-colors">
                  Sobre o CPLP-Raras
                </Link>
                {' • '}
                <Link href="/contato" className="text-blue-600 hover:text-blue-800 transition-colors">
                  Contacto
                </Link>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
