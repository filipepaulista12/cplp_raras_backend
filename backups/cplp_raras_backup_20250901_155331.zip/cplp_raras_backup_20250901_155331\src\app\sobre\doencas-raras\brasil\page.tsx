import { Metadata } from 'next';
import { Card, CardContent } from "@/components/ui/card";
import Link from 'next/link';
import TopShare from '@/components/TopShare';

export const metadata: Metadata = {
  title: 'Doenças Raras no Brasil | CPLP-Raras',
  description: 'Situação das doenças raras no sistema de saúde brasileiro, políticas públicas e programas específicos.',
  keywords: 'doenças raras Brasil, SUS, política nacional, PCDT, medicamentos órfãos',
};

export default function DoencasRarasBrasilPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-yellow-50 to-blue-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        
        {/* Compartilhamento no topo */}
        <TopShare 
          title="Doenças Raras no Brasil"
          description="Situação das doenças raras no sistema de saúde brasileiro, políticas públicas e programas específicos"
        />
        
        {/* Breadcrumb */}
        <div className="mb-8 text-sm text-gray-600">
          <Link href="/sobre/doencas-raras" className="hover:text-blue-600">Doenças Raras</Link>
          <span className="mx-2">→</span>
          <span>Brasil</span>
        </div>

        {/* Header */}
        <div className="text-center mb-12">
          <div className="text-6xl mb-4">🇧🇷</div>
          <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-green-600 via-yellow-500 to-blue-600 bg-clip-text text-transparent mb-6">
            Doenças Raras no Brasil
          </h1>
          <p className="text-xl text-gray-700 leading-relaxed">
            Políticas públicas e ações do Sistema Único de Saúde (SUS)
          </p>
        </div>

        {/* Em Construção */}
        <Card className="mb-12 bg-gradient-to-r from-blue-100 to-green-100">
          <CardContent className="p-8 text-center">
            <div className="text-4xl mb-4">🚧</div>
            <h2 className="text-2xl font-bold mb-4 text-gray-800">Página em Construção</h2>
            <p className="text-gray-700 mb-6">
              Esta seção está sendo desenvolvida e conterá informações detalhadas sobre:
            </p>
            <div className="grid md:grid-cols-2 gap-4 text-left max-w-2xl mx-auto">
              <ul className="space-y-2 text-sm text-gray-600">
                <li>• Política Nacional de Atenção Integral às Pessoas com Doenças Raras</li>
                <li>• Protocolos Clínicos e Diretrizes Terapêuticas (PCDT)</li>
                <li>• Centros de Referência em Doenças Raras</li>
                <li>• Medicamentos disponíveis no SUS</li>
              </ul>
              <ul className="space-y-2 text-sm text-gray-600">
                <li>• Programa de Medicamentos Excepcionais</li>
                <li>• Rede de Cuidados à Pessoa com Deficiência</li>
                <li>• Triagem neonatal ampliada</li>
                <li>• Regulamentações da ANVISA</li>
              </ul>
            </div>
          </CardContent>
        </Card>

        {/* Link de retorno */}
        <div className="text-center">
          <Link 
            href="/sobre/doencas-raras" 
            className="inline-flex items-center text-blue-600 hover:text-blue-800 font-medium"
          >
            ← Voltar para Doenças Raras
          </Link>
        </div>

      </div>
    </div>
  );
}
