import Link from 'next/link';
import TopShare from '@/components/TopShare';
import Image from 'next/image';
import { getImageSrc } from '@/lib/imageUtils';

export default function GT5() {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white border-b">
        <div className="mx-auto max-w-7xl px-4 py-4 sm:px-6 lg:px-8">
          <nav className="flex" aria-label="Breadcrumb">
            <ol className="inline-flex items-center space-x-1 md:space-x-3">
              <li><Link href="/" className="text-blue-600 hover:text-blue-800">Início</Link></li>
              <li><div className="flex items-center"><span className="mx-2 text-gray-400">/</span><Link href="/grupos-trabalho" className="text-blue-600 hover:text-blue-800">Grupos de Trabalho</Link></div></li>
              <li aria-current="page"><div className="flex items-center"><span className="mx-2 text-gray-400">/</span><span className="text-gray-500">GT5 - Conscientização Social</span></div></li>
            </ol>
          </nav>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        
        {/* Compartilhamento no topo */}
        <TopShare 
          title="GT5 - Comunicação e Divulgação"
          description="Estratégias de comunicação e divulgação científica do projeto CPLP-Raras"
        />
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">🧠 GT5 – Conscientização e Engajamento Social</h1>
          <div className="w-32 h-1 bg-gradient-to-r from-pink-500 to-pink-600 mx-auto mb-8"></div>
          <p className="text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed">
            Criação e divulgação de ações educativas e participativas voltadas à população, profissionais de saúde e escolas.
          </p>
        </div>

        <section className="mb-16">
          <div className="bg-white rounded-2xl shadow-lg p-8 md:p-12">
            <div className="text-center mb-8">
              <Image src={getImageSrc("/images/GT5.png")} alt="GT5 - Conscientização Social" width={600} height={400} className="rounded-lg shadow-md mx-auto" />
            </div>
            
            <div className="bg-pink-50 border-l-4 border-pink-600 p-6">
              <p className="text-lg text-gray-700 leading-relaxed">
                O GT5 desenvolve estratégias de comunicação e educação para aumentar a consciência 
                sobre doenças raras, capacitar profissionais de saúde e promover o engajamento 
                social em todos os países da CPLP.
              </p>
            </div>
          </div>
        </section>

        <section className="text-center">
          <div className="bg-gradient-to-r from-pink-600 to-purple-600 rounded-2xl p-8 text-white">
            <h2 className="text-2xl font-bold mb-4">Educação e Conscientização</h2>
            <p className="text-xl mb-6 opacity-90">Materiais educativos e campanhas de conscientização.</p>
            <Link href="/eventos" className="inline-block bg-white text-pink-600 px-8 py-3 rounded-lg font-semibold hover:bg-pink-50 transition-colors">
              Ver Eventos Educativos
            </Link>
          </div>
        </section>
      </div>
    </div>
  );
}
