'use client'

import { useHPOStore } from '@/store/hpoStore'
import { useState, useRef } from 'react'
import type { HPOTerm } from '@/types/hpo'

export default function UploadPage() {
  const { setTerms, terms } = useHPOStore()
  const [uploadStatus, setUploadStatus] = useState<'idle' | 'uploading' | 'success' | 'error'>('idle')
  const [uploadMessage, setUploadMessage] = useState('')
  const [parsedTerms, setParsedTerms] = useState<HPOTerm[]>([])
  const [isPreviewMode, setIsPreviewMode] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)
  
  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return
    
    setUploadStatus('uploading')
    setUploadMessage('Processando arquivo...')
    
    try {
      const text = await file.text()
      
      if (file.name.endsWith('.json')) {
        await handleJSONUpload(text)
      } else if (file.name.endsWith('.owl') || file.name.endsWith('.obo')) {
        await handleOntologyUpload(text, file.name.endsWith('.owl') ? 'owl' : 'obo')
      } else if (file.name.endsWith('.tsv') || file.name.endsWith('.csv')) {
        await handleTSVUpload(text)
      } else {
        throw new Error('Formato de arquivo não suportado. Use JSON, OWL, OBO, TSV ou CSV.')
      }
      
    } catch (error) {
      setUploadStatus('error')
      setUploadMessage(error instanceof Error ? error.message : 'Erro desconhecido ao processar arquivo')
    }
  }
  
  const handleJSONUpload = async (text: string) => {
    try {
      const data = JSON.parse(text)
      
      // Verifica se tem a estrutura esperada
      if (data.terms && Array.isArray(data.terms)) {
        validateAndSetTerms(data.terms)
      } else if (Array.isArray(data)) {
        validateAndSetTerms(data)
      } else {
        throw new Error('Estrutura JSON inválida. Esperado: {terms: [...]} ou [...]')
      }
    } catch (error) {
      throw new Error('Erro ao analisar JSON: ' + (error instanceof Error ? error.message : 'Formato inválido'))
    }
  }
  
  const handleOntologyUpload = async (text: string, format: 'owl' | 'obo') => {
    const terms: HPOTerm[] = []
    
    if (format === 'obo') {
      // Parser básico para formato OBO
      const stanzas = text.split('\n\n').filter(stanza => stanza.trim().startsWith('[Term]'))
      
      for (const stanza of stanzas) {
        const lines = stanza.split('\n').filter(line => line.trim())
        const term: Partial<HPOTerm> = {}
        
        for (const line of lines) {
          if (line.startsWith('id: ')) {
            term.id = line.substring(4).trim()
          } else if (line.startsWith('name: ')) {
            term.label_en = line.substring(6).trim()
          } else if (line.startsWith('def: ')) {
            // Remove aspas e referências
            const def = line.substring(5).trim()
            term.definition_en = def.split('"')[1] || def
          } else if (line.startsWith('synonym: ')) {
            if (!term.synonyms_en) term.synonyms_en = []
            const synonym = line.substring(9).split('"')[1]
            if (synonym) term.synonyms_en.push(synonym)
          }
        }
        
        if (term.id && term.label_en) {
          terms.push({
            id: term.id,
            label_en: term.label_en,
            definition_en: term.definition_en || '',
            synonyms_en: term.synonyms_en || [],
            category: 'imported',
            last_updated: new Date().toISOString()
          })
        }
      }
    } else {
      // Parser básico para formato OWL (RDF/XML)
      // Implementação simplificada - em produção usar biblioteca XML proper
      const classMatches = text.match(/<owl:Class[^>]*rdf:about="[^"]*HP_\d+"[^>]*>/g) || []
      
      for (const classMatch of classMatches) {
        const idMatch = classMatch.match(/HP_\d+/)
        if (idMatch) {
          const id = 'HP:' + idMatch[0].substring(3)
          
          // Busca label após a classe
          const classIndex = text.indexOf(classMatch)
          const nextClassIndex = text.indexOf('<owl:Class', classIndex + 1)
          const classContent = text.substring(classIndex, nextClassIndex > 0 ? nextClassIndex : text.length)
          
          const labelMatch = classContent.match(/<rdfs:label[^>]*>([^<]+)<\/rdfs:label>/)
          if (labelMatch) {
            terms.push({
              id: id,
              label_en: labelMatch[1].trim(),
              definition_en: '',
              synonyms_en: [],
              category: 'imported',
              last_updated: new Date().toISOString()
            })
          }
        }
      }
    }
    
    if (terms.length === 0) {
      throw new Error(`Nenhum termo HPO válido encontrado no arquivo ${format.toUpperCase()}`)
    }
    
    validateAndSetTerms(terms)
  }
  
  const handleTSVUpload = async (text: string) => {
    const lines = text.split('\n').filter(line => line.trim())
    if (lines.length < 2) {
      throw new Error('Arquivo TSV deve ter pelo menos uma linha de cabeçalho e uma linha de dados')
    }
    
    const headers = lines[0].split('\t').map(h => h.trim())
    const terms: HPOTerm[] = []
    
    // Mapeia colunas esperadas
    const idIndex = headers.findIndex(h => h.toLowerCase().includes('id') || h.toLowerCase().includes('hp'))
    const labelIndex = headers.findIndex(h => h.toLowerCase().includes('label') || h.toLowerCase().includes('name'))
    const defIndex = headers.findIndex(h => h.toLowerCase().includes('def') || h.toLowerCase().includes('description'))
    
    if (idIndex === -1 || labelIndex === -1) {
      throw new Error('Arquivo TSV deve conter pelo menos colunas de ID e Label/Name')
    }
    
    for (let i = 1; i < lines.length; i++) {
      const columns = lines[i].split('\t')
      const id = columns[idIndex]?.trim()
      const label = columns[labelIndex]?.trim()
      
      if (id && label && id.match(/^HP:\d+$/)) {
        terms.push({
          id: id,
          label_en: label,
          definition_en: defIndex >= 0 ? (columns[defIndex]?.trim() || '') : '',
          synonyms_en: [],
          category: 'imported',
          last_updated: new Date().toISOString()
        })
      }
    }
    
    if (terms.length === 0) {
      throw new Error('Nenhum termo HPO válido encontrado no arquivo TSV')
    }
    
    validateAndSetTerms(terms)
  }
  
  const validateAndSetTerms = (newTerms: HPOTerm[]) => {
    // Validação básica
    const validTerms = newTerms.filter(term => 
      term.id && 
      term.id.match(/^HP:\d+$/) && 
      term.label_en &&
      term.label_en.trim().length > 0
    )
    
    if (validTerms.length === 0) {
      throw new Error('Nenhum termo válido encontrado no arquivo')
    }
    
    setParsedTerms(validTerms)
    setIsPreviewMode(true)
    setUploadStatus('success')
    setUploadMessage(`${validTerms.length} termos válidos encontrados. Revise antes de importar.`)
  }
  
  const confirmImport = () => {
    // Mescla com termos existentes, evitando duplicatas
    const existingIds = new Set(terms.map(t => t.id))
    const newTerms = parsedTerms.filter(t => !existingIds.has(t.id))
    const updatedTerms = parsedTerms.filter(t => existingIds.has(t.id))
    
    // Atualiza termos existentes e adiciona novos
    const finalTerms = [
      ...terms.map(existing => {
        const update = updatedTerms.find(u => u.id === existing.id)
        return update ? { ...existing, ...update, last_updated: new Date().toISOString() } : existing
      }),
      ...newTerms
    ]
    
    setTerms(finalTerms)
    setUploadStatus('success')
    setUploadMessage(`Importação concluída: ${newTerms.length} novos termos, ${updatedTerms.length} atualizados`)
    setIsPreviewMode(false)
    setParsedTerms([])
    
    // Reset do input
    if (fileInputRef.current) {
      fileInputRef.current.value = ''
    }
  }
  
  const cancelImport = () => {
    setIsPreviewMode(false)
    setParsedTerms([])
    setUploadStatus('idle')
    setUploadMessage('')
    
    if (fileInputRef.current) {
      fileInputRef.current.value = ''
    }
  }
  
  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">
          📤 Upload de Ontologia HPO
        </h1>
        <p className="text-gray-600">
          Importe termos HPO de arquivos OWL, OBO, JSON, TSV ou CSV para expandir a base de tradução.
        </p>
      </div>
      
      {!isPreviewMode ? (
        <>
          {/* Área de upload */}
          <div className="bg-white rounded-lg shadow-md border border-gray-200 p-8 mb-8">
            <div className="text-center">
              <div className="mx-auto h-12 w-12 text-gray-400 mb-4">
                📁
              </div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                Selecione um arquivo para importar
              </h3>
              <p className="text-sm text-gray-500 mb-6">
                Formatos suportados: OWL, OBO, JSON, TSV, CSV
              </p>
              
              <input
                ref={fileInputRef}
                type="file"
                accept=".owl,.obo,.json,.tsv,.csv"
                onChange={handleFileUpload}
                disabled={uploadStatus === 'uploading'}
                className="hidden"
                id="file-upload"
              />
              
              <label
                htmlFor="file-upload"
                className={`inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-white ${
                  uploadStatus === 'uploading' 
                    ? 'bg-gray-400 cursor-not-allowed' 
                    : 'bg-blue-600 hover:bg-blue-700 cursor-pointer'
                } transition-colors`}
              >
                {uploadStatus === 'uploading' ? 'Processando...' : 'Escolher Arquivo'}
              </label>
            </div>
            
            {uploadMessage && (
              <div className={`mt-6 p-4 rounded-md ${
                uploadStatus === 'error' 
                  ? 'bg-red-50 text-red-800 border border-red-200'
                  : uploadStatus === 'success'
                  ? 'bg-green-50 text-green-800 border border-green-200'
                  : 'bg-blue-50 text-blue-800 border border-blue-200'
              }`}>
                {uploadMessage}
              </div>
            )}
          </div>
          
          {/* Guia de formatos */}
          <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">
              📋 Formatos Suportados
            </h3>
            
            <div className="space-y-4">
              <div className="border-l-4 border-blue-500 pl-4">
                <h4 className="font-medium text-gray-900">OWL (Web Ontology Language)</h4>
                <p className="text-sm text-gray-600">Formato padrão da HPO. Arquivo XML com classes e propriedades.</p>
              </div>
              
              <div className="border-l-4 border-green-500 pl-4">
                <h4 className="font-medium text-gray-900">OBO (Open Biomedical Ontologies)</h4>
                <p className="text-sm text-gray-600">Formato texto estruturado com stanzas [Term].</p>
              </div>
              
              <div className="border-l-4 border-purple-500 pl-4">
                <h4 className="font-medium text-gray-900">JSON</h4>
                <p className="text-sm text-gray-600">
                  Estrutura: <code className="bg-gray-100 px-1 rounded">{`{"terms": [{"id": "HP:0000001", "label_en": "...", ...}]}`}</code>
                </p>
              </div>
              
              <div className="border-l-4 border-yellow-500 pl-4">
                <h4 className="font-medium text-gray-900">TSV/CSV</h4>
                <p className="text-sm text-gray-600">Colunas necessárias: ID (HP:XXXXXXX), Label/Name. Definição opcional.</p>
              </div>
            </div>
          </div>
        </>
      ) : (
        /* Modo de preview */
        <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-gray-900">
              🔍 Preview da Importação
            </h3>
            <div className="flex space-x-3">
              <button
                onClick={cancelImport}
                className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50"
              >
                Cancelar
              </button>
              <button
                onClick={confirmImport}
                className="px-4 py-2 text-sm font-medium text-white bg-green-600 border border-transparent rounded-md hover:bg-green-700"
              >
                Confirmar Importação
              </button>
            </div>
          </div>
          
          <div className="mb-6 p-4 bg-blue-50 rounded-md border border-blue-200">
            <p className="text-blue-800">
              <strong>{parsedTerms.length}</strong> termos encontrados. 
              <strong> {parsedTerms.filter(t => !terms.some(existing => existing.id === t.id)).length}</strong> novos,
              <strong> {parsedTerms.filter(t => terms.some(existing => existing.id === t.id)).length}</strong> serão atualizados.
            </p>
          </div>
          
          <div className="max-h-96 overflow-y-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50 sticky top-0">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    ID HPO
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Label (Inglês)
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Definição
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {parsedTerms.map((term, index) => {
                  const isExisting = terms.some(existing => existing.id === term.id)
                  return (
                    <tr key={term.id} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                          isExisting 
                            ? 'bg-yellow-100 text-yellow-800' 
                            : 'bg-green-100 text-green-800'
                        }`}>
                          {isExisting ? 'Atualizar' : 'Novo'}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                        {term.id}
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-900">
                        {term.label_en}
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-500">
                        {term.definition_en ? (
                          term.definition_en.length > 100 
                            ? term.definition_en.substring(0, 100) + '...'
                            : term.definition_en
                        ) : (
                          <span className="italic text-gray-400">Sem definição</span>
                        )}
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  )
}
