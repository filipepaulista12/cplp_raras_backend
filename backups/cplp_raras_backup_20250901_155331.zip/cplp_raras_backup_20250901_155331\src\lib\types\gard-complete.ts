// =====================================================================================
// TIPOS TYPESCRIPT PARA SISTEMA GARD BRASILEIRO COMPLETO
// Estrutura bilíngue com suporte a importação e tradução
// =====================================================================================

// =====================================================================================
// ENUMS E TIPOS BÁSICOS
// =====================================================================================

export type TranslationStatus = 'pending' | 'in_progress' | 'completed' | 'reviewed';
export type DataQuality = 'confirmed' | 'estimated' | 'unknown';
export type Availability = 'available' | 'limited' | 'unavailable';
export type OrganizationType = 'patient_association' | 'research_center' | 'hospital' | 'government';
export type CenterType = 'university_hospital' | 'specialized_clinic' | 'research_center';
export type ArticleType = 'case_report' | 'review' | 'clinical_trial' | 'cohort_study' | 'meta_analysis';
export type ResourceType = 'guide' | 'brochure' | 'video' | 'website' | 'app' | 'book';
export type ReadingLevel = 'basic' | 'intermediate' | 'advanced';
export type TargetAudience = 'patients' | 'families' | 'caregivers' | 'professionals';
export type TranslationMethod = 'ai_automatic' | 'ai_assisted' | 'human' | 'hybrid';

// Países CPLP
export type CPLPCountry = 'BRA' | 'PRT' | 'AGO' | 'CPV' | 'GNB' | 'GNQ' | 'MOZ' | 'STP' | 'TLS';

export const CPLP_COUNTRIES = {
  BRA: 'Brasil',
  PRT: 'Portugal', 
  AGO: 'Angola',
  CPV: 'Cabo Verde',
  GNB: 'Guiné-Bissau',
  GNQ: 'Guiné Equatorial',
  MOZ: 'Moçambique',
  STP: 'São Tomé e Príncipe',
  TLS: 'Timor-Leste'
} as const;

// =====================================================================================
// INTERFACE PRINCIPAL - DOENÇA
// =====================================================================================

export interface Disease {
  // Identificadores
  id: string;
  gard_br_id: string;
  gard_original_id?: string;
  
  // Nomenclatura bilíngue
  name_en: string;
  name_pt?: string;
  
  // Sinônimos
  synonyms_en: string[];
  synonyms_pt: string[];
  
  // Classificação
  category_en: string;
  category_pt?: string;
  
  // Códigos médicos
  orpha_code?: string;
  icd10_code?: string;
  icd11_code?: string;
  omim_code?: string;
  
  // Epidemiologia
  prevalence_en?: string;
  prevalence_pt?: string;
  inheritance_pattern_en?: string;
  inheritance_pattern_pt?: string;
  age_of_onset_en?: string;
  age_of_onset_pt?: string;
  
  // Status de tradução
  translation_status: TranslationStatus;
  translated_by?: string;
  reviewed_by?: string;
  
  // Metadados
  is_active: boolean;
  created_at: Date;
  updated_at: Date;
  last_reviewed_at?: Date;
  
  // Relações (quando populadas)
  content?: DiseaseContent;
  epidemiology_cplp?: DiseaseEpidemiologyCPLP[];
  support_organizations?: SupportOrganization[];
  clinical_trials?: ClinicalTrial[];
  scientific_articles?: ScientificArticle[];
  patient_resources?: PatientResource[];
}

// =====================================================================================
// CONTEÚDO DETALHADO DA DOENÇA
// =====================================================================================

export interface DiseaseContent {
  id: string;
  disease_id: string;
  
  // Resumo bilíngue
  summary_en?: string;
  summary_pt?: string;
  
  // Sintomas
  symptoms_en: string[];
  symptoms_pt: string[];
  
  // Causas e genética
  causes_en?: string;
  causes_pt?: string;
  genes_involved: string[];
  
  // Diagnóstico
  diagnosis_en?: string;
  diagnosis_pt?: string;
  diagnostic_methods: string[];
  
  // Tratamento
  treatment_en?: string;
  treatment_pt?: string;
  
  // Prognóstico
  prognosis_en?: string;
  prognosis_pt?: string;
  
  // Especialidades
  specialties: string[];
  
  // Metadados
  content_version: number;
  last_medical_review?: Date;
  medical_reviewer?: string;
  created_at: Date;
  updated_at: Date;
}

// =====================================================================================
// EPIDEMIOLOGIA POR PAÍS CPLP
// =====================================================================================

export interface DiseaseEpidemiologyCPLP {
  id: string;
  disease_id: string;
  
  // País
  country_code: CPLPCountry;
  country_name: string;
  
  // Dados epidemiológicos
  prevalence_local?: string;
  incidence_local?: string;
  carrier_frequency?: number;
  
  // Fatores regionais
  genetic_variants: string[];
  environmental_factors: string[];
  
  // Disponibilidade de recursos
  diagnostic_availability: Availability;
  treatment_availability: Availability;
  specialist_availability: Availability;
  
  // Políticas de saúde
  covered_by_public_health: boolean;
  orphan_drug_policy?: string;
  
  // Qualidade dos dados
  data_source?: string;
  data_quality: DataQuality;
  last_updated: Date;
}

// =====================================================================================
// ORGANIZAÇÕES DE APOIO
// =====================================================================================

export interface SupportOrganization {
  id: string;
  disease_id: string;
  
  // Informações básicas
  name: string;
  name_local?: string;
  
  // Localização
  country_code: CPLPCountry;
  city?: string;
  region?: string;
  
  // Tipo
  organization_type: OrganizationType;
  
  // Contacto
  website?: string;
  email?: string;
  phone?: string;
  address?: string;
  
  // Serviços
  services_offered: string[];
  languages_supported: string[];
  
  // Status
  is_active: boolean;
  verified: boolean;
  last_verified?: Date;
  created_at: Date;
  updated_at: Date;
}

// =====================================================================================
// ENSAIOS CLÍNICOS
// =====================================================================================

export interface ClinicalTrial {
  id: string;
  disease_id: string;
  
  // Identificadores
  clinicaltrials_gov_id?: string;
  eudract_number?: string;
  rebec_id?: string;
  
  // Informações básicas
  title_en: string;
  title_pt?: string;
  brief_summary_en?: string;
  brief_summary_pt?: string;
  
  // Status
  phase?: string;
  status?: string;
  start_date?: Date;
  completion_date?: Date;
  
  // Localização
  countries: CPLPCountry[];
  cities_cplp: string[];
  principal_investigator?: string;
  
  // Critérios
  min_age?: number;
  max_age?: number;
  gender?: 'male' | 'female' | 'all';
  
  // Contacto
  contact_name?: string;
  contact_email?: string;
  contact_phone?: string;
  
  // URLs
  clinicaltrials_url?: string;
  local_contact_url?: string;
  
  created_at: Date;
  updated_at: Date;
}

// =====================================================================================
// ARTIGOS CIENTÍFICOS
// =====================================================================================

export interface ScientificArticle {
  id: string;
  disease_id: string;
  
  // Identificadores
  pmid?: string;
  doi?: string;
  pmc_id?: string;
  
  // Informações bibliográficas
  title: string;
  authors: string;
  journal?: string;
  publication_year?: number;
  volume?: string;
  issue?: string;
  pages?: string;
  
  // Tipo e relevância
  article_type?: ArticleType;
  relevance_score: number; // 1-10
  language: string;
  
  // Resumos
  abstract_en?: string;
  abstract_pt?: string;
  keywords: string[];
  
  // Relevância CPLP
  cplp_relevance: boolean;
  cplp_countries: CPLPCountry[];
  cplp_specific_findings?: string;
  
  // Status
  is_open_access: boolean;
  pdf_available: boolean;
  quality_checked: boolean;
  
  created_at: Date;
  updated_at: Date;
}

// =====================================================================================
// RECURSOS PARA PACIENTES
// =====================================================================================

export interface PatientResource {
  id: string;
  disease_id: string;
  
  // Informações básicas
  title: string;
  description?: string;
  resource_type: ResourceType;
  
  // Idioma e adaptação
  language: string;
  country_adaptation?: CPLPCountry;
  reading_level?: ReadingLevel;
  
  // Fonte
  organization?: string;
  author?: string;
  publication_date?: Date;
  last_reviewed?: Date;
  
  // Acesso
  url?: string;
  download_url?: string;
  is_free: boolean;
  requires_registration: boolean;
  
  // Qualidade
  medical_reviewed: boolean;
  reviewed_by?: string;
  quality_rating?: number; // 1-5
  
  // Utilidade
  target_audience: TargetAudience[];
  topics_covered: string[];
  
  created_at: Date;
  updated_at: Date;
}

// =====================================================================================
// CENTROS ESPECIALIZADOS
// =====================================================================================

export interface SpecialistCenter {
  id: string;
  
  // Informações básicas
  name: string;
  institution?: string;
  
  // Localização
  country_code: CPLPCountry;
  state_province?: string;
  city?: string;
  address?: string;
  
  // Tipo
  center_type: CenterType;
  specialties: string[];
  
  // Contacto
  website?: string;
  email?: string;
  phone?: string;
  
  // Serviços
  diagnostic_services: string[];
  treatment_services: string[];
  research_activities: string[];
  
  // Qualificações
  certifications: string[];
  is_reference_center: boolean;
  government_recognized: boolean;
  
  // Doenças atendidas
  diseases_treated: string[]; // Array de disease IDs
  
  // Status
  is_active: boolean;
  accepts_new_patients: boolean;
  public_healthcare: boolean;
  private_healthcare: boolean;
  
  created_at: Date;
  updated_at: Date;
}

// =====================================================================================
// CATEGORIAS DE DOENÇAS
// =====================================================================================

export interface DiseaseCategory {
  id: string;
  
  // Nomes bilíngues
  name_en: string;
  name_pt: string;
  
  // Hierarquia
  parent_category_id?: string;
  level: number;
  sort_order: number;
  
  // Descrições
  description_en?: string;
  description_pt?: string;
  
  // Metadados
  disease_count: number;
  is_active: boolean;
  
  // Relações
  subcategories?: DiseaseCategory[];
  parent_category?: DiseaseCategory;
  
  created_at: Date;
  updated_at: Date;
}

// =====================================================================================
// HISTÓRICO DE TRADUÇÃO
// =====================================================================================

export interface TranslationHistory {
  id: string;
  disease_id: string;
  
  // Detalhes da tradução
  field_name: string;
  original_text_en?: string;
  translated_text_pt?: string;
  
  // Método
  translation_method: TranslationMethod;
  translator_id?: string;
  ai_model_used?: string;
  
  // Qualidade
  confidence_score?: number; // 0.0 to 1.0
  human_reviewed: boolean;
  medical_reviewed: boolean;
  approved: boolean;
  
  // Feedback
  feedback?: string;
  corrections?: string;
  
  created_at: Date;
}

// =====================================================================================
// TIPOS PARA IMPORTAÇÃO DE DADOS GARD
// =====================================================================================

export interface GARDImportData {
  gard_id: string;
  name: string;
  synonyms: string[];
  definition?: string;
  symptoms?: string[];
  causes?: string;
  inheritance?: string;
  prevalence?: string;
  age_of_onset?: string;
  icd10_codes?: string[];
  orpha_code?: string;
  omim_codes?: string[];
  category: string;
  sources?: string[];
  last_updated?: string;
}

// =====================================================================================
// TIPOS PARA BUSCA E FILTROS
// =====================================================================================

export interface DiseaseSearchFilters {
  query?: string;
  category?: string;
  country?: CPLPCountry;
  translation_status?: TranslationStatus;
  has_treatment?: boolean;
  has_clinical_trials?: boolean;
  inheritance_pattern?: string;
  prevalence_range?: 'very_rare' | 'rare' | 'uncommon';
  language?: 'en' | 'pt';
  page?: number;
  limit?: number;
  sort_by?: 'name' | 'prevalence' | 'updated_at';
  sort_order?: 'asc' | 'desc';
}

export interface DiseaseSearchResult {
  diseases: Disease[];
  total_count: number;
  page: number;
  total_pages: number;
  filters_applied: DiseaseSearchFilters;
  suggestion?: string; // Para correção de busca
}

// =====================================================================================
// TIPOS PARA ESTATÍSTICAS
// =====================================================================================

export interface TranslationStats {
  translation_status: TranslationStatus;
  disease_count: number;
  percentage: number;
}

export interface CountryStats {
  country_code: CPLPCountry;
  country_name: string;
  disease_count: number;
  support_organizations: number;
  specialist_centers: number;
}

export interface SystemStats {
  total_diseases: number;
  translated_diseases: number;
  translation_progress: number;
  total_countries: number;
  total_specialists: number;
  total_trials: number;
  last_updated: Date;
}

// =====================================================================================
// TIPOS PARA API
// =====================================================================================

export interface APIResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
  metadata?: {
    total_count?: number;
    page?: number;
    limit?: number;
    execution_time_ms?: number;
  };
}

export interface BulkImportRequest {
  diseases: GARDImportData[];
  translation_settings?: {
    auto_translate: boolean;
    target_language: 'pt-BR' | 'pt-PT';
    ai_model: string;
    require_review: boolean;
  };
  source: 'gard_nih' | 'orpha' | 'manual';
  imported_by: string;
}

export interface TranslationRequest {
  disease_ids: string[];
  fields: string[];
  method: TranslationMethod;
  target_language: 'pt-BR' | 'pt-PT';
  ai_model?: string;
  priority: 'low' | 'normal' | 'high';
  requested_by: string;
}

// =====================================================================================
// TIPOS PARA COMPONENTES REACT
// =====================================================================================

export interface DiseaseCardProps {
  disease: Disease;
  showTranslationStatus?: boolean;
  showCPLPData?: boolean;
  compact?: boolean;
  language: 'en' | 'pt';
}

export interface DiseaseDetailProps {
  disease: Disease;
  content?: DiseaseContent;
  epidemiology?: DiseaseEpidemiologyCPLP[];
  language: 'en' | 'pt';
  showEditControls?: boolean;
}

export interface SearchFiltersProps {
  filters: DiseaseSearchFilters;
  onFiltersChange: (filters: DiseaseSearchFilters) => void;
  categories: DiseaseCategory[];
  countries: CPLPCountry[];
}

// =====================================================================================
// VALIDAÇÃO ZOD (Schema de Validação)
// =====================================================================================

export const DiseaseSchema = {
  // Schema será implementado usando Zod para validação
  // Incluindo validação de códigos médicos, formatos de dados, etc.
};

// =====================================================================================
// CONSTANTES
// =====================================================================================

export const DISEASE_CATEGORIES_EN = [
  'Birth defects',
  'Blood diseases', 
  'Cancer',
  'Endocrine diseases',
  'Gastrointestinal diseases',
  'Genetic diseases',
  'Infectious diseases',
  'Kidney diseases',
  'Neurological diseases',
  'Respiratory diseases',
  'Skin diseases',
  'Urinary and reproductive diseases'
] as const;

export const DISEASE_CATEGORIES_PT = [
  'Defeitos congênitos',
  'Doenças do sangue',
  'Cancro',
  'Doenças endócrinas', 
  'Doenças gastrointestinais',
  'Doenças genéticas',
  'Doenças infecciosas',
  'Doenças renais',
  'Doenças neurológicas',
  'Doenças respiratórias',
  'Doenças da pele',
  'Doenças urinárias e reprodutivas'
] as const;

export const INHERITANCE_PATTERNS = [
  'Autosomal dominant',
  'Autosomal recessive', 
  'X-linked dominant',
  'X-linked recessive',
  'Mitochondrial',
  'Multifactorial',
  'Unknown'
] as const;

export const INHERITANCE_PATTERNS_PT = [
  'Autossómica dominante',
  'Autossómica recessiva',
  'Ligada ao X dominante', 
  'Ligada ao X recessiva',
  'Mitocondrial',
  'Multifatorial',
  'Desconhecido'
] as const;

// =====================================================================================
// FINALIZAÇÃO DOS TIPOS
// =====================================================================================

// Todos os tipos já são exportados individualmente acima
// Este arquivo define a estrutura completa para o sistema GARD brasileiro
