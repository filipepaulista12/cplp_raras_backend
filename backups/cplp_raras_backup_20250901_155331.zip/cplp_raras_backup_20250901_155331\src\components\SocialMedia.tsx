interface SocialMediaProps {
  variant?: 'default' | 'compact' | 'hero';
  showLabels?: boolean;
  className?: string;
}

export default function SocialMedia({ 
  variant = 'default', 
  showLabels = true, 
  className = '' 
}: SocialMediaProps) {
  const socialLinks = [
    {
      name: 'Instagram',
      handle: '@rarasporti',
      url: 'https://instagram.com/rarasporti',
      icon: (
        <svg className="w-full h-full" fill="currentColor" viewBox="0 0 24 24">
          <path d="M12.017 0C5.396 0 .029 5.367.029 11.987c0 6.621 5.367 11.988 11.988 11.988s11.987-5.367 11.987-11.988C24.004 5.367 18.637.001 12.017.001zm3.94 6.994c.318 0 .576.258.576.576v1.44c0 .318-.258.576-.576.576h-1.44c-.318 0-.576-.258-.576-.576v-1.44c0-.318.258-.576.576-.576h1.44zm-2.957 2.88c1.512 0 2.737 1.225 2.737 2.737s-1.225 2.737-2.737 2.737-2.737-1.225-2.737-2.737 1.225-2.737 2.737-2.737zm4.32-5.76H6.68c-.792 0-1.44.648-1.44 1.44v10.08c0 .792.648 1.44 1.44 1.44h10.08c.792 0 1.44-.648 1.44-1.44V5.554c0-.792-.648-1.44-1.44-1.44z"/>
        </svg>
      ),
      gradient: 'from-pink-500 to-purple-600',
      hoverGradient: 'hover:from-pink-600 hover:to-purple-700'
    },
    {
      name: 'Facebook',
      handle: 'CPLP-Raras',
      url: 'https://www.facebook.com/profile.php?id=61578726425301',
      icon: (
        <svg className="w-full h-full" fill="currentColor" viewBox="0 0 24 24">
          <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
        </svg>
      ),
      gradient: 'from-blue-500 to-blue-600',
      hoverGradient: 'hover:from-blue-600 hover:to-blue-700'
    }
  ];

  if (variant === 'compact') {
    return (
      <div className={`flex space-x-2 ${className}`}>
        {socialLinks.map((social) => (
          <a
            key={social.name}
            href={social.url}
            target="_blank"
            rel="noopener noreferrer"
            className={`w-8 h-8 bg-gradient-to-br ${social.gradient} ${social.hoverGradient} rounded-lg flex items-center justify-center transition-all duration-200 transform hover:scale-110 shadow-md hover:shadow-lg`}
            title={`${social.name} - ${social.handle}`}
          >
            <div className="w-4 h-4 text-white">
              {social.icon}
            </div>
          </a>
        ))}
      </div>
    );
  }

  if (variant === 'hero') {
    return (
      <div className={`flex space-x-4 ${className}`}>
        {socialLinks.map((social) => (
          <a
            key={social.name}
            href={social.url}
            target="_blank"
            rel="noopener noreferrer"
            className={`group flex items-center space-x-3 px-4 py-3 bg-gradient-to-br ${social.gradient} ${social.hoverGradient} rounded-full transition-all duration-200 transform hover:scale-105 shadow-lg hover:shadow-xl backdrop-blur-sm`}
          >
            <div className="w-5 h-5 text-white">
              {social.icon}
            </div>
            {showLabels && (
              <span className="text-white font-medium text-sm">
                {social.handle}
              </span>
            )}
          </a>
        ))}
      </div>
    );
  }

  // Default variant
  return (
    <div className={`space-y-3 ${className}`}>
      <h4 className="text-sm font-semibold text-gray-700 uppercase tracking-wider">
        Redes Sociais
      </h4>
      <div className="flex space-x-3">
        {socialLinks.map((social) => (
          <a
            key={social.name}
            href={social.url}
            target="_blank"
            rel="noopener noreferrer"
            className={`group flex items-center space-x-3 p-3 bg-gradient-to-br ${social.gradient} ${social.hoverGradient} rounded-xl transition-all duration-200 transform hover:scale-105 shadow-lg hover:shadow-xl min-w-0 flex-1`}
          >
            <div className="w-6 h-6 text-white flex-shrink-0">
              {social.icon}
            </div>
            {showLabels && (
              <div className="min-w-0 flex-1">
                <p className="text-white font-semibold text-sm truncate">
                  {social.name}
                </p>
                <p className="text-white/80 text-xs truncate">
                  {social.handle}
                </p>
              </div>
            )}
          </a>
        ))}
      </div>
    </div>
  );
}
