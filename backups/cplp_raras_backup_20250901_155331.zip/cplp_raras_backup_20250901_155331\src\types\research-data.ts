// Types para os dados coletados dos scrapers CPLP-Raras

export interface GardDataItem {
  id: string;
  nome: string;
  url_original: string;
  resumo: string;
  categorias: string[];
  links_relacionados: {
    text: string;
    href: string;
  }[];
  estatisticas: {
    tamanho_conteudo: number;
    paragrafos: number;
    cabecalhos: number;
    links: number;
  };
  coletado_em: string;
}

export interface GardData {
  fonte: string;
  url_origem: string;
  descricao: string;
  atualizado_em: string;
  total_itens: number;
  dados: GardDataItem[];
}

export interface PCDTPdf {
  title: string;
  url: string;
  letter: string;
  is_rare_disease: boolean;
  found_at: string;
}

export interface PCDTLetterData {
  total_pdfs: number;
  pdfs_relevantes: number;
  url: string;
  status: string;
  pdfs: PCDTPdf[];
}

export interface PCDTData {
  fonte: string;
  url_origem: string;
  descricao: string;
  atualizado_em: string;
  total_pdfs: number;
  pdfs_doencas_raras: number;
  dados: {
    todos_pdfs: PCDTPdf[];
    pdfs_relevantes: PCDTPdf[];
    por_letra: Record<string, PCDTLetterData>;
  };
}

export interface ResearchDataSources {
  gard: {
    nome: string;
    total_itens: number;
    status: string;
  };
  pcdt: {
    nome: string;
    total_pdfs: number;
    pdfs_relevantes: number;
    status: string;
  };
}

export interface ResearchDataStats {
  total_recursos: number;
  recursos_relevantes: number;
  cobertura_linguistica: string[];
  paises_cplp_cobertura: string[];
}

export interface ResearchData {
  projeto: string;
  descricao: string;
  atualizado_em: string;
  fontes: ResearchDataSources;
  estatisticas: ResearchDataStats;
  areas_pesquisa: string[];
}

// Types para dados de doenças existentes
export interface Disease {
  id: string;
  name: string;
  description: string;
  prevalence: string;
  symptoms: string[];
  diagnosis: string[];
  treatment: string[];
  resources: string[];
  countries: string[];
}

// Types para componentes de UI
export interface DataSourceCardProps {
  fonte: string;
  descricao: string;
  total_items: number;
  url: string;
  status: 'ativo' | 'inativo';
}

export interface StatisticCardProps {
  title: string;
  value: number | string;
  description?: string;
  icon?: string;
}

export interface ResearchAreaProps {
  areas: string[];
  onAreaSelect?: (area: string) => void;
}
