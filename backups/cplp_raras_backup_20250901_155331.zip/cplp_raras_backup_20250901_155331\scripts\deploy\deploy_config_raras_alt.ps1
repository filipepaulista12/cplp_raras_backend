# Configurações para o domínio raras-cplp.org - Pasta específica
# Como backup, caso seja necessário usar uma subpasta

$ServerIP = "200.144.254.4"
$ServerPort = "22"
$Username = "ubuntu"
$Password = "vFpyJS4FA"
$RemotePath = "/var/www/html/raras-cplp"  # Subpasta específica para o novo domínio
$FinalURL = "https://raras-cplp.org/"

# Configuração alternativa para teste
$AlternativeRemotePath = "/var/www/raras-cplp.org"  # Diretório virtual host
