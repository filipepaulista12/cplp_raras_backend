'use client';

import React, { createContext, useContext, useState, useEffect } from 'react';

export type Language = 'pt-BR' | 'pt-PT' | 'en' | 'es' | 'fr' | 'it';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

// Traduções completas para todo o site
const translations = {
  'pt-BR': {
    // Navigation
    'nav.home': 'Início',
    'nav.about': 'Sobre',
    'nav.team': 'Equipe',
    'nav.digital-resources': 'Recursos Digitais',
    'nav.contact': 'Contato',
    
    // Digital Resources submenu
    'nav.diseases-database': 'Base de Doenças',
    'nav.public-data': 'Dados Públicos',
    'nav.sof': 'SOF',
    'nav.educational-gpt': 'GPT Educativo',
    
    // About submenu
    'nav.about-project': 'Sobre o Projeto',
    'nav.methodology': 'Metodologia',
    'nav.tools-platforms': 'Ferramentas e Plataformas',
    'nav.working-groups': 'Grupos de Trabalho',
    
    // Team submenu
    'nav.researchers': 'Pesquisadores',
    'nav.collaborators': 'Colaboradores',
    'nav.partners': 'Parceiros',
    'nav.institutions': 'Instituições',
    
    // Home page
    'home.title': 'CPLP-Raras',
    'home.subtitle': 'Rede de Pesquisa em Doenças Raras da Comunidade dos Países de Língua Portuguesa',
    'home.description': 'Conectando pesquisadores, profissionais de saúde e comunidades para avançar no conhecimento e tratamento de doenças raras nos países lusófonos.',
    'home.explore-resources': 'Explorar Recursos',
    'home.learn-more': 'Saiba Mais',
    
    // About page
    'about.title': 'Sobre o Projeto CPLP-Raras',
    'about.mission': 'Nossa Missão',
    'about.mission-text': 'Promover a colaboração científica e o compartilhamento de conhecimento sobre doenças raras entre os países da CPLP.',
    'about.vision': 'Nossa Visão',
    'about.vision-text': 'Ser a principal rede de referência em doenças raras para a comunidade lusófona.',
    'about.objectives': 'Objetivos',
    'about.obj1': 'Facilitar o intercâmbio de informações científicas',
    'about.obj2': 'Desenvolver ferramentas digitais especializadas',
    'about.obj3': 'Promover a educação e capacitação',
    'about.obj4': 'Apoiar políticas públicas baseadas em evidências',
    
    // Digital Resources
    'resources.title': 'Recursos Digitais',
    'resources.subtitle': 'Ferramentas especializadas para pesquisa e tratamento de doenças raras',
    'resources.gt-connection': 'Conexão com Grupos de Trabalho',
    'resources.development-status': 'Status de Desenvolvimento',
    'resources.coming-soon': 'Em breve disponível',
    
    // Working Groups
    'gt.1': 'GT1 - Mapeamento de Recursos',
    'gt.2': 'GT2 - Plataformas Digitais',
    'gt.3': 'GT3 - Educação e Capacitação',
    'gt.4': 'GT4 - Sistemas de Informação',
    'gt.5': 'GT5 - Inteligência Artificial',
    'gt.6': 'GT6 - Análise de Dados',
    
    // Disease Database
    'diseases.title': 'Base de Doenças Raras',
    'diseases.subtitle': 'Consulta abrangente de doenças raras na CPLP',
    'diseases.description': 'Sistema em desenvolvimento pelo GT2 para catalogar e fornecer informações detalhadas sobre doenças raras.',
    'diseases.search-placeholder': 'Pesquisar por doença, sintoma ou código...',
    'diseases.categories': 'Categorias',
    'diseases.symptoms': 'Sintomas',
    'diseases.diagnosis': 'Diagnóstico',
    'diseases.treatment': 'Tratamento',
    'diseases.prevalence': 'Prevalência',
    'diseases.genes': 'Genes Associados',
    'diseases.demo-warning': 'Esta é uma demonstração. Os dados apresentados são fictícios e para fins de desenvolvimento.',
    
    // Public Data
    'data.title': 'Dados Públicos',
    'data.subtitle': 'Repositório de dados organizados sobre doenças raras',
    'data.description': 'Plataforma em desenvolvimento pelo GT1 para disponibilizar dados de pesquisa e estatísticas.',
    'data.datasets': 'Conjuntos de Dados',
    'data.download': 'Baixar',
    'data.view-details': 'Ver Detalhes',
    'data.api-docs': 'Documentação da API',
    'data.last-updated': 'Última atualização',
    'data.records': 'registros',
    
    // SOF System
    'sof.title': 'Sistema SOF',
    'sof.subtitle': 'Sistema de Organização de Funcionalidades',
    'sof.description': 'Ferramenta em planejamento pelo GT4 para gestão integrada de informações clínicas.',
    'sof.features': 'Funcionalidades Planejadas',
    'sof.feature1': 'Gestão de casos clínicos',
    'sof.feature2': 'Integração com sistemas de saúde',
    'sof.feature3': 'Relatórios automatizados',
    'sof.feature4': 'Análise epidemiológica',
    
    // Educational GPT
    'gpt.title': 'GPT Educativo',
    'gpt.subtitle': 'Assistente de IA para educação em doenças raras',
    'gpt.description': 'Sistema em desenvolvimento pelos GT5 e GT6 para suporte educacional especializado.',
    'gpt.capabilities': 'Capacidades Planejadas',
    'gpt.cap1': 'Respostas especializadas sobre doenças raras',
    'gpt.cap2': 'Materiais educativos personalizados',
    'gpt.cap3': 'Suporte a múltiplos idiomas',
    'gpt.cap4': 'Análise de literatura científica',
    
    // Page titles (for dynamic content)
    'page.diseases.title': 'Base de Doenças Raras',
    'page.diseases.subtitle': 'Consulta abrangente de doenças raras na CPLP',
    'page.public-data.title': 'Dados Públicos',
    'page.public-data.subtitle': 'Repositório de dados organizados sobre doenças raras',
    'page.sof.title': 'Sistema SOF',
    'page.sof.subtitle': 'Sistema de Organização de Funcionalidades',
    'page.gpt.title': 'GPT Educativo',
    'page.gpt.subtitle': 'Assistente de IA para educação em doenças raras',
    
    // Common terms
    'common.search': 'Pesquisar',
    'common.filter': 'Filtrar',
    'common.language': 'Idioma',
    'common.coming-soon': 'Em breve',
    'common.under-development': 'Em desenvolvimento',
    'common.in-planning': 'Em planejamento',
    'common.gt': 'Grupo de Trabalho',
    'common.preview': 'Prévia',
    'common.demo': 'Demonstração',
    'common.back': 'Voltar',
    'common.next': 'Próximo',
    'common.previous': 'Anterior',
    'common.loading': 'Carregando...',
    'common.error': 'Erro',
    'common.success': 'Sucesso',
    'common.warning': 'Aviso',
    'common.info': 'Informação',
  },
  
  'pt-PT': {
    // Navigation
    'nav.home': 'Início',
    'nav.about': 'Sobre',
    'nav.team': 'Equipa',
    'nav.digital-resources': 'Recursos Digitais',
    'nav.contact': 'Contacto',
    
    // Digital Resources submenu
    'nav.diseases-database': 'Base de Doenças',
    'nav.public-data': 'Dados Públicos',
    'nav.sof': 'SOF',
    'nav.educational-gpt': 'GPT Educativo',
    
    // About submenu
    'nav.about-project': 'Sobre o Projecto',
    'nav.methodology': 'Metodologia',
    'nav.tools-platforms': 'Ferramentas e Plataformas',
    'nav.working-groups': 'Grupos de Trabalho',
    
    // Team submenu
    'nav.researchers': 'Investigadores',
    'nav.collaborators': 'Colaboradores',
    'nav.partners': 'Parceiros',
    'nav.institutions': 'Instituições',
    
    // Home page
    'home.title': 'CPLP-Raras',
    'home.subtitle': 'Rede de Investigação em Doenças Raras da Comunidade dos Países de Língua Portuguesa',
    'home.description': 'Conectando investigadores, profissionais de saúde e comunidades para avançar no conhecimento e tratamento de doenças raras nos países lusófonos.',
    'home.explore-resources': 'Explorar Recursos',
    'home.learn-more': 'Saber Mais',
    
    // About page
    'about.title': 'Sobre o Projecto CPLP-Raras',
    'about.mission': 'A Nossa Missão',
    'about.mission-text': 'Promover a colaboração científica e a partilha de conhecimento sobre doenças raras entre os países da CPLP.',
    'about.vision': 'A Nossa Visão',
    'about.vision-text': 'Ser a principal rede de referência em doenças raras para a comunidade lusófona.',
    'about.objectives': 'Objectivos',
    'about.obj1': 'Facilitar o intercâmbio de informações científicas',
    'about.obj2': 'Desenvolver ferramentas digitais especializadas',
    'about.obj3': 'Promover a educação e capacitação',
    'about.obj4': 'Apoiar políticas públicas baseadas em evidências',
    
    // Digital Resources
    'resources.title': 'Recursos Digitais',
    'resources.subtitle': 'Ferramentas especializadas para investigação e tratamento de doenças raras',
    'resources.gt-connection': 'Conexão com Grupos de Trabalho',
    'resources.development-status': 'Estado de Desenvolvimento',
    'resources.coming-soon': 'Brevemente disponível',
    
    // Working Groups
    'gt.1': 'GT1 - Mapeamento de Recursos',
    'gt.2': 'GT2 - Plataformas Digitais',
    'gt.3': 'GT3 - Educação e Capacitação',
    'gt.4': 'GT4 - Sistemas de Informação',
    'gt.5': 'GT5 - Inteligência Artificial',
    'gt.6': 'GT6 - Análise de Dados',
    
    // Disease Database
    'diseases.title': 'Base de Doenças Raras',
    'diseases.subtitle': 'Consulta abrangente de doenças raras na CPLP',
    'diseases.description': 'Sistema em desenvolvimento pelo GT2 para catalogar e fornecer informações detalhadas sobre doenças raras.',
    'diseases.search-placeholder': 'Pesquisar por doença, sintoma ou código...',
    'diseases.categories': 'Categorias',
    'diseases.symptoms': 'Sintomas',
    'diseases.diagnosis': 'Diagnóstico',
    'diseases.treatment': 'Tratamento',
    'diseases.prevalence': 'Prevalência',
    'diseases.genes': 'Genes Associados',
    'diseases.demo-warning': 'Esta é uma demonstração. Os dados apresentados são fictícios e para fins de desenvolvimento.',
    
    // Public Data
    'data.title': 'Dados Públicos',
    'data.subtitle': 'Repositório de dados organizados sobre doenças raras',
    'data.description': 'Plataforma em desenvolvimento pelo GT1 para disponibilizar dados de investigação e estatísticas.',
    'data.datasets': 'Conjuntos de Dados',
    'data.download': 'Transferir',
    'data.view-details': 'Ver Detalhes',
    'data.api-docs': 'Documentação da API',
    'data.last-updated': 'Última actualização',
    'data.records': 'registos',
    
    // SOF System
    'sof.title': 'Sistema SOF',
    'sof.subtitle': 'Sistema de Organização de Funcionalidades',
    'sof.description': 'Ferramenta em planeamento pelo GT4 para gestão integrada de informações clínicas.',
    'sof.features': 'Funcionalidades Planeadas',
    'sof.feature1': 'Gestão de casos clínicos',
    'sof.feature2': 'Integração com sistemas de saúde',
    'sof.feature3': 'Relatórios automatizados',
    'sof.feature4': 'Análise epidemiológica',
    
    // Educational GPT
    'gpt.title': 'GPT Educativo',
    'gpt.subtitle': 'Assistente de IA para educação em doenças raras',
    'gpt.description': 'Sistema em desenvolvimento pelos GT5 e GT6 para suporte educacional especializado.',
    'gpt.capabilities': 'Capacidades Planeadas',
    'gpt.cap1': 'Respostas especializadas sobre doenças raras',
    'gpt.cap2': 'Materiais educativos personalizados',
    'gpt.cap3': 'Suporte a múltiplos idiomas',
    'gpt.cap4': 'Análise de literatura científica',
    
    // Page titles (for dynamic content)
    'page.diseases.title': 'Base de Doenças Raras',
    'page.diseases.subtitle': 'Consulta abrangente de doenças raras na CPLP',
    'page.public-data.title': 'Dados Públicos',
    'page.public-data.subtitle': 'Repositório de dados organizados sobre doenças raras',
    'page.sof.title': 'Sistema SOF',
    'page.sof.subtitle': 'Sistema de Organização de Funcionalidades',
    'page.gpt.title': 'GPT Educativo',
    'page.gpt.subtitle': 'Assistente de IA para educação em doenças raras',
    
    // Common terms
    'common.search': 'Pesquisar',
    'common.filter': 'Filtrar',
    'common.language': 'Idioma',
    'common.coming-soon': 'Em breve',
    'common.under-development': 'Em desenvolvimento',
    'common.in-planning': 'Em planeamento',
    'common.gt': 'Grupo de Trabalho',
    'common.preview': 'Pré-visualização',
    'common.demo': 'Demonstração',
    'common.back': 'Voltar',
    'common.next': 'Próximo',
    'common.previous': 'Anterior',
    'common.loading': 'A carregar...',
    'common.error': 'Erro',
    'common.success': 'Sucesso',
    'common.warning': 'Aviso',
    'common.info': 'Informação',
  },
  
  'en': {
    // Navigation
    'nav.home': 'Home',
    'nav.about': 'About',
    'nav.team': 'Team',
    'nav.digital-resources': 'Digital Resources',
    'nav.contact': 'Contact',
    
    // Digital Resources submenu
    'nav.diseases-database': 'Diseases Database',
    'nav.public-data': 'Public Data',
    'nav.sof': 'SOF',
    'nav.educational-gpt': 'Educational GPT',
    
    // About submenu
    'nav.about-project': 'About the Project',
    'nav.methodology': 'Methodology',
    'nav.tools-platforms': 'Tools & Platforms',
    'nav.working-groups': 'Working Groups',
    
    // Team submenu
    'nav.researchers': 'Researchers',
    'nav.collaborators': 'Collaborators',
    'nav.partners': 'Partners',
    'nav.institutions': 'Institutions',
    
    // Home page
    'home.title': 'CPLP-Raras',
    'home.subtitle': 'Portuguese-Speaking Countries Community Rare Diseases Research Network',
    'home.description': 'Connecting researchers, healthcare professionals, and communities to advance knowledge and treatment of rare diseases in Portuguese-speaking countries.',
    'home.explore-resources': 'Explore Resources',
    'home.learn-more': 'Learn More',
    
    // About page
    'about.title': 'About the CPLP-Raras Project',
    'about.mission': 'Our Mission',
    'about.mission-text': 'To promote scientific collaboration and knowledge sharing about rare diseases among CPLP countries.',
    'about.vision': 'Our Vision',
    'about.vision-text': 'To be the leading reference network for rare diseases in the Portuguese-speaking community.',
    'about.objectives': 'Objectives',
    'about.obj1': 'Facilitate scientific information exchange',
    'about.obj2': 'Develop specialized digital tools',
    'about.obj3': 'Promote education and training',
    'about.obj4': 'Support evidence-based public policies',
    
    // Digital Resources
    'resources.title': 'Digital Resources',
    'resources.subtitle': 'Specialized tools for rare disease research and treatment',
    'resources.gt-connection': 'Working Group Connection',
    'resources.development-status': 'Development Status',
    'resources.coming-soon': 'Coming soon',
    
    // Working Groups
    'gt.1': 'WG1 - Resource Mapping',
    'gt.2': 'WG2 - Digital Platforms',
    'gt.3': 'WG3 - Education & Training',
    'gt.4': 'WG4 - Information Systems',
    'gt.5': 'WG5 - Artificial Intelligence',
    'gt.6': 'WG6 - Data Analysis',
    
    // Disease Database
    'diseases.title': 'Rare Diseases Database',
    'diseases.subtitle': 'Comprehensive rare diseases consultation for CPLP',
    'diseases.description': 'System under development by WG2 to catalog and provide detailed information about rare diseases.',
    'diseases.search-placeholder': 'Search by disease, symptom, or code...',
    'diseases.categories': 'Categories',
    'diseases.symptoms': 'Symptoms',
    'diseases.diagnosis': 'Diagnosis',
    'diseases.treatment': 'Treatment',
    'diseases.prevalence': 'Prevalence',
    'diseases.genes': 'Associated Genes',
    'diseases.demo-warning': 'This is a demonstration. The data presented is fictional and for development purposes.',
    
    // Public Data
    'data.title': 'Public Data',
    'data.subtitle': 'Organized data repository on rare diseases',
    'data.description': 'Platform under development by WG1 to provide research data and statistics.',
    'data.datasets': 'Datasets',
    'data.download': 'Download',
    'data.view-details': 'View Details',
    'data.api-docs': 'API Documentation',
    'data.last-updated': 'Last updated',
    'data.records': 'records',
    
    // SOF System
    'sof.title': 'SOF System',
    'sof.subtitle': 'System for Functionality Organization',
    'sof.description': 'Tool in planning by WG4 for integrated clinical information management.',
    'sof.features': 'Planned Features',
    'sof.feature1': 'Clinical case management',
    'sof.feature2': 'Health system integration',
    'sof.feature3': 'Automated reports',
    'sof.feature4': 'Epidemiological analysis',
    
    // Educational GPT
    'gpt.title': 'Educational GPT',
    'gpt.subtitle': 'AI Assistant for rare diseases education',
    'gpt.description': 'System under development by WG5 and WG6 for specialized educational support.',
    'gpt.capabilities': 'Planned Capabilities',
    'gpt.cap1': 'Specialized responses about rare diseases',
    'gpt.cap2': 'Personalized educational materials',
    'gpt.cap3': 'Multi-language support',
    'gpt.cap4': 'Scientific literature analysis',
    
    // Page titles (for dynamic content)
    'page.diseases.title': 'Rare Diseases Database',
    'page.diseases.subtitle': 'Comprehensive rare diseases consultation for CPLP',
    'page.public-data.title': 'Public Data',
    'page.public-data.subtitle': 'Organized data repository on rare diseases',
    'page.sof.title': 'SOF System',
    'page.sof.subtitle': 'System for Functionality Organization',
    'page.gpt.title': 'Educational GPT',
    'page.gpt.subtitle': 'AI Assistant for rare diseases education',
    
    // Common terms
    'common.search': 'Search',
    'common.filter': 'Filter',
    'common.language': 'Language',
    'common.coming-soon': 'Coming Soon',
    'common.under-development': 'Under Development',
    'common.in-planning': 'In Planning',
    'common.gt': 'Working Group',
    'common.preview': 'Preview',
    'common.demo': 'Demo',
    'common.back': 'Back',
    'common.next': 'Next',
    'common.previous': 'Previous',
    'common.loading': 'Loading...',
    'common.error': 'Error',
    'common.success': 'Success',
    'common.warning': 'Warning',
    'common.info': 'Information',
  },
  
  'es': {
    // Navigation
    'nav.home': 'Inicio',
    'nav.about': 'Acerca de',
    'nav.team': 'Equipo',
    'nav.digital-resources': 'Recursos Digitales',
    'nav.contact': 'Contacto',
    
    // Digital Resources submenu
    'nav.diseases-database': 'Base de Enfermedades',
    'nav.public-data': 'Datos Públicos',
    'nav.sof': 'SOF',
    'nav.educational-gpt': 'GPT Educativo',
    
    // About submenu
    'nav.about-project': 'Sobre el Proyecto',
    'nav.methodology': 'Metodología',
    'nav.tools-platforms': 'Herramientas y Plataformas',
    'nav.working-groups': 'Grupos de Trabajo',
    
    // Team submenu
    'nav.researchers': 'Investigadores',
    'nav.collaborators': 'Colaboradores',
    'nav.partners': 'Socios',
    'nav.institutions': 'Instituciones',
    
    // Home page
    'home.title': 'CPLP-Raras',
    'home.subtitle': 'Red de Investigación en Enfermedades Raras de la Comunidad de Países de Lengua Portuguesa',
    'home.description': 'Conectando investigadores, profesionales de la salud y comunidades para avanzar en el conocimiento y tratamiento de enfermedades raras en países de habla portuguesa.',
    'home.explore-resources': 'Explorar Recursos',
    'home.learn-more': 'Saber Más',
    
    // About page
    'about.title': 'Sobre el Proyecto CPLP-Raras',
    'about.mission': 'Nuestra Misión',
    'about.mission-text': 'Promover la colaboración científica y el intercambio de conocimientos sobre enfermedades raras entre los países de la CPLP.',
    'about.vision': 'Nuestra Visión',
    'about.vision-text': 'Ser la principal red de referencia en enfermedades raras para la comunidad lusófona.',
    'about.objectives': 'Objetivos',
    'about.obj1': 'Facilitar el intercambio de información científica',
    'about.obj2': 'Desarrollar herramientas digitales especializadas',
    'about.obj3': 'Promover la educación y capacitación',
    'about.obj4': 'Apoyar políticas públicas basadas en evidencia',
    
    // Digital Resources
    'resources.title': 'Recursos Digitales',
    'resources.subtitle': 'Herramientas especializadas para investigación y tratamiento de enfermedades raras',
    'resources.gt-connection': 'Conexión con Grupos de Trabajo',
    'resources.development-status': 'Estado de Desarrollo',
    'resources.coming-soon': 'Próximamente disponible',
    
    // Working Groups
    'gt.1': 'GT1 - Mapeo de Recursos',
    'gt.2': 'GT2 - Plataformas Digitales',
    'gt.3': 'GT3 - Educación y Capacitación',
    'gt.4': 'GT4 - Sistemas de Información',
    'gt.5': 'GT5 - Inteligencia Artificial',
    'gt.6': 'GT6 - Análisis de Datos',
    
    // Disease Database
    'diseases.title': 'Base de Enfermedades Raras',
    'diseases.subtitle': 'Consulta integral de enfermedades raras en CPLP',
    'diseases.description': 'Sistema en desarrollo por GT2 para catalogar y proporcionar información detallada sobre enfermedades raras.',
    'diseases.search-placeholder': 'Buscar por enfermedad, síntoma o código...',
    'diseases.categories': 'Categorías',
    'diseases.symptoms': 'Síntomas',
    'diseases.diagnosis': 'Diagnóstico',
    'diseases.treatment': 'Tratamiento',
    'diseases.prevalence': 'Prevalencia',
    'diseases.genes': 'Genes Asociados',
    'diseases.demo-warning': 'Esta es una demostración. Los datos presentados son ficticios y para fines de desarrollo.',
    
    // Public Data
    'data.title': 'Datos Públicos',
    'data.subtitle': 'Repositorio de datos organizados sobre enfermedades raras',
    'data.description': 'Plataforma en desarrollo por GT1 para proporcionar datos de investigación y estadísticas.',
    'data.datasets': 'Conjuntos de Datos',
    'data.download': 'Descargar',
    'data.view-details': 'Ver Detalles',
    'data.api-docs': 'Documentación de API',
    'data.last-updated': 'Última actualización',
    'data.records': 'registros',
    
    // SOF System
    'sof.title': 'Sistema SOF',
    'sof.subtitle': 'Sistema de Organización de Funcionalidades',
    'sof.description': 'Herramienta en planificación por GT4 para gestión integrada de información clínica.',
    'sof.features': 'Características Planificadas',
    'sof.feature1': 'Gestión de casos clínicos',
    'sof.feature2': 'Integración con sistemas de salud',
    'sof.feature3': 'Informes automatizados',
    'sof.feature4': 'Análisis epidemiológico',
    
    // Educational GPT
    'gpt.title': 'GPT Educativo',
    'gpt.subtitle': 'Asistente de IA para educación en enfermedades raras',
    'gpt.description': 'Sistema en desarrollo por GT5 y GT6 para apoyo educativo especializado.',
    'gpt.capabilities': 'Capacidades Planificadas',
    'gpt.cap1': 'Respuestas especializadas sobre enfermedades raras',
    'gpt.cap2': 'Materiales educativos personalizados',
    'gpt.cap3': 'Soporte multiidioma',
    'gpt.cap4': 'Análisis de literatura científica',
    
    // Page titles (for dynamic content)
    'page.diseases.title': 'Base de Enfermedades Raras',
    'page.diseases.subtitle': 'Consulta integral de enfermedades raras en CPLP',
    'page.public-data.title': 'Datos Públicos',
    'page.public-data.subtitle': 'Repositorio de datos organizados sobre enfermedades raras',
    'page.sof.title': 'Sistema SOF',
    'page.sof.subtitle': 'Sistema de Organización de Funcionalidades',
    'page.gpt.title': 'GPT Educativo',
    'page.gpt.subtitle': 'Asistente de IA para educación en enfermedades raras',
    
    // Common terms
    'common.search': 'Buscar',
    'common.filter': 'Filtrar',
    'common.language': 'Idioma',
    'common.coming-soon': 'Próximamente',
    'common.under-development': 'En Desarrollo',
    'common.in-planning': 'En Planificación',
    'common.gt': 'Grupo de Trabajo',
    'common.preview': 'Vista previa',
    'common.demo': 'Demostración',
    'common.back': 'Atrás',
    'common.next': 'Siguiente',
    'common.previous': 'Anterior',
    'common.loading': 'Cargando...',
    'common.error': 'Error',
    'common.success': 'Éxito',
    'common.warning': 'Advertencia',
    'common.info': 'Información',
  },
  
  'fr': {
    // Navigation
    'nav.home': 'Accueil',
    'nav.about': 'À propos',
    'nav.team': 'Équipe',
    'nav.digital-resources': 'Ressources Numériques',
    'nav.contact': 'Contact',
    
    // Digital Resources submenu
    'nav.diseases-database': 'Base de Maladies',
    'nav.public-data': 'Données Publiques',
    'nav.sof': 'SOF',
    'nav.educational-gpt': 'GPT Éducatif',
    
    // About submenu
    'nav.about-project': 'À propos du Projet',
    'nav.methodology': 'Méthodologie',
    'nav.tools-platforms': 'Outils et Plateformes',
    'nav.working-groups': 'Groupes de Travail',
    
    // Team submenu
    'nav.researchers': 'Chercheurs',
    'nav.collaborators': 'Collaborateurs',
    'nav.partners': 'Partenaires',
    'nav.institutions': 'Institutions',
    
    // Home page
    'home.title': 'CPLP-Raras',
    'home.subtitle': 'Réseau de Recherche sur les Maladies Rares de la Communauté des Pays de Langue Portugaise',
    'home.description': 'Connecter chercheurs, professionnels de santé et communautés pour faire progresser la connaissance et le traitement des maladies rares dans les pays lusophones.',
    'home.explore-resources': 'Explorer les Ressources',
    'home.learn-more': 'En Savoir Plus',
    
    // About page
    'about.title': 'À propos du Projet CPLP-Raras',
    'about.mission': 'Notre Mission',
    'about.mission-text': 'Promouvoir la collaboration scientifique et le partage de connaissances sur les maladies rares entre les pays de la CPLP.',
    'about.vision': 'Notre Vision',
    'about.vision-text': 'Être le principal réseau de référence pour les maladies rares dans la communauté lusophone.',
    'about.objectives': 'Objectifs',
    'about.obj1': 'Faciliter l\'échange d\'informations scientifiques',
    'about.obj2': 'Développer des outils numériques spécialisés',
    'about.obj3': 'Promouvoir l\'éducation et la formation',
    'about.obj4': 'Soutenir les politiques publiques basées sur des preuves',
    
    // Digital Resources
    'resources.title': 'Ressources Numériques',
    'resources.subtitle': 'Outils spécialisés pour la recherche et le traitement des maladies rares',
    'resources.gt-connection': 'Connexion avec les Groupes de Travail',
    'resources.development-status': 'Statut de Développement',
    'resources.coming-soon': 'Bientôt disponible',
    
    // Working Groups
    'gt.1': 'GT1 - Cartographie des Ressources',
    'gt.2': 'GT2 - Plateformes Numériques',
    'gt.3': 'GT3 - Éducation et Formation',
    'gt.4': 'GT4 - Systèmes d\'Information',
    'gt.5': 'GT5 - Intelligence Artificielle',
    'gt.6': 'GT6 - Analyse de Données',
    
    // Disease Database
    'diseases.title': 'Base de Maladies Rares',
    'diseases.subtitle': 'Consultation complète des maladies rares dans la CPLP',
    'diseases.description': 'Système en développement par GT2 pour cataloguer et fournir des informations détaillées sur les maladies rares.',
    'diseases.search-placeholder': 'Rechercher par maladie, symptôme ou code...',
    'diseases.categories': 'Catégories',
    'diseases.symptoms': 'Symptômes',
    'diseases.diagnosis': 'Diagnostic',
    'diseases.treatment': 'Traitement',
    'diseases.prevalence': 'Prévalence',
    'diseases.genes': 'Gènes Associés',
    'diseases.demo-warning': 'Ceci est une démonstration. Les données présentées sont fictives et à des fins de développement.',
    
    // Public Data
    'data.title': 'Données Publiques',
    'data.subtitle': 'Référentiel de données organisées sur les maladies rares',
    'data.description': 'Plateforme en développement par GT1 pour fournir des données de recherche et des statistiques.',
    'data.datasets': 'Jeux de Données',
    'data.download': 'Télécharger',
    'data.view-details': 'Voir les Détails',
    'data.api-docs': 'Documentation API',
    'data.last-updated': 'Dernière mise à jour',
    'data.records': 'enregistrements',
    
    // SOF System
    'sof.title': 'Système SOF',
    'sof.subtitle': 'Système d\'Organisation des Fonctionnalités',
    'sof.description': 'Outil en planification par GT4 pour la gestion intégrée d\'informations cliniques.',
    'sof.features': 'Fonctionnalités Prévues',
    'sof.feature1': 'Gestion de cas cliniques',
    'sof.feature2': 'Intégration avec les systèmes de santé',
    'sof.feature3': 'Rapports automatisés',
    'sof.feature4': 'Analyse épidémiologique',
    
    // Educational GPT
    'gpt.title': 'GPT Éducatif',
    'gpt.subtitle': 'Assistant IA pour l\'éducation sur les maladies rares',
    'gpt.description': 'Système en développement par GT5 et GT6 pour un soutien éducatif spécialisé.',
    'gpt.capabilities': 'Capacités Prévues',
    'gpt.cap1': 'Réponses spécialisées sur les maladies rares',
    'gpt.cap2': 'Matériels éducatifs personnalisés',
    'gpt.cap3': 'Support multilingue',
    'gpt.cap4': 'Analyse de littérature scientifique',
    
    // Page titles (for dynamic content)
    'page.diseases.title': 'Base de Maladies Rares',
    'page.diseases.subtitle': 'Consultation complète des maladies rares dans la CPLP',
    'page.public-data.title': 'Données Publiques',
    'page.public-data.subtitle': 'Référentiel de données organisées sur les maladies rares',
    'page.sof.title': 'Système SOF',
    'page.sof.subtitle': 'Système d\'Organisation des Fonctionnalités',
    'page.gpt.title': 'GPT Éducatif',
    'page.gpt.subtitle': 'Assistant IA pour l\'éducation sur les maladies rares',
    
    // Common terms
    'common.search': 'Rechercher',
    'common.filter': 'Filtrer',
    'common.language': 'Langue',
    'common.coming-soon': 'Bientôt',
    'common.under-development': 'En Développement',
    'common.in-planning': 'En Planification',
    'common.gt': 'Groupe de Travail',
    'common.preview': 'Aperçu',
    'common.demo': 'Démonstration',
    'common.back': 'Retour',
    'common.next': 'Suivant',
    'common.previous': 'Précédent',
    'common.loading': 'Chargement...',
    'common.error': 'Erreur',
    'common.success': 'Succès',
    'common.warning': 'Avertissement',
    'common.info': 'Information',
  },
  
  'it': {
    // Navigation
    'nav.home': 'Home',
    'nav.about': 'Chi Siamo',
    'nav.team': 'Team',
    'nav.digital-resources': 'Risorse Digitali',
    'nav.contact': 'Contatto',
    
    // Digital Resources submenu
    'nav.diseases-database': 'Database Malattie',
    'nav.public-data': 'Dati Pubblici',
    'nav.sof': 'SOF',
    'nav.educational-gpt': 'GPT Educativo',
    
    // About submenu
    'nav.about-project': 'Sul Progetto',
    'nav.methodology': 'Metodologia',
    'nav.tools-platforms': 'Strumenti e Piattaforme',
    'nav.working-groups': 'Gruppi di Lavoro',
    
    // Team submenu
    'nav.researchers': 'Ricercatori',
    'nav.collaborators': 'Collaboratori',
    'nav.partners': 'Partner',
    'nav.institutions': 'Istituzioni',
    
    // Home page
    'home.title': 'CPLP-Raras',
    'home.subtitle': 'Rete di Ricerca sulle Malattie Rare della Comunità dei Paesi di Lingua Portoghese',
    'home.description': 'Collegando ricercatori, professionisti sanitari e comunità per far progredire la conoscenza e il trattamento delle malattie rare nei paesi lusofoni.',
    'home.explore-resources': 'Esplora Risorse',
    'home.learn-more': 'Scopri di Più',
    
    // About page
    'about.title': 'Sul Progetto CPLP-Raras',
    'about.mission': 'La Nostra Missione',
    'about.mission-text': 'Promuovere la collaborazione scientifica e la condivisione di conoscenze sulle malattie rare tra i paesi CPLP.',
    'about.vision': 'La Nostra Visione',
    'about.vision-text': 'Essere la principale rete di riferimento per le malattie rare nella comunità lusofona.',
    'about.objectives': 'Obiettivi',
    'about.obj1': 'Facilitare lo scambio di informazioni scientifiche',
    'about.obj2': 'Sviluppare strumenti digitali specializzati',
    'about.obj3': 'Promuovere educazione e formazione',
    'about.obj4': 'Supportare politiche pubbliche basate su evidenze',
    
    // Digital Resources
    'resources.title': 'Risorse Digitali',
    'resources.subtitle': 'Strumenti specializzati per ricerca e trattamento di malattie rare',
    'resources.gt-connection': 'Connessione con Gruppi di Lavoro',
    'resources.development-status': 'Stato di Sviluppo',
    'resources.coming-soon': 'Prossimamente disponibile',
    
    // Working Groups
    'gt.1': 'GT1 - Mappatura Risorse',
    'gt.2': 'GT2 - Piattaforme Digitali',
    'gt.3': 'GT3 - Educazione e Formazione',
    'gt.4': 'GT4 - Sistemi Informativi',
    'gt.5': 'GT5 - Intelligenza Artificiale',
    'gt.6': 'GT6 - Analisi Dati',
    
    // Disease Database
    'diseases.title': 'Database Malattie Rare',
    'diseases.subtitle': 'Consultazione completa malattie rare CPLP',
    'diseases.description': 'Sistema in sviluppo da GT2 per catalogare e fornire informazioni dettagliate sulle malattie rare.',
    'diseases.search-placeholder': 'Cerca per malattia, sintomo o codice...',
    'diseases.categories': 'Categorie',
    'diseases.symptoms': 'Sintomi',
    'diseases.diagnosis': 'Diagnosi',
    'diseases.treatment': 'Trattamento',
    'diseases.prevalence': 'Prevalenza',
    'diseases.genes': 'Geni Associati',
    'diseases.demo-warning': 'Questa è una dimostrazione. I dati presentati sono fittizi e per scopi di sviluppo.',
    
    // Public Data
    'data.title': 'Dati Pubblici',
    'data.subtitle': 'Repository dati organizzati su malattie rare',
    'data.description': 'Piattaforma in sviluppo da GT1 per fornire dati di ricerca e statistiche.',
    'data.datasets': 'Dataset',
    'data.download': 'Scarica',
    'data.view-details': 'Vedi Dettagli',
    'data.api-docs': 'Documentazione API',
    'data.last-updated': 'Ultimo aggiornamento',
    'data.records': 'record',
    
    // SOF System
    'sof.title': 'Sistema SOF',
    'sof.subtitle': 'Sistema di Organizzazione Funzionalità',
    'sof.description': 'Strumento in pianificazione da GT4 per gestione integrata informazioni cliniche.',
    'sof.features': 'Funzionalità Pianificate',
    'sof.feature1': 'Gestione casi clinici',
    'sof.feature2': 'Integrazione con sistemi sanitari',
    'sof.feature3': 'Report automatizzati',
    'sof.feature4': 'Analisi epidemiologica',
    
    // Educational GPT
    'gpt.title': 'GPT Educativo',
    'gpt.subtitle': 'Assistente IA per educazione malattie rare',
    'gpt.description': 'Sistema in sviluppo da GT5 e GT6 per supporto educativo specializzato.',
    'gpt.capabilities': 'Capacità Pianificate',
    'gpt.cap1': 'Risposte specializzate su malattie rare',
    'gpt.cap2': 'Materiali educativi personalizzati',
    'gpt.cap3': 'Supporto multilingue',
    'gpt.cap4': 'Analisi letteratura scientifica',
    
    // Page titles (for dynamic content)
    'page.diseases.title': 'Database Malattie Rare',
    'page.diseases.subtitle': 'Consultazione completa malattie rare CPLP',
    'page.public-data.title': 'Dati Pubblici',
    'page.public-data.subtitle': 'Repository dati organizzati su malattie rare',
    'page.sof.title': 'Sistema SOF',
    'page.sof.subtitle': 'Sistema di Organizzazione Funzionalità',
    'page.gpt.title': 'GPT Educativo',
    'page.gpt.subtitle': 'Assistente IA per educazione malattie rare',
    
    // Common terms
    'common.search': 'Cerca',
    'common.filter': 'Filtra',
    'common.language': 'Lingua',
    'common.coming-soon': 'Prossimamente',
    'common.under-development': 'In Sviluppo',
    'common.in-planning': 'In Pianificazione',
    'common.gt': 'Gruppo di Lavoro',
    'common.preview': 'Anteprima',
    'common.demo': 'Dimostrazione',
    'common.back': 'Indietro',
    'common.next': 'Avanti',
    'common.previous': 'Precedente',
    'common.loading': 'Caricamento...',
    'common.error': 'Errore',
    'common.success': 'Successo',
    'common.warning': 'Attenzione',
    'common.info': 'Informazione',
  },
};

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguage] = useState<Language>('pt-BR');

  useEffect(() => {
    // Load saved language from localStorage
    const savedLanguage = localStorage.getItem('cplp-language') as Language;
    if (savedLanguage && translations[savedLanguage]) {
      setLanguage(savedLanguage);
    } else {
      // Auto-detect based on browser language
      const browserLang = navigator.language.toLowerCase();
      if (browserLang.includes('pt-pt') || browserLang.includes('pt_pt')) {
        setLanguage('pt-PT');
      } else if (browserLang.includes('en')) {
        setLanguage('en');
      } else if (browserLang.includes('es')) {
        setLanguage('es');
      } else if (browserLang.includes('fr')) {
        setLanguage('fr');
      } else if (browserLang.includes('it')) {
        setLanguage('it');
      } else {
        setLanguage('pt-BR');
      }
    }
  }, []);

  const handleSetLanguage = (lang: Language) => {
    setLanguage(lang);
    localStorage.setItem('cplp-language', lang);
  };

  const t = (key: string): string => {
    return translations[language][key as keyof typeof translations[typeof language]] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage: handleSetLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage deve ser usado dentro de um LanguageProvider');
  }
  return context;
}
