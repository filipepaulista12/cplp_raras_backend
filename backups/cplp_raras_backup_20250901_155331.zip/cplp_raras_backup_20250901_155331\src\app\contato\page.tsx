'use client';

import Link from 'next/link';
import { ArrowLeftIcon } from '@heroicons/react/24/outline';
import { useState } from 'react';
import { sendContactForm, openEmailClient, getSpecificContact, validateFormData, type ContactFormData } from '@/lib/emailService';

const countries = [
  { name: 'Coordenação Geral do estudo', flag: '🇧🇷', coordinator: 'Prof. Dr. Domingos Alves', email: 'cplp@raras.org.br' },
  { name: 'Brasil', flag: '🇧🇷', coordinator: 'Dr. Filipe Bernardi', email: 'cplp@raras.org.br' },
  { name: 'Portugal', flag: '🇵🇹', coordinator: 'Dr. Vinícius Lima', email: 'cplp@raras.org.br' },
  { name: 'Angola', flag: '🇦🇴', coordinator: 'Dr. Tomás Sanjuluca', email: 'cplp@raras.org.br' },
  { name: 'Moçambique', flag: '🇲🇿', coordinator: 'Dr. Luís F. A. Madeira', email: 'cplp@raras.org.br' },
  { name: 'Guiné-Bissau', flag: '🇬🇼', coordinator: 'MSc. Adulai G. Rodrigues', email: 'cplp@raras.org.br' },
];

export default function Contact() {
  const [formData, setFormData] = useState<ContactFormData>({
    name: '',
    email: '',
    institution: '',
    country: '',
    subject: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [statusMessage, setStatusMessage] = useState<string>('');

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validação
    const errors = validateFormData(formData);
    if (errors.length > 0) {
      alert('Por favor, corrija os seguintes erros:\n' + errors.join('\n'));
      return;
    }

    setIsSubmitting(true);
    setSubmitStatus('idle');

    try {
      const result = await sendContactForm(formData);
      
      if (result.success) {
        setSubmitStatus('success');
        setStatusMessage(result.message);
        
        // Reset form apenas se o email foi realmente enviado
        if (result.emailSent) {
          setFormData({
            name: '',
            email: '',
            institution: '',
            country: '',
            subject: '',
            message: ''
          });
        }
      } else {
        setSubmitStatus('error');
        setStatusMessage('Erro ao enviar mensagem');
      }
    } catch (error) {
      setSubmitStatus('error');
      setStatusMessage('Erro inesperado ao enviar formulário');
      console.error('Erro ao enviar formulário:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDirectEmail = (email: string, name: string) => {
    openEmailClient({
      email: email,
      subject: `Contato via CPLP-Raras - ${name}`,
      message: 'Olá! Entro em contato através do site CPLP-Raras.\n\nMinha dúvida/interesse é:\n'
    });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Breadcrumb */}
      <div className="bg-white border-b">
        <div className="mx-auto max-w-7xl px-4 py-4 sm:px-6 lg:px-8">
          <Link 
            href="/"
            className="inline-flex items-center text-blue-600 hover:text-blue-800 transition-colors"
          >
            <ArrowLeftIcon className="h-4 w-4 mr-2" />
            Voltar ao Início
          </Link>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            📞 Entre em Contato
          </h1>
          <div className="w-32 h-1 bg-gradient-to-r from-blue-600 to-green-600 mx-auto mb-8"></div>
          <p className="text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed">
            Tem dúvidas sobre o projeto? Quer participar da rede CPLP-Raras? 
            Entre em contato conosco através dos canais abaixo.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Contact Form */}
          <div className="bg-white rounded-2xl shadow-lg p-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">
              📝 Envie sua Mensagem
            </h2>
            
            {/* Status Messages */}
            {submitStatus === 'success' && (
              <div className="mb-6 p-4 bg-green-100 border border-green-400 rounded-lg">
                <p className="text-green-800 font-medium">✅ {statusMessage}</p>
              </div>
            )}
            
            {submitStatus === 'error' && (
              <div className="mb-6 p-4 bg-red-100 border border-red-400 rounded-lg">
                <p className="text-red-800 font-medium">❌ {statusMessage || 'Erro ao enviar mensagem. Tente novamente ou use o email direto abaixo.'}</p>
              </div>
            )}
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-2">
                    Nome Completo *
                  </label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    required
                    value={formData.name}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Seu nome completo"
                  />
                </div>
                
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                    E-mail *
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    required
                    value={formData.email}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="seu@email.com"
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="institution" className="block text-sm font-medium text-gray-700 mb-2">
                    Instituição
                  </label>
                  <input
                    type="text"
                    id="institution"
                    name="institution"
                    value={formData.institution}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Sua instituição"
                  />
                </div>
                
                <div>
                  <label htmlFor="country" className="block text-sm font-medium text-gray-700 mb-2">
                    País
                  </label>
                  <select
                    id="country"
                    name="country"
                    value={formData.country}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="">Selecione um país</option>
                    <option value="brasil">🇧🇷 Brasil</option>
                    <option value="portugal">🇵🇹 Portugal</option>
                    <option value="angola">🇦🇴 Angola</option>
                    <option value="mocambique">🇲🇿 Moçambique</option>
                    <option value="guine-bissau">🇬🇼 Guiné-Bissau</option>
                    <option value="cabo-verde">🇨🇻 Cabo Verde</option>
                    <option value="timor-leste">🇹🇱 Timor-Leste</option>
                    <option value="guine-equatorial">🇬🇶 Guiné Equatorial</option>
                    <option value="sao-tome">🇸🇹 São Tomé e Príncipe</option>
                    <option value="outro">🌍 Outro</option>
                  </select>
                </div>
              </div>
              
              <div>
                <label htmlFor="subject" className="block text-sm font-medium text-gray-700 mb-2">
                  Assunto *
                </label>
                <select
                  id="subject"
                  name="subject"
                  required
                  value={formData.subject}
                  onChange={handleInputChange}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="">Selecione um assunto</option>
                  <option value="participacao">Participar do projeto</option>
                  <option value="colaboracao">Colaboração científica</option>
                  <option value="informacoes">Solicitar informações</option>
                  <option value="imprensa">Imprensa</option>
                  <option value="suporte">Suporte técnico</option>
                  <option value="outro">Outro</option>
                </select>
              </div>
              
              <div>
                <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-2">
                  Mensagem *
                </label>
                <textarea
                  id="message"
                  name="message"
                  required
                  rows={5}
                  value={formData.message}
                  onChange={handleInputChange}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Descreva sua dúvida ou interesse em participar do projeto..."
                ></textarea>
              </div>
              
              <button
                type="submit"
                disabled={isSubmitting}
                className={`w-full py-3 rounded-lg font-semibold transition-all duration-200 ${
                  isSubmitting
                    ? 'bg-gray-400 cursor-not-allowed text-white'
                    : 'bg-gradient-to-r from-blue-600 to-green-600 text-white hover:opacity-90 hover:scale-105'
                }`}
              >
                {isSubmitting ? '⏳ Enviando...' : '📧 Enviar Mensagem'}
              </button>
              
              <p className="text-xs text-gray-500 mt-3 text-center">
                * Campos obrigatórios. Sua mensagem será direcionada para a equipe apropriada.
              </p>
            </form>
          </div>

          {/* Contact Information */}
          <div className="space-y-8">
            {/* General Contact */}
            <div className="bg-white rounded-2xl shadow-lg p-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">
                📋 Informações Gerais
              </h2>
              
              <div className="space-y-4">
                <div className="flex items-center space-x-3">
                  <span className="text-2xl">📧</span>
                  <div>
                    <p className="font-medium text-gray-900">E-mail Principal</p>
                    <p className="text-gray-600">cplp@raras.org.br</p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-3">
                  <span className="text-2xl">🌐</span>
                  <div>
                    <p className="font-medium text-gray-900">Website</p>
                    <p className="text-gray-600">www.cplp-raras.org</p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-3">
                  <span className="text-2xl">📱</span>
                  <div>
                    <p className="font-medium text-gray-900">Redes Sociais</p>
                    <p className="text-gray-600">@rarasporti</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Country Coordinators */}
            <div className="bg-white rounded-2xl shadow-lg p-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">
                🌍 Coordenadores por País
              </h2>
              
              <div className="space-y-4">
                {countries.map((country) => (
                  <div key={country.name} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-3">
                        <span className="text-2xl">{country.flag}</span>
                        <span className="font-medium text-gray-900">{country.name}</span>
                      </div>
                    </div>
                    <p className="text-gray-600 text-sm mb-2">{country.coordinator}</p>
                    <button
                      onClick={() => handleDirectEmail(country.email, country.name)}
                      className="text-blue-600 text-sm hover:text-blue-800 underline font-medium"
                    >
                      📧 {country.email}
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* FAQ */}
            <div className="bg-white rounded-2xl shadow-lg p-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">
                ❓ Perguntas Frequentes
              </h2>
              
              <div className="space-y-4">
                <div>
                  <h3 className="font-medium text-gray-900 mb-2">
                    Como posso participar do projeto?
                  </h3>
                  <p className="text-gray-600 text-sm">
                    Entre em contato conosco através do formulário ou e-mail. Avaliaremos como 
                    sua instituição pode contribuir com o projeto.
                  </p>
                </div>
                
                <div>
                  <h3 className="font-medium text-gray-900 mb-2">
                    O projeto aceita colaboradores individuais?
                  </h3>
                  <p className="text-gray-600 text-sm">
                    Sim, pesquisadores individuais podem participar através de suas instituições 
                    ou como colaboradores especializados.
                  </p>
                </div>
                
                <div>
                  <h3 className="font-medium text-gray-900 mb-2">
                    Qual o prazo de resposta?
                  </h3>
                  <p className="text-gray-600 text-sm">
                    Respondemos em até 48 horas úteis. Para questões urgentes, utilize o 
                    e-mail direto do coordenador do seu país.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
