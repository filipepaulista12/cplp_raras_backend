/**
 * Serviço de Email para CPLP-Raras
 * Fornece funcionalidades para abrir o cliente de email padrão ou enviar formulários
 */

export interface ContactFormData {
  name: string;
  email: string;
  institution?: string;
  country?: string;
  subject: string;
  message: string;
}

export interface QuickContactData {
  email?: string;
  subject?: string;
  message?: string;
}

/**
 * Abre o cliente de email padrão com dados pré-preenchidos
 */
export const openEmailClient = (data: QuickContactData) => {
  const to = data.email || 'cplp@raras.org.br';
  const subject = encodeURIComponent(data.subject || 'Contato via CPLP-Raras');
  const body = encodeURIComponent(data.message || '');
  
  const mailtoLink = `mailto:${to}?subject=${subject}&body=${body}`;
  
  // Abre o cliente de email padrão
  window.location.href = mailtoLink;
};

/**
 * Envia formulário de contato via API ou abre cliente de email como fallback
 */
export const sendContactForm = async (formData: ContactFormData): Promise<{ success: boolean; message: string; emailSent?: boolean }> => {
  console.log('🚀 sendContactForm chamada com dados:', formData);
  
  try {
    // Primeiro, tenta enviar via API
    console.log('📡 Fazendo requisição para /api/contact...');
    const response = await fetch('/api/contact', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(formData),
    });

    console.log('📡 Resposta da API - Status:', response.status);
    const result = await response.json();
    console.log('📡 Resposta da API - Dados:', result);

    if (response.ok && result.success) {
      return {
        success: true,
        message: result.message,
        emailSent: result.emailSent
      };
    }

    // Se a API falhar mas retornar fallback info
    if (result.fallbackInfo) {
      openEmailClient({
        email: result.fallbackInfo.email,
        subject: result.fallbackInfo.subject,
        message: result.fallbackInfo.body
      });
      
      return {
        success: true,
        message: 'Abrindo seu cliente de email...',
        emailSent: false
      };
    }

    throw new Error(result.error || 'Erro na API');
  } catch (error) {
    console.log('Usando fallback de email client:', error);
    
    // Fallback: abre cliente de email com dados do formulário
    const emailBody = formatFormDataForEmail(formData);
    
    openEmailClient({
      email: 'cplp@raras.org.br',
      subject: `[CPLP-Raras] ${formData.subject}`,
      message: emailBody,
    });
    
    return {
      success: true,
      message: 'Abrindo seu cliente de email como alternativa...',
      emailSent: false
    };
  }
};

/**
 * Formata dados do formulário para email
 */
const formatFormDataForEmail = (data: ContactFormData): string => {
  return `
Mensagem enviada via formulário CPLP-Raras

Nome: ${data.name}
Email: ${data.email}
Instituição: ${data.institution || 'Não informado'}
País: ${data.country || 'Não informado'}
Assunto: ${data.subject}

Mensagem:
${data.message}

---
Enviado em: ${new Date().toLocaleString('pt-BR')}
  `.trim();
};

/**
 * Contatos específicos por tipo ou área
 */
export const getSpecificContact = (type: string): QuickContactData => {
  const contacts: Record<string, QuickContactData> = {
    'gpt-educativo': {
      email: 'cplp@raras.org.br',
      subject: 'Dúvidas sobre GPT Educativo CPLP-Raras',
      message: 'Olá! Tenho dúvidas sobre o GPT Educativo CPLP-Raras.\n\nMinha dúvida é:\n'
    },
    'colaboracao': {
      email: 'cplp@raras.org.br',
      subject: 'Interesse em colaboração - CPLP-Raras',
      message: 'Olá! Tenho interesse em colaborar com o projeto CPLP-Raras.\n\nMinha área de atuação:\nComo posso contribuir:\n'
    },
    'suporte': {
      email: 'cplp@raras.org.br',
      subject: 'Suporte técnico - CPLP-Raras',
      message: 'Olá! Preciso de suporte técnico.\n\nDescrição do problema:\n'
    },
    'imprensa': {
      email: 'cplp@raras.org.br',
      subject: 'Contato de imprensa - CPLP-Raras',
      message: 'Olá! Sou jornalista e gostaria de informações sobre o projeto CPLP-Raras.\n\nVeículo:\nPauta:\n'
    },
    'pesquisa': {
      email: 'cplp@raras.org.br',
      subject: 'Interesse em pesquisa - CPLP-Raras',
      message: 'Olá! Sou pesquisador(a) e tenho interesse no projeto CPLP-Raras.\n\nInstituição:\nÁrea de pesquisa:\n'
    }
  };

  return contacts[type] || contacts['colaboracao'];
};

/**
 * Valida dados do formulário
 */
export const validateFormData = (data: ContactFormData): string[] => {
  const errors: string[] = [];

  if (!data.name?.trim()) {
    errors.push('Nome é obrigatório');
  }

  if (!data.email?.trim()) {
    errors.push('Email é obrigatório');
  } else if (!isValidEmail(data.email)) {
    errors.push('Email inválido');
  }

  if (!data.subject?.trim()) {
    errors.push('Assunto é obrigatório');
  }

  if (!data.message?.trim()) {
    errors.push('Mensagem é obrigatória');
  }

  return errors;
};

/**
 * Valida formato de email
 */
const isValidEmail = (email: string): boolean => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

/**
 * Utilitário para criar links de contato rápido
 */
export const createQuickContactLink = (type: string, customMessage?: string): string => {
  const contact = getSpecificContact(type);
  const message = customMessage || contact.message || '';
  
  const subject = encodeURIComponent(contact.subject || 'Contato via CPLP-Raras');
  const body = encodeURIComponent(message);
  
  return `mailto:${contact.email}?subject=${subject}&body=${body}`;
};

/**
 * Objeto principal do serviço de email
 * Centraliza todas as funcionalidades de email
 */
export const emailService = {
  sendContactForm,
  openEmailClient,
  createQuickContactLink,
};

// Export default para compatibilidade
export default emailService;
