'use client'

import { useHPOStore } from '@/store/hpoStore'
import { useState, useEffect } from 'react'
import { useForm } from 'react-hook-form'
import { HPOTerm, Translation } from '@/types/hpo'

interface TranslationFormData {
  label_pt: string
  definition_pt: string
  synonyms_pt: string
  likert_score: number
  comments: string
}

export default function TranslatePage() {
  const { 
    terms, 
    translations, 
    setTerms,
    addTranslation, 
    getTranslationsByTerm, 
    currentTranslator 
  } = useHPOStore()
  
  const [selectedTerm, setSelectedTerm] = useState<HPOTerm | null>(null)
  const [filter, setFilter] = useState('')
  const [statusFilter, setStatusFilter] = useState<string>('all')
  const [currentPage, setCurrentPage] = useState(1)
  const itemsPerPage = 10
  
  const { register, handleSubmit, reset, watch } = useForm<TranslationFormData>()
  
  // Carregar dados se não existirem
  useEffect(() => {
    if (terms.length === 0) {
      fetch('/hpo-sample.json')
        .then(res => res.json())
        .then(data => setTerms(data.terms))
        .catch(err => console.error('Erro ao carregar dados:', err))
    }
  }, [terms.length, setTerms])
  
  // Filtrar termos
  const filteredTerms = terms.filter(term => {
    const matchesFilter = term.id.toLowerCase().includes(filter.toLowerCase()) ||
                         term.label_en.toLowerCase().includes(filter.toLowerCase())
    const matchesStatus = statusFilter === 'all' || term.status === statusFilter
    return matchesFilter && matchesStatus
  })
  
  // Paginação
  const totalPages = Math.ceil(filteredTerms.length / itemsPerPage)
  const paginatedTerms = filteredTerms.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  )
  
  const onSubmit = (data: TranslationFormData) => {
    if (!selectedTerm) return
    
    const translation: Translation = {
      id: `trans_${Date.now()}_${Math.random()}`,
      term_id: selectedTerm.id,
      translator: currentTranslator,
      translation_date: new Date().toISOString(),
      label_pt: data.label_pt,
      definition_pt: data.definition_pt,
      synonyms_pt: data.synonyms_pt.split(',').map(s => s.trim()).filter(s => s),
      likert_score: data.likert_score,
      comments: data.comments,
      is_final: false
    }
    
    addTranslation(translation)
    setSelectedTerm(null)
    reset()
    alert('Tradução salva com sucesso!')
  }
  
  const getStatusBadge = (status: string) => {
    const baseClasses = "px-2 py-1 rounded-full text-xs font-medium"
    switch (status) {
      case 'candidate':
        return `${baseClasses} bg-gray-100 text-gray-800`
      case 'under_review':
        return `${baseClasses} bg-yellow-100 text-yellow-800`
      case 'official':
        return `${baseClasses} bg-green-100 text-green-800`
      default:
        return baseClasses
    }
  }
  
  return (
    <div className="max-w-7xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">
          📝 Interface de Tradução Colaborativa
        </h1>
        <p className="text-gray-600">
          Traduza e revise termos da HPO para português. Cada termo deve ser revisado por pelo menos dois especialistas.
        </p>
      </div>
      
      {/* Filtros */}
      <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6 mb-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Buscar por código ou termo
            </label>
            <input
              type="text"
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
              className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="HP:0000001 ou Seizure"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Status
            </label>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="all">Todos</option>
              <option value="candidate">Candidato</option>
              <option value="under_review">Em Revisão</option>
              <option value="official">Oficial</option>
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Tradutor Atual
            </label>
            <div className="px-3 py-2 bg-gray-100 rounded-md text-gray-700">
              {currentTranslator}
            </div>
          </div>
        </div>
      </div>
      
      {/* Tabela de termos */}
      <div className="bg-white rounded-lg shadow-md border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Código HP
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Label (EN)
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Sugestão IA
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Revisões
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Ações
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {paginatedTerms.map((term) => {
                const termTranslations = getTranslationsByTerm(term.id)
                return (
                  <tr key={term.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-mono text-blue-600">
                      {term.id}
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-900 max-w-xs">
                      <div className="font-medium">{term.label_en}</div>
                      <div className="text-gray-500 truncate">{term.definition_en}</div>
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-700 max-w-xs">
                      <div className="font-medium text-green-600">{term.ai_label_pt}</div>
                      <div className="text-gray-500 truncate">{term.ai_definition_pt}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={getStatusBadge(term.status)}>
                        {term.status === 'candidate' ? 'Candidato' :
                         term.status === 'under_review' ? 'Em Revisão' : 'Oficial'}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {termTranslations.length} revisão(ões)
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                      <button
                        onClick={() => setSelectedTerm(term)}
                        className="text-blue-600 hover:text-blue-900 mr-4"
                      >
                        Traduzir
                      </button>
                      {termTranslations.length > 0 && (
                        <button className="text-green-600 hover:text-green-900">
                          Ver Histórico
                        </button>
                      )}
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
        
        {/* Paginação */}
        <div className="bg-white px-4 py-3 flex items-center justify-between border-t border-gray-200 sm:px-6">
          <div className="flex-1 flex justify-between sm:hidden">
            <button
              onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
              disabled={currentPage === 1}
              className="relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 disabled:opacity-50"
            >
              Anterior
            </button>
            <button
              onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
              disabled={currentPage === totalPages}
              className="ml-3 relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 disabled:opacity-50"
            >
              Próximo
            </button>
          </div>
          <div className="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between">
            <div>
              <p className="text-sm text-gray-700">
                Mostrando <span className="font-medium">{(currentPage - 1) * itemsPerPage + 1}</span> a{' '}
                <span className="font-medium">
                  {Math.min(currentPage * itemsPerPage, filteredTerms.length)}
                </span>{' '}
                de <span className="font-medium">{filteredTerms.length}</span> resultados
              </p>
            </div>
            <div>
              <nav className="relative z-0 inline-flex rounded-md shadow-sm -space-x-px">
                <button
                  onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                  disabled={currentPage === 1}
                  className="relative inline-flex items-center px-2 py-2 rounded-l-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50 disabled:opacity-50"
                >
                  Anterior
                </button>
                {Array.from({ length: totalPages }, (_, i) => i + 1).map(page => (
                  <button
                    key={page}
                    onClick={() => setCurrentPage(page)}
                    className={`relative inline-flex items-center px-4 py-2 border text-sm font-medium ${
                      currentPage === page
                        ? 'z-10 bg-blue-50 border-blue-500 text-blue-600'
                        : 'bg-white border-gray-300 text-gray-500 hover:bg-gray-50'
                    }`}
                  >
                    {page}
                  </button>
                ))}
                <button
                  onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                  disabled={currentPage === totalPages}
                  className="relative inline-flex items-center px-2 py-2 rounded-r-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50 disabled:opacity-50"
                >
                  Próximo
                </button>
              </nav>
            </div>
          </div>
        </div>
      </div>
      
      {/* Modal de tradução */}
      {selectedTerm && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-5 border w-11/12 max-w-4xl shadow-lg rounded-md bg-white">
            <div className="mt-3">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-medium text-gray-900">
                  Traduzir Termo: {selectedTerm.id}
                </h3>
                <button
                  onClick={() => setSelectedTerm(null)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  ✕
                </button>
              </div>
              
              <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
                {/* Termo original */}
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-medium text-gray-900 mb-2">Termo Original (Inglês)</h4>
                  <div className="space-y-2">
                    <div>
                      <span className="font-medium">Label:</span> {selectedTerm.label_en}
                    </div>
                    <div>
                      <span className="font-medium">Definição:</span> {selectedTerm.definition_en}
                    </div>
                    {selectedTerm.synonyms_en.length > 0 && (
                      <div>
                        <span className="font-medium">Sinônimos:</span> {selectedTerm.synonyms_en.join(', ')}
                      </div>
                    )}
                  </div>
                </div>
                
                {/* Sugestão da IA */}
                <div className="bg-green-50 p-4 rounded-lg">
                  <h4 className="font-medium text-gray-900 mb-2">Sugestão da IA</h4>
                  <div className="space-y-2">
                    <div>
                      <span className="font-medium">Label:</span> {selectedTerm.ai_label_pt}
                    </div>
                    <div>
                      <span className="font-medium">Definição:</span> {selectedTerm.ai_definition_pt}
                    </div>
                  </div>
                </div>
                
                {/* Campos de tradução */}
                <div className="grid grid-cols-1 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Label em Português *
                    </label>
                    <input
                      {...register('label_pt', { required: true })}
                      type="text"
                      className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="Digite a tradução do label"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Definição em Português *
                    </label>
                    <textarea
                      {...register('definition_pt', { required: true })}
                      rows={4}
                      className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="Digite a tradução da definição"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Sinônimos em Português (separados por vírgula)
                    </label>
                    <input
                      {...register('synonyms_pt')}
                      type="text"
                      className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="sinônimo1, sinônimo2, sinônimo3"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Avaliação da Tradução IA (1-5) *
                    </label>
                    <select
                      {...register('likert_score', { required: true, valueAsNumber: true })}
                      className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="">Selecione uma nota</option>
                      <option value={1}>1 - Muito ruim</option>
                      <option value={2}>2 - Ruim</option>
                      <option value={3}>3 - Regular</option>
                      <option value={4}>4 - Boa</option>
                      <option value={5}>5 - Excelente</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Comentários
                    </label>
                    <textarea
                      {...register('comments')}
                      rows={3}
                      className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="Comentários sobre a tradução ou sugestões"
                    />
                  </div>
                </div>
                
                {/* Botões */}
                <div className="flex justify-end space-x-4 pt-4">
                  <button
                    type="button"
                    onClick={() => setSelectedTerm(null)}
                    className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
                  >
                    Salvar Revisão
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
