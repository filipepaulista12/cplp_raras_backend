# Dados CPLP-Raras

## Descrição
Este diretório contém dados coletados automaticamente sobre doenças raras para o projeto CPLP-Raras.

## Arquivos

### gard_data.json
- **Fonte**: GARD (Genetic and Rare Diseases Information Center) - NIH
- **Conteúdo**: Informações sobre doenças raras e jornadas diagnósticas
- **URL**: https://rarediseases.info.nih.gov

### pcdt_data.json
- **Fonte**: PCDT (Protocolos Clínicos e Diretrizes Terapêuticas) - Ministério da Saúde
- **Conteúdo**: Protocolos oficiais brasileiros para tratamento de doenças
- **URL**: https://www.gov.br/saude/pt-br/assuntos/pcdt

### research_data.json
- **Conteúdo**: Dados consolidados para pesquisa
- **Uso**: Estatísticas, métricas e informações aggregadas

## Atualização
Os dados foram coletados em: 02/08/2025 16:50:42

## Uso no Site
Estes dados são utilizados pelos componentes React do site para:
- Exibir informações sobre doenças raras
- Mostrar recursos disponíveis
- Apresentar estatísticas de pesquisa
- Fornecer links para protocolos oficiais

## Estrutura TypeScript
Para usar estes dados no TypeScript, consulte as interfaces em `src/types/`.

## Responsabilidade
Dados coletados respeitando as políticas de uso dos sites originais.
Sempre verificar informações médicas com profissionais qualificados.
