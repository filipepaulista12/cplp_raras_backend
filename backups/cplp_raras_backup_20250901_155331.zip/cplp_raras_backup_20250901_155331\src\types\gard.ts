// =====================================================================================
// TIPOS TYPESCRIPT PARA O SISTEMA GARD BRASILEIRO
// =====================================================================================
// Estruturas de dados correspondentes ao schema SQL
// Compatível com Prisma, Drizzle, ou uso direto com APIs
// =====================================================================================

// =====================================================================================
// 1. TIPOS BÁSICOS E ENUMS
// =====================================================================================

export type InfoStatus = 
  | 'draft'
  | 'under_review' 
  | 'reviewed'
  | 'published'
  | 'needs_update'
  | 'archived';

export type PrevalenceType = 
  | 'point'
  | 'birth'
  | 'lifetime'
  | 'unknown';

export type StudyType = 
  | 'case_report'
  | 'clinical_trial'
  | 'review'
  | 'cohort_study'
  | 'case_control'
  | 'systematic_review'
  | 'meta_analysis';

export type SpecialistType = 
  | 'doctor'
  | 'center'
  | 'clinic'
  | 'hospital'
  | 'research_institute';

export type OrganizationType = 
  | 'patient_association'
  | 'research_foundation'
  | 'government_agency'
  | 'healthcare_provider'
  | 'advocacy_group';

export type AvailabilityStatus = 
  | 'available'
  | 'restricted'
  | 'unavailable'
  | 'unknown';

// =====================================================================================
// 2. INTERFACES PRINCIPAIS
// =====================================================================================

export interface DiseaseCategory {
  id: number;
  code: string;
  name_pt: string;
  name_en: string;
  description?: string;
  color_hex?: string;
  icon?: string;
  sort_order: number;
  created_at: Date;
  updated_at: Date;
}

export interface CPLPCountry {
  id: number;
  code: string;
  name: string;
  flag_emoji?: string;
  population?: number;
  healthcare_system?: string;
  rare_disease_policy?: string;
  created_at: Date;
}

export interface InheritancePattern {
  id: number;
  code: string;
  name_pt: string;
  name_en: string;
  description?: string;
  created_at: Date;
}

// =====================================================================================
// 3. ESTRUTURA PRINCIPAL - DOENÇA
// =====================================================================================

export interface Disease {
  id: string;
  gard_br_id: string;
  gard_original_id?: string;
  
  // Identificação
  name_pt: string;
  name_en?: string;
  synonyms: string[];
  
  // Classificação
  category_id?: number;
  category?: DiseaseCategory;
  subcategory?: string;
  
  // Códigos de referência
  orpha_code?: string;
  icd10_codes: string[];
  icd11_codes: string[];
  omim_codes: string[];
  
  // Informações epidemiológicas
  prevalence_value?: string;
  prevalence_type: PrevalenceType;
  age_of_onset?: string;
  
  // Genética
  inheritance_pattern_id?: number;
  inheritance_pattern?: InheritancePattern;
  genes_involved: string[];
  chromosomal_location?: string;
  
  // Metadados
  info_status: InfoStatus;
  quality_score: number;
  last_medical_review?: Date;
  next_review_due?: Date;
  
  // Auditoria
  created_at: Date;
  updated_at: Date;
  created_by?: string;
  updated_by?: string;
  
  // Relacionamentos
  content?: DiseaseContent;
  clinical_trials?: DiseaseClinicalTrial[];
  support_organizations?: DiseaseSupportOrganization[];
  publications?: DiseasePublication[];
  specialists?: DiseaseSpecialist[];
  epidemiology?: DiseaseEpidemiologyCPLP[];
  medications_availability?: DiseaseMedicationsAvailability[];
  references?: DiseaseReference[];
}

// =====================================================================================
// 4. CONTEÚDO DETALHADO
// =====================================================================================

export interface DiseaseContent {
  id: string;
  disease_id: string;
  
  // Conteúdo principal
  summary?: string;
  detailed_description?: string;
  
  // Seções estruturadas
  symptoms: string[];
  signs: string[];
  causes?: string;
  pathophysiology?: string;
  
  // Diagnóstico
  diagnostic_criteria: string[];
  diagnostic_tests: string[];
  differential_diagnosis: string[];
  
  // Tratamento
  treatment_options: string[];
  management_guidelines?: string;
  medications: string[];
  therapies: string[];
  
  // Prognóstico
  prognosis?: string;
  life_expectancy?: string;
  quality_of_life_impact?: string;
  
  // Recursos
  patient_resources: string[];
  family_resources: string[];
  professional_resources: string[];
  
  // Metadados
  content_version: number;
  language_code: string;
  medical_reviewer?: string;
  reviewed_at?: Date;
  
  created_at: Date;
  updated_at: Date;
}

// =====================================================================================
// 5. RELACIONAMENTOS E ASSOCIAÇÕES
// =====================================================================================

export interface DiseaseClinicalTrial {
  id: string;
  disease_id: string;
  
  trial_id: string;
  title: string;
  description?: string;
  status: string;
  phase?: string;
  location?: string;
  country_code?: string;
  contact_info?: string;
  
  start_date?: Date;
  estimated_completion?: Date;
  last_updated: Date;
  
  source?: string;
  source_url?: string;
}

export interface DiseaseSupportOrganization {
  id: string;
  disease_id: string;
  
  name: string;
  description?: string;
  organization_type: OrganizationType;
  
  contact_info?: ContactInfo;
  website?: string;
  social_media?: SocialMediaInfo;
  
  country_id?: number;
  country?: CPLPCountry;
  languages: string[];
  
  services_offered: string[];
  target_audience?: string;
  
  verified: boolean;
  last_verified?: Date;
  
  created_at: Date;
  updated_at: Date;
}

export interface DiseasePublication {
  id: string;
  disease_id: string;
  
  pubmed_id?: string;
  doi?: string;
  title: string;
  authors: string[];
  journal?: string;
  publication_date?: Date;
  abstract?: string;
  
  study_type?: StudyType;
  evidence_level?: number;
  language_code?: string;
  
  is_open_access: boolean;
  full_text_url?: string;
  
  created_at: Date;
}

export interface DiseaseSpecialist {
  id: string;
  disease_id: string;
  
  specialist_type: SpecialistType;
  name: string;
  specialty?: string;
  
  contact_info?: ContactInfo;
  address?: AddressInfo;
  country_id?: number;
  country?: CPLPCountry;
  
  accepts_new_patients: boolean;
  languages: string[];
  telemedicine_available: boolean;
  
  verification_status: string;
  verified_by?: string;
  verified_at?: Date;
  
  created_at: Date;
  updated_at: Date;
}

// =====================================================================================
// 6. DADOS REGIONAIS CPLP
// =====================================================================================

export interface DiseaseEpidemiologyCPLP {
  id: string;
  disease_id: string;
  country_id: number;
  country?: CPLPCountry;
  
  estimated_cases?: number;
  prevalence_per_100k?: number;
  incidence_per_100k_year?: number;
  
  data_source?: string;
  data_quality?: 'high' | 'medium' | 'low' | 'estimated';
  collection_date?: Date;
  
  notes?: string;
  
  created_at: Date;
  updated_at: Date;
}

export interface DiseaseMedicationsAvailability {
  id: string;
  disease_id: string;
  country_id: number;
  country?: CPLPCountry;
  
  medication_name: string;
  generic_name?: string;
  
  availability_status: AvailabilityStatus;
  regulatory_status?: string;
  reimbursement_status?: string;
  
  cost_info?: string;
  access_conditions: string[];
  prescription_requirements: string[];
  
  last_updated: Date;
  data_source?: string;
}

// =====================================================================================
// 7. AUDITORIA E VERSIONING
// =====================================================================================

export interface DiseaseAuditLog {
  id: string;
  disease_id: string;
  
  action: 'create' | 'update' | 'delete' | 'publish' | 'review';
  table_affected: string;
  old_values?: Record<string, any>;
  new_values?: Record<string, any>;
  
  changed_by?: string;
  changed_at: Date;
  change_reason?: string;
  
  ip_address?: string;
  user_agent?: string;
}

export interface DiseaseReference {
  id: string;
  disease_id: string;
  
  reference_type: 'guideline' | 'study' | 'database' | 'expert_opinion';
  title: string;
  authors: string[];
  source?: string;
  url?: string;
  publication_date?: Date;
  access_date?: Date;
  
  reliability_score?: number; // 1-5
  notes?: string;
  
  created_at: Date;
}

// =====================================================================================
// 8. TIPOS AUXILIARES
// =====================================================================================

export interface ContactInfo {
  email?: string;
  phone?: string;
  fax?: string;
  website?: string;
  contact_person?: string;
  office_hours?: string;
}

export interface SocialMediaInfo {
  facebook?: string;
  twitter?: string;
  instagram?: string;
  linkedin?: string;
  youtube?: string;
}

export interface AddressInfo {
  street?: string;
  city?: string;
  state?: string;
  postal_code?: string;
  country?: string;
  coordinates?: {
    lat: number;
    lng: number;
  };
}

// =====================================================================================
// 9. TIPOS PARA APIs E REQUESTS
// =====================================================================================

export interface DiseaseSearchParams {
  search_term?: string;
  category_filter?: number;
  country_filter?: number;
  inheritance_filter?: number;
  status_filter?: InfoStatus;
  letter_filter?: string;
  limit?: number;
  offset?: number;
}

export interface DiseaseSearchResult {
  disease_id: string;
  gard_br_id: string;
  name_pt: string;
  category_name?: string;
  prevalence_value?: string;
  rank?: number;
}

export interface DiseaseSearchResponse {
  diseases: DiseaseSearchResult[];
  total_count: number;
  page: number;
  per_page: number;
  total_pages: number;
  has_more: boolean;
}

export interface DiseaseDetailResponse {
  disease: Disease;
  related_diseases?: Disease[];
  similar_symptoms?: Disease[];
}

// =====================================================================================
// 10. TIPOS PARA FORMS E VALIDAÇÃO
// =====================================================================================

export interface CreateDiseaseRequest {
  name_pt: string;
  name_en?: string;
  synonyms?: string[];
  category_id?: number;
  orpha_code?: string;
  icd10_codes?: string[];
  prevalence_value?: string;
  inheritance_pattern_id?: number;
  genes_involved?: string[];
}

export interface UpdateDiseaseRequest extends Partial<CreateDiseaseRequest> {
  id: string;
}

export interface CreateDiseaseContentRequest {
  disease_id: string;
  summary?: string;
  symptoms?: string[];
  causes?: string;
  diagnostic_criteria?: string[];
  treatment_options?: string[];
  prognosis?: string;
  language_code?: string;
}

// =====================================================================================
// 11. TIPOS PARA ESTATÍSTICAS E DASHBOARD
// =====================================================================================

export interface DiseaseStatistics {
  total_diseases: number;
  by_category: Record<string, number>;
  by_country: Record<string, number>;
  by_status: Record<InfoStatus, number>;
  recent_additions: number;
  needs_review: number;
}

export interface QualityMetrics {
  diseases_with_content: number;
  reviewed_diseases: number;
  diseases_with_specialists: number;
  diseases_with_trials: number;
  average_quality_score: number;
}

// =====================================================================================
// 12. EXPORT DEFAULT TYPES
// =====================================================================================

export type {
  // Core entities
  Disease as GARDDisease,
  DiseaseContent as GARDDiseaseContent,
  DiseaseCategory as GARDCategory,
  
  // Search and API
  DiseaseSearchParams as GARDSearchParams,
  DiseaseSearchResponse as GARDSearchResponse,
  DiseaseDetailResponse as GARDDetailResponse,
  
  // Statistics
  DiseaseStatistics as GARDStatistics,
  QualityMetrics as GARDQualityMetrics
};

// =====================================================================================
// 13. CONSTANTES ÚTEIS
// =====================================================================================

export const DISEASE_CATEGORIES = {
  BIRTH_DEFECTS: 'birth_defects',
  BLOOD_DISEASES: 'blood_diseases',
  CANCER: 'cancer',
  ENDOCRINE: 'endocrine',
  GASTROINTESTINAL: 'gastrointestinal',
  GENETIC: 'genetic',
  INFECTIOUS: 'infectious',
  KIDNEY: 'kidney',
  NEUROLOGICAL: 'neurological',
  RESPIRATORY: 'respiratory',
  SKIN: 'skin',
  URINARY_REPRODUCTIVE: 'urinary_reproductive'
} as const;

export const INHERITANCE_PATTERNS = {
  AUTOSOMAL_DOMINANT: 'autosomal_dominant',
  AUTOSOMAL_RECESSIVE: 'autosomal_recessive',
  X_LINKED: 'x_linked',
  Y_LINKED: 'y_linked',
  MITOCHONDRIAL: 'mitochondrial',
  COMPLEX: 'complex',
  SPORADIC: 'sporadic',
  UNKNOWN: 'unknown'
} as const;

export const CPLP_COUNTRIES = {
  BRAZIL: 'BRA',
  PORTUGAL: 'PRT',
  ANGOLA: 'AGO',
  MOZAMBIQUE: 'MOZ',
  CAPE_VERDE: 'CPV',
  GUINEA_BISSAU: 'GNB',
  SAO_TOME: 'STP',
  TIMOR_LESTE: 'TLS',
  EQUATORIAL_GUINEA: 'GNQ'
} as const;

export const INFO_STATUS_LABELS = {
  draft: 'Rascunho',
  under_review: 'Em Revisão',
  reviewed: 'Revisado',
  published: 'Publicado',
  needs_update: 'Precisa Atualização',
  archived: 'Arquivado'
} as const;

// =====================================================================================
// COMENTÁRIOS FINAIS
// =====================================================================================

/*
Este arquivo de tipos TypeScript foi criado para:

1. **Compatibilidade Total**: Mapeia exatamente o schema SQL criado
2. **Type Safety**: Garante tipagem forte em toda a aplicação
3. **API Ready**: Inclui tipos para requests/responses de API
4. **Extensibilidade**: Estrutura preparada para futuras expansões
5. **Documentação**: Tipos auto-documentados para desenvolvimento
6. **Validação**: Base para schemas de validação (Zod, Joi, etc.)

Uso recomendado:
- Importar tipos específicos conforme necessário
- Usar com ORMs como Prisma ou Drizzle
- Aplicar em APIs Next.js
- Validar formulários e inputs
- Gerar documentação automática

Exemplo de uso:
```typescript
import { Disease, DiseaseSearchParams, DiseaseSearchResponse } from '@/types/gard';

async function searchDiseases(params: DiseaseSearchParams): Promise<DiseaseSearchResponse> {
  // Implementation
}
```
*/
