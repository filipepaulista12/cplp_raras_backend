'use client';

import { useState, useCallback, useEffect } from 'react';

interface FeedbackData {
  id: number;
  type: 'suggestion' | 'rating' | 'error';
  rating?: number;
  category: string;
  message: string;
  email?: string;
  page: string;
  userAgent: string;
  timestamp: string;
}

interface InteractionData {
  totalVisits: number;
  totalFeedback: number;
  uniqueVisitors: number;
  feedbackByType: Record<string, number>;
  feedbackByCategory: Record<string, number>;
  averageRating: number;
  recentFeedback: FeedbackData[];
}

export function useInteractionData() {
  const [data, setData] = useState<InteractionData>({
    totalVisits: 0,
    totalFeedback: 0,
    uniqueVisitors: 0,
    feedbackByType: {},
    feedbackByCategory: {},
    averageRating: 0,
    recentFeedback: []
  });

  const loadData = useCallback(() => {
    if (typeof window === 'undefined') return;

    try {
      // Carregar dados do localStorage
      const totalVisits = parseInt(localStorage.getItem('cplp-visits') || '0');
      const uniqueVisitors = parseInt(localStorage.getItem('cplp-unique-visitors') || '0');
      const feedbackData = JSON.parse(localStorage.getItem('cplp-feedback') || '[]') as FeedbackData[];
      
      // Processar dados de feedback
      const feedbackByType: Record<string, number> = {};
      const feedbackByCategory: Record<string, number> = {};
      let totalRating = 0;
      let ratingCount = 0;

      feedbackData.forEach(feedback => {
        feedbackByType[feedback.type] = (feedbackByType[feedback.type] || 0) + 1;
        feedbackByCategory[feedback.category] = (feedbackByCategory[feedback.category] || 0) + 1;
        
        if (feedback.rating) {
          totalRating += feedback.rating;
          ratingCount++;
        }
      });

      const averageRating = ratingCount > 0 ? totalRating / ratingCount : 0;
      const recentFeedback = feedbackData
        .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
        .slice(0, 5);

      setData({
        totalVisits,
        totalFeedback: feedbackData.length,
        uniqueVisitors,
        feedbackByType,
        feedbackByCategory,
        averageRating,
        recentFeedback
      });
    } catch (error) {
      console.error('Erro ao carregar dados de interação:', error);
    }
  }, []);

  const exportData = useCallback(() => {
    const allData = {
      visits: data.totalVisits,
      uniqueVisitors: data.uniqueVisitors,
      feedback: JSON.parse(localStorage.getItem('cplp-feedback') || '[]'),
      exportedAt: new Date().toISOString(),
      stats: {
        feedbackByType: data.feedbackByType,
        feedbackByCategory: data.feedbackByCategory,
        averageRating: data.averageRating
      }
    };

    // Criar arquivo para download
    const dataStr = JSON.stringify(allData, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    
    const exportFileDefaultName = `cplp-raras-analytics-${new Date().toISOString().split('T')[0]}.json`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  }, [data]);

  const clearData = useCallback(() => {
    if (confirm('⚠️ Tem certeza que deseja limpar todos os dados de analytics?\n\nEsta ação não pode ser desfeita.')) {
      localStorage.removeItem('cplp-visits');
      localStorage.removeItem('cplp-unique-visitors');
      localStorage.removeItem('cplp-feedback');
      localStorage.removeItem('cplp-feedback-count');
      localStorage.removeItem('cplp-last-visit');
      loadData();
    }
  }, [loadData]);

  useEffect(() => {
    loadData();
    
    // Recarregar dados a cada 10 segundos
    const interval = setInterval(loadData, 10000);
    
    return () => clearInterval(interval);
  }, [loadData]);

  return {
    data,
    loadData,
    exportData,
    clearData
  };
}

// Hook para gerenciar feedback
export function useFeedback() {
  const [isSubmitting, setIsSubmitting] = useState(false);

  const submitFeedback = useCallback(async (feedbackData: Omit<FeedbackData, 'id' | 'timestamp'>): Promise<boolean> => {
    setIsSubmitting(true);
    
    try {
      const feedback: FeedbackData = {
        ...feedbackData,
        id: Date.now(),
        timestamp: new Date().toISOString()
      };

      // Salvar no localStorage
      const existingFeedback = JSON.parse(localStorage.getItem('cplp-feedback') || '[]');
      existingFeedback.push(feedback);
      localStorage.setItem('cplp-feedback', JSON.stringify(existingFeedback));

      // Incrementar contador de feedback
      const feedbackCount = localStorage.getItem('cplp-feedback-count') || '0';
      localStorage.setItem('cplp-feedback-count', String(parseInt(feedbackCount) + 1));

      return true;
    } catch (error) {
      console.error('Erro ao enviar feedback:', error);
      return false;
    } finally {
      setIsSubmitting(false);
    }
  }, []);

  return {
    submitFeedback,
    isSubmitting
  };
}
