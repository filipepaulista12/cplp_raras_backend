import Link from 'next/link';
import TopShare from '@/components/TopShare';

export default function GT1() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Breadcrumb */}
      <div className="bg-white border-b">
        <div className="mx-auto max-w-7xl px-4 py-4 sm:px-6 lg:px-8">
          <nav className="flex" aria-label="Breadcrumb">
            <ol className="inline-flex items-center space-x-1 md:space-x-3">
              <li className="inline-flex items-center">
                <Link href="/" className="text-blue-600 hover:text-blue-800">
                  Início
                </Link>
              </li>
              <li>
                <div className="flex items-center">
                  <span className="mx-2 text-gray-400">/</span>
                  <Link href="/grupos-trabalho" className="text-blue-600 hover:text-blue-800">
                    Grupos de Trabalho
                  </Link>
                </div>
              </li>
              <li aria-current="page">
                <div className="flex items-center">
                  <span className="mx-2 text-gray-400">/</span>
                  <span className="text-gray-500">GT1 - Mapeamento de Recursos</span>
                </div>
              </li>
            </ol>
          </nav>
        </div>
      </div>

      <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6 lg:px-8">
        
        {/* Compartilhamento no topo */}
        <TopShare 
          title="GT1 - Mapeamento de Recursos em Doenças Raras"
          description="Levantamento sistemático de estruturas e recursos para doenças raras nos países da CPLP"
        />
        
        {/* Header Compacto */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">
            GT1 – Mapeamento de Recursos em Doenças Raras
          </h1>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Levantamento sistemático de estruturas, recursos e maturidade dos sistemas de saúde 
            para doenças raras nos países da CPLP.
          </p>
        </div>

        {/* Objetivo e Metodologia */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
          <div className="bg-white rounded-xl shadow-sm p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-4 flex items-center">
              <span className="text-2xl mr-3">🎯</span>
              Objetivo Principal
            </h2>
            <p className="text-gray-600 leading-relaxed">
              Identificar e catalogar centros especializados, profissionais, recursos diagnósticos, 
              terapias disponíveis e avaliar a maturidade dos sistemas de saúde para doenças raras 
              em todos os países da Comunidade dos Países de Língua Portuguesa.
            </p>
          </div>

          <div className="bg-white rounded-xl shadow-sm p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-4 flex items-center">
              <span className="text-2xl mr-3">🔬</span>
              Metodologia
            </h2>
            <p className="text-gray-600 leading-relaxed">
              Coleta estruturada de dados através de formulários REDCap, parcerias com instituições 
              locais, técnica snowball para expansão da rede e validação dos dados através de 
              múltiplas fontes em cada país participante.
            </p>
          </div>
        </div>

        {/* Atividades de Mapeamento */}
        <div className="bg-white rounded-xl shadow-sm p-8 mb-8">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-semibold text-gray-900">
              Atividades de Mapeamento
            </h2>
            <Link
              href="/grupos-trabalho/gt1/dados"
              className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors"
            >
              Ver Todos os Dados Coletados
            </Link>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            
            {/* Atividade 1 */}
            <div className="border border-gray-200 rounded-lg p-5 hover:shadow-md transition-shadow">
              <div className="flex items-center mb-3">
                <div className="bg-blue-600 text-white rounded-full w-7 h-7 flex items-center justify-center text-sm font-bold mr-3">
                  1
                </div>
                <h3 className="font-semibold text-gray-900 text-sm">Centros Especializados</h3>
              </div>
              <p className="text-gray-600 text-xs mb-4">
                Hospitais, clínicas e centros de pesquisa especializados em doenças raras.
              </p>
              <div className="text-center">
                <span className="block w-full bg-gray-200 text-gray-700 text-center px-3 py-2 rounded text-xs font-medium">
                  Ver Detalhes em Breve
                </span>
              </div>
            </div>

            {/* Atividade 2 */}
            <div className="border border-gray-200 rounded-lg p-5 hover:shadow-md transition-shadow">
              <div className="flex items-center mb-3">
                <div className="bg-green-600 text-white rounded-full w-7 h-7 flex items-center justify-center text-sm font-bold mr-3">
                  2
                </div>
                <h3 className="font-semibold text-gray-900 text-sm">Profissionais</h3>
              </div>
              <p className="text-gray-600 text-xs mb-4">
                Médicos especialistas, geneticistas, pesquisadores e outros profissionais.
              </p>
              <Link
                href="https://redcap.link/cplpDR"
                target="_blank"
                className="block w-full bg-blue-600 hover:bg-blue-700 text-white text-center px-3 py-2 rounded text-xs font-medium transition-colors"
              >
                Participar do Mapeamento
              </Link>
            </div>

            {/* Atividade 3 */}
            <div className="border border-gray-200 rounded-lg p-5 hover:shadow-md transition-shadow">
              <div className="flex items-center mb-3">
                <div className="bg-purple-600 text-white rounded-full w-7 h-7 flex items-center justify-center text-sm font-bold mr-3">
                  3
                </div>
                <h3 className="font-semibold text-gray-900 text-sm">Recursos Diagnósticos</h3>
              </div>
              <p className="text-gray-600 text-xs mb-4">
                Laboratórios, equipamentos e testes disponíveis para diagnóstico.
              </p>
              <div className="text-center">
                <span className="block w-full bg-gray-200 text-gray-700 text-center px-3 py-2 rounded text-xs font-medium">
                  Ver Detalhes em Breve
                </span>
              </div>
            </div>

            {/* Atividade 4 */}
            <div className="border border-gray-200 rounded-lg p-5 hover:shadow-md transition-shadow">
              <div className="flex items-center mb-3">
                <div className="bg-orange-600 text-white rounded-full w-7 h-7 flex items-center justify-center text-sm font-bold mr-3">
                  4
                </div>
                <h3 className="font-semibold text-gray-900 text-sm">Terapias e Tratamentos</h3>
              </div>
              <p className="text-gray-600 text-xs mb-4">
                Tratamentos disponíveis, acesso a medicamentos órfãos e terapias.
              </p>
              <div className="text-center">
                <span className="block w-full bg-gray-200 text-gray-700 text-center px-3 py-2 rounded text-xs font-medium">
                  Ver Detalhes em Breve
                </span>
              </div>
            </div>

            {/* Atividade 5 */}
            <div className="border border-gray-200 rounded-lg p-5 hover:shadow-md transition-shadow">
              <div className="flex items-center mb-3">
                <div className="bg-pink-600 text-white rounded-full w-7 h-7 flex items-center justify-center text-sm font-bold mr-3">
                  5
                </div>
                <h3 className="font-semibold text-gray-900 text-sm">Avaliação de Maturidade</h3>
              </div>
              <p className="text-gray-600 text-xs mb-4">
                Análise do nível de desenvolvimento dos sistemas de saúde e políticas.
              </p>
              <div className="text-center">
                <span className="block w-full bg-gray-200 text-gray-700 text-center px-3 py-2 rounded text-xs font-medium">
                  Ver Detalhes em Breve
                </span>
              </div>
            </div>

            {/* Atividade 6 */}
            <div className="border border-gray-200 rounded-lg p-5 hover:shadow-md transition-shadow">
              <div className="flex items-center mb-3">
                <div className="bg-teal-600 text-white rounded-full w-7 h-7 flex items-center justify-center text-sm font-bold mr-3">
                  6
                </div>
                <h3 className="font-semibold text-gray-900 text-sm">Base de Dados Integrada</h3>
              </div>
              <p className="text-gray-600 text-xs mb-4">
                Repositório centralizado com informações coletadas dos países.
              </p>
              <div className="text-center">
                <span className="block w-full bg-gray-200 text-gray-700 text-center px-3 py-2 rounded text-xs font-medium">
                  Ver Detalhes em Breve
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Resultados e Impacto */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          <div className="bg-white rounded-xl shadow-sm p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-4 flex items-center">
              <span className="text-2xl mr-3">📊</span>
              Resultados Esperados
            </h2>
            <ul className="space-y-2 text-gray-600 text-sm">
              <li className="flex items-center"><span className="text-green-600 mr-2">•</span>Atlas de recursos para doenças raras na CPLP</li>
              <li className="flex items-center"><span className="text-green-600 mr-2">•</span>Diretório de especialistas e centros</li>
              <li className="flex items-center"><span className="text-green-600 mr-2">•</span>Análise comparativa de maturidade</li>
              <li className="flex items-center"><span className="text-green-600 mr-2">•</span>Recomendações para fortalecimento</li>
              <li className="flex items-center"><span className="text-green-600 mr-2">•</span>Plataforma digital interativa</li>
            </ul>
          </div>

          <div className="bg-white rounded-xl shadow-sm p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-4 flex items-center">
              <span className="text-2xl mr-3">🌍</span>
              Impacto na CPLP
            </h2>
            <p className="text-gray-600 text-sm leading-relaxed mb-4">
              Este mapeamento permitirá identificar lacunas, oportunidades de colaboração e 
              recursos compartilháveis entre os países, fortalecendo a rede de cuidados em 
              doenças raras em toda a comunidade lusófona.
            </p>
            <div className="text-center bg-blue-50 rounded-lg p-4">
              <div className="text-lg font-bold text-blue-600">8 Países CPLP</div>
              <div className="text-xs text-gray-500">Mapeamento Colaborativo</div>
            </div>
          </div>
        </div>

        {/* Call to Action Final */}
        <div className="text-center bg-gradient-to-r from-blue-600 to-indigo-600 rounded-xl p-8 text-white">
          <h2 className="text-2xl font-bold mb-4">Contribua com o Mapeamento GT1</h2>
          <p className="text-lg opacity-90 mb-6">
            Sua participação é fundamental para construir uma rede robusta de recursos em doenças raras na CPLP.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              href="https://redcap.link/cplpDR"
              target="_blank"
              className="bg-white text-blue-600 px-6 py-3 rounded-lg font-semibold hover:bg-blue-50 transition-colors"
            >
              Acessar Formulário Principal
            </Link>
            <Link
              href="/grupos-trabalho/gt1/dados"
              className="bg-blue-500 hover:bg-blue-400 text-white px-6 py-3 rounded-lg font-semibold transition-colors"
            >
              Visualizar Dados Coletados
            </Link>
          </div>
        </div>

      </div>
    </div>
  );
}
