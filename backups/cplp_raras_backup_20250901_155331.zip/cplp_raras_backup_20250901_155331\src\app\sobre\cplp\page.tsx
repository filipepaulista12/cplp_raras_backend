import { Metadata } from 'next';
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import TopShare from '@/components/TopShare';

export const metadata: Metadata = {
  title: 'CPLP - Comunidade dos Países de Língua Portuguesa | CPLP-Raras',
  description: 'Conheça a Comunidade dos Países de Língua Portuguesa (CPLP) e a distribuição global do idioma português nos países membros.',
  keywords: 'CPLP, países lusófonos, língua portuguesa, comunidade países, doenças raras',
};

export default function CPLPPage() {

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        
        {/* Compartilhamento no topo */}
        <TopShare 
          title="CPLP - Comunidade dos Países de Língua Portuguesa"
          description="Conheça a organização internacional que reúne países e territórios lusófonos, espalhados por quatro continentes."
        />
        
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent mb-6">
            Comunidade dos Países de Língua Portuguesa
          </h1>
          <p className="text-xl text-gray-700 max-w-4xl mx-auto leading-relaxed">
            A CPLP é uma organização internacional formada por países e territórios que têm o português como língua oficial, 
            espalhados por quatro continentes e representando mais de 290 milhões de falantes.
          </p>
        </div>

        {/* Mapa dos Países */}
        <Card className="mb-12 overflow-hidden">
          <CardContent className="p-8">
            <h2 className="text-3xl font-bold text-center mb-6 text-gray-800">
              Distribuição Global dos Países Lusófonos
            </h2>
            <div className="relative bg-gradient-to-br from-blue-100 to-green-100 rounded-lg p-8 mb-6">
              {/* SVG Map representation */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 text-center">
                <div className="bg-green-200 p-4 rounded-lg border-2 border-green-400">
                  <div className="text-3xl mb-2">🇧🇷</div>
                  <h3 className="font-bold text-green-800">América</h3>
                  <p className="text-sm text-green-700">Brasil</p>
                  <p className="text-xs text-green-600">213M habitantes</p>
                </div>
                <div className="bg-red-200 p-4 rounded-lg border-2 border-red-400">
                  <div className="text-3xl mb-2">🇵🇹</div>
                  <h3 className="font-bold text-red-800">Europa</h3>
                  <p className="text-sm text-red-700">Portugal</p>
                  <p className="text-xs text-red-600">10M habitantes</p>
                </div>
                <div className="bg-yellow-200 p-4 rounded-lg border-2 border-yellow-400">
                  <div className="text-3xl mb-2">🇹🇱</div>
                  <h3 className="font-bold text-yellow-800">Ásia</h3>
                  <p className="text-sm text-yellow-700">Timor-Leste</p>
                  <p className="text-xs text-yellow-600">1.4M habitantes</p>
                </div>
                <div className="bg-orange-200 p-4 rounded-lg border-2 border-orange-400">
                  <div className="text-3xl mb-2">🌍</div>
                  <h3 className="font-bold text-orange-800">África</h3>
                  <div className="text-xs text-orange-600 space-y-1">
                    <p>• Angola (33M)</p>
                    <p>• Moçambique (32M)</p>
                    <p>• Guiné-Bissau (2M)</p>
                    <p>• Guiné Equatorial (1.5M)</p>
                    <p>• São Tomé e Príncipe (220K)</p>
                    <p>• Cabo Verde (558K)</p>
                  </div>
                </div>
              </div>
            </div>
            <p className="text-gray-600 text-center text-sm">
              Fonte: <a href="https://www.instagram.com/p/CLkr4fqHpEu/" target="_blank" rel="noopener noreferrer" 
                       className="text-blue-600 hover:text-blue-800 underline">
                Geografia Panorâmica - Instagram
              </a>
            </p>
          </CardContent>
        </Card>

        {/* Todos os Países Membros */}
        <Card className="mb-12 overflow-hidden">
          <CardContent className="p-8">
            <h2 className="text-3xl font-bold text-center mb-6 text-gray-800">
              Países Membros da CPLP
            </h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {[
                { pais: "🇧🇷 Brasil", pop: "213M", continente: "América", primaria: true, cor: "bg-green-100 border-green-400" },
                { pais: "🇦🇴 Angola", pop: "33M", continente: "África", primaria: false, cor: "bg-orange-100 border-orange-400" },
                { pais: "🇲🇿 Moçambique", pop: "32M", continente: "África", primaria: false, cor: "bg-orange-100 border-orange-400" },
                { pais: "🇵🇹 Portugal", pop: "10M", continente: "Europa", primaria: true, cor: "bg-red-100 border-red-400" },
                { pais: "🇬🇼 Guiné-Bissau", pop: "2M", continente: "África", primaria: false, cor: "bg-orange-100 border-orange-400" },
                { pais: "🇬🇶 Guiné Equatorial", pop: "1.5M", continente: "África", primaria: false, cor: "bg-yellow-100 border-yellow-400" },
                { pais: "🇹🇱 Timor-Leste", pop: "1.4M", continente: "Ásia", primaria: false, cor: "bg-blue-100 border-blue-400" },
                { pais: "🇨🇻 Cabo Verde", pop: "558K", continente: "África", primaria: false, cor: "bg-orange-100 border-orange-400" },
                { pais: "🇸🇹 São Tomé e Príncipe", pop: "220K", continente: "África", primaria: true, cor: "bg-orange-100 border-orange-400" }
              ].map((item, index) => (
                <div key={index} className={`flex items-center justify-between p-4 rounded-lg border-l-4 ${item.cor}`}>
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">{item.pais.split(' ')[0]}</span>
                    <div>
                      <p className="font-semibold text-gray-800">{item.pais.substring(3)}</p>
                      <p className="text-xs text-gray-600">{item.continente}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-gray-700">{item.pop}</p>
                    {item.primaria && (
                      <Badge variant="secondary" className="text-xs">
                        Primária
                      </Badge>
                    )}
                  </div>
                </div>
              ))}
            </div>
            
            {/* Região Autônoma */}
            <div className="mt-6 bg-yellow-50 border-l-4 border-yellow-400 p-4 rounded-lg">
              <div className="flex items-center gap-3">
                <span className="text-2xl">🇲🇴</span>
                <div>
                  <p className="font-semibold text-gray-800">Macau (Região Autônoma da China)</p>
                  <p className="text-sm text-gray-600">649 mil habitantes • Apenas 0,7% fala português</p>
                </div>
              </div>
            </div>
            
            <div className="grid md:grid-cols-3 gap-6 mt-8 pt-6 border-t">
              <div className="text-center p-4 bg-blue-50 rounded-lg">
                <h3 className="font-bold text-lg text-blue-700 mb-2">Total de Falantes</h3>
                <p className="text-2xl font-bold text-gray-800">290M+</p>
                <p className="text-sm text-gray-600">Em todo o mundo</p>
              </div>
              <div className="text-center p-4 bg-green-50 rounded-lg">
                <h3 className="font-bold text-lg text-green-700 mb-2">Língua Primária</h3>
                <p className="text-2xl font-bold text-gray-800">3</p>
                <p className="text-sm text-gray-600">Brasil, Portugal, São Tomé</p>
              </div>
              <div className="text-center p-4 bg-purple-50 rounded-lg">
                <h3 className="font-bold text-lg text-purple-700 mb-2">Continentes</h3>
                <p className="text-2xl font-bold text-gray-800">4</p>
                <p className="text-sm text-gray-600">América, Europa, África, Ásia</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Informações Adicionais */}
        <Card className="mb-12">
          <CardContent className="p-8">
            <h2 className="text-3xl font-bold text-center mb-8 text-gray-800">
              Sobre a Língua Portuguesa
            </h2>
            <div className="grid md:grid-cols-2 gap-8">
              <div className="bg-gradient-to-r from-blue-100 to-purple-100 p-6 rounded-lg">
                <h3 className="font-bold text-lg mb-3 text-gray-800">Língua Primária</h3>
                <p className="text-gray-700">
                  Apenas no <strong>Brasil</strong>, <strong>Portugal</strong> e <strong>São Tomé e Príncipe</strong> 
                  o português é a língua primária da população. Nos demais países, coexiste com outras 
                  línguas oficiais ou regionais.
                </p>
              </div>
              <div className="bg-gradient-to-r from-purple-100 to-pink-100 p-6 rounded-lg">
                <h3 className="font-bold text-lg mb-3 text-gray-800">Expansão Histórica</h3>
                <p className="text-gray-700">
                  A língua portuguesa expandiu-se através da colonização a partir do século XV, 
                  estabelecendo entrepostos comerciais e assentamentos em quatro continentes diferentes.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="mb-12">
          <CardContent className="p-8">
            <h2 className="text-3xl font-bold text-center mb-8 text-gray-800">
              Os 9 Membros da CPLP
            </h2>
            
            <div className="grid md:grid-cols-3 lg:grid-cols-4 gap-4">
              {[
                { pais: "🇧🇷 Brasil", pop: "213M", primaria: true },
                { pais: "🇵🇹 Portugal", pop: "10M", primaria: true },
                { pais: "🇦🇴 Angola", pop: "33M", primaria: false },
                { pais: "🇲🇿 Moçambique", pop: "32M", primaria: false },
                { pais: "🇬🇼 Guiné-Bissau", pop: "2M", primaria: false },
                { pais: "🇨🇻 Cabo Verde", pop: "558K", primaria: false },
                { pais: "🇸🇹 São Tomé e Príncipe", pop: "220K", primaria: true },
                { pais: "🇹🇱 Timor-Leste", pop: "1.4M", primaria: false },
                { pais: "🇬🇶 Guiné Equatorial", pop: "1.5M", primaria: false }
              ].map((membro, index) => (
                <div key={index} className={`p-4 rounded-lg border-2 ${membro.primaria ? 'bg-green-50 border-green-300' : 'bg-blue-50 border-blue-300'}`}>
                  <div className="text-center">
                    <div className="text-2xl mb-2">{membro.pais.split(' ')[0]}</div>
                    <p className="font-semibold text-sm text-gray-800">{membro.pais.substring(3)}</p>
                    <p className="text-xs text-gray-600">{membro.pop}</p>
                    {membro.primaria && (
                      <Badge variant="secondary" className="text-xs mt-1">
                        Língua Primária
                      </Badge>
                    )}
                  </div>
                </div>
              ))}
            </div>

            {/* Região Autônoma */}
            <div className="bg-yellow-50 border-l-4 border-yellow-400 p-6 rounded-lg mt-8">
              <h3 className="font-bold text-lg mb-3 text-gray-800">Região Autônoma</h3>
              <div className="flex items-center gap-4">
                <div className="text-3xl">🇲🇴</div>
                <div>
                  <p className="font-semibold text-gray-700">Macau (China)</p>
                  <p className="text-sm text-gray-600">649 mil habitantes • Apenas 0,7% fala português</p>
                  <p className="text-sm text-gray-600">Status especial até 2049</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Cronologia Resumida */}
        <Card className="mb-12">
          <CardContent className="p-8">
            <h2 className="text-3xl font-bold text-center mb-8 text-gray-800">
              Marcos da Expansão Portuguesa
            </h2>
            
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[
                { periodo: "Séc. XV", eventos: ["1446 - Guiné-Bissau", "1460 - Cabo Verde", "1485 - São Tomé"], cor: "bg-blue-100 border-blue-400" },
                { periodo: "Séc. XV-XVI", eventos: ["1482 - Angola", "1498 - Moçambique", "1512 - Timor-Leste"], cor: "bg-green-100 border-green-400" },
                { periodo: "Moderno", eventos: ["1996 - Fundação CPLP", "2014 - Guiné Equatorial", "1999 - Macau → China"], cor: "bg-purple-100 border-purple-400" }
              ].map((item, index) => (
                <div key={index} className={`p-6 rounded-lg border-l-4 ${item.cor}`}>
                  <h3 className="font-bold text-lg mb-3 text-gray-800">{item.periodo}</h3>
                  <ul className="space-y-1 text-sm text-gray-700">
                    {item.eventos.map((evento, i) => (
                      <li key={i}>{evento}</li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Casos Especiais */}
        <Card className="mb-12">
          <CardContent className="p-8">
            <h2 className="text-3xl font-bold text-center mb-8 text-gray-800">
              Situações Particulares
            </h2>
            
            <div className="grid md:grid-cols-2 gap-8">
              
              {/* Guiné Equatorial */}
              <div className="bg-gradient-to-br from-orange-50 to-red-50 p-6 rounded-lg border-l-4 border-orange-400">
                <h3 className="font-bold text-lg mb-4 text-gray-800">Guiné Equatorial</h3>
                <div className="space-y-3 text-sm text-gray-700">
                  <p><strong>Entrada na CPLP:</strong> 2014</p>
                  <p><strong>Línguas oficiais:</strong> Português, Espanhol e Francês</p>
                  <p><strong>Realidade:</strong> Espanhol é predominante na população</p>
                  <p><strong>Desafio:</strong> Português não é usado na administração ou nas ruas</p>
                  <p className="text-orange-700 font-semibold">
                    Portugal inicialmente resistiu à entrada, exigindo uso corrente do português 
                    e eliminação da pena de morte.
                  </p>
                </div>
              </div>

              {/* Timor-Leste */}
              <div className="bg-gradient-to-br from-green-50 to-blue-50 p-6 rounded-lg border-l-4 border-green-400">
                <h3 className="font-bold text-lg mb-4 text-gray-800">Timor-Leste</h3>
                <div className="space-y-3 text-sm text-gray-700">
                  <p><strong>Ocupação portuguesa:</strong> 1512</p>
                  <p><strong>Colônia:</strong> 1702</p>
                  <p><strong>Independência de Portugal:</strong> 1975</p>
                  <p><strong>Ocupação indonésia:</strong> 1975-2002</p>
                  <p><strong>Independência final:</strong> 2002</p>
                  <p className="text-green-700 font-semibold">
                    Único país da CPLP na Ásia, com história complexa de dupla colonização.
                  </p>
                </div>
              </div>

            </div>
          </CardContent>
        </Card>

        {/* Outros Territórios */}
        <Card className="mb-12">
          <CardContent className="p-8">
            <h2 className="text-3xl font-bold text-center mb-6 text-gray-800">
              Outros Territórios com Falantes de Português
            </h2>
            
            <div className="bg-blue-50 p-6 rounded-lg">
              <p className="text-gray-700 mb-4">
                Existem ainda comunidades falantes de português em diversos territórios onde não é língua oficial:
              </p>
              
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4 text-sm">
                <div className="bg-white p-3 rounded border-l-4 border-blue-400">
                  <p className="font-semibold">Índia</p>
                  <p className="text-gray-600">Goa, Damão, Diu</p>
                </div>
                <div className="bg-white p-3 rounded border-l-4 border-blue-400">
                  <p className="font-semibold">Malásia</p>
                  <p className="text-gray-600">Malaca</p>
                </div>
                <div className="bg-white p-3 rounded border-l-4 border-blue-400">
                  <p className="font-semibold">Indonésia</p>
                  <p className="text-gray-600">Ilha das Flores</p>
                </div>
                <div className="bg-white p-3 rounded border-l-4 border-blue-400">
                  <p className="font-semibold">Sri Lanka</p>
                  <p className="text-gray-600">Batticaloa</p>
                </div>
                <div className="bg-white p-3 rounded border-l-4 border-blue-400">
                  <p className="font-semibold">Caribe</p>
                  <p className="text-gray-600">Aruba, Bonaire, Curaçao</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Fundação da CPLP */}
        <Card className="mb-12">
          <CardContent className="p-8 text-center bg-gradient-to-br from-blue-50 to-purple-50">
            <h2 className="text-3xl font-bold mb-6 text-gray-800">
              Fundação da CPLP
            </h2>
            
            <div className="max-w-3xl mx-auto">
              <div className="bg-white p-8 rounded-lg shadow-md border-l-4 border-purple-500">
                <p className="text-2xl font-bold text-purple-600 mb-4">1996</p>
                <p className="text-lg text-gray-700 mb-4">
                  Fundação da Comunidade dos Países de Língua Portuguesa
                </p>
                <p className="text-gray-600">
                  Todos os países lusófonos são membros da CPLP, <strong>exceto Macau</strong>, 
                  que mantém status de região autônoma da China.
                </p>
              </div>
              
              <div className="mt-8 p-6 bg-gradient-to-r from-blue-100 to-purple-100 rounded-lg">
                <p className="text-lg font-semibold text-gray-800 mb-2">
                  Missão da CPLP
                </p>
                <p className="text-gray-700">
                  Promover a cooperação política, diplomática, econômica, social, cultural, 
                  jurídica e técnico-científica entre seus membros.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Referencias */}
        <Card className="bg-gray-50">
          <CardContent className="p-6">
            <h3 className="font-bold text-lg mb-4 text-gray-800">Referências</h3>
            <div className="space-y-2 text-sm text-gray-600">
              <p>
                1. Geografia Panorâmica. "Países que falam português". Instagram, 
                <a href="https://www.instagram.com/p/CLkr4fqHpEu/" target="_blank" rel="noopener noreferrer" 
                   className="text-blue-600 hover:text-blue-800 underline ml-1">
                  https://www.instagram.com/p/CLkr4fqHpEu/
                </a>
              </p>
              <p>
                2. Geoplaza. "Onde o português é língua oficial". Infográfico estatístico sobre população 
                dos países lusófonos.
              </p>
            </div>
          </CardContent>
        </Card>

      </div>
    </div>
  );
}
