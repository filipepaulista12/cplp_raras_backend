import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: 'export',
  // Removido basePath para raras-cplp.org (domínio raiz)
  // basePath: '/filipe',
  // assetPrefix: '/filipe',
  trailingSlash: true,
  skipTrailingSlashRedirect: true,
  typescript: {
    // Ignorar erros de TypeScript durante o build para permitir deploy
    ignoreBuildErrors: true,
  },
  images: {
    unoptimized: true,
    remotePatterns: [
      {
        protocol: 'https',
        hostname: 'cintesis.eu',
      },
      {
        protocol: 'https',
        hostname: 'raras.org.br',
      },
      {
        protocol: 'https',
        hostname: 'i1.rgstatic.net',
      },
      {
        protocol: 'https',
        hostname: 'static.wixstatic.com',
      },
      {
        protocol: 'https',
        hostname: 'media.licdn.com',
      },
      {
        protocol: 'https',
        hostname: 'researchid.co',
      },
      {
        protocol: 'http',
        hostname: 'servicosweb.cnpq.br',
      },
      {
        protocol: 'https',
        hostname: 'info.orcid.org',
      },
    ],
  },
};

export default nextConfig;
