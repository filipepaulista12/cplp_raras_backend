import Link from 'next/link';
import Image from 'next/image';
import { ArrowLeftIcon } from '@heroicons/react/24/outline';
import TopShare from '@/components/TopShare';

const collaborators = [
  {
    name: 'Dr. Filipe Andrade Bernardi',
    country: 'Brasil/Portugal',
    role: 'Pesquisador em Saúde Digital',
    institution: 'Rede RARAS',
    orcid: '0000-0002-9597-5470',
    photo: 'https://researchid.co/uploads/filipe.bernardi.gif',
    bio: 'Pesquisador em saúde digital e qualidade de dados colaborador da rede RARAS. Possui ampla atuação em protocolos, governança e sistemas colaborativos para doenças raras.'
  },
  {
    name: 'Dr. Vinícius Lima',
    country: 'Brasil/Portugal',
    role: 'Especialista em Sistemas de Informação',
    institution: 'Rede RARAS',
    orcid: '0000-0002-8765-4321',
    photo: 'https://raras.org.br/assets/img/SiteRaras/participantes/4772.jpg',
    bio: 'Especialista em sistemas de informação em saúde, IA e governança digital. Possui experiência em desenvolvimento de tecnologias e integração de sistemas.'
  },
  {
    name: 'Dr.a Aline Zanatta',
    country: 'Brasil',
    role: 'Biomédica e Pesquisadora',
    institution: 'FMRP-USP',
    orcid: '0000-0002-0097-2403',
    photo: 'http://servicosweb.cnpq.br/wspessoa/servletrecuperafoto?tipo=1&id=K8572218Y7',
    bio: 'Biomédica e doutora em Ciências pela FMRP-USP, com experiência em fisiologia, metabolismo, endocrinologia e programação fetal.'
  },
  {
    name: 'MsC. José Carlos Bueno de Moraes',
    country: 'Brasil',
    role: 'Engenheiro de Software',
    institution: 'USP/Carefy',
    orcid: '0009-0009-1977-2354',
    photo: 'http://servicosweb.cnpq.br/wspessoa/servletrecuperafoto?tipo=1&id=K4868860A7',
    bio: 'Mestre em Computação Aplicada pela USP e cofundador da Carefy. Atua como engenheiro de software com foco em soluções escaláveis em saúde digital.'
  },
  {
    name: 'MsC. Mariane de Souza',
    country: 'Brasil',
    role: 'Pedagoga e Educadora',
    institution: 'LIS/USP',
    orcid: '0009-0006-6360-4567',
    photo: 'http://servicosweb.cnpq.br/wspessoa/servletrecuperafoto?tipo=1&id=K1536698D4',
    bio: 'Pedagoga e colaboradora do LIS/USP. Educadora de infância com atuação em educação inclusiva, neuropsicopedagogia e artes visuais.'
  },
  {
    name: 'MsC Victor Cassão',
    country: 'Brasil',
    role: 'Cientista da Computação',
    institution: 'Universidade Barão de Mauá/LIS-USP',
    orcid: '0000-0002-8967-0267',
    photo: 'http://servicosweb.cnpq.br/wspessoa/servletrecuperafoto?tipo=1&id=K9190177U9',
    bio: 'Docente na Universidade Barão de Mauá e cientista da computação com experiência em ciência de dados e aprendizado de máquina.'
  }
];

export default function Colaboradores() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Breadcrumb */}
      <div className="bg-white border-b">
        <div className="mx-auto max-w-7xl px-4 py-4 sm:px-6 lg:px-8">
          <div className="flex items-center space-x-2 text-sm">
            <Link 
              href="/"
              className="text-blue-600 hover:text-blue-800 transition-colors"
            >
              Início
            </Link>
            <span className="text-gray-400">/</span>
            <Link 
              href="/equipe"
              className="text-blue-600 hover:text-blue-800 transition-colors"
            >
              Equipe
            </Link>
            <span className="text-gray-400">/</span>
            <span className="text-gray-600">Colaboradores</span>
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <TopShare 
          title="Colaboradores da Força-Tarefa - CPLP-Raras"
          description="Conheça os pesquisadores e especialistas colaboradores que contribuem com a rede CPLP-Raras no avanço da pesquisa em doenças raras."
        />
        
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            🤝 Colaboradores da Força-Tarefa
          </h1>
          <div className="w-32 h-1 bg-gradient-to-r from-green-600 to-emerald-600 mx-auto mb-8"></div>
          <p className="text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed">
            Os colaboradores da CPLP-Raras são alunos, parceiros institucionais e pessoas engajadas que se juntaram 
            voluntariamente a esta força-tarefa. Eles contribuem com dedicação em diversas frentes do projeto, 
            apoiando atividades de pesquisa, divulgação, tecnologia, organização de eventos e integração entre 
            os países da Comunidade dos Países de Língua Portuguesa.
          </p>
        </div>

        {/* Botão de Voltar */}
        <div className="mb-8">
          <Link 
            href="/equipe"
            className="inline-flex items-center text-green-600 hover:text-green-800 transition-colors font-medium"
          >
            <ArrowLeftIcon className="h-4 w-4 mr-2" />
            Voltar para Equipe Principal
          </Link>
        </div>

        {/* Lista de Colaboradores */}
        <section className="mb-16">
          <div className="bg-white rounded-2xl shadow-lg p-8 md:p-12">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {collaborators.map((collaborator, index) => (
                <div key={index} className="bg-gradient-to-br from-green-50 to-emerald-100 border border-green-200 rounded-xl p-6 hover:shadow-lg transition-all duration-200">
                  <div className="flex items-start space-x-4">
                    <div className="w-16 h-16 rounded-full border-2 border-green-200 overflow-hidden flex-shrink-0">
                      <Image 
                        src={collaborator.photo} 
                        alt={collaborator.name}
                        width={64}
                        height={64}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-semibold text-gray-900 mb-1">{collaborator.name}</h4>
                      <p className="text-sm text-green-600 font-medium mb-1">{collaborator.role}</p>
                      <p className="text-xs text-gray-600 mb-2">{collaborator.institution}</p>
                      <div className="flex items-center space-x-1 mb-2">
                        <span className="text-sm">{collaborator.country.includes('Brasil') ? '🇧🇷' : '🇵🇹'}</span>
                        <span className="text-xs text-gray-500">{collaborator.country}</span>
                      </div>
                      {collaborator.orcid && (
                        <a 
                          href={`https://orcid.org/${collaborator.orcid}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center text-xs text-green-600 hover:text-green-800 mb-2"
                        >
                          <Image 
                            src="https://info.orcid.org/wp-content/uploads/2019/11/orcid_16x16.png" 
                            className="w-3 h-3 mr-1" 
                            alt="ORCID"
                            width={12}
                            height={12}
                          />
                          {collaborator.orcid}
                        </a>
                      )}
                      <p className="text-xs text-gray-600 leading-relaxed">{collaborator.bio}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Call to Action */}
        <section>
          <div className="bg-gradient-to-r from-green-600 to-emerald-600 rounded-2xl p-8 text-white text-center">
            <h2 className="text-2xl md:text-3xl font-bold mb-4">
              💡 Quer fazer parte da nossa equipe de colaboradores?
            </h2>
            <p className="text-xl mb-2 opacity-90">
              Junte-se a nós nesta jornada de pesquisa e inovação em doenças raras!
            </p>
            <p className="text-lg mb-6 opacity-90">
              Contribua com suas habilidades e conhecimentos para fortalecer a rede CPLP-Raras.
            </p>
            <Link
              href="/contato"
              className="inline-block bg-white text-green-600 px-8 py-3 rounded-lg font-semibold hover:bg-green-50 transition-colors"
            >
              Envie um e-mail e faça parte desta rede!
            </Link>
          </div>
        </section>
      </div>
    </div>
  );
}
