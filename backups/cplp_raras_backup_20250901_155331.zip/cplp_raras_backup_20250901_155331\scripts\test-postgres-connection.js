/**
 * 🔧 TESTE DE CONEXÃO POSTGRESQL
 * =============================
 * Script para testar diferentes senhas e conectar ao PostgreSQL
 */

const { Client } = require('pg');
const fs = require('fs');
const path = require('path');

// Senhas comuns para testar
const commonPasswords = [
  'postgres',
  'password', 
  'admin',
  'root',
  '123456',
  'password123',
  'postgres123',
  '', // senha vazia
  'qwerty',
  '12345'
];

async function testConnection(password) {
  const client = new Client({
    host: 'localhost',
    port: 5432,
    user: 'postgres',
    password: password,
    database: 'postgres'
  });

  try {
    await client.connect();
    console.log(`✅ SUCESSO! Conectado com senha: "${password}"`);
    
    // Testar uma query básica
    const result = await client.query('SELECT version();');
    console.log(`📋 PostgreSQL: ${result.rows[0].version.split(' ').slice(0, 2).join(' ')}`);
    
    // Verificar se o banco orphanet_db existe
    const dbResult = await client.query("SELECT 1 FROM pg_database WHERE datname = 'orphanet_db'");
    if (dbResult.rows.length > 0) {
      console.log('📦 Banco orphanet_db já existe');
    } else {
      console.log('📦 Banco orphanet_db não existe - será criado');
      await client.query('CREATE DATABASE orphanet_db;');
      console.log('✅ Banco orphanet_db criado');
    }
    
    await client.end();
    return password;
  } catch (error) {
    await client.end().catch(() => {});
    return null;
  }
}

async function main() {
  console.log('🔐 Testando conexão PostgreSQL...\n');
  
  for (const password of commonPasswords) {
    console.log(`Testando senha: "${password}"`);
    const success = await testConnection(password);
    
    if (success !== null) {
      console.log('\n🎉 Conexão estabelecida!');
      console.log(`✏️  Atualizando arquivo .env com senha correta...`);
      
      // Atualizar .env
      const envPath = path.join(__dirname, '..', '.env');
      let envContent = '';
      
      if (fs.existsSync(envPath)) {
        envContent = fs.readFileSync(envPath, 'utf8');
        // Substituir a linha de senha
        envContent = envContent.replace(/DB_PASSWORD=.*/, `DB_PASSWORD=${success}`);
        envContent = envContent.replace(/postgresql:\/\/postgres:.*@/, `postgresql://postgres:${success}@`);
      } else {
        envContent = `# PostgreSQL Database Configuration
DB_HOST=localhost
DB_PORT=5432
DB_USER=postgres
DB_PASSWORD=${success}
DB_NAME=orphanet_db
DB_SSL=false

# Prisma Database URL
DATABASE_URL="postgresql://postgres:${success}@localhost:5432/orphanet_db"`;
      }
      
      fs.writeFileSync(envPath, envContent);
      console.log('✅ Arquivo .env atualizado');
      
      process.exit(0);
    }
    
    console.log('❌ Falhou\n');
  }
  
  console.log('💥 Nenhuma senha funcionou!');
  console.log('\n📋 Possíveis soluções:');
  console.log('1. Verificar se PostgreSQL está rodando: Get-Service postgresql*');
  console.log('2. Reinstalar PostgreSQL com senha conhecida');
  console.log('3. Usar pgAdmin para redefinir a senha');
  console.log('4. Configurar autenticação trust temporariamente');
  
  process.exit(1);
}

if (require.main === module) {
  main().catch(console.error);
}
