import Link from 'next/link';
import TopShare from '@/components/TopShare';
import Image from 'next/image';
import { getImageSrc } from '@/lib/imageUtils';

export default function GT6() {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white border-b">
        <div className="mx-auto max-w-7xl px-4 py-4 sm:px-6 lg:px-8">
          <nav className="flex" aria-label="Breadcrumb">
            <ol className="inline-flex items-center space-x-1 md:space-x-3">
              <li><Link href="/" className="text-blue-600 hover:text-blue-800">Início</Link></li>
              <li><div className="flex items-center"><span className="mx-2 text-gray-400">/</span><Link href="/grupos-trabalho" className="text-blue-600 hover:text-blue-800">Grupos de Trabalho</Link></div></li>
              <li aria-current="page"><div className="flex items-center"><span className="mx-2 text-gray-400">/</span><span className="text-gray-500">GT6 - Disseminação</span></div></li>
            </ol>
          </nav>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        
        {/* Compartilhamento no topo */}
        <TopShare 
          title="GT6 - Avaliação e Monitoramento"
          description="Métodos de avaliação e monitoramento das atividades do projeto CPLP-Raras"
        />
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">📣 GT6 – Disseminação e Sustentabilidade</h1>
          <div className="w-32 h-1 bg-gradient-to-r from-teal-500 to-teal-600 mx-auto mb-8"></div>
          <p className="text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed">
            Comunicação de resultados, mobilização social e plano de continuidade das ações do projeto.
          </p>
        </div>

        <section className="mb-16">
          <div className="bg-white rounded-2xl shadow-lg p-8 md:p-12">
            <div className="text-center mb-8">
              <Image src={getImageSrc("/images/GT6.png")} alt="GT6 - Disseminação e Sustentabilidade" width={600} height={400} className="rounded-lg shadow-md mx-auto" />
            </div>
            
            <div className="bg-teal-50 border-l-4 border-teal-600 p-6">
              <p className="text-lg text-gray-700 leading-relaxed">
                O GT6 garante a comunicação efetiva dos resultados do projeto, desenvolve estratégias 
                de sustentabilidade e mobiliza stakeholders para garantir a continuidade das ações 
                em benefício das pessoas com doenças raras na CPLP.
              </p>
            </div>
          </div>
        </section>

        <section className="text-center">
          <div className="bg-gradient-to-r from-teal-600 to-green-600 rounded-2xl p-8 text-white">
            <h2 className="text-2xl font-bold mb-4">Resultados e Impacto</h2>
            <p className="text-xl mb-6 opacity-90">Comunicação de resultados e estratégias de sustentabilidade.</p>
            <Link href="/publicacoes" className="inline-block bg-white text-teal-600 px-8 py-3 rounded-lg font-semibold hover:bg-teal-50 transition-colors">
              Ver Publicações
            </Link>
          </div>
        </section>
      </div>
    </div>
  );
}
