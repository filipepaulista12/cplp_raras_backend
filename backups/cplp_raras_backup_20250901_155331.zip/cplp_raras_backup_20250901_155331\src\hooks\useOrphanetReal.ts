/**
 * 🪝 HOOKS ORPHANET REAIS - CPLP RARAS
 * 
 * Hooks para consumir dados reais das APIs Orphanet aprimoradas
 */

import { useState, useEffect, useCallback } from 'react';
import { OrphanetStats, OrphanetDisease } from '../types/orphanet';

// Hook para estatísticas reais
export function useOrphanetRealStats() {
  const [stats, setStats] = useState<OrphanetStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        setLoading(true);
        setError(null);
        
        const response = await fetch('/api/orphanet/stats-enhanced');
        const data = await response.json();
        
        if (data.success) {
          setStats(data.data);
        } else {
          throw new Error(data.details || 'Erro ao carregar estatísticas');
        }
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Erro desconhecido');
      } finally {
        setLoading(false);
      }
    };

    fetchStats();
  }, []);

  const refetch = useCallback(async () => {
    const response = await fetch('/api/orphanet/stats-enhanced');
    const data = await response.json();
    if (data.success) setStats(data.data);
  }, []);

  return { stats, loading, error, refetch };
}

// Hook para busca de doenças reais
export function useOrphanetRealSearch() {
  const [diseases, setDiseases] = useState<OrphanetDisease[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const searchDiseases = useCallback(async (params: {
    query?: string;
    language?: string;
    status?: string;
    limit?: number;
    offset?: number;
  } = {}) => {
    try {
      setLoading(true);
      setError(null);

      const searchParams = new URLSearchParams();
      if (params.query) searchParams.append('query', params.query);
      if (params.language) searchParams.append('language', params.language);
      if (params.status) searchParams.append('status', params.status);
      if (params.limit) searchParams.append('limit', params.limit.toString());
      if (params.offset) searchParams.append('offset', params.offset.toString());

      const response = await fetch(`/api/orphanet/diseases-enhanced?${searchParams}`);
      const data = await response.json();

      if (data.success) {
        setDiseases(data.data.diseases);
        setTotal(data.data.total);
      } else {
        throw new Error(data.details || 'Erro ao buscar doenças');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Erro desconhecido');
      setDiseases([]);
      setTotal(0);
    } finally {
      setLoading(false);
    }
  }, []);

  const reset = useCallback(() => {
    setDiseases([]);
    setTotal(0);
    setError(null);
  }, []);

  return { 
    diseases, 
    total, 
    loading, 
    error, 
    searchDiseases, 
    reset 
  };
}
