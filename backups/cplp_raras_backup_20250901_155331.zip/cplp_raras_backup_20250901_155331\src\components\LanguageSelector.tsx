'use client';

import { useLanguage, Language } from '@/contexts/LanguageContext';
import { ChevronDownIcon, GlobeAltIcon } from '@heroicons/react/24/outline';
import { useState } from 'react';

const languages = [
  { code: 'pt-BR' as Language, name: 'Português (BR)', flag: '🇧🇷' },
  { code: 'pt-PT' as Language, name: 'Português (PT)', flag: '🇵🇹' },
  { code: 'en' as Language, name: 'English', flag: '🇺🇸' },
  { code: 'es' as Language, name: 'Español', flag: '🇪🇸' },
  { code: 'fr' as Language, name: 'Français', flag: '🇫🇷' },
  { code: 'it' as Language, name: 'Italiano', flag: '🇮🇹' },
];

export default function LanguageSelector() {
  const { language, setLanguage, t } = useLanguage();
  const [isOpen, setIsOpen] = useState(false);

  const currentLanguage = languages.find(lang => lang.code === language);

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center space-x-2 px-3 py-2 text-sm text-gray-700 hover:text-pink-600 hover:bg-pink-50 rounded-lg transition-all duration-200"
        aria-label={t('common.language')}
      >
        <GlobeAltIcon className="h-4 w-4" />
        <span className="hidden sm:inline">{currentLanguage?.flag}</span>
        <ChevronDownIcon className={`h-3 w-3 transition-transform duration-200 ${
          isOpen ? 'rotate-180' : ''
        }`} />
      </button>

      {isOpen && (
        <div className="absolute right-0 mt-2 w-48 bg-white rounded-xl shadow-lg ring-1 ring-black ring-opacity-5 z-50 border border-pink-100">
          <div className="py-2">
            {languages.map((lang) => (
              <button
                key={lang.code}
                onClick={() => {
                  setLanguage(lang.code);
                  setIsOpen(false);
                }}
                className={`block w-full text-left px-4 py-3 text-sm transition-all duration-200 flex items-center space-x-3 ${
                  language === lang.code
                    ? 'bg-gradient-to-r from-pink-50 to-purple-50 text-pink-700 border-l-4 border-pink-400'
                    : 'text-gray-700 hover:bg-gradient-to-r hover:from-pink-50 hover:to-purple-50 hover:text-pink-700 border-l-4 border-transparent hover:border-pink-400'
                }`}
              >
                <span className="text-lg">{lang.flag}</span>
                <span>{lang.name}</span>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
