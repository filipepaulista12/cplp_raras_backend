'use client';

import Link from 'next/link';
import { useState } from 'react';
import { Bars3Icon, XMarkIcon, ChevronDownIcon } from '@heroicons/react/24/outline';
import { useLanguage } from '@/contexts/LanguageContext';
import LanguageSelector from '@/components/LanguageSelector';

// Navigation function that returns dynamic navigation based on language
const getNavigation = (t: (key: string) => string) => [
  { name: t('nav.home'), href: '/', ariaLabel: 'Ir para a página inicial' },
  { 
    name: t('nav.about'), 
    href: '/sobre',
    ariaLabel: 'Informações sobre o projeto',
    submenu: [
      { 
        name: 'CPLP-Raras', 
        href: '/sobre', 
        ariaLabel: 'Sobre o projeto CPLP-Raras',
        submenu: [
          { name: t('nav.about-project'), href: '/sobre', ariaLabel: 'Informações gerais sobre o projeto CPLP-Raras' },
          { name: t('nav.methodology'), href: '/sobre/metodologia', ariaLabel: 'Metodologia de pesquisa utilizada' },
          { name: t('nav.tools-platforms'), href: '/sobre/ferramentas', ariaLabel: 'Ferramentas e plataformas utilizadas no projeto' },
          { 
            name: t('nav.working-groups'), 
            href: '/grupos-trabalho', 
            ariaLabel: 'Grupos de trabalho da rede CPLP-Raras',
            submenu: [
              { name: 'Visão Geral', href: '/grupos-trabalho', ariaLabel: 'Visão geral dos grupos de trabalho' },
              { name: 'GT1 - Mapeamento de Recursos', href: '/grupos-trabalho/gt1', ariaLabel: 'Grupo de Trabalho 1: Mapeamento de Recursos' },
              { name: 'GT2 - Plataformas Digitais', href: '/grupos-trabalho/gt2', ariaLabel: 'Grupo de Trabalho 2: Plataformas Digitais' },
              { name: 'GT3 - Rede Colaborativa', href: '/grupos-trabalho/gt3', ariaLabel: 'Grupo de Trabalho 3: Rede Colaborativa' },
              { name: 'GT4 - Protocolos e Algoritmos', href: '/grupos-trabalho/gt4', ariaLabel: 'Grupo de Trabalho 4: Protocolos e Algoritmos' },
              { name: 'GT5 - Conscientização Social', href: '/grupos-trabalho/gt5', ariaLabel: 'Grupo de Trabalho 5: Conscientização Social' },
              { name: 'GT6 - Disseminação', href: '/grupos-trabalho/gt6', ariaLabel: 'Grupo de Trabalho 6: Disseminação' }
            ]
          }
        ]
      },
      { name: 'CPLP', href: '/sobre/cplp', ariaLabel: 'Comunidade dos Países de Língua Portuguesa' },
      { 
        name: 'Doenças Raras', 
        href: '/sobre/doencas-raras', 
        ariaLabel: 'Informações sobre doenças raras',
        submenu: [
          { name: 'Dia Mundial Doenças Raras', href: '/sobre/doencas-raras/dia-mundial', ariaLabel: 'Dia Mundial das Doenças Raras' },
          { name: 'Lista de Doenças Raras', href: '/sobre/doencas-raras/lista', ariaLabel: 'Lista completa de doenças raras' },
          { name: 'Doenças Raras no Brasil', href: '/sobre/doencas-raras/brasil', ariaLabel: 'Situação das doenças raras no Brasil' },
          { name: 'Organização Mundial da Saúde (OMS)', href: '/sobre/doencas-raras/oms', ariaLabel: 'OMS e doenças raras' },
          { name: 'Doenças Raras na Europa', href: '/sobre/doencas-raras/europa', ariaLabel: 'Doenças raras na Europa' },
          { name: 'Doenças Raras no EUA', href: '/sobre/doencas-raras/eua', ariaLabel: 'Doenças raras nos Estados Unidos' },
          { name: 'Doenças Raras na Austrália', href: '/sobre/doencas-raras/australia', ariaLabel: 'Doenças raras na Austrália' }
        ]
      }
    ]
  },
  { 
    name: t('nav.team'), 
    href: '/equipe',
    ariaLabel: 'Equipe de pesquisadores e colaboradores',
    submenu: [
      { name: t('nav.researchers'), href: '/equipe', ariaLabel: 'Pesquisadores principais por país' },
      { name: t('nav.collaborators'), href: '/equipe/colaboradores', ariaLabel: 'Colaboradores da força-tarefa' },
      { name: t('nav.partners'), href: '/equipe/parceiros', ariaLabel: 'Parceiros estratégicos' },
      { name: t('nav.institutions'), href: '/equipe/instituicoes', ariaLabel: 'Instituições participantes' },
    ]
  },
  { 
    name: t('nav.digital-resources'), 
    href: '/recursos-digitais',
    ariaLabel: 'Recursos digitais e ferramentas do projeto',
    submenu: [
      { name: t('nav.diseases-database'), href: '/recursos-digitais/doencas', ariaLabel: 'Base de dados de doenças raras da CPLP' },
      { name: t('nav.public-data'), href: '/recursos-digitais/dados-publicos', ariaLabel: 'Repositório de dados públicos organizados' },
      { name: 'Podcast CPLP-Raras', href: '/recursos-digitais/podcast', ariaLabel: 'Podcast semanal sobre doenças raras na CPLP' },
      { name: t('nav.sof'), href: '/recursos-digitais/sof', ariaLabel: 'Sistema de Orientação Diagnóstica', comingSoon: true },
      { name: t('nav.educational-gpt'), href: '/recursos-digitais/gpt-educativo', ariaLabel: 'GPT educativo sobre doenças raras', comingSoon: true },
    ]
  },
  { name: t('nav.contact'), href: '/contato', ariaLabel: 'Informações de contato da rede CPLP-Raras' }

  /* TO DO: Uncomment when INTEGRATION ready
    { name: 'Publicações', href: '/publicacoes', ariaLabel: 'Publicações científicas da rede' },
    { name: 'Eventos', href: '/eventos',ariaLabel: 'Eventos e notícias',
    submenu: [
      { name: 'Próximos Eventos', href: '/eventos', ariaLabel: 'Calendário de eventos futuros' },
      { name: 'Notícias', href: '/noticias', ariaLabel: 'Últimas notícias e atualizações' },
    ]
  } */
];

export default function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [openDropdown, setOpenDropdown] = useState<string | null>(null);
  const [openSubDropdown, setOpenSubDropdown] = useState<string | null>(null);
  const { t } = useLanguage();
  
  const navigation = getNavigation(t);

  const handleDropdownToggle = (itemName: string) => {
    setOpenDropdown(openDropdown === itemName ? null : itemName);
  };

  return (
    <header className="bg-white shadow-md sticky top-0 z-50">
      <nav className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8" aria-label="Top">
        <div className="flex w-full items-center justify-between py-4 lg:py-6">
          <div className="flex items-center">
            <Link href="/" className="flex items-center space-x-3">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-gradient-to-br from-blue-600 via-purple-600 to-pink-600 rounded-full flex items-center justify-center shadow-lg">
                  <span className="text-white font-bold text-xl">🦓</span>
                </div>
                <div>
                  <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">
                    CPLP-Raras
                  </h1>
                  <p className="text-sm text-gray-600">Doenças Raras</p>
                </div>
              </div>
            </Link>
          </div>
          
          {/* Desktop navigation */}
          <div className="hidden lg:ml-8 lg:flex lg:items-center lg:space-x-2">
            {navigation.map((item) => (
              <div key={item.name} className="relative group">
                {item.submenu ? (
                  <div className="relative">
                    <button
                      className="text-gray-700 hover:text-pink-600 px-4 py-3 text-base font-medium transition-all duration-200 flex items-center space-x-1 hover:bg-pink-50 rounded-lg"
                      onMouseEnter={() => setOpenDropdown(item.name)}
                      onMouseLeave={() => setOpenDropdown(null)}
                    >
                      <span>{item.name}</span>
                      <ChevronDownIcon className={`h-4 w-4 transition-transform duration-200 ${
                        openDropdown === item.name ? 'rotate-180' : ''
                      }`} />
                    </button>
                    
                    {/* Dropdown menu */}
                    <div
                      className={`absolute left-0 mt-2 w-64 bg-white rounded-xl shadow-lg ring-1 ring-black ring-opacity-5 z-50 transition-all duration-200 border border-pink-100 ${
                        openDropdown === item.name ? 'opacity-100 visible transform scale-100' : 'opacity-0 invisible transform scale-95'
                      }`}
                      onMouseEnter={() => setOpenDropdown(item.name)}
                      onMouseLeave={() => {
                        setOpenDropdown(null);
                        setOpenSubDropdown(null);
                      }}
                    >
                      <div className="py-2">
                        {item.submenu.map((subItem) => (
                          <div key={subItem.name} className="relative">
                            {'submenu' in subItem && subItem.submenu ? (
                              // Sub-item com submenu (terceiro nível)
                              <div className="relative group">
                                <button
                                  className="w-full flex items-center justify-between px-4 py-3 text-sm text-gray-700 hover:bg-gradient-to-r hover:from-pink-50 hover:to-purple-50 hover:text-pink-700 transition-all duration-200 border-l-4 border-transparent hover:border-pink-400"
                                  onMouseEnter={() => setOpenSubDropdown(subItem.name)}
                                >
                                  <span>{subItem.name}</span>
                                  <ChevronDownIcon className="h-3 w-3 rotate-[-90deg]" />
                                </button>
                                
                                {/* Submenu de terceiro nível */}
                                <div
                                  className={`absolute left-full top-0 ml-1 w-56 bg-white rounded-xl shadow-lg ring-1 ring-black ring-opacity-5 border border-purple-100 transition-all duration-200 ${
                                    openSubDropdown === subItem.name ? 'opacity-100 visible transform scale-100' : 'opacity-0 invisible transform scale-95'
                                  }`}
                                  onMouseEnter={() => setOpenSubDropdown(subItem.name)}
                                  onMouseLeave={() => setOpenSubDropdown(null)}
                                >
                                  <div className="py-2">
                                    {subItem.submenu.map((subSubItem: any) => (
                                      <Link
                                        key={subSubItem.name}
                                        href={subSubItem.href}
                                        className="block px-4 py-2 text-sm text-gray-700 hover:bg-gradient-to-r hover:from-purple-50 hover:to-blue-50 hover:text-purple-700 transition-all duration-200 border-l-4 border-transparent hover:border-purple-400"
                                      >
                                        {subSubItem.name}
                                      </Link>
                                    ))}
                                  </div>
                                </div>
                              </div>
                            ) : (
                              // Sub-item sem submenu (segundo nível)
                              <Link
                                href={subItem.href}
                                className="block px-4 py-3 text-sm text-gray-700 hover:bg-gradient-to-r hover:from-pink-50 hover:to-purple-50 hover:text-pink-700 transition-all duration-200 border-l-4 border-transparent hover:border-pink-400"
                              >
                                {subItem.name}
                              </Link>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                ) : (
                  <Link
                    href={item.href}
                    className="text-gray-700 hover:text-pink-600 px-4 py-3 text-base font-medium transition-all duration-200 hover:bg-pink-50 rounded-lg"
                  >
                    {item.name}
                  </Link>
                )}
              </div>
            ))}
            
            {/* Language Selector and Social Media Icons */}
            <div className="flex items-center space-x-3 ml-4 pl-4 border-l border-gray-200">
              <LanguageSelector />
              <a
                href="https://instagram.com/rarasporti"
                target="_blank"
                rel="noopener noreferrer"
                className="w-8 h-8 bg-gradient-to-br from-pink-500 to-purple-600 rounded-lg flex items-center justify-center hover:from-pink-600 hover:to-purple-700 transition-all duration-200 transform hover:scale-110 shadow-sm hover:shadow-md"
                title="Instagram @rarasporti"
              >
                <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
                </svg>
              </a>
              <a
                href="https://www.facebook.com/profile.php?id=61578726425301"
                target="_blank"
                rel="noopener noreferrer"
                className="w-8 h-8 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg flex items-center justify-center hover:from-blue-600 hover:to-blue-700 transition-all duration-200 transform hover:scale-110 shadow-sm hover:shadow-md"
                title="Facebook CPLP-Raras"
              >
                <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                </svg>
              </a>
            </div>
          </div>
          
          {/* Mobile menu button */}
          <div className="lg:hidden">
            <button
              type="button"
              className="rounded-lg p-2 text-gray-400 hover:bg-pink-50 hover:text-pink-600 transition-all duration-200"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              <span className="sr-only">Abrir menu principal</span>
              {mobileMenuOpen ? (
                <XMarkIcon className="h-6 w-6" aria-hidden="true" />
              ) : (
                <Bars3Icon className="h-6 w-6" aria-hidden="true" />
              )}
            </button>
          </div>
        </div>
        
        {/* Mobile navigation */}
        {mobileMenuOpen && (
          <div className="lg:hidden border-t border-pink-100 bg-gradient-to-b from-white to-pink-50">
            <div className="space-y-1 pb-4 pt-3">
              {navigation.map((item) => (
                <div key={item.name}>
                  {item.submenu ? (
                    <div>
                      <button
                        className="w-full flex items-center justify-between px-4 py-3 text-base font-medium text-gray-700 hover:bg-pink-100 hover:text-pink-700 rounded-lg mx-2 transition-all duration-200"
                        onClick={() => handleDropdownToggle(item.name)}
                      >
                        <span>{item.name}</span>
                        <ChevronDownIcon 
                          className={`h-4 w-4 transform transition-transform duration-200 ${
                            openDropdown === item.name ? 'rotate-180' : ''
                          }`} 
                        />
                      </button>
                      
                      {/* Mobile submenu */}
                      {openDropdown === item.name && (
                        <div className="pl-6 space-y-1 ml-2 mr-2 mt-2 bg-white rounded-lg border border-pink-200 shadow-sm">
                          {item.submenu.map((subItem) => (
                            <Link
                              key={subItem.name}
                              href={subItem.href}
                              className="block px-4 py-3 text-sm text-gray-600 hover:bg-gradient-to-r hover:from-pink-50 hover:to-purple-50 hover:text-pink-700 rounded-lg border-l-4 border-transparent hover:border-pink-400 transition-all duration-200"
                              onClick={() => setMobileMenuOpen(false)}
                            >
                              {subItem.name}
                            </Link>
                          ))}
                        </div>
                      )}
                    </div>
                  ) : (
                    <Link
                      href={item.href}
                      className="block px-4 py-3 text-base font-medium text-gray-700 hover:bg-pink-100 hover:text-pink-700 rounded-lg mx-2 transition-all duration-200"
                      onClick={() => setMobileMenuOpen(false)}
                    >
                      {item.name}
                    </Link>
                  )}
                </div>
              ))}
              
              {/* Language Selector and Social Media for Mobile */}
              <div className="pt-4 mt-4 border-t border-pink-200 mx-2">
                <div className="flex items-center justify-between px-4 py-2">
                  <div className="flex items-center space-x-3">
                    <LanguageSelector />
                  </div>
                  <div className="flex items-center space-x-3">
                    <a
                      href="https://instagram.com/rarasporti"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-8 h-8 bg-gradient-to-br from-pink-500 to-purple-600 rounded-lg flex items-center justify-center hover:from-pink-600 hover:to-purple-700 transition-all duration-200 transform hover:scale-110 shadow-sm hover:shadow-md"
                      title="Instagram @rarasporti"
                    >
                      <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
                      </svg>
                    </a>
                    <a
                      href="https://www.facebook.com/profile.php?id=61578726425301"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-8 h-8 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg flex items-center justify-center hover:from-blue-600 hover:to-blue-700 transition-all duration-200 transform hover:scale-110 shadow-sm hover:shadow-md"
                      title="Facebook CPLP-Raras"
                    >
                      <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                      </svg>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </nav>
    </header>
  );
}
