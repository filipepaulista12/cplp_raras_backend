'use client';

import { useState } from 'react';
import { 
  ChatBubbleLeftRightIcon, 
  StarIcon, 
  ExclamationTriangleIcon,
  LightBulbIcon,
  XMarkIcon 
} from '@heroicons/react/24/outline';
import { StarIcon as StarSolid } from '@heroicons/react/24/solid';

interface FeedbackData {
  type: 'suggestion' | 'rating' | 'error';
  rating?: number;
  category: string;
  message: string;
  email?: string;
  page: string;
  userAgent: string;
  timestamp: string;
}

const feedbackTypes = [
  {
    id: 'suggestion' as const,
    label: 'Sugestão',
    icon: LightBulbIcon,
    color: 'blue',
    description: 'Compartilhe ideias para melhorar o site'
  },
  {
    id: 'rating' as const,
    label: 'Avaliação',
    icon: StarIcon,
    color: 'yellow',
    description: 'Avalie sua experiência no site'
  },
  {
    id: 'error' as const,
    label: 'Reportar Erro',
    icon: ExclamationTriangleIcon,
    color: 'red',
    description: 'Informe problemas técnicos ou de conteúdo'
  }
];

const categories = {
  suggestion: [
    'Conteúdo Científico',
    'Design e Usabilidade',
    'Funcionalidade',
    'Acessibilidade',
    'Performance',
    'Outro'
  ],
  rating: [
    'Experiência Geral',
    'Facilidade de Navegação',
    'Qualidade do Conteúdo',
    'Design Visual',
    'Velocidade do Site'
  ],
  error: [
    'Erro de Carregamento',
    'Link Quebrado',
    'Erro de Formulário',
    'Problema de Layout',
    'Conteúdo Incorreto',
    'Problema de Acessibilidade'
  ]
};

interface FeedbackSystemProps {
  isOpen?: boolean;
  onClose?: () => void;
}

export default function FeedbackSystem({ isOpen: externalIsOpen, onClose: externalOnClose }: FeedbackSystemProps = {}) {
  const [internalIsOpen, setInternalIsOpen] = useState(false);
  
  // Usar controle externo se fornecido, senão usar interno
  const isOpen = externalIsOpen !== undefined ? externalIsOpen : internalIsOpen;
  const closeModal = () => {
    if (externalOnClose) {
      externalOnClose();
    } else {
      setInternalIsOpen(false);
    }
  };
  const [feedbackType, setFeedbackType] = useState<'suggestion' | 'rating' | 'error'>('suggestion');
  const [rating, setRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);
  const [category, setCategory] = useState('');
  const [message, setMessage] = useState('');
  const [email, setEmail] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    const feedbackData: FeedbackData = {
      type: feedbackType,
      rating: feedbackType === 'rating' ? rating : undefined,
      category,
      message,
      email: email || undefined,
      page: typeof window !== 'undefined' ? window.location.pathname : '',
      userAgent: typeof window !== 'undefined' ? navigator.userAgent : '',
      timestamp: new Date().toISOString()
    };

    try {
      // ENVIAR VIA RESEND API
      const response = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: email ? email.split('@')[0] : 'Usuário Anônimo',
          email: email || 'feedback@cplp-raras.org',
          institution: '',
          country: '',
          subject: `[FEEDBACK CPLP-RARAS] ${feedbackData.type === 'suggestion' ? 'Sugestão' : feedbackData.type === 'rating' ? 'Avaliação' : 'Reportar Erro'} - ${category}`,
          message: `
FEEDBACK DO SITE CPLP-RARAS

Tipo: ${feedbackData.type === 'suggestion' ? 'Sugestão' : feedbackData.type === 'rating' ? 'Avaliação' : 'Reportar Erro'}
Categoria: ${category}
${rating ? `Avaliação: ${rating}/5 estrelas` : ''}
Página: ${feedbackData.page}
${email ? `Email para resposta: ${email}` : ''}

Mensagem:
${message}

---
Dados Técnicos:
User Agent: ${feedbackData.userAgent}
Data/Hora: ${feedbackData.timestamp}
          `.trim()
        })
      });

      if (response.ok) {
        console.log('✅ Feedback enviado via Resend!');
        
        // Salvar no localStorage também (backup)
        const existingFeedback = localStorage.getItem('cplp-feedback') || '[]';
        const feedbackList = JSON.parse(existingFeedback);
        feedbackList.push({
          ...feedbackData,
          id: Date.now()
        });
        localStorage.setItem('cplp-feedback', JSON.stringify(feedbackList));

        // Incrementar contador de feedback
        const feedbackCount = localStorage.getItem('cplp-feedback-count') || '0';
        localStorage.setItem('cplp-feedback-count', String(parseInt(feedbackCount) + 1));

        setIsSubmitted(true);
        setTimeout(() => {
          resetForm();
          closeModal();
        }, 2000);
      } else {
        throw new Error('Erro na API');
      }
    } catch (error) {
      console.error('Erro ao enviar feedback via API, usando fallback:', error);
      
      // FALLBACK: Abrir email client
      const emailBody = `
FEEDBACK CPLP-RARAS

Tipo: ${feedbackData.type === 'suggestion' ? 'Sugestão' : feedbackData.type === 'rating' ? 'Avaliação' : 'Reportar Erro'}
Categoria: ${category}
${rating ? `Avaliação: ${rating}/5 estrelas` : ''}

Mensagem:
${message}
      `.trim();

      const subject = `[FEEDBACK] ${feedbackData.type === 'suggestion' ? 'Sugestão' : feedbackData.type === 'rating' ? 'Avaliação' : 'Erro'} - ${category}`;
      const mailtoLink = `mailto:cplp@raras.org.br?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(emailBody)}`;
      
      window.location.href = mailtoLink;
      closeModal();
    } finally {
      setIsSubmitting(false);
    }
  };

  const resetForm = () => {
    setFeedbackType('suggestion');
    setRating(0);
    setHoverRating(0);
    setCategory('');
    setMessage('');
    setEmail('');
    setIsSubmitted(false);
    setIsSubmitting(false);
  };

  return (
    <>
      {/* Botão Flutuante de Feedback - apenas se não controlado externamente */}
      {externalIsOpen === undefined && (
        <div className="fixed bottom-6 right-6 z-50">
          <button
            onClick={() => setInternalIsOpen(true)}
            className="bg-gradient-to-r from-orange-600 to-amber-600 text-white p-4 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 group"
            aria-label="Enviar feedback"
          >
            <ChatBubbleLeftRightIcon className="h-6 w-6 group-hover:animate-pulse" />
          </button>
        </div>
      )}

      {/* Modal de Feedback */}
      {isOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto">
          <div className="flex min-h-full items-end justify-center p-4 text-center sm:items-center sm:p-0">
          <div 
            className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity"
            onClick={closeModal}
          />            <div className="relative transform overflow-hidden rounded-2xl bg-white text-left shadow-xl transition-all sm:my-8 sm:w-full sm:max-w-2xl">
              {isSubmitted ? (
                <div className="p-8 text-center">
                  <div className="mb-4">
                    <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-green-100">
                      <ChatBubbleLeftRightIcon className="h-8 w-8 text-green-600" />
                    </div>
                  </div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">
                    🎉 Obrigado pelo seu feedback!
                  </h3>
                  <p className="text-gray-600">
                    Sua contribuição é muito importante para melhorarmos o site CPLP-Raras.
                  </p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="p-6">
                  <div className="flex items-center justify-between mb-6">
                    <h3 className="text-2xl font-bold text-gray-900">
                      💬 Envie seu Feedback
                    </h3>
                    <button
                      type="button"
                      onClick={closeModal}
                      className="rounded-md bg-white text-gray-400 hover:text-gray-500"
                    >
                      <XMarkIcon className="h-6 w-6" />
                    </button>
                  </div>

                  {/* Tipo de Feedback */}
                  <div className="mb-6">
                    <label className="block text-sm font-medium text-gray-700 mb-3">
                      Tipo de Feedback
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      {feedbackTypes.map((type) => {
                        const Icon = type.icon;
                        return (
                          <button
                            key={type.id}
                            type="button"
                            onClick={() => {
                              setFeedbackType(type.id);
                              setCategory('');
                              setRating(0);
                            }}
                            className={`p-4 rounded-lg border-2 transition-colors text-left ${
                              feedbackType === type.id 
                                ? 'border-orange-300 bg-orange-50' 
                                : 'border-gray-200 hover:border-gray-300'
                            }`}
                          >
                            <div className="flex items-center space-x-3">
                              <Icon className={`h-5 w-5 ${
                                type.color === 'blue' ? 'text-blue-600' :
                                type.color === 'yellow' ? 'text-yellow-600' :
                                'text-red-600'
                              }`} />
                              <div>
                                <div className="font-medium text-gray-900">{type.label}</div>
                                <div className="text-xs text-gray-500">{type.description}</div>
                              </div>
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Rating para Avaliação */}
                  {feedbackType === 'rating' && (
                    <div className="mb-6">
                      <label className="block text-sm font-medium text-gray-700 mb-3">
                        Sua Avaliação (obrigatório)
                      </label>
                      <div className="flex space-x-2">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <button
                            key={star}
                            type="button"
                            onClick={() => setRating(star)}
                            onMouseEnter={() => setHoverRating(star)}
                            onMouseLeave={() => setHoverRating(0)}
                            className="p-1 rounded transition-transform hover:scale-110"
                          >
                            {star <= (hoverRating || rating) ? (
                              <StarSolid className="h-8 w-8 text-yellow-400" />
                            ) : (
                              <StarIcon className="h-8 w-8 text-gray-300" />
                            )}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Categoria */}
                  <div className="mb-6">
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Categoria *
                    </label>
                    <select
                      value={category}
                      onChange={(e) => setCategory(e.target.value)}
                      required
                      className="w-full rounded-lg border-gray-300 shadow-sm focus:border-orange-500 focus:ring-orange-500"
                    >
                      <option value="">Selecione uma categoria</option>
                      {categories[feedbackType].map((cat) => (
                        <option key={cat} value={cat}>{cat}</option>
                      ))}
                    </select>
                  </div>

                  {/* Mensagem */}
                  <div className="mb-6">
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Sua Mensagem *
                    </label>
                    <textarea
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      required
                      rows={4}
                      placeholder="Descreva detalhadamente seu feedback, sugestão ou o erro encontrado..."
                      className="w-full rounded-lg border-gray-300 shadow-sm focus:border-orange-500 focus:ring-orange-500"
                    />
                  </div>

                  {/* Email (opcional) */}
                  <div className="mb-6">
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Email (opcional)
                    </label>
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="Para respondermos ao seu feedback"
                      className="w-full rounded-lg border-gray-300 shadow-sm focus:border-orange-500 focus:ring-orange-500"
                    />
                  </div>

                  {/* Botões */}
                  <div className="flex space-x-4">
                    <button
                      type="button"
                      onClick={closeModal}
                      className="flex-1 bg-gray-100 text-gray-700 px-4 py-3 rounded-lg font-medium hover:bg-gray-200 transition-colors"
                    >
                      Cancelar
                    </button>
                    <button
                      type="submit"
                      disabled={
                        isSubmitting || 
                        !category || 
                        !message || 
                        (feedbackType === 'rating' && rating === 0)
                      }
                      className="flex-1 bg-gradient-to-r from-orange-600 to-amber-600 text-white px-4 py-3 rounded-lg font-medium hover:from-orange-700 hover:to-amber-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      {isSubmitting ? 'Enviando...' : 'Enviar Feedback'}
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
}
