import Link from 'next/link';
import { ArrowLeftIcon } from '@heroicons/react/24/outline';
import TopShare from '@/components/TopShare';

export default function About() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Breadcrumb */}
      <div className="bg-white border-b">
        <div className="mx-auto max-w-7xl px-4 py-4 sm:px-6 lg:px-8">
          <Link 
            href="/"
            className="inline-flex items-center text-blue-600 hover:text-blue-800 transition-colors"
          >
            <ArrowLeftIcon className="h-4 w-4 mr-2" />
            Voltar ao Início
          </Link>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        
        {/* Compartilhamento no topo */}
        <TopShare 
          title="Sobre a CPLP-Raras"
          description="Rede de pesquisa e cooperação científica em doenças raras entre os países de língua portuguesa"
        />
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            🌍 Sobre o Projeto CPLP-Raras
          </h1>
          <div className="w-32 h-1 bg-gradient-to-r from-blue-600 to-green-600 mx-auto mb-8"></div>
          <p className="text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed">
            Mapeamento de Doenças Raras na Comunidade dos Países de Língua Portuguesa
          </p>
        </div>

        {/* Por que as Doenças Raras Importam */}
        <section className="mb-16">
          <div className="bg-white rounded-2xl shadow-lg p-8 md:p-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">
              🌍 Por que as Doenças Raras Importam?
            </h2>
            
            <div className="bg-blue-50 border-l-4 border-blue-600 p-6 mb-8">
              <p className="text-lg text-gray-700 leading-relaxed">
                As doenças raras afetam mais de <strong>300 milhões de pessoas globalmente</strong>, 
                representando um desafio significativo para os sistemas de saúde. Nos países da 
                Comunidade dos Países de Língua Portuguesa (CPLP), esta realidade é agravada pela 
                escassez de dados sistematizados, recursos limitados e fragmentação das informações 
                disponíveis.
              </p>
            </div>

            <div className="bg-gradient-to-r from-orange-50 to-red-50 border border-orange-200 rounded-xl p-6 mb-8">
              <h3 className="text-xl font-semibold text-gray-900 mb-3">📊 O Desafio:</h3>
              <p className="text-gray-700 leading-relaxed">
                Aproximadamente <strong>7% da população mundial</strong> convive com alguma doença rara, 
                mas nos países de língua portuguesa, a falta de registros adequados e estratégias 
                coordenadas limita o desenvolvimento de políticas públicas eficazes e o acesso a 
                cuidados especializados.
              </p>
            </div>

            <p className="text-lg text-gray-700 leading-relaxed">
              O projeto CPLP-Raras surge como resposta a esta lacuna, promovendo a cooperação 
              internacional, o compartilhamento de conhecimentos e o desenvolvimento de soluções 
              sustentáveis baseadas em evidências científicas e tecnologias digitais inovadoras.
            </p>
          </div>
        </section>

        {/* Missão, Visão e Objetivos */}
        <section className="mb-16">
          <div className="bg-white rounded-2xl shadow-lg p-8 md:p-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">
              🎯 Missão, Visão e Objetivos
            </h2>
            
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Missão */}
              <div className="bg-gradient-to-br from-blue-50 to-blue-100 border border-blue-200 rounded-xl p-6">
                <div className="text-center mb-4">
                  <span className="text-4xl">🧭</span>
                  <h3 className="text-xl font-bold text-blue-900 mt-2">Missão</h3>
                </div>
                <p className="text-blue-800 leading-relaxed">
                  Mapear, conectar e fortalecer recursos para doenças raras nos países da CPLP, 
                  promovendo equidade no acesso à informação, diagnóstico e tratamento através 
                  da cooperação internacional e soluções digitais inovadoras.
                </p>
              </div>

              {/* Visão */}
              <div className="bg-gradient-to-br from-green-50 to-green-100 border border-green-200 rounded-xl p-6">
                <div className="text-center mb-4">
                  <span className="text-4xl">🔭</span>
                  <h3 className="text-xl font-bold text-green-900 mt-2">Visão</h3>
                </div>
                <p className="text-green-800 leading-relaxed">
                  Tornar-se a principal plataforma de referência para doenças raras no espaço 
                  lusófono, estabelecendo uma rede colaborativa sustentável que transforme dados 
                  em ações concretas para melhorar a qualidade de vida dos pacientes.
                </p>
              </div>

              {/* Objetivos */}
              <div className="bg-gradient-to-br from-purple-50 to-purple-100 border border-purple-200 rounded-xl p-6">
                <div className="text-center mb-4">
                  <span className="text-4xl">📊</span>
                  <h3 className="text-xl font-bold text-purple-900 mt-2">Objetivos Estratégicos</h3>
                </div>
                <ul className="text-purple-800 space-y-2">
                  <li className="flex items-start">
                    <span className="text-purple-600 mr-2">•</span>
                    Criar um repositório integrado de dados sobre doenças raras
                  </li>
                  <li className="flex items-start">
                    <span className="text-purple-600 mr-2">•</span>
                    Desenvolver protocolos padronizados de coleta e análise
                  </li>
                  <li className="flex items-start">
                    <span className="text-purple-600 mr-2">•</span>
                    Estabelecer redes de colaboração multinacional
                  </li>
                  <li className="flex items-start">
                    <span className="text-purple-600 mr-2">•</span>
                    Promover capacitação técnica e científica
                  </li>
                  <li className="flex items-start">
                    <span className="text-purple-600 mr-2">•</span>
                    Implementar soluções de saúde digital sustentáveis
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </section>

        {/* Componentes do Projeto */}
        <section className="mb-16">
          <div className="bg-white rounded-2xl shadow-lg p-8 md:p-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">
              🔧 Componentes do Projeto
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow">
                <h3 className="text-xl font-semibold text-gray-900 mb-3 flex items-center">
                  <span className="text-2xl mr-3">🗺️</span>
                  Mapeamento de Recursos
                </h3>
                <p className="text-gray-600 leading-relaxed">
                  Identificação e catalogação de centros especializados, profissionais, recursos 
                  diagnósticos e terapêuticos disponíveis em cada país da CPLP.
                </p>
              </div>

              <div className="border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow">
                <h3 className="text-xl font-semibold text-gray-900 mb-3 flex items-center">
                  <span className="text-2xl mr-3">💻</span>
                  Plataformas Digitais
                </h3>
                <p className="text-gray-600 leading-relaxed">
                  Desenvolvimento de sistemas interoperáveis usando REDCap, repositórios FAIR e 
                  ferramentas de análise de dados para gestão integrada da informação.
                </p>
              </div>

              <div className="border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow">
                <h3 className="text-xl font-semibold text-gray-900 mb-3 flex items-center">
                  <span className="text-2xl mr-3">🤝</span>
                  Rede Colaborativa
                </h3>
                <p className="text-gray-600 leading-relaxed">
                  Estabelecimento de parcerias estratégicas entre instituições acadêmicas, 
                  hospitalares e organizações da sociedade civil nos países participantes.
                </p>
              </div>

              <div className="border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow">
                <h3 className="text-xl font-semibold text-gray-900 mb-3 flex items-center">
                  <span className="text-2xl mr-3">⚙️</span>
                  Protocolos e Algoritmos
                </h3>
                <p className="text-gray-600 leading-relaxed">
                  Criação de conjunto mínimo de dados, algoritmos de análise e protocolos 
                  padronizados para coleta, validação e interpretação de informações.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Call to Action */}
        <section className="text-center">
          <div className="bg-gradient-to-r from-blue-600 to-green-600 rounded-2xl p-8 text-white">
            <h2 className="text-2xl font-bold mb-4">Junte-se ao CPLP-Raras</h2>
            <p className="text-xl mb-6 opacity-90">
              Faça parte desta rede colaborativa e contribua para o avanço da pesquisa em doenças raras.
            </p>
            <Link
              href="/contato"
              className="inline-block bg-white text-blue-600 px-8 py-3 rounded-lg font-semibold hover:bg-blue-50 transition-colors"
            >
              Entre em Contato
            </Link>
          </div>
        </section>
      </div>
    </div>
  );
}
