'use client'

import { useHPOStore } from '@/store/hpoStore'
import { useEffect, useState } from 'react'
import type { Translation } from '@/types/hpo'

export default function HistoryPage() {
  const { terms, translations, setTerms } = useHPOStore()
  const [isLoaded, setIsLoaded] = useState(false)
  const [selectedTerm, setSelectedTerm] = useState<string>('')
  const [filteredTranslations, setFilteredTranslations] = useState<Translation[]>([])
  
  useEffect(() => {
    if (terms.length === 0 && !isLoaded) {
      fetch('/hpo-sample.json')
        .then(res => res.json())
        .then(data => {
          setTerms(data.terms)
          setIsLoaded(true)
        })
        .catch(err => console.error('Erro ao carregar dados:', err))
    } else {
      setIsLoaded(true)
    }
  }, [terms.length, setTerms, isLoaded])
  
  useEffect(() => {
    if (selectedTerm) {
      const termTranslations = translations
        .filter(t => t.term_id === selectedTerm)
        .sort((a, b) => new Date(b.translation_date).getTime() - new Date(a.translation_date).getTime())
      setFilteredTranslations(termTranslations)
    } else {
      const allTranslations = translations
        .sort((a, b) => new Date(b.translation_date).getTime() - new Date(a.translation_date).getTime())
      setFilteredTranslations(allTranslations)
    }
  }, [selectedTerm, translations])
  
  const getTermLabel = (termId: string) => {
    const term = terms.find(t => t.id === termId)
    return term?.label_en || termId
  }
  
  const getStatusColor = (isFinal: boolean) => {
    return isFinal ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
  }
  
  const getStatusLabel = (isFinal: boolean) => {
    return isFinal ? 'Final' : 'Em Revisão'
  }
  
  const getLikertColor = (score: number) => {
    if (score >= 4) return 'text-green-600'
    if (score >= 3) return 'text-yellow-600'
    return 'text-red-600'
  }
  
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }
  
  // Estatísticas rápidas
  const recentTranslations = translations
    .filter(t => {
      const date = new Date(t.translation_date)
      const weekAgo = new Date()
      weekAgo.setDate(weekAgo.getDate() - 7)
      return date >= weekAgo
    }).length
  
  const uniqueTermsTranslated = new Set(translations.map(t => t.term_id)).size
  const uniqueTranslators = new Set(translations.map(t => t.translator)).size
  
  if (!isLoaded) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="text-gray-500">Carregando histórico...</div>
      </div>
    )
  }
  
  return (
    <div className="max-w-7xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">
          📋 Histórico de Traduções
        </h1>
        <p className="text-gray-600">
          Acompanhe o progresso e as versões das traduções colaborativas da HPO.
        </p>
      </div>
      
      {/* Estatísticas rápidas */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6 text-center">
          <div className="text-2xl font-bold text-blue-600 mb-2">
            {translations.length}
          </div>
          <div className="text-gray-600 text-sm">Total de Revisões</div>
        </div>
        
        <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6 text-center">
          <div className="text-2xl font-bold text-green-600 mb-2">
            {recentTranslations}
          </div>
          <div className="text-gray-600 text-sm">Esta Semana</div>
        </div>
        
        <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6 text-center">
          <div className="text-2xl font-bold text-purple-600 mb-2">
            {uniqueTermsTranslated}
          </div>
          <div className="text-gray-600 text-sm">Termos Únicos</div>
        </div>
        
        <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6 text-center">
          <div className="text-2xl font-bold text-orange-600 mb-2">
            {uniqueTranslators}
          </div>
          <div className="text-gray-600 text-sm">Tradutores Ativos</div>
        </div>
      </div>
      
      {/* Filtros */}
      <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6 mb-8">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex-1">
            <label htmlFor="term-filter" className="block text-sm font-medium text-gray-700 mb-1">
              Filtrar por Termo HPO
            </label>
            <select
              id="term-filter"
              value={selectedTerm}
              onChange={(e) => setSelectedTerm(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="">Todos os termos</option>
              {terms.map(term => (
                <option key={term.id} value={term.id}>
                  {term.id} - {term.label_en}
                </option>
              ))}
            </select>
          </div>
          
          <div className="flex items-end">
            <button
              onClick={() => setSelectedTerm('')}
              className="px-4 py-2 text-sm text-gray-600 bg-gray-100 rounded-md hover:bg-gray-200 transition-colors"
            >
              Limpar Filtros
            </button>
          </div>
        </div>
      </div>
      
      {/* Timeline de traduções */}
      <div className="bg-white rounded-lg shadow-md border border-gray-200">
        <div className="p-6 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900">
            Timeline de Atividades
            {selectedTerm && (
              <span className="ml-2 text-sm font-normal text-gray-600">
                • Filtrado para: {getTermLabel(selectedTerm)}
              </span>
            )}
          </h3>
        </div>
        
        <div className="p-6">
          {filteredTranslations.length > 0 ? (
            <div className="space-y-6">
              {filteredTranslations.map((translation, index) => (
                <div key={`${translation.term_id}-${translation.translation_date}-${index}`} className="relative">
                  {/* Linha conectora */}
                  {index < filteredTranslations.length - 1 && (
                    <div className="absolute left-4 top-12 w-0.5 h-16 bg-gray-200"></div>
                  )}
                  
                  <div className="flex items-start space-x-4">
                    {/* Ícone de status */}
                    <div className="flex-shrink-0 w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center">
                      <div className="w-3 h-3 bg-blue-600 rounded-full"></div>
                    </div>
                    
                    {/* Conteúdo */}
                    <div className="flex-1 min-w-0">
                      <div className="bg-gray-50 rounded-lg p-4">
                        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-3">
                          <div className="flex items-center space-x-2 mb-2 sm:mb-0">
                            <span className="font-medium text-gray-900">
                              {translation.term_id}
                            </span>
                            <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(translation.is_final)}`}>
                              {getStatusLabel(translation.is_final)}
                            </span>
                          </div>
                          
                          <div className="flex items-center space-x-4 text-sm text-gray-500">
                            <span>📅 {formatDate(translation.translation_date)}</span>
                            <span>👤 {translation.translator}</span>
                            {translation.likert_score > 0 && (
                              <span className={`font-medium ${getLikertColor(translation.likert_score)}`}>
                                ⭐ {translation.likert_score}/5
                              </span>
                            )}
                          </div>
                        </div>
                        
                        <div className="space-y-2">
                          <div>
                            <span className="text-sm font-medium text-gray-700">Original:</span>
                            <span className="ml-2 text-sm text-gray-900">{getTermLabel(translation.term_id)}</span>
                          </div>
                          
                          <div>
                            <span className="text-sm font-medium text-gray-700">Tradução:</span>
                            <span className="ml-2 text-sm text-gray-900">{translation.label_pt}</span>
                          </div>
                          
                          {translation.definition_pt && (
                            <div>
                              <span className="text-sm font-medium text-gray-700">Definição:</span>
                              <p className="mt-1 text-sm text-gray-900">{translation.definition_pt}</p>
                            </div>
                          )}
                          
                          {translation.comments && (
                            <div>
                              <span className="text-sm font-medium text-gray-700">Comentário:</span>
                              <p className="mt-1 text-sm text-gray-600 italic">{translation.comments}</p>
                            </div>
                          )}
                          
                          <div>
                            <span className="text-sm font-medium text-gray-700">Sinônimos:</span>
                            <div className="mt-1 flex flex-wrap gap-1">
                              {translation.synonyms_pt.length > 0 ? (
                                translation.synonyms_pt.map((synonym, idx) => (
                                  <span key={idx} className="inline-flex items-center px-2 py-1 rounded-full text-xs bg-blue-100 text-blue-800">
                                    {synonym}
                                  </span>
                                ))
                              ) : (
                                <span className="text-sm text-gray-500">Nenhum sinônimo</span>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <div className="text-gray-400 text-lg mb-2">📋</div>
              <div className="text-gray-500">
                {selectedTerm ? 'Nenhuma tradução encontrada para este termo' : 'Nenhuma tradução registrada ainda'}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
