export default function TestImagePage() {
  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold mb-8 text-center">🔍 Teste de Imagens - CPLP-Raras</h1>
        
        <div className="bg-white rounded-lg p-6 shadow-lg mb-8">
          <h2 className="text-xl font-semibold mb-4">📋 Status das Imagens no Servidor</h2>
          <div className="bg-green-50 border border-green-200 rounded p-4">
            <p className="text-green-800 font-medium">✅ Todas as 12 imagens testadas estão FUNCIONANDO no servidor!</p>
            <p className="text-sm text-green-600 mt-2">URLs testadas e confirmadas em 06 de agosto de 2025</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* Teste com IMG nativo HTML - sem JavaScript */}
          <div className="bg-white rounded-lg p-4 shadow">
            <h3 className="font-semibold mb-3">🖼️ UFRGS (HTML puro)</h3>
            <img 
              src="/filipe/images/logo-ufrgs.png" 
              alt="UFRGS Logo" 
              className="w-full h-24 object-contain border rounded"
            />
            <p className="text-xs text-gray-600 mt-2">/filipe/images/logo-ufrgs.png</p>
          </div>

          <div className="bg-white rounded-lg p-4 shadow">
            <h3 className="font-semibold mb-3">🖼️ Background (HTML puro)</h3>
            <img 
              src="/filipe/images/background.png" 
              alt="Background" 
              className="w-full h-24 object-cover border rounded"
            />
            <p className="text-xs text-gray-600 mt-2">/filipe/images/background.png</p>
          </div>

          <div className="bg-white rounded-lg p-4 shadow">
            <h3 className="font-semibold mb-3">🖼️ GT1 (HTML puro)</h3>
            <img 
              src="/filipe/images/GT1.png" 
              alt="GT1" 
              className="w-full h-24 object-contain border rounded"
            />
            <p className="text-xs text-gray-600 mt-2">/filipe/images/GT1.png</p>
          </div>

          <div className="bg-white rounded-lg p-4 shadow">
            <h3 className="font-semibold mb-3">🖼️ GT2 (HTML puro)</h3>
            <img 
              src="/filipe/images/GT2.png.png" 
              alt="GT2" 
              className="w-full h-24 object-contain border rounded"
            />
            <p className="text-xs text-gray-600 mt-2">/filipe/images/GT2.png.png</p>
          </div>

          <div className="bg-white rounded-lg p-4 shadow">
            <h3 className="font-semibold mb-3">🖼️ FAQ (HTML puro)</h3>
            <img 
              src="/filipe/images/faq.png" 
              alt="FAQ" 
              className="w-full h-24 object-contain border rounded"
            />
            <p className="text-xs text-gray-600 mt-2">/filipe/images/faq.png</p>
          </div>

          <div className="bg-white rounded-lg p-4 shadow">
            <h3 className="font-semibold mb-3">🖼️ USP (HTML puro)</h3>
            <img 
              src="/filipe/images/logo-usp.png" 
              alt="USP" 
              className="w-full h-24 object-contain border rounded"
            />
            <p className="text-xs text-gray-600 mt-2">/filipe/images/logo-usp.png</p>
          </div>
        </div>

        <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 mt-8">
          <h2 className="text-lg font-semibold text-blue-900 mb-4">🚀 Se as imagens acima NÃO aparecerem:</h2>
          <ol className="space-y-2 text-blue-800">
            <li><strong>1. Cache:</strong> Pressione Ctrl+F5 ou Cmd+Shift+R para forçar refresh</li>
            <li><strong>2. Incógnito:</strong> Teste em janela privada/incógnita</li>
            <li><strong>3. JavaScript:</strong> Verifique se JavaScript está habilitado</li>
            <li><strong>4. Console:</strong> Abra F12 e veja se há erros no Console</li>
            <li><strong>5. Network:</strong> Na aba Network (F12), veja se há falhas 404</li>
          </ol>
        </div>

        <div className="bg-green-50 border border-green-200 rounded-lg p-6 mt-4">
          <h2 className="text-lg font-semibold text-green-900 mb-4">✅ Se as imagens acima APARECEM:</h2>
          <p className="text-green-800">O problema está resolvido! O sistema de imagens está funcionando perfeitamente. 
          O problema anterior era cache do navegador.</p>
        </div>
      </div>
    </div>
  );
}
