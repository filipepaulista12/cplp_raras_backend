import { Metadata } from 'next';
import { Card, CardContent } from "@/components/ui/card";
import Link from 'next/link';
import TopShare from '@/components/TopShare';

export const metadata: Metadata = {
  title: 'Doenças Raras - Informações Globais | CPLP-Raras',
  description: 'Informações sobre doenças raras em diferentes regiões e organizações mundiais.',
  keywords: 'doenças raras, dia mundial, OMS, Brasil, Europa, EUA, Austrália',
};

export default function DoencasRarasPage() {
  const secoes = [
    {
      titulo: "Dia Mundial Doenças Raras",
      href: "/sobre/doencas-raras/dia-mundial",
      descricao: "Informações sobre o Dia Mundial das Doenças Raras, celebrado anualmente.",
      cor: "bg-gradient-to-br from-pink-500 to-purple-600"
    },
    {
      titulo: "Lista de Doenças Raras",
      href: "/sobre/doencas-raras/lista",
      descricao: "Lista completa e categorizada de doenças raras reconhecidas mundialmente.",
      cor: "bg-gradient-to-br from-blue-500 to-purple-600"
    },
    {
      titulo: "Doenças Raras no Brasil",
      href: "/sobre/doencas-raras/brasil",
      descricao: "Situação das doenças raras no sistema de saúde brasileiro.",
      cor: "bg-gradient-to-br from-green-500 to-blue-500"
    },
    {
      titulo: "Organização Mundial da Saúde (OMS)",
      href: "/sobre/doencas-raras/oms",
      descricao: "Diretrizes e políticas da OMS para doenças raras.",
      cor: "bg-gradient-to-br from-cyan-500 to-blue-600"
    },
    {
      titulo: "Doenças Raras na Europa",
      href: "/sobre/doencas-raras/europa",
      descricao: "Políticas e programas europeus para doenças raras.",
      cor: "bg-gradient-to-br from-blue-600 to-indigo-600"
    },
    {
      titulo: "Doenças Raras no EUA",
      href: "/sobre/doencas-raras/eua",
      descricao: "Sistema americano de pesquisa e tratamento de doenças raras.",
      cor: "bg-gradient-to-br from-red-500 to-pink-600"
    },
    {
      titulo: "Doenças Raras na Austrália",
      href: "/sobre/doencas-raras/australia",
      descricao: "Iniciativas australianas para pacientes com doenças raras.",
      cor: "bg-gradient-to-br from-yellow-500 to-orange-600"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        
        {/* Compartilhamento no topo */}
        <TopShare 
          title="Doenças Raras - Informações Globais"
          description="Informações sobre doenças raras em diferentes regiões e organizações mundiais"
        />
        
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent mb-6">
            Doenças Raras no Mundo
          </h1>
          <p className="text-xl text-gray-700 max-w-4xl mx-auto leading-relaxed">
            Explore informações sobre doenças raras em diferentes regiões do mundo, 
            políticas de saúde, listas oficiais e iniciativas globais.
          </p>
        </div>

        {/* Grid de Seções */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {secoes.map((secao, index) => (
            <Link key={index} href={secao.href}>
              <Card className="h-full transition-all duration-300 hover:scale-105 hover:shadow-xl cursor-pointer group">
                <CardContent className="p-0 h-full">
                  <div className={`${secao.cor} text-white p-8 rounded-t-lg h-32 flex items-center justify-center group-hover:opacity-90 transition-opacity`}>
                    <h2 className="text-xl font-bold text-center leading-tight">
                      {secao.titulo}
                    </h2>
                  </div>
                  <div className="p-6 bg-white rounded-b-lg flex-1">
                    <p className="text-gray-600 text-sm leading-relaxed">
                      {secao.descricao}
                    </p>
                    <div className="mt-4 inline-flex items-center text-blue-600 text-sm font-medium group-hover:text-blue-800">
                      Saiba mais →
                    </div>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>

        {/* Informação Geral */}
        <Card className="bg-gradient-to-r from-blue-100 to-purple-100">
          <CardContent className="p-8 text-center">
            <h2 className="text-2xl font-bold mb-4 text-gray-800">
              O que são Doenças Raras?
            </h2>
            <p className="text-gray-700 max-w-4xl mx-auto leading-relaxed">
              Doenças raras são condições médicas que afetam um pequeno número de pessoas em comparação 
              com a população geral. Embora individualmente raras, existem milhares dessas condições que, 
              juntas, afetam milhões de pessoas em todo o mundo. A pesquisa e o desenvolvimento de 
              tratamentos para essas doenças requer cooperação internacional e políticas específicas.
            </p>
          </CardContent>
        </Card>

      </div>
    </div>
  );
}
