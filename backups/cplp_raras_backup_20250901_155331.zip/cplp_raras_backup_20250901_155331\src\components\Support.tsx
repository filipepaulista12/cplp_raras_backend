export default function Support() {
  /* 
  return (
    <section className="py-16 bg-white">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            🤝 Apoio
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-blue-600 to-green-600 mx-auto mb-8"></div>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            O projeto CPLP-Raras conta com o apoio de instituições de renome internacional 
            e organizações dedicadas à pesquisa em doenças raras.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 items-center">
          <div className="text-center">
            <div className="bg-gray-100 rounded-lg p-8 h-32 flex items-center justify-center mb-4">
              <span className="text-2xl font-bold text-gray-600">CPLP</span>
            </div>
            <h3 className="text-lg font-semibold text-gray-900">
              Comunidade dos Países de Língua Portuguesa
            </h3>
          </div>
          
          <div className="text-center">
            <div className="bg-gray-100 rounded-lg p-8 h-32 flex items-center justify-center mb-4">
              <span className="text-2xl font-bold text-gray-600">USP</span>
            </div>
            <h3 className="text-lg font-semibold text-gray-900">
              Universidade de São Paulo
            </h3>
          </div>
          
          <div className="text-center">
            <div className="bg-gray-100 rounded-lg p-8 h-32 flex items-center justify-center mb-4">
              <span className="text-xl font-bold text-gray-600">Fundação</span>
            </div>
            <h3 className="text-lg font-semibold text-gray-900">
              Agências de Fomento
            </h3>
          </div>
          
          <div className="text-center">
            <div className="bg-gray-100 rounded-lg p-8 h-32 flex items-center justify-center mb-4">
              <span className="text-xl font-bold text-gray-600">Parceiros</span>
            </div>
            <h3 className="text-lg font-semibold text-gray-900">
              Instituições Internacionais
            </h3>
          </div>
        </div>
        
        <div className="mt-12 bg-gradient-to-r from-blue-50 to-green-50 rounded-xl p-8 text-center">
          <h3 className="text-2xl font-bold text-gray-900 mb-4">
            Quer ser nosso parceiro?
          </h3>
          <p className="text-lg text-gray-600 mb-6">
            Entre em contato conosco para saber como sua instituição pode contribuir 
            com o projeto CPLP-Raras.
          </p>
          <button className="bg-gradient-to-r from-blue-600 to-green-600 text-white px-8 py-3 rounded-lg font-semibold hover:opacity-90 transition-opacity">
            Fale Conosco
          </button>
        </div>
      </div>
    </section>
  );*/
}
