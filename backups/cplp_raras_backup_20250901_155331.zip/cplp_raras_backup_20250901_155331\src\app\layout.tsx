import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import AccessibilityPanel from "@/components/AccessibilityPanel";
import AccessibilityStatus from "@/components/AccessibilityStatus";
import FloatingActionButtons from "@/components/FloatingActionButtons";
import InteractionCounter from "@/components/InteractionCounter";
import { LanguageProvider } from "@/contexts/LanguageContext";

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "CPLP-Raras | Comunidade dos Países de Língua Portuguesa - Doenças Raras",
  description: "Fortalecer a resposta dos países da CPLP às doenças raras por meio do mapeamento informacional, do uso de tecnologias em saúde digital e da promoção de cooperação científica, educacional e clínica.",
  keywords: "CPLP, doenças raras, pesquisa, cooperação científica, saúde digital, países lusófonos, Brasil, Portugal, Angola, Moçambique, Cabo Verde, Guiné-Bissau, São Tomé e Príncipe, Timor-Leste",
  authors: [{ name: "CPLP-Raras Network" }],
  creator: "CPLP-Raras",
  publisher: "CPLP-Raras",
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  openGraph: {
    title: "CPLP-Raras | Rede de Pesquisa em Doenças Raras",
    description: "Fortalecer a resposta dos países da CPLP às doenças raras através de cooperação científica e tecnologias em saúde digital",
    type: "website",
    locale: "pt_BR",
    url: "https://cplp-raras.org",
    siteName: "CPLP-Raras",
  },
  twitter: {
    card: "summary_large_image",
    title: "CPLP-Raras | Rede de Pesquisa em Doenças Raras",
    description: "Fortalecer a resposta dos países da CPLP às doenças raras através de cooperação científica",
  },
  alternates: {
    canonical: "https://cplp-raras.org",
  },
  category: "healthcare",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="pt-BR">
      <head>
        <script 
          defer 
          src="https://cloud.umami.is/script.js" 
          data-website-id="591ab490-a929-42f9-a770-75eeb2e3a335"
        />
      </head>
      <body
        className={`${inter.variable} font-sans antialiased min-h-screen flex flex-col`}
      >
        <LanguageProvider>
          {/* Link para pular conteúdo - Acessibilidade */}
          <a 
            href="#main-content" 
            className="skip-link"
            tabIndex={1}
          >
            Pular para o conteúdo principal
          </a>
          
          <Header />
          <main id="main-content" className="flex-grow" tabIndex={-1}>
            {children}
          </main>
          <Footer />
          
          {/* Painel de Acessibilidade */}
          <AccessibilityPanel />
          
          {/* Barra de Status de Acessibilidade */}
          <AccessibilityStatus />

          {/* Contador de Interações (invisível, só para dados) */}
          <InteractionCounter />

          {/* Botões Flutuantes de Funcionalidades */}
          <FloatingActionButtons />
        </LanguageProvider>
      </body>
    </html>
  );
}
