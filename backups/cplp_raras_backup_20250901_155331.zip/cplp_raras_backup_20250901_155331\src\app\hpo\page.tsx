'use client'

import { useHPOStore } from '@/store/hpoStore'
import { useEffect } from 'react'
import Link from 'next/link'

export default function HPOHomePage() {
  const { terms, getStats, setTerms } = useHPOStore()
  const stats = getStats()
  
  // Carregar dados mockados na primeira execução
  useEffect(() => {
    if (terms.length === 0) {
      fetch('/hpo-sample.json')
        .then(res => res.json())
        .then(data => setTerms(data.terms))
        .catch(err => console.error('Erro ao carregar dados:', err))
    }
  }, [terms.length, setTerms])
  
  return (
    <div className="max-w-6xl mx-auto">
      {/* Header */}
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">
          🧬 HPO Translator CPLP
        </h1>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto">
          Plataforma colaborativa para tradução da Human Phenotype Ontology (HPO) 
          para português, seguindo os padrões da HPOIE para publicação no repositório oficial.
        </p>
      </div>
      
      {/* Estatísticas principais */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
        <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6 text-center">
          <div className="text-3xl font-bold text-blue-600 mb-2">
            {stats.total}
          </div>
          <div className="text-gray-600">Termos Total</div>
        </div>
        
        <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6 text-center">
          <div className="text-3xl font-bold text-gray-500 mb-2">
            {stats.candidate}
          </div>
          <div className="text-gray-600">Candidatos</div>
        </div>
        
        <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6 text-center">
          <div className="text-3xl font-bold text-yellow-600 mb-2">
            {stats.under_review}
          </div>
          <div className="text-gray-600">Em Revisão</div>
        </div>
        
        <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6 text-center">
          <div className="text-3xl font-bold text-green-600 mb-2">
            {stats.official}
          </div>
          <div className="text-gray-600">Oficiais</div>
        </div>
      </div>
      
      {/* Ações principais */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
        <Link href="/hpo/upload" className="bg-white rounded-lg shadow-md border border-gray-200 p-6 hover:shadow-lg transition-shadow">
          <div className="text-center">
            <div className="text-4xl mb-4">📂</div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">
              Importar HPO
            </h3>
            <p className="text-gray-600">
              Faça upload de arquivos OWL/OBO da HPO em inglês para começar o processo de tradução.
            </p>
          </div>
        </Link>
        
        <Link href="/hpo/translate" className="bg-white rounded-lg shadow-md border border-gray-200 p-6 hover:shadow-lg transition-shadow">
          <div className="text-center">
            <div className="text-4xl mb-4">📝</div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">
              Traduzir Termos
            </h3>
            <p className="text-gray-600">
              Interface colaborativa para tradução e revisão de termos HPO com sistema de avaliação.
            </p>
          </div>
        </Link>
        
        <Link href="/hpo/dashboard" className="bg-white rounded-lg shadow-md border border-gray-200 p-6 hover:shadow-lg transition-shadow">
          <div className="text-center">
            <div className="text-4xl mb-4">📊</div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">
              Dashboard
            </h3>
            <p className="text-gray-600">
              Visualizações e métricas de qualidade do processo de tradução colaborativa.
            </p>
          </div>
        </Link>
        
        <Link href="/hpo/history" className="bg-white rounded-lg shadow-md border border-gray-200 p-6 hover:shadow-lg transition-shadow">
          <div className="text-center">
            <div className="text-4xl mb-4">📚</div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">
              Histórico
            </h3>
            <p className="text-gray-600">
              Rastreamento completo de versões e decisões para cada termo traduzido.
            </p>
          </div>
        </Link>
        
        <Link href="/hpo/export" className="bg-white rounded-lg shadow-md border border-gray-200 p-6 hover:shadow-lg transition-shadow">
          <div className="text-center">
            <div className="text-4xl mb-4">📦</div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">
              Exportar
            </h3>
            <p className="text-gray-600">
              Gerar arquivos Babelon TSV e XLIFF compatíveis com o repositório HPOIE.
            </p>
          </div>
        </Link>
        
        <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6">
          <div className="text-center">
            <div className="text-4xl mb-4">🌐</div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">
              Padrão HPOIE
            </h3>
            <p className="text-gray-600">
              Seguimos os padrões internacionais para contribuição no repositório hpo-translations.
            </p>
          </div>
        </div>
      </div>
      
      {/* Informações sobre o projeto */}
      <div className="bg-white rounded-lg shadow-md border border-gray-200 p-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-4">
          Sobre o HPO Translator CPLP
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-3">Objetivo</h3>
            <p className="text-gray-600 mb-4">
              Esta plataforma facilita a tradução colaborativa da Human Phenotype Ontology (HPO) 
              para português, permitindo que especialistas dos países da CPLP contribuam com 
              traduções de alta qualidade.
            </p>
            
            <h3 className="text-lg font-semibold text-gray-900 mb-3">Fluxo de Trabalho</h3>
            <ul className="text-gray-600 space-y-2">
              <li>• Import de arquivos HPO originais em inglês</li>
              <li>• Sugestões iniciais de tradução via IA</li>
              <li>• Revisão colaborativa por especialistas</li>
              <li>• Sistema de consenso e versionamento</li>
              <li>• Export no formato padrão HPOIE</li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-3">Compatibilidade</h3>
            <p className="text-gray-600 mb-4">
              Os arquivos gerados seguem o padrão Babelon TSV utilizado pelo 
              repositório oficial hpo-translations da HPOIE, garantindo 
              compatibilidade total.
            </p>
            
            <h3 className="text-lg font-semibold text-gray-900 mb-3">Qualidade</h3>
            <ul className="text-gray-600 space-y-2">
              <li>• Sistema de avaliação Likert (1-5)</li>
              <li>• Revisão por múltiplos especialistas</li>
              <li>• Rastreamento completo de versões</li>
              <li>• Validação por consenso</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  )
}
