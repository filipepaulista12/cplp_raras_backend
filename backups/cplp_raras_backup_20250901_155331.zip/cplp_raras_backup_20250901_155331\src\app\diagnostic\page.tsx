import ImageDiagnostic from '@/components/ImageDiagnostic';

export default function DiagnosticPage() {
  return (
    <div className="min-h-screen bg-gray-100">
      <div className="container mx-auto py-8">
        <h1 className="text-3xl font-bold text-center mb-8 text-gray-900">
          Diagnóstico de Imagens CPLP-Raras
        </h1>
        <ImageDiagnostic />
        
        <div className="mt-8 p-6 bg-white rounded-lg border max-w-4xl mx-auto">
          <h2 className="text-xl font-semibold mb-4">📋 Checklist de Resolução:</h2>
          <div className="space-y-3">
            <div className="flex items-center space-x-3">
              <input type="checkbox" className="w-4 h-4" />
              <span>Verificar se imagens existem em /var/www/html/filipe/images/ no servidor</span>
            </div>
            <div className="flex items-center space-x-3">
              <input type="checkbox" className="w-4 h-4" />
              <span>Confirmar permissões 644 para arquivos de imagem</span>
            </div>
            <div className="flex items-center space-x-3">
              <input type="checkbox" className="w-4 h-4" />
              <span>Testar acesso direto às URLs das imagens</span>
            </div>
            <div className="flex items-center space-x-3">
              <input type="checkbox" className="w-4 h-4" />
              <span>Verificar logs do servidor Apache/Nginx</span>
            </div>
            <div className="flex items-center space-x-3">
              <input type="checkbox" className="w-4 h-4" />
              <span>Limpar cache do navegador (Ctrl+F5)</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
