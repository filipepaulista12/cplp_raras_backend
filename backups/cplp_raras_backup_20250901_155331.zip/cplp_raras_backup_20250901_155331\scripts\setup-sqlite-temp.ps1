# Configuração temporária com SQLite para desenvolvimento
# ====================================================

# Para resolver o problema do PostgreSQL, vamos usar SQLite temporariamente

# 1. Backup do .env atual
if (Test-Path ".env") {
    Copy-Item ".env" ".env.postgresql.backup"
    Write-Host "Backup do .env criado: .env.postgresql.backup" -ForegroundColor Yellow
}

# 2. Criar nova configuração SQLite
$sqliteEnv = @"
# CONFIGURACAO TEMPORARIA - SQLite para desenvolvimento
# ====================================================

# SQLite Database (temporario)
DATABASE_URL="file:./database/gard_dev.db"

# Configuracoes de Import
IMPORT_BATCH_SIZE=1000
IMPORT_MAX_RETRIES=3
IMPORT_TIMEOUT_MS=30000
IMPORT_LANGUAGES=en,pt

# Environment
NODE_ENV=development
NEXT_PUBLIC_API_URL=http://localhost:3000

# Configuracao GARD
GARD_API_KEY=
GARD_BASE_URL=https://rarediseases.info.nih.gov

# Email (opcional para desenvolvimento)
RESEND_API_KEY=

# Analytics (opcional)
VERCEL_ANALYTICS_ID=

# Security
NEXTAUTH_URL=http://localhost:3000
NEXTAUTH_SECRET=development-secret-key-change-in-production
"@

# 3. Salvar nova configuração
$sqliteEnv | Out-File -FilePath ".env" -Encoding UTF8
Write-Host "Nova configuracao SQLite criada em .env" -ForegroundColor Green

# 4. Criar diretório da base de dados
if (-not (Test-Path "database")) {
    New-Item -ItemType Directory -Path "database"
    Write-Host "Diretorio database/ criado" -ForegroundColor Green
}

Write-Host ""
Write-Host "=== CONFIGURACAO TEMPORARIA CONCLUIDA ===" -ForegroundColor Cyan
Write-Host "1. Usando SQLite temporariamente para desenvolvimento" -ForegroundColor Yellow
Write-Host "2. Execute: npx prisma db push" -ForegroundColor Green
Write-Host "3. Execute: npm run dev" -ForegroundColor Green
Write-Host ""
Write-Host "Para voltar ao PostgreSQL posteriormente, renomeie:" -ForegroundColor Yellow
Write-Host "  .env.postgresql.backup -> .env" -ForegroundColor Yellow
