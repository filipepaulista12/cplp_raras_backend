-- =====================================================================================
-- GARD BRASILEIRO - SCHEMA COMPLETO COM SUPORTE BILÍNGUE
-- Base de dados para importação completa do GARD + tradução
-- =====================================================================================

-- Extensões necessárias
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";
CREATE EXTENSION IF NOT EXISTS "unaccent";

-- =====================================================================================
-- TABELA PRINCIPAL DE DOENÇAS
-- =====================================================================================
CREATE TABLE diseases (
    -- Identificadores únicos
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    gard_br_id VARCHAR(20) UNIQUE NOT NULL, -- GARD-BR-0001
    gard_original_id VARCHAR(20), -- ID do GARD original (NIH)
    
    -- Nomenclatura bilíngue
    name_en VARCHAR(500) NOT NULL, -- Nome original em inglês
    name_pt VARCHAR(500), -- Nome traduzido para português
    
    -- Sinônimos em ambos idiomas
    synonyms_en TEXT[], -- Array de sinônimos em inglês
    synonyms_pt TEXT[], -- Array de sinônimos em português
    
    -- Classificação médica
    category_en VARCHAR(100) NOT NULL,
    category_pt VARCHAR(100),
    
    -- Códigos médicos internacionais
    orpha_code VARCHAR(50), -- Código Orphanet
    icd10_code VARCHAR(50), -- CID-10
    icd11_code VARCHAR(50), -- CID-11
    omim_code VARCHAR(50), -- OMIM
    
    -- Epidemiologia
    prevalence_en TEXT,
    prevalence_pt TEXT,
    inheritance_pattern_en VARCHAR(200),
    inheritance_pattern_pt VARCHAR(200),
    age_of_onset_en VARCHAR(100),
    age_of_onset_pt VARCHAR(100),
    
    -- Status de tradução
    translation_status VARCHAR(20) DEFAULT 'pending', -- pending, in_progress, completed, reviewed
    translated_by VARCHAR(100), -- AI ou human translator
    reviewed_by VARCHAR(100), -- Medical reviewer
    
    -- Metadados
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_reviewed_at TIMESTAMP,
    
    -- Indexes para busca
    search_vector_en TSVECTOR,
    search_vector_pt TSVECTOR,
    
    CONSTRAINT valid_translation_status CHECK (translation_status IN ('pending', 'in_progress', 'completed', 'reviewed'))
);

-- =====================================================================================
-- CONTEÚDO DETALHADO POR DOENÇA (BILÍNGUE)
-- =====================================================================================
CREATE TABLE disease_content (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    disease_id UUID REFERENCES diseases(id) ON DELETE CASCADE,
    
    -- Resumo/Definição
    summary_en TEXT,
    summary_pt TEXT,
    
    -- Sintomas
    symptoms_en TEXT[],
    symptoms_pt TEXT[],
    
    -- Causas/Genética
    causes_en TEXT,
    causes_pt TEXT,
    genes_involved VARCHAR(500)[], -- Array de genes (internacional)
    
    -- Diagnóstico
    diagnosis_en TEXT,
    diagnosis_pt TEXT,
    diagnostic_methods TEXT[], -- Métodos diagnósticos (internacional)
    
    -- Tratamento
    treatment_en TEXT,
    treatment_pt TEXT,
    
    -- Prognóstico
    prognosis_en TEXT,
    prognosis_pt TEXT,
    
    -- Especialidades médicas envolvidas
    specialties VARCHAR(100)[], -- Array de especialidades
    
    -- Metadados de conteúdo
    content_version INTEGER DEFAULT 1,
    last_medical_review TIMESTAMP,
    medical_reviewer VARCHAR(200),
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    UNIQUE(disease_id) -- Uma entrada de conteúdo por doença
);

-- =====================================================================================
-- DADOS EPIDEMIOLÓGICOS POR PAÍS CPLP
-- =====================================================================================
CREATE TABLE disease_epidemiology_cplp (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    disease_id UUID REFERENCES diseases(id) ON DELETE CASCADE,
    
    -- País CPLP
    country_code VARCHAR(3) NOT NULL, -- BRA, PRT, AGO, MOZ, etc.
    country_name VARCHAR(100) NOT NULL,
    
    -- Dados epidemiológicos específicos
    prevalence_local TEXT,
    incidence_local TEXT,
    carrier_frequency DECIMAL(10,8), -- Para doenças recessivas
    
    -- Fatores regionais
    genetic_variants TEXT[], -- Variantes genéticas comuns na região
    environmental_factors TEXT[], -- Fatores ambientais relevantes
    
    -- Disponibilidade de recursos
    diagnostic_availability VARCHAR(50), -- available, limited, unavailable
    treatment_availability VARCHAR(50),
    specialist_availability VARCHAR(50),
    
    -- Políticas de saúde
    covered_by_public_health BOOLEAN DEFAULT false,
    orphan_drug_policy TEXT,
    
    -- Fontes dos dados
    data_source TEXT,
    data_quality VARCHAR(20) DEFAULT 'estimated', -- confirmed, estimated, unknown
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    UNIQUE(disease_id, country_code)
);

-- =====================================================================================
-- ORGANIZAÇÕES DE APOIO POR REGIÃO CPLP
-- =====================================================================================
CREATE TABLE support_organizations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    disease_id UUID REFERENCES diseases(id) ON DELETE CASCADE,
    
    -- Informações da organização
    name VARCHAR(300) NOT NULL,
    name_local VARCHAR(300), -- Nome local se diferente
    
    -- Localização
    country_code VARCHAR(3) NOT NULL,
    city VARCHAR(100),
    region VARCHAR(100),
    
    -- Tipo de organização
    organization_type VARCHAR(50), -- patient_association, research_center, hospital, government
    
    -- Contacto
    website VARCHAR(500),
    email VARCHAR(200),
    phone VARCHAR(50),
    address TEXT,
    
    -- Serviços oferecidos
    services_offered TEXT[],
    languages_supported VARCHAR(10)[], -- pt-BR, pt-PT, crioulo, etc.
    
    -- Status
    is_active BOOLEAN DEFAULT true,
    verified BOOLEAN DEFAULT false,
    last_verified TIMESTAMP,
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =====================================================================================
-- ENSAIOS CLÍNICOS REGIONAIS
-- =====================================================================================
CREATE TABLE clinical_trials (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    disease_id UUID REFERENCES diseases(id) ON DELETE CASCADE,
    
    -- Identificadores
    clinicaltrials_gov_id VARCHAR(20), -- NCT number
    eudract_number VARCHAR(50), -- European trials
    rebec_id VARCHAR(20), -- Brazilian registry
    
    -- Informações básicas
    title_en VARCHAR(500) NOT NULL,
    title_pt VARCHAR(500),
    brief_summary_en TEXT,
    brief_summary_pt TEXT,
    
    -- Status e fase
    phase VARCHAR(20), -- Phase I, Phase II, etc.
    status VARCHAR(50), -- Recruiting, Active, Completed, etc.
    start_date DATE,
    completion_date DATE,
    
    -- Localização
    countries VARCHAR(3)[],
    cities_cplp TEXT[], -- Cidades nos países CPLP participantes
    principal_investigator VARCHAR(200),
    
    -- Critérios
    min_age INTEGER,
    max_age INTEGER,
    gender VARCHAR(10), -- male, female, all
    
    -- Contacto
    contact_name VARCHAR(200),
    contact_email VARCHAR(200),
    contact_phone VARCHAR(50),
    
    -- URLs
    clinicaltrials_url VARCHAR(500),
    local_contact_url VARCHAR(500),
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =====================================================================================
-- BIBLIOGRAFIA CIENTÍFICA
-- =====================================================================================
CREATE TABLE scientific_articles (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    disease_id UUID REFERENCES diseases(id) ON DELETE CASCADE,
    
    -- Identificadores da publicação
    pmid VARCHAR(20), -- PubMed ID
    doi VARCHAR(200),
    pmc_id VARCHAR(20), -- PMC ID
    
    -- Informações bibliográficas
    title TEXT NOT NULL,
    authors TEXT NOT NULL,
    journal VARCHAR(300),
    publication_year INTEGER,
    volume VARCHAR(20),
    issue VARCHAR(20),
    pages VARCHAR(50),
    
    -- Tipo e relevância
    article_type VARCHAR(50), -- case_report, review, clinical_trial, etc.
    relevance_score INTEGER DEFAULT 5, -- 1-10
    language VARCHAR(5) DEFAULT 'en',
    
    -- Resumo e palavras-chave
    abstract_en TEXT,
    abstract_pt TEXT,
    keywords VARCHAR(100)[],
    
    -- CPLP relevância
    cplp_relevance BOOLEAN DEFAULT false,
    cplp_countries VARCHAR(3)[], -- Países CPLP mencionados/estudados
    cplp_specific_findings TEXT,
    
    -- Status
    is_open_access BOOLEAN DEFAULT false,
    pdf_available BOOLEAN DEFAULT false,
    quality_checked BOOLEAN DEFAULT false,
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =====================================================================================
-- RECURSOS EDUCACIONAIS PARA PACIENTES
-- =====================================================================================
CREATE TABLE patient_resources (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    disease_id UUID REFERENCES diseases(id) ON DELETE CASCADE,
    
    -- Informações básicas
    title VARCHAR(300) NOT NULL,
    description TEXT,
    resource_type VARCHAR(50), -- guide, brochure, video, website, app
    
    -- Idioma e adaptação
    language VARCHAR(5) NOT NULL,
    country_adaptation VARCHAR(3), -- Adaptado para país específico
    reading_level VARCHAR(20), -- basic, intermediate, advanced
    
    -- Fonte
    organization VARCHAR(200),
    author VARCHAR(200),
    publication_date DATE,
    last_reviewed DATE,
    
    -- Acesso
    url VARCHAR(500),
    download_url VARCHAR(500),
    is_free BOOLEAN DEFAULT true,
    requires_registration BOOLEAN DEFAULT false,
    
    -- Qualidade
    medical_reviewed BOOLEAN DEFAULT false,
    reviewed_by VARCHAR(200),
    quality_rating INTEGER, -- 1-5 stars
    
    -- Utilidade
    target_audience VARCHAR(50)[], -- patients, families, caregivers, professionals
    topics_covered VARCHAR(100)[],
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =====================================================================================
-- ESPECIALISTAS E CENTROS DE REFERÊNCIA
-- =====================================================================================
CREATE TABLE specialist_centers (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    
    -- Informações básicas
    name VARCHAR(300) NOT NULL,
    institution VARCHAR(300),
    
    -- Localização
    country_code VARCHAR(3) NOT NULL,
    state_province VARCHAR(100),
    city VARCHAR(100),
    address TEXT,
    
    -- Tipo de centro
    center_type VARCHAR(50), -- university_hospital, specialized_clinic, research_center
    specialties VARCHAR(100)[], -- Array de especialidades
    
    -- Contacto
    website VARCHAR(500),
    email VARCHAR(200),
    phone VARCHAR(50),
    
    -- Serviços
    diagnostic_services TEXT[],
    treatment_services TEXT[],
    research_activities TEXT[],
    
    -- Qualificações
    certifications VARCHAR(200)[],
    is_reference_center BOOLEAN DEFAULT false,
    government_recognized BOOLEAN DEFAULT false,
    
    -- Doenças atendidas
    diseases_treated UUID[], -- Array de disease IDs
    
    -- Status
    is_active BOOLEAN DEFAULT true,
    accepts_new_patients BOOLEAN DEFAULT true,
    public_healthcare BOOLEAN DEFAULT false,
    private_healthcare BOOLEAN DEFAULT false,
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =====================================================================================
-- CATEGORIAS HIERÁRQUICAS
-- =====================================================================================
CREATE TABLE disease_categories (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    
    -- Nomes bilíngues
    name_en VARCHAR(100) NOT NULL,
    name_pt VARCHAR(100) NOT NULL,
    
    -- Hierarquia
    parent_category_id UUID REFERENCES disease_categories(id),
    level INTEGER NOT NULL DEFAULT 1, -- 1 = principal, 2 = subcategoria
    sort_order INTEGER DEFAULT 1,
    
    -- Descrições
    description_en TEXT,
    description_pt TEXT,
    
    -- Metadados
    disease_count INTEGER DEFAULT 0, -- Calculado automaticamente
    is_active BOOLEAN DEFAULT true,
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =====================================================================================
-- HISTÓRICO DE TRADUÇÕES
-- =====================================================================================
CREATE TABLE translation_history (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    disease_id UUID REFERENCES diseases(id) ON DELETE CASCADE,
    
    -- Detalhes da tradução
    field_name VARCHAR(100) NOT NULL, -- name, summary, symptoms, etc.
    original_text_en TEXT,
    translated_text_pt TEXT,
    
    -- Método de tradução
    translation_method VARCHAR(50), -- ai_automatic, ai_assisted, human, hybrid
    translator_id VARCHAR(100),
    ai_model_used VARCHAR(100), -- gpt-4, claude, etc.
    
    -- Qualidade
    confidence_score DECIMAL(3,2), -- 0.0 to 1.0
    human_reviewed BOOLEAN DEFAULT false,
    medical_reviewed BOOLEAN DEFAULT false,
    approved BOOLEAN DEFAULT false,
    
    -- Feedback
    feedback TEXT,
    corrections TEXT,
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =====================================================================================
-- ÍNDICES PARA PERFORMANCE
-- =====================================================================================

-- Índices de busca textual
CREATE INDEX idx_diseases_search_en ON diseases USING gin(search_vector_en);
CREATE INDEX idx_diseases_search_pt ON diseases USING gin(search_vector_pt);

-- Índices de busca por similaridade
CREATE INDEX idx_diseases_name_en_trgm ON diseases USING gin(name_en gin_trgm_ops);
CREATE INDEX idx_diseases_name_pt_trgm ON diseases USING gin(name_pt gin_trgm_ops);

-- Índices por códigos médicos
CREATE INDEX idx_diseases_orpha ON diseases(orpha_code);
CREATE INDEX idx_diseases_icd10 ON diseases(icd10_code);
CREATE INDEX idx_diseases_omim ON diseases(omim_code);

-- Índices por status
CREATE INDEX idx_diseases_translation_status ON diseases(translation_status);
CREATE INDEX idx_diseases_active ON diseases(is_active);

-- Índices geográficos
CREATE INDEX idx_epidemiology_country ON disease_epidemiology_cplp(country_code);
CREATE INDEX idx_support_orgs_country ON support_organizations(country_code);
CREATE INDEX idx_specialist_centers_country ON specialist_centers(country_code);

-- Índices de relacionamento
CREATE INDEX idx_disease_content_disease ON disease_content(disease_id);
CREATE INDEX idx_clinical_trials_disease ON clinical_trials(disease_id);
CREATE INDEX idx_articles_disease ON scientific_articles(disease_id);

-- =====================================================================================
-- FUNÇÕES AUXILIARES
-- =====================================================================================

-- Função para atualizar vetores de busca
CREATE OR REPLACE FUNCTION update_disease_search_vectors()
RETURNS TRIGGER AS $$
BEGIN
    NEW.search_vector_en = to_tsvector('english', 
        COALESCE(NEW.name_en, '') || ' ' || 
        COALESCE(array_to_string(NEW.synonyms_en, ' '), '') || ' ' ||
        COALESCE(NEW.category_en, '')
    );
    
    IF NEW.name_pt IS NOT NULL THEN
        NEW.search_vector_pt = to_tsvector('portuguese', 
            COALESCE(NEW.name_pt, '') || ' ' || 
            COALESCE(array_to_string(NEW.synonyms_pt, ' '), '') || ' ' ||
            COALESCE(NEW.category_pt, '')
        );
    END IF;
    
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger para atualização automática dos vetores de busca
CREATE TRIGGER trigger_update_disease_search_vectors
    BEFORE INSERT OR UPDATE ON diseases
    FOR EACH ROW
    EXECUTE FUNCTION update_disease_search_vectors();

-- Função para atualizar contadores de categoria
CREATE OR REPLACE FUNCTION update_category_counts()
RETURNS TRIGGER AS $$
BEGIN
    -- Atualizar contador da categoria antiga (se houver)
    IF OLD.category_en IS NOT NULL THEN
        UPDATE disease_categories 
        SET disease_count = disease_count - 1 
        WHERE name_en = OLD.category_en;
    END IF;
    
    -- Atualizar contador da nova categoria
    IF NEW.category_en IS NOT NULL THEN
        UPDATE disease_categories 
        SET disease_count = disease_count + 1 
        WHERE name_en = NEW.category_en;
    END IF;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger para contadores de categoria
CREATE TRIGGER trigger_update_category_counts
    AFTER INSERT OR UPDATE OR DELETE ON diseases
    FOR EACH ROW
    EXECUTE FUNCTION update_category_counts();

-- =====================================================================================
-- VIEWS ÚTEIS
-- =====================================================================================

-- View para doenças com tradução completa
CREATE VIEW diseases_translated AS
SELECT 
    d.*,
    dc.summary_pt,
    dc.symptoms_pt,
    dc.causes_pt,
    dc.diagnosis_pt,
    dc.treatment_pt,
    dc.prognosis_pt
FROM diseases d
LEFT JOIN disease_content dc ON d.id = dc.disease_id
WHERE d.translation_status = 'completed' OR d.translation_status = 'reviewed';

-- View para estatísticas de tradução
CREATE VIEW translation_stats AS
SELECT 
    translation_status,
    COUNT(*) as disease_count,
    ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM diseases), 2) as percentage
FROM diseases 
GROUP BY translation_status;

-- View para doenças por país CPLP
CREATE VIEW diseases_by_country AS
SELECT 
    dec.country_code,
    dec.country_name,
    COUNT(DISTINCT dec.disease_id) as disease_count,
    COUNT(DISTINCT so.id) as support_organizations,
    COUNT(DISTINCT sc.id) as specialist_centers
FROM disease_epidemiology_cplp dec
LEFT JOIN support_organizations so ON dec.country_code = so.country_code
LEFT JOIN specialist_centers sc ON dec.country_code = sc.country_code
GROUP BY dec.country_code, dec.country_name;

-- =====================================================================================
-- COMENTÁRIOS FINAIS
-- =====================================================================================

COMMENT ON TABLE diseases IS 'Tabela principal com todas as doenças raras em formato bilíngue';
COMMENT ON TABLE disease_content IS 'Conteúdo detalhado médico para cada doença';
COMMENT ON TABLE disease_epidemiology_cplp IS 'Dados epidemiológicos específicos por país CPLP';
COMMENT ON TABLE support_organizations IS 'Organizações de apoio a pacientes por região';
COMMENT ON TABLE clinical_trials IS 'Ensaios clínicos relevantes na região CPLP';
COMMENT ON TABLE scientific_articles IS 'Bibliografia científica com foco CPLP';
COMMENT ON TABLE patient_resources IS 'Recursos educacionais para pacientes e famílias';
COMMENT ON TABLE specialist_centers IS 'Centros especializados e profissionais de referência';
COMMENT ON TABLE translation_history IS 'Histórico de traduções para controle de qualidade';
