import Link from 'next/link';
import Image from 'next/image';
import { getImageSrc } from '@/lib/imageUtils';

const workingGroups = [
  {
    id: 'gt1',
    title: 'GT1 – Mapeamento de Recursos',
    icon: '🧩',
    description: 'Levantamento dos dados, iniciativas e maturidade de estruturas e recursos existentes sobre doenças raras nos países da CPLP.',
    color: 'from-blue-500 to-blue-600',
    image: getImageSrc('/images/GT1.png'),
    bgColor: 'bg-blue-50',
    hoverColor: 'hover:from-blue-600 hover:to-blue-700'
  },
  {
    id: 'gt2',
    title: 'GT2 – Plataformas Digitais',
    icon: '💻',
    description: 'Ferramentas digitais para apoio à decisão clínica, registro de casos, e fortalecimento da saúde digital. Amplia a capacidade local de resposta aos desafios das doenças raras.',
    color: 'from-green-500 to-green-600',
    image: getImageSrc('/images/GT2.png.png'),
    bgColor: 'bg-green-50',
    hoverColor: 'hover:from-green-600 hover:to-green-700'
  },
  {
    id: 'gt3',
    title: 'GT3 – Rede Colaborativa de Pesquisa',
    icon: '🔍',
    description: 'Rede de pesquisa da CPLP voltada ao avanço científico que conecta investigadores para fortalecer a produção de conhecimento e inovação.',
    color: 'from-purple-500 to-purple-600',
    image: getImageSrc('/images/GT3.png'),
    bgColor: 'bg-purple-50',
    hoverColor: 'hover:from-purple-600 hover:to-purple-700'
  },
  {
    id: 'gt4',
    title: 'GT4 – Protocolos e Algoritmos',
    icon: '⚙️',
    description: 'Co-criação de recomendações estratégicas e algoritmos baseados em dados e evidências regionais.',
    color: 'from-orange-500 to-orange-600',
    image: getImageSrc('/images/GT4.png'),
    bgColor: 'bg-orange-50',
    hoverColor: 'hover:from-orange-600 hover:to-orange-700'
  },
  {
    id: 'gt5',
    title: 'GT5 – Conscientização e Engajamento Social',
    icon: '🧠',
    description: 'Criação e divulgação de ações educativas e participativas voltadas à população, profissionais de saúde e escolas.',
    color: 'from-pink-500 to-pink-600',
    image: getImageSrc('/images/GT5.png'),
    bgColor: 'bg-pink-50',
    hoverColor: 'hover:from-pink-600 hover:to-pink-700'
  },
  {
    id: 'gt6',
    title: 'GT6 – Disseminação e Sustentabilidade',
    icon: '📣',
    description: 'Comunicação de resultados, mobilização social e plano de continuidade das ações do projeto.',
    color: 'from-teal-500 to-teal-600',
    image: getImageSrc('/images/GT6.png'),
    bgColor: 'bg-teal-50',
    hoverColor: 'hover:from-teal-600 hover:to-teal-700'
  }
];

export default function WorkingGroups() {
  return (
    <section className="py-16 bg-gradient-to-b from-white to-pink-50">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <div className="inline-flex items-center space-x-3 mb-6">
            <div className="w-12 h-12 bg-gradient-to-br from-pink-500 to-purple-600 rounded-full flex items-center justify-center">
              <span className="text-white text-2xl">🦓</span>
            </div>
            <h2 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">
              Grupos de Trabalho (GTs)
            </h2>
          </div>
          <div className="w-24 h-1 bg-gradient-to-r from-pink-500 via-purple-500 to-blue-500 mx-auto mb-8 rounded-full"></div>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            O projeto está organizado em seis grupos de trabalho especializados, cada um focado 
            em aspectos específicos das doenças raras nos países da CPLP.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {workingGroups.map((group) => (
            <div
              key={group.id}
              className={`${group.bgColor} rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 overflow-hidden border border-pink-200 hover:border-pink-300 transform hover:-translate-y-2 group`}
            >
              <div className={`bg-gradient-to-r ${group.color} ${group.hoverColor} p-6 text-white relative overflow-hidden`}>
                {/* Background pattern */}
                <div className="absolute inset-0 opacity-10">
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent transform -skew-x-12"></div>
                </div>
                
                <div className="relative flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center backdrop-blur-sm">
                      <Image
                        src={group.image}
                        alt={group.title}
                        width={24}
                        height={24}
                        className="filter brightness-0 invert"
                      />
                    </div>
                    <div>
                      <h3 className="text-lg font-bold leading-tight">
                        {group.title}
                      </h3>
                    </div>
                  </div>
                  <span className="text-2xl opacity-80">{group.icon}</span>
                </div>
              </div>
              
              <div className="p-6">
                <p className="text-gray-700 mb-6 leading-relaxed text-sm">
                  {group.description}
                </p>
                
                <Link
                  href={`/grupos-trabalho/${group.id}`}
                  className="inline-flex items-center justify-between w-full p-3 rounded-xl bg-white border-2 border-gray-200 hover:border-pink-300 group-hover:bg-pink-50 transition-all duration-200"
                >
                  <span className={`text-sm font-semibold bg-gradient-to-r ${group.color} bg-clip-text text-transparent group-hover:text-pink-600`}>
                    Saiba mais
                  </span>
                  <div className={`w-8 h-8 bg-gradient-to-r ${group.color} rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform duration-200`}>
                    <svg
                      className="w-4 h-4 text-white"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M9 5l7 7-7 7"
                      />
                    </svg>
                  </div>
                </Link>
              </div>
            </div>
          ))}
        </div>
        
        <div className="text-center mt-12">
          <Link
            href="/grupos-trabalho"
            className="bg-gradient-to-r from-pink-500 via-purple-500 to-blue-500 text-white px-8 py-4 rounded-full font-semibold hover:from-pink-600 hover:via-purple-600 hover:to-blue-600 transition-all duration-200 transform hover:scale-105 shadow-lg hover:shadow-xl"
          >
            Ver Todos os Grupos
          </Link>
        </div>
      </div>
    </section>
  );
}
