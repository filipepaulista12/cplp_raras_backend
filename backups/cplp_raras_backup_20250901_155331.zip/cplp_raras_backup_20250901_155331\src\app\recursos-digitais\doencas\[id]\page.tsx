import { notFound } from 'next/navigation';
import DoencaClientWrapper from './DoencaClientWrapper';

// Dados completos de 20 doenças raras CPLP com estrutura bilíngue
const MOCK_DISEASE_DATA: { [key: string]: any } = {
  'gard-br-0001': {
    id: 'gard-br-0001',
    gard_br_id: 'GARD-BR-0001',
    name_pt: 'Síndrome de Marfan',
    name_en: 'Marfan Syndrome',
    synonyms: ['Aracnodactilia', 'Doença de Marfan', 'Síndrome de Marfan-Achard'],
    category: 'Doenças Genéticas',
    orpha_code: 'ORPHA558',
    icd10_code: 'Q87.4',
    prevalence: '1 em 5.000 a 10.000 pessoas',
    inheritance_pattern: 'Autossómica dominante',
    age_of_onset: 'Todas as idades',
    last_updated: '2025-08-30',
    
    summary: `A Síndrome de Marfan é uma doença hereditária do tecido conjuntivo que afeta principalmente o sistema cardiovascular, esquelético e ocular. É causada por mutações no gene FBN1, que codifica a fibrilina-1, uma proteína essencial para a formação de fibras elásticas nos tecidos conjuntivos.`,
    
    symptoms: [
      'Estatura alta e constituição longilínea',
      'Aracnodactilia (dedos longos e finos)',
      'Hiperflexibilidade articular',
      'Escoliose ou cifose',
      'Pectus carinatum ou pectus excavatum',
      'Dilatação da raiz aórtica',
      'Prolapso da válvula mitral',
      'Subluxação do cristalino',
      'Miopia',
      'Pele elástica',
      'Estrias cutâneas'
    ],
    
    causes: `A Síndrome de Marfan é causada por mutações no gene FBN1, localizado no cromossomo 15. Este gene codifica a fibrilina-1, uma glicoproteína que é um componente importante das microfibras elásticas presentes no tecido conjuntivo. As mutações resultam na produção de fibrilina-1 defeituosa ou em quantidades reduzidas, afetando a integridade estrutural de vários tecidos.`,
    
    diagnosis: `O diagnóstico da Síndrome de Marfan baseia-se nos critérios de Ghent revisados, que incluem características clínicas dos sistemas cardiovascular, ocular, esquelético e tegumentar. Testes genéticos podem identificar mutações no gene FBN1, confirmando o diagnóstico. Exames complementares incluem ecocardiograma, exame oftalmológico completo e radiografias do esqueleto.`,
    
    treatment: `Não existe cura para a Síndrome de Marfan, mas o tratamento visa prevenir complicações e melhorar a qualidade de vida. Inclui monitorização cardiovascular regular, restrição de atividades físicas intensas, correção cirúrgica de problemas cardíacos quando necessário, correção oftalmológica, fisioterapia para problemas esqueléticos, e aconselhamento genético para famílias afetadas.`,
    
    prognosis: `O prognóstico varia significativamente dependendo do grau de envolvimento dos diferentes sistemas, especialmente o cardiovascular. Com diagnóstico precoce e acompanhamento médico adequado, muitos pacientes podem ter uma expectativa de vida próxima do normal. As complicações cardiovasculares, particularmente a dilatação aórtica, são a principal causa de morbidade e mortalidade.`,
    
    support_organizations: [],
    clinical_trials: [],
    recent_articles: [],
    patient_resources: [],
    expert_reviewers: ['Dr. João Silva - Cardiologista', 'Dra. Maria Santos - Geneticista'],
    sources: ['Orphanet', 'GeneReviews', 'Ghent Nosology']
  },
  
  'gard-br-0002': {
    id: 'gard-br-0002',
    gard_br_id: 'GARD-BR-0002', 
    name_pt: 'Fibrose Cística',
    name_en: 'Cystic Fibrosis',
    synonyms: ['Mucoviscidose', 'Fibrose Quística'],
    category: 'Doenças Genéticas',
    orpha_code: 'ORPHA586',
    icd10_code: 'E84',
    prevalence: '1 em 2.500 a 3.500 nascidos vivos (população caucasiana)',
    inheritance_pattern: 'Autossómica recessiva',
    age_of_onset: 'Nascimento/infância',
    last_updated: '2025-08-30',
    
    summary: `A Fibrose Cística é uma doença genética multissistêmica que afeta principalmente os pulmões e o sistema digestivo. É causada por mutações no gene CFTR, resultando na produção de muco espesso e pegajoso que obstrui vias aéreas e ductos pancreáticos.`,
    
    symptoms: [
      'Tosse persistente com muco espesso',
      'Infeções pulmonares recorrentes',
      'Falta de ar',
      'Suor salgado',
      'Problemas digestivos',
      'Má absorção de nutrientes',
      'Crescimento deficiente',
      'Pólipos nasais',
      'Infertilidade masculina'
    ],
    
    causes: `A Fibrose Cística é causada por mutações no gene CFTR (Cystic Fibrosis Transmembrane Conductance Regulator). As mutações resultam numa proteína CFTR defeituosa ou ausente, que regula o transporte de cloreto através das membranas celulares.`,
    
    diagnosis: `O diagnóstico inclui teste do pezinho (screening neonatal), teste do suor, e análise genética. O teste do suor mede a concentração de cloreto no suor - valores elevados indicam Fibrose Cística.`,
    
    treatment: `O tratamento é multidisciplinar e inclui fisioterapia respiratória, antibióticos para infeções, enzimas pancreáticas, suplementos nutricionais, broncodilatadores, e medicamentos moduladores do CFTR como ivacaftor e lumacaftor/ivacaftor.`,
    
    prognosis: `O prognóstico tem melhorado significativamente com os avanços no tratamento. A mediana de sobrevida atualmente ultrapassa os 40 anos em países desenvolvidos, com muitos pacientes vivendo até à idade adulta.`,
    
    support_organizations: [],
    clinical_trials: [],
    recent_articles: [],
    patient_resources: [],
    expert_reviewers: ['Dr. Carlos Pneumo - Pneumologista', 'Dra. Ana Pediatra - Pediatra'],
    sources: ['Cystic Fibrosis Foundation', 'European Cystic Fibrosis Society']
  },

  // ADICIONANDO 18 NOVAS DOENÇAS RARAS CPLP
  'gard-br-0003': {
    id: 'gard-br-0003',
    gard_br_id: 'GARD-BR-0003',
    name_pt: 'Anemia Falciforme',
    name_en: 'Sickle Cell Disease',
    synonyms: ['Drepanocitose', 'Anemia das Células Falciformes'],
    category: 'Doenças do sangue',
    orpha_code: 'ORPHA232',
    icd10_code: 'D57',
    prevalence: '1 em 600 nascimentos (população afrodescendente)',
    inheritance_pattern: 'Autossómica recessiva',
    age_of_onset: 'Nascimento',
    last_updated: '2025-08-30',
    
    summary: `A Anemia Falciforme é uma doença hereditária caracterizada pela produção de hemoglobina anormal (HbS), causando deformação dos glóbulos vermelhos em formato de foice. Altamente prevalente em países CPLP com população africana.`,
    
    symptoms: [
      'Crises de dor intensa',
      'Anemia crónica',
      'Fadiga extrema',
      'Icterícia',
      'Infecções recorrentes',
      'Atraso no crescimento',
      'Úlceras nas pernas',
      'Síndrome torácica aguda',
      'Priapismo'
    ],
    
    causes: `Causada por mutação no gene da beta-globina, resultando na produção de hemoglobina S (HbS). Em condições de baixo oxigênio, os eritrócitos assumem forma de foice, causando obstrução vascular.`,
    
    diagnosis: `Diagnosticada através de eletroforese de hemoglobina, HPLC, e testes genéticos. Rastreio neonatal permite diagnóstico precoce.`,
    
    treatment: `Tratamento inclui hidroxiureia, transfusões sanguíneas, antibióticos profiláticos, analgésicos para crises, e transplante de medula óssea em casos selecionados.`,
    
    prognosis: `Com tratamento adequado, muitos pacientes vivem até à idade adulta. Complicações incluem AVC, síndrome torácica aguda, e lesões orgânicas.`,
    
    support_organizations: [],
    clinical_trials: [],
    recent_articles: [],
    patient_resources: [],
    expert_reviewers: ['Dr. Fernando Hematologia - Angola', 'Dra. Carla Pediatra - Brasil'],
    sources: ['WHO Sickle Cell Disease Guidelines', 'Brazilian Sickle Cell Association']
  },

  'gard-br-0004': {
    id: 'gard-br-0004',
    gard_br_id: 'GARD-BR-0004',
    name_pt: 'Doença de Huntington',
    name_en: 'Huntington Disease',
    synonyms: ['Coreia de Huntington', 'Mal de Huntington'],
    category: 'Doenças neurológicas',
    orpha_code: 'ORPHA399',
    icd10_code: 'G10',
    prevalence: '1 em 10.000 pessoas',
    inheritance_pattern: 'Autossómica dominante',
    age_of_onset: '35-45 anos',
    last_updated: '2025-08-30',
    
    summary: `A Doença de Huntington é uma doença neurodegenerativa hereditária que causa deterioração progressiva das células nervosas no cérebro, afetando movimento, cognição e comportamento.`,
    
    symptoms: [
      'Movimentos coreiformes involuntários',
      'Distúrbios psiquiátricos',
      'Depressão e irritabilidade',
      'Declínio cognitivo progressivo',
      'Dificuldades de fala',
      'Problemas de deglutição',
      'Perda de coordenação',
      'Demência'
    ],
    
    causes: `Causada por expansão de repetições CAG no gene HTT (huntingtina), localizado no cromossomo 4. Maior número de repetições correlaciona com início mais precoce.`,
    
    diagnosis: `Diagnóstico baseado em história familiar, sinais clínicos, neuroimagem (atrofia dos núcleos da base) e teste genético confirmativo.`,
    
    treatment: `Não há cura. Tratamento sintomático inclui neurolépticos para coreia, antidepressivos, fonoaudiologia, fisioterapia e apoio multidisciplinar.`,
    
    prognosis: `Doença progressiva com expectativa de vida de 15-20 anos após início dos sintomas. Morte usualmente por complicações (pneumonia, suicídio).`,
    
    support_organizations: [],
    clinical_trials: [],
    recent_articles: [],
    patient_resources: [],
    expert_reviewers: ['Prof. António Neurologista - Portugal', 'Dr. Ricardo Genética - Brasil'],
    sources: ['Huntington Disease Society', 'International Huntington Association']
  },

  'gard-br-0005': {
    id: 'gard-br-0005',
    gard_br_id: 'GARD-BR-0005',
    name_pt: 'Distrofia Muscular de Duchenne',
    name_en: 'Duchenne Muscular Dystrophy',
    synonyms: ['DMD', 'Distrofia de Duchenne'],
    category: 'Doenças neuromusculares',
    orpha_code: 'ORPHA98896',
    icd10_code: 'G71.0',
    prevalence: '1 em 3.500-5.000 nascimentos masculinos',
    inheritance_pattern: 'Ligada ao X (recessiva)',
    age_of_onset: '2-5 anos',
    last_updated: '2025-08-30',
    
    summary: `A Distrofia Muscular de Duchenne é uma doença genética caracterizada por fraqueza muscular progressiva causada por deficiência da proteína distrofina.`,
    
    symptoms: [
      'Atraso no desenvolvimento motor',
      'Fraqueza muscular proximal',
      'Pseudohipertrofia das panturrilhas',
      'Sinal de Gowers positivo',
      'Dificuldades para correr e saltar',
      'Cardiomiopatia',
      'Dificuldades respiratórias',
      'Comprometimento cognitivo leve'
    ],
    
    causes: `Causada por mutações no gene DMD (Xp21), que codifica a distrofina. Ausência desta proteína causa degeneração progressiva das fibras musculares.`,
    
    diagnosis: `Diagnóstico através de elevação da CK sérica, biópsia muscular (ausência de distrofina), e análise genética molecular.`,
    
    treatment: `Corticosteroides (prednisona), fisioterapia, suporte respiratório, cardioproteção, e terapias experimentais como exon-skipping.`,
    
    prognosis: `Progressão para cadeira de rodas aos 10-12 anos. Com cuidados atuais, sobrevida pode estender-se aos 30-40 anos.`,
    
    support_organizations: [],
    clinical_trials: [],
    recent_articles: [],
    patient_resources: [],
    expert_reviewers: ['Dra. Isabel Neuropediatria - Portugal', 'Dr. José Genética - Brasil'],
    sources: ['Muscular Dystrophy Association', 'European Neuromuscular Centre']
  },

  'gard-br-0006': {
    id: 'gard-br-0006',
    gard_br_id: 'GARD-BR-0006',
    name_pt: 'Talassemia Major',
    name_en: 'Beta Thalassemia Major',
    synonyms: ['Anemia de Cooley', 'Talassemia β'],
    category: 'Doenças do sangue',
    orpha_code: 'ORPHA231214',
    icd10_code: 'D56.1',
    prevalence: '1 em 10.000 (região mediterrânica)',
    inheritance_pattern: 'Autossómica recessiva',
    age_of_onset: 'Primeiros 2 anos de vida',
    last_updated: '2025-08-30',
    
    summary: `A Talassemia Major é uma doença hereditária do sangue caracterizada por produção deficiente de hemoglobina beta, resultando em anemia grave. Comum em populações mediterrânicas, incluindo Portugal.`,
    
    symptoms: [
      'Anemia grave',
      'Fadiga extrema',
      'Palidez',
      'Icterícia',
      'Hepatoesplenomegalia',
      'Deformidades ósseas faciais',
      'Atraso no crescimento',
      'Osteoporose'
    ],
    
    causes: `Causada por mutações nos genes da globina beta (HBB), resultando em síntese reduzida ou ausente de cadeias beta da hemoglobina.`,
    
    diagnosis: `Diagnosticada por eletroforese de hemoglobina, análises hematológicas (microcitose, hipocromia), e testes genéticos.`,
    
    treatment: `Transfusões sanguíneas regulares, quelação do ferro (deferoxamina, deferasirox), esplenectomia se necessário, transplante de medula óssea.`,
    
    prognosis: `Com tratamento adequado, muitos pacientes vivem até à idade adulta. Complicações por sobrecarga de ferro são preocupação principal.`,
    
    support_organizations: [],
    clinical_trials: [],
    recent_articles: [],
    patient_resources: [],
    expert_reviewers: ['Dr. Mário Hematologia - Portugal', 'Dra. Sofia Pediatria - Timor-Leste'],
    sources: ['Thalassaemia International Federation', 'European Hematology Association']
  },

  'gard-br-0007': {
    id: 'gard-br-0007',
    gard_br_id: 'GARD-BR-0007',
    name_pt: 'Deficiência de G6PD',
    name_en: 'Glucose-6-Phosphate Dehydrogenase Deficiency',
    synonyms: ['Favismo', 'Deficiência de G6PD'],
    category: 'Doenças do sangue',
    orpha_code: 'ORPHA466',
    icd10_code: 'D55.0',
    prevalence: '1 em 20 homens (áreas endémicas de malária)',
    inheritance_pattern: 'Ligada ao X',
    age_of_onset: 'Qualquer idade',
    last_updated: '2025-08-30',
    
    summary: `A Deficiência de G6PD é a deficiência enzimática mais comum mundialmente, causando hemólise quando exposto a oxidantes. Alta prevalência em países CPLP africanos devido à proteção contra malária.`,
    
    symptoms: [
      'Anemia hemolítica aguda',
      'Icterícia',
      'Urina escura',
      'Fadiga',
      'Dispneia',
      'Taquicardia',
      'Palidez',
      'Hemoglobinúria'
    ],
    
    causes: `Mutações no gene G6PD (Xq28) causam deficiência da enzima glucose-6-fosfato desidrogenase, essencial para proteção contra stress oxidativo.`,
    
    diagnosis: `Teste quantitativo da atividade de G6PD, teste de redução da metemoglobina, análise genética molecular.`,
    
    treatment: `Evitar desencadeantes oxidantes (fava, medicamentos como primaquina, sulfonamidas), transfusões em crises graves.`,
    
    prognosis: `Excelente se evitados os desencadeantes. Episódios hemolíticos são autolimitados na maioria dos casos.`,
    
    support_organizations: [],
    clinical_trials: [],
    recent_articles: [],
    patient_resources: [],
    expert_reviewers: ['Dr. Paulo Hematologia - Cabo Verde', 'Dra. Teresa Pediatria - São Tomé'],
    sources: ['WHO Malaria Guidelines', 'G6PD Deficiency Association']
  },

  'gard-br-0008': {
    id: 'gard-br-0008',
    gard_br_id: 'GARD-BR-0008',
    name_pt: 'Fenilcetonúria',
    name_en: 'Phenylketonuria',
    synonyms: ['PKU', 'Deficiência de Fenilalanina Hidroxilase'],
    category: 'Doenças metabólicas',
    orpha_code: 'ORPHA716',
    icd10_code: 'E70.0',
    prevalence: '1 em 10.000-15.000 nascimentos',
    inheritance_pattern: 'Autossómica recessiva',
    age_of_onset: 'Nascimento',
    last_updated: '2025-08-30',
    
    summary: `A Fenilcetonúria é um erro inato do metabolismo causado por deficiência da enzima fenilalanina hidroxilase, levando ao acúmulo de fenilalanina e deficiência de tirosina.`,
    
    symptoms: [
      'Atraso no desenvolvimento neurológico',
      'Deficiência intelectual',
      'Convulsões',
      'Hiperatividade',
      'Comportamento autista',
      'Odor característico de mofo',
      'Eczema',
      'Cabelo louro',
      'Pele clara'
    ],
    
    causes: `Causada por mutações no gene PAH que codifica a fenilalanina hidroxilase, enzima que converte fenilalanina em tirosina.`,
    
    diagnosis: `Rastreio neonatal (teste do pezinho) detecta níveis elevados de fenilalanina. Confirmação por dosagem enzimática e análise genética.`,
    
    treatment: `Dieta restrita em fenilalanina desde o nascimento, suplementos de tirosina, monitorização regular dos níveis sanguíneos, fórmulas especiais.`,
    
    prognosis: `Com tratamento dietético adequado iniciado precocemente, desenvolvimento normal é possível. Sem tratamento, causa deficiência intelectual grave.`,
    
    support_organizations: [],
    clinical_trials: [],
    recent_articles: [],
    patient_resources: [],
    expert_reviewers: ['Dra. Fernanda Metabolismo - Brasil', 'Dr. Miguel Pediatria - Portugal'],
    sources: ['PKU Organization', 'International Society for PKU']
  },

  'gard-br-0009': {
    id: 'gard-br-0009',
    gard_br_id: 'GARD-BR-0009',
    name_pt: 'Esclerose Lateral Amiotrófica',
    name_en: 'Amyotrophic Lateral Sclerosis',
    synonyms: ['ELA', 'Doença de Lou Gehrig', 'Doença do Neurónio Motor'],
    category: 'Doenças neurológicas',
    orpha_code: 'ORPHA803',
    icd10_code: 'G12.2',
    prevalence: '1-2 em 100.000 pessoas',
    inheritance_pattern: '90% esporádica, 10% familiar (autossómica dominante)',
    age_of_onset: '50-60 anos',
    last_updated: '2025-08-30',
    
    summary: `A Esclerose Lateral Amiotrófica é uma doença neurodegenerativa progressiva que afeta os neurónios motores superiores e inferiores, causando paralisia progressiva.`,
    
    symptoms: [
      'Fraqueza muscular progressiva',
      'Fasciculações',
      'Cãibras musculares',
      'Dificuldade de fala (disartria)',
      'Dificuldade de deglutição (disfagia)',
      'Atrofia muscular',
      'Espasticidade',
      'Labilidade emocional'
    ],
    
    causes: `Causa desconhecida na maioria dos casos. Formas familiares associadas a mutações em genes como SOD1, C9orf72, TARDBP, FUS.`,
    
    diagnosis: `Diagnóstico clínico baseado em critérios de El Escorial, electromiografia, exclusão de outras doenças. Não há teste diagnóstico específico.`,
    
    treatment: `Riluzol (prolonga sobrevida), edaravone (antioxidante), ventilação não-invasiva, gastrostomia, fisioterapia, fonoaudiologia.`,
    
    prognosis: `Doença progressiva com sobrevida média de 3-5 anos após diagnóstico. Ventilação assistida pode prolongar vida.`,
    
    support_organizations: [],
    clinical_trials: [],
    recent_articles: [],
    patient_resources: [],
    expert_reviewers: ['Prof. Carlos Neurologia - Brasil', 'Dr. António Neurologia - Portugal'],
    sources: ['ALS Association', 'European Network for ALS']
  },

  'gard-br-0010': {
    id: 'gard-br-0010',
    gard_br_id: 'GARD-BR-0010',
    name_pt: 'Ataxia de Friedreich',
    name_en: 'Friedreich Ataxia',
    synonyms: ['FRDA', 'Ataxia Hereditária'],
    category: 'Doenças neurológicas',
    orpha_code: 'ORPHA95',
    icd10_code: 'G11.1',
    prevalence: '1 em 50.000 pessoas',
    inheritance_pattern: 'Autossómica recessiva',
    age_of_onset: '10-15 anos',
    last_updated: '2025-08-30',
    
    summary: `A Ataxia de Friedreich é uma doença neurodegenerativa hereditária caracterizada por ataxia progressiva, cardiomiopatia e diabetes mellitus.`,
    
    symptoms: [
      'Ataxia de marcha progressiva',
      'Disartria',
      'Perda de reflexos tendinosos profundos',
      'Cardiomiopatia hipertrófica',
      'Diabetes mellitus',
      'Escoliose',
      'Pés cavos',
      'Perda auditiva'
    ],
    
    causes: `Causada por expansão de repetições GAA no gene FXN (frataxina), resultando em deficiência desta proteína mitocondrial.`,
    
    diagnosis: `Teste genético para expansão GAA, ecocardiograma, curva glicémica, exame neurológico detalhado.`,
    
    treatment: `Não há cura específica. Tratamento sintomático: fisioterapia, tratamento da cardiomiopatia, controlo do diabetes, antioxidantes experimentais.`,
    
    prognosis: `Progressão variável. Muitos pacientes ficam em cadeira de rodas 10-20 anos após início. Complicações cardíacas são preocupação principal.`,
    
    support_organizations: [],
    clinical_trials: [],
    recent_articles: [],
    patient_resources: [],
    expert_reviewers: ['Dra. Raquel Neurologia - Brasil', 'Dr. Pedro Cardiologia - Portugal'],
    sources: ['Friedreich Ataxia Research Alliance', 'European Ataxia Alliance']
  },

  'gard-br-0011': {
    id: 'gard-br-0011',
    gard_br_id: 'GARD-BR-0011',
    name_pt: 'Síndrome de Turner',
    name_en: 'Turner Syndrome',
    synonyms: ['Disgenesia Gonadal', 'Monossomia X'],
    category: 'Cromossomopatias',
    orpha_code: 'ORPHA881',
    icd10_code: 'Q96',
    prevalence: '1 em 2.500 nascimentos femininos',
    inheritance_pattern: 'Cromossómica (monossomia X)',
    age_of_onset: 'Nascimento',
    last_updated: '2025-08-30',
    
    summary: `A Síndrome de Turner é uma cromossomopatia que afeta apenas mulheres, caracterizada pela ausência completa ou parcial de um cromossomo X.`,
    
    symptoms: [
      'Baixa estatura',
      'Disgenesia gonadal',
      'Amenorreia primária',
      'Infertilidade',
      'Pescoço alado (pterygium colli)',
      'Tórax em barril',
      'Cúbito valgo',
      'Cardiopatia congénita',
      'Rim em ferradura'
    ],
    
    causes: `Causada por monossomia completa (45,X) ou mosaicismo envolvendo o cromossomo X. Não há fatores de risco maternos conhecidos.`,
    
    diagnosis: `Cariótipo confirma o diagnóstico. Suspeita clínica baseada em fenótipo característico e baixa estatura.`,
    
    treatment: `Hormona de crescimento na infância, terapia de reposição estrogénica na adolescência, monitorização cardíaca e renal.`,
    
    prognosis: `Com tratamento hormonal adequado, qualidade de vida normal. Fertilidade requer técnicas de reprodução assistida.`,
    
    support_organizations: [],
    clinical_trials: [],
    recent_articles: [],
    patient_resources: [],
    expert_reviewers: ['Dra. Cristina Endocrinologia - Brasil', 'Dr. Luís Pediatria - Portugal'],
    sources: ['Turner Syndrome Society', 'European Society for Endocrinology']
  },

  'gard-br-0012': {
    id: 'gard-br-0012',
    gard_br_id: 'GARD-BR-0012',
    name_pt: 'Hemofilia A',
    name_en: 'Hemophilia A',
    synonyms: ['Deficiência de Factor VIII', 'Hemofilia Clássica'],
    category: 'Doenças do sangue',
    orpha_code: 'ORPHA98878',
    icd10_code: 'D66',
    prevalence: '1 em 5.000-10.000 nascimentos masculinos',
    inheritance_pattern: 'Ligada ao X (recessiva)',
    age_of_onset: 'Infância',
    last_updated: '2025-08-30',
    
    summary: `A Hemofilia A é um distúrbio hereditário da coagulação causado por deficiência do fator VIII da coagulação, resultando em tendência hemorrágica.`,
    
    symptoms: [
      'Hemartroses recorrentes',
      'Hematomas extensos',
      'Hemorragias prolongadas pós-trauma',
      'Hemorragias intramusculares',
      'Hematúria',
      'Hemorragias gastrointestinais',
      'Hemorragias intracranianas (raras)'
    ],
    
    causes: `Mutações no gene F8 (Xq28) que codifica o fator VIII da coagulação. Inversão do intrão 22 é a mutação mais comum.`,
    
    diagnosis: `Tempo de tromboplastina parcial ativada (aPTT) prolongado, dosagem específica do fator VIII reduzida, análise genética.`,
    
    treatment: `Concentrados de fator VIII (plasmático ou recombinante), desmopressina em formas leves, profilaxia em casos graves.`,
    
    prognosis: `Com tratamento adequado, expectativa de vida normal. Artropatia hemofílica é complicação a longo prazo.`,
    
    support_organizations: [],
    clinical_trials: [],
    recent_articles: [],
    patient_resources: [],
    expert_reviewers: ['Dr. Rui Hematologia - Portugal', 'Dra. Carla Hematologia - Brasil'],
    sources: ['World Federation of Hemophilia', 'European Haemophilia Consortium']
  },

  'gard-br-0013': {
    id: 'gard-br-0013',
    gard_br_id: 'GARD-BR-0013',
    name_pt: 'Síndrome de Prader-Willi',
    name_en: 'Prader-Willi Syndrome',
    synonyms: ['PWS', 'Síndrome de Prader-Labhart-Willi'],
    category: 'Doenças genéticas',
    orpha_code: 'ORPHA739',
    icd10_code: 'Q87.1',
    prevalence: '1 em 15.000-25.000 nascimentos',
    inheritance_pattern: 'Imprinting genómico (deleção paterna 15q11-q13)',
    age_of_onset: 'Nascimento',
    last_updated: '2025-08-30',
    
    summary: `A Síndrome de Prader-Willi é uma doença genética complexa caracterizada por hipotonia neonatal, dificuldades alimentares iniciais seguidas de hiperfagia e obesidade.`,
    
    symptoms: [
      'Hipotonia neonatal severa',
      'Dificuldades de alimentação iniciais',
      'Hiperfagia (após 2-3 anos)',
      'Obesidade',
      'Baixa estatura',
      'Hipogonadismo',
      'Deficiência intelectual ligeira-moderada',
      'Comportamentos obsessivo-compulsivos',
      'Características faciais distintivas'
    ],
    
    causes: `Causada por deleção paterna da região 15q11-q13, dissomia uniparental materna do cromossomo 15, ou defeitos no centro de imprinting.`,
    
    diagnosis: `Análise de metilação do gene SNRPN, FISH para deleção 15q11-q13, análise de microssatélites para dissomia uniparental.`,
    
    treatment: `Hormona de crescimento, controlo dietético rigoroso, exercício supervisionado, terapia comportamental, apoio educativo especializado.`,
    
    prognosis: `Com manejo adequado da obesidade e complications, qualidade de vida pode ser boa. Obesidade é principal causa de morbilidade.`,
    
    support_organizations: [],
    clinical_trials: [],
    recent_articles: [],
    patient_resources: [],
    expert_reviewers: ['Dra. Sandra Genética - Brasil', 'Dr. Nuno Endocrinologia - Portugal'],
    sources: ['Prader-Willi Syndrome Association', 'International PWS Organization']
  },

  'gard-br-0014': {
    id: 'gard-br-0014',
    gard_br_id: 'GARD-BR-0014',
    name_pt: 'Osteogénese Imperfeita',
    name_en: 'Osteogenesis Imperfecta',
    synonyms: ['OI', 'Doença dos Ossos de Vidro'],
    category: 'Doenças do tecido conjuntivo',
    orpha_code: 'ORPHA666',
    icd10_code: 'Q78.0',
    prevalence: '1 em 15.000-20.000 nascimentos',
    inheritance_pattern: 'Maioritariamente autossómica dominante',
    age_of_onset: 'Nascimento',
    last_updated: '2025-08-30',
    
    summary: `A Osteogénese Imperfeita é um grupo de doenças genéticas caracterizadas por fragilidade óssea devido a defeitos na produção ou estrutura do colagénio tipo I.`,
    
    symptoms: [
      'Fraturas recorrentes com trauma mínimo',
      'Baixa estatura',
      'Escleróticas azuis',
      'Perda auditiva',
      'Dentinogénese imperfeita',
      'Hiperlaxidão ligamentar',
      'Deformidades ósseas',
      'Face triangular'
    ],
    
    causes: `Mutações nos genes COL1A1 e COL1A2 (85% dos casos), que codificam as cadeias alfa do colagénio tipo I. Outros genes mais raros também envolvidos.`,
    
    diagnosis: `Diagnóstico clínico baseado em critérios de Sillence, radiografias, densitometria óssea, análise genética molecular.`,
    
    treatment: `Bifosfonatos (pamidronato, zoledronato), fisioterapia, prevenção de fraturas, cirurgia ortopédica, suporte auditivo.`,
    
    prognosis: `Varia de acordo com o tipo. OI tipo I tem prognóstico excelente, enquanto tipo II é geralmente letal no período neonatal.`,
    
    support_organizations: [],
    clinical_trials: [],
    recent_articles: [],
    patient_resources: [],
    expert_reviewers: ['Dr. José Ortopedia - Brasil', 'Dra. Helena Genética - Portugal'],
    sources: ['Osteogenesis Imperfecta Foundation', 'European OI Federation']
  },

  'gard-br-0015': {
    id: 'gard-br-0015',
    gard_br_id: 'GARD-BR-0015',
    name_pt: 'Síndrome de Angelman',
    name_en: 'Angelman Syndrome',
    synonyms: ['AS', 'Síndrome da Boneca Feliz'],
    category: 'Doenças neurológicas',
    orpha_code: 'ORPHA72',
    icd10_code: 'Q93.5',
    prevalence: '1 em 12.000-20.000 nascimentos',
    inheritance_pattern: 'Imprinting genómico (deleção materna 15q11-q13)',
    age_of_onset: '6-12 meses',
    last_updated: '2025-08-30',
    
    summary: `A Síndrome de Angelman é uma doença neurogenética caracterizada por deficiência intelectual severa, ataxia, convulsões e comportamento feliz característico.`,
    
    symptoms: [
      'Deficiência intelectual severa',
      'Ausência ou limitação severa da fala',
      'Ataxia e tremor',
      'Convulsões',
      'Comportamento feliz inapropriado',
      'Riso frequente',
      'Hiperatividade',
      'Distúrbios do sono',
      'Microcefalia'
    ],
    
    causes: `Causada por deleção materna da região 15q11-q13, mutações no gene UBE3A, dissomia uniparental paterna, ou defeitos de imprinting.`,
    
    diagnosis: `Análise de metilação, FISH para deleção 15q11-q13, sequenciação do gene UBE3A, análise de microssatélites.`,
    
    treatment: `Anticonvulsivantes para epilepsia, fisioterapia, terapia ocupacional, terapia da fala, melatonina para distúrbios do sono.`,
    
    prognosis: `Deficiência intelectual permanece severa. Com suporte adequado, muitos indivíduos vivem até à idade adulta com qualidade de vida razoável.`,
    
    support_organizations: [],
    clinical_trials: [],
    recent_articles: [],
    patient_resources: [],
    expert_reviewers: ['Dra. Patricia Neurologia - Brasil', 'Dr. Ricardo Genética - Portugal'],
    sources: ['Angelman Syndrome Foundation', 'International Angelman Syndrome Organisation']
  },

  'gard-br-0016': {
    id: 'gard-br-0016',
    gard_br_id: 'GARD-BR-0016',
    name_pt: 'Doença de Wilson',
    name_en: 'Wilson Disease',
    synonyms: ['Degeneração Hepatolenticular', 'Doença de Wilson-Konovalov'],
    category: 'Doenças metabólicas',
    orpha_code: 'ORPHA905',
    icd10_code: 'E83.0',
    prevalence: '1 em 30.000-40.000 pessoas',
    inheritance_pattern: 'Autossómica recessiva',
    age_of_onset: '5-40 anos',
    last_updated: '2025-08-30',
    
    summary: `A Doença de Wilson é um distúrbio hereditário do metabolismo do cobre caracterizado por acumulação tóxica de cobre no fígado, cérebro e outros órgãos.`,
    
    symptoms: [
      'Hepatomegália',
      'Cirrose hepática',
      'Tremor',
      'Disartria',
      'Distonia',
      'Anel de Kayser-Fleischer',
      'Alterações psiquiátricas',
      'Anemia hemolítica',
      'Cataratas'
    ],
    
    causes: `Mutações no gene ATP7B que codifica uma ATPase transportadora de cobre, resultando em acumulação tóxica de cobre nos tecidos.`,
    
    diagnosis: `Ceruloplasmina sérica baixa, cobre urinário elevado, anel de Kayser-Fleischer ao exame oftalmológico, análise genética.`,
    
    treatment: `Quelantes de cobre (penicilamina, trientina), zinco para reduzir absorção de cobre, transplante hepático em casos severos.`,
    
    prognosis: `Excelente se diagnosticada e tratada precocemente. Sem tratamento, é invariavelmente fatal. Dano neurológico pode ser irreversível.`,
    
    support_organizations: [],
    clinical_trials: [],
    recent_articles: [],
    patient_resources: [],
    expert_reviewers: ['Dr. Manuel Hepatologia - Portugal', 'Dra. Lúcia Neurologia - Brasil'],
    sources: ['Wilson Disease Association', 'European Association for Wilson Disease']
  },

  'gard-br-0017': {
    id: 'gard-br-0017',
    gard_br_id: 'GARD-BR-0017',
    name_pt: 'Síndrome de DiGeorge',
    name_en: 'DiGeorge Syndrome',
    synonyms: ['Síndrome de Deleção 22q11.2', 'VCFS', 'Síndrome Velocardiofacial'],
    category: 'Cromossomopatias',
    orpha_code: 'ORPHA567',
    icd10_code: 'D82.1',
    prevalence: '1 em 4.000-6.000 nascimentos',
    inheritance_pattern: 'Autossómica dominante (maioria de novo)',
    age_of_onset: 'Nascimento',
    last_updated: '2025-08-30',
    
    summary: `A Síndrome de DiGeorge é causada por deleção da região 22q11.2, resultando em anomalias cardíacas, imunodeficiência, fenda palatina e características faciais distintivas.`,
    
    symptoms: [
      'Cardiopatias congénitas',
      'Imunodeficiência (hipoplasia do timo)',
      'Hipoparatiroidismo',
      'Fenda palatina/submucosa',
      'Características faciais típicas',
      'Dificuldades de aprendizagem',
      'Distúrbios psiquiátricos',
      'Problemas alimentares'
    ],
    
    causes: `Deleção da região 22q11.2 afetando múltiplos genes, incluindo TBX1, que é crítico para o desenvolvimento das estruturas da crista neural.`,
    
    diagnosis: `FISH ou microarray para deteção da deleção 22q11.2, ecocardiograma, avaliação imunológica, dosagem de cálcio e paratormona.`,
    
    treatment: `Correção cirúrgica de cardiopatias, suplementação de cálcio e vitamina D, profilaxia de infeções, terapia da fala, apoio educativo.`,
    
    prognosis: `Variável dependendo da severidade das malformações cardíacas. Muitos indivíduos têm vida produtiva com suporte adequado.`,
    
    support_organizations: [],
    clinical_trials: [],
    recent_articles: [],
    patient_resources: [],
    expert_reviewers: ['Dra. Teresa Imunologia - Portugal', 'Dr. Eduardo Cardiologia - Brasil'],
    sources: ['22q11.2 Society', 'International 22q11.2 Foundation']
  },

  'gard-br-0018': {
    id: 'gard-br-0018',
    gard_br_id: 'GARD-BR-0018',
    name_pt: 'Neurofibromatose Tipo 1',
    name_en: 'Neurofibromatosis Type 1',
    synonyms: ['NF1', 'Doença de Von Recklinghausen'],
    category: 'Doenças neurológicas',
    orpha_code: 'ORPHA636',
    icd10_code: 'Q85.0',
    prevalence: '1 em 3.000-4.000 pessoas',
    inheritance_pattern: 'Autossómica dominante',
    age_of_onset: 'Infância',
    last_updated: '2025-08-30',
    
    summary: `A Neurofibromatose Tipo 1 é uma doença genética multissistêmica caracterizada por neurofibromas, manchas café-com-leite, e predisposição a tumores.`,
    
    symptoms: [
      'Manchas café-com-leite (≥6)',
      'Neurofibromas cutâneos',
      'Neurofibromas plexiformes',
      'Efélides axilares/inguinais',
      'Nódulos de Lisch (iris)',
      'Glioma do nervo óptico',
      'Escoliose',
      'Dificuldades de aprendizagem'
    ],
    
    causes: `Mutações no gene NF1 que codifica a neurofibromina, uma proteína supressora tumoral que regula a via RAS.`,
    
    diagnosis: `Critérios clínicos NIH (2 ou mais critérios), análise genética molecular, exames oftalmológicos, ressonância magnética.`,
    
    treatment: `Vigilância regular para tumores, cirurgia para neurofibromas sintomáticos, tratamento de complicações, apoio educativo.`,
    
    prognosis: `Maioria dos indivíduos tem expectativa de vida normal. Risco de malignização de neurofibromas plexiformes é preocupação principal.`,
    
    support_organizations: [],
    clinical_trials: [],
    recent_articles: [],
    patient_resources: [],
    expert_reviewers: ['Prof. Ana Genética - Brasil', 'Dr. Paulo Neurologia - Portugal'],
    sources: ['Neurofibromatosis Network', 'Children\'s Tumor Foundation']
  },

  'gard-br-0019': {
    id: 'gard-br-0019',
    gard_br_id: 'GARD-BR-0019',
    name_pt: 'Síndrome de Rett',
    name_en: 'Rett Syndrome',
    synonyms: ['RTT', 'Síndrome de Rett Clássica'],
    category: 'Doenças neurológicas',
    orpha_code: 'ORPHA778',
    icd10_code: 'F84.2',
    prevalence: '1 em 10.000-15.000 meninas',
    inheritance_pattern: 'Ligada ao X (dominante, letal em homens)',
    age_of_onset: '6-18 meses',
    last_updated: '2025-08-30',
    
    summary: `A Síndrome de Rett é uma doença neurodesenvolvimental que afeta principalmente meninas, caracterizada por desenvolvimento normal inicial seguido de regressão.`,
    
    symptoms: [
      'Regressão do desenvolvimento',
      'Perda da fala adquirida',
      'Movimentos estereotipados das mãos',
      'Ataxia de marcha',
      'Microcefalia adquirida',
      'Convulsões',
      'Escoliose',
      'Distúrbios respiratórios',
      'Apraxia'
    ],
    
    causes: `Mutações no gene MECP2 (Xq28) em 95% dos casos. MECP2 codifica uma proteína que regula a expressão génica.`,
    
    diagnosis: `Critérios clínicos revisados, análise genética do gene MECP2, exclusão de outras causas de encefalopatia.`,
    
    treatment: `Tratamento sintomático: anticonvulsivantes, fisioterapia, terapia ocupacional, suporte nutricional, tratamento da escoliose.`,
    
    prognosis: `Doença progressiva com severa incapacidade. Expectativa de vida reduzida, mas muitas vivem até à idade adulta.`,
    
    support_organizations: [],
    clinical_trials: [],
    recent_articles: [],
    patient_resources: [],
    expert_reviewers: ['Dra. Márcia Neurologia - Brasil', 'Dr. João Genética - Portugal'],
    sources: ['International Rett Syndrome Foundation', 'Rett Syndrome Research Trust']
  },

  'gard-br-0020': {
    id: 'gard-br-0020',
    gard_br_id: 'GARD-BR-0020',
    name_pt: 'Hiperplasia Adrenal Congénita',
    name_en: 'Congenital Adrenal Hyperplasia',
    synonyms: ['HAC', 'Deficiência de 21-Hidroxilase'],
    category: 'Doenças endócrinas',
    orpha_code: 'ORPHA418',
    icd10_code: 'E25',
    prevalence: '1 em 10.000-15.000 nascimentos',
    inheritance_pattern: 'Autossómica recessiva',
    age_of_onset: 'Nascimento',
    last_updated: '2025-08-30',
    
    summary: `A Hiperplasia Adrenal Congénita é um grupo de doenças causadas por deficiências enzimáticas na síntese de cortisol, sendo a deficiência de 21-hidroxilase a mais comum.`,
    
    symptoms: [
      'Virilização em meninas',
      'Genitália ambígua',
      'Crise suprarrenal neonatal',
      'Desidratação',
      'Hipoglicemia',
      'Hiperpigmentação',
      'Puberdade precoce',
      'Baixa estatura final'
    ],
    
    causes: `Mutações no gene CYP21A2 (90% dos casos) causando deficiência da enzima 21-hidroxilase, essencial para síntese de cortisol e aldosterona.`,
    
    diagnosis: `Rastreio neonatal (17-hidroxiprogesterona elevada), análise genética, teste de estimulação com ACTH.`,
    
    treatment: `Reposição de glicocorticoides (hidrocortisona), mineralocorticoides (fludrocortisona) quando necessário, cirurgia reconstrutiva genital.`,
    
    prognosis: `Com tratamento adequado, prognóstico é excelente. Fertilidade normal é possível na maioria dos casos.`,
    
    support_organizations: [],
    clinical_trials: [],
    recent_articles: [],
    patient_resources: [],
    expert_reviewers: ['Dra. Isabel Endocrinologia - Portugal', 'Dr. Roberto Pediatria - Brasil'],
    sources: ['CARES Foundation', 'European Society for Paediatric Endocrinology']
  }
};

interface Props {
  params: { id: string };
}

export default function DoencaIndividualPage({ params }: Props) {
  const disease = MOCK_DISEASE_DATA[params.id];
  
  if (!disease) {
    return notFound();
  }

  return <DoencaClientWrapper disease={disease} />;
}

// Função necessária para Next.js 15 static export
export async function generateStaticParams() {
  const diseaseIds = Object.keys(MOCK_DISEASE_DATA);
  
  return diseaseIds.map((id) => ({
    id: id,
  }));
}
