'use client';

import { useState, useRef, useEffect } from 'react';
import { 
  PaperAirplaneIcon, 
  SparklesIcon,
  UserIcon,
  ExclamationTriangleIcon 
} from '@heroicons/react/24/outline';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

export default function GPTChatInterface() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'assistant',
      content: 'Olá! Sou o GPT Educativo da CPLP especializado em doenças raras. Como posso ajudá-lo hoje? Pode me fazer perguntas sobre diagnóstico, tratamentos, casos clínicos ou qualquer aspecto das doenças raras.',
      timestamp: new Date()
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const sendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    const currentInput = input;
    setInput('');
    setIsLoading(true);
    setError(null);

    try {
      const response = await fetch('/api/gpt-educativo', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          message: currentInput,
          context: 'doenças raras CPLP'
        }),
      });

      if (!response.ok) {
        // Se a API falhar, usar uma resposta demo
        throw new Error('API não disponível');
      }

      const data = await response.json();
      
      if (data.error) {
        throw new Error(data.error);
      }
      
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: data.message,
        timestamp: new Date()
      };

      setMessages(prev => [...prev, assistantMessage]);
    } catch (error) {
      // Modo demo - respostas pré-programadas quando a API não está disponível
      const demoResponses = getDemoResponse(currentInput.toLowerCase());
      
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: demoResponses,
        timestamp: new Date()
      };

      setMessages(prev => [...prev, assistantMessage]);
      
      // Mostrar aviso sobre modo demo
      setTimeout(() => {
        setError('🔧 Modo Demo Ativo - Para funcionalidade completa, configure a API OpenAI (ver CHAT_SETUP.md)');
      }, 1000);
    } finally {
      setIsLoading(false);
    }
  };

  // Respostas demo para quando a API não está configurada
  const getDemoResponse = (input: string): string => {
    const responses: { [key: string]: string } = {
      'marfan': `🧬 **Síndrome de Marfan**

A síndrome de Marfan é uma doença hereditária do tecido conjuntivo com prevalência de 1:5.000 nascimentos.

**🏗️ Manifestações Principais:**
• **Cardiovasculares**: Dilatação da aorta ascendente (80% dos casos)
• **Esqueléticas**: Estatura elevada, aracnodactilia, pectus deformity
• **Oculares**: Luxação do cristalino (60% dos casos)
• **Pulmonares**: Pneumotórax espontâneo

**🎯 Critérios Diagnósticos (Ghent Criteria):**
Sistema de pontuação que avalia manifestações em múltiplos órgãos.

**⚠️ Importante**: Este é um modo demonstrativo. Consulte sempre literatura médica atualizada e profissionais especializados.`,

      'fibrose': `🫁 **Fibrose Cística**

Doença autossômica recessiva mais comum em caucasianos, causada por mutações no gene CFTR.

**📊 Epidemiologia na CPLP:**
• Brasil: ~1:10.000 nascimentos
• Portugal: ~1:7.500 nascimentos

**🔬 Principais Manifestações:**
• **Pulmonares**: Infecções respiratórias recorrentes
• **Digestivas**: Insuficiência pancreática (85% dos casos)
• **Outros**: Íleo meconial, infertilidade masculina

**🧪 Diagnóstico:**
• Teste do suor (padrão-ouro)
• Triagem neonatal
• Análise genética

**💊 Tratamento:**
• Fisioterapia respiratória
• Enzimas pancreáticas
• Antibioticoterapia dirigida

*Modo Demo - Configure API OpenAI para respostas mais detalhadas*`,

      'prader': `🧬 **Síndrome de Prader-Willi**

Distúrbio genético complexo causado pela perda de expressão de genes no cromossomo 15 paterno.

**📈 Características por Fase:**

**🍼 Neonatal/Lactente:**
• Hipotonia severa
• Dificuldades alimentares
• Falha no crescimento

**👶 Infância (2-8 anos):**
• Hiperfagia e obesidade
• Baixa estatura
• Hipogonadismo

**👨‍⚕️ Manejo Multidisciplinar:**
• Endocrinologia: Hormônio do crescimento
• Nutrição: Controle calórico rigoroso
• Psicologia: Suporte comportamental
• Fisioterapia: Fortalecimento muscular

**🌍 Recursos CPLP:**
• Associação Brasileira PWS
• Protocolo SUS para hormônio do crescimento

*Demonstração - Para informações completas, ative a API OpenAI*`,

      'default': `👋 Olá! Sou o GPT Educativo especializado em doenças raras da CPLP.

**💡 Posso ajudá-lo com:**
• Informações sobre doenças raras específicas
• Protocolos diagnósticos
• Orientações terapêuticas
• Casos clínicos educativos
• Recursos disponíveis na CPLP

**🔧 Status Atual:** Modo Demonstrativo
Para funcionalidade completa com IA, configure a API OpenAI seguindo as instruções em CHAT_SETUP.md

**📝 Tente perguntar sobre:**
• "Síndrome de Marfan"
• "Fibrose cística"
• "Prader-Willi"
• Ou qualquer doença rara específica

Como posso ajudá-lo hoje?`
    };

    // Buscar resposta baseada em palavras-chave
    for (const [key, response] of Object.entries(responses)) {
      if (key !== 'default' && input.includes(key)) {
        return response;
      }
    }

    return responses.default;
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('pt-BR', {
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white rounded-2xl shadow-2xl border border-gray-200 overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-orange-500 to-red-600 px-6 py-4">
          <div className="flex items-center">
            <SparklesIcon className="h-6 w-6 text-white mr-3" />
            <div>
              <h3 className="text-white font-bold text-lg">GPT Educativo CPLP-Raras</h3>
              <p className="text-white/80 text-sm">Especialista em Doenças Raras</p>
            </div>
            <div className="ml-auto flex items-center">
              <div className="w-3 h-3 bg-green-400 rounded-full mr-2"></div>
              <span className="text-white/80 text-sm">Online</span>
            </div>
          </div>
        </div>

        {/* Messages Area */}
        <div className="h-96 overflow-y-auto p-6 bg-gray-50">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex mb-4 ${
                message.role === 'user' ? 'justify-end' : 'justify-start'
              }`}
            >
              <div
                className={`flex max-w-xs lg:max-w-md ${
                  message.role === 'user' ? 'flex-row-reverse' : 'flex-row'
                }`}
              >
                {/* Avatar */}
                <div className={`flex-shrink-0 ${
                  message.role === 'user' ? 'ml-3' : 'mr-3'
                }`}>
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                    message.role === 'user' 
                      ? 'bg-blue-600' 
                      : 'bg-gradient-to-r from-orange-500 to-red-600'
                  }`}>
                    {message.role === 'user' ? (
                      <UserIcon className="h-4 w-4 text-white" />
                    ) : (
                      <SparklesIcon className="h-4 w-4 text-white" />
                    )}
                  </div>
                </div>

                {/* Message Bubble */}
                <div className="flex flex-col">
                  <div
                    className={`px-4 py-2 rounded-2xl ${
                      message.role === 'user'
                        ? 'bg-blue-600 text-white'
                        : 'bg-white text-gray-900 shadow-md border'
                    }`}
                  >
                    <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                  </div>
                  <span className={`text-xs text-gray-500 mt-1 ${
                    message.role === 'user' ? 'text-right' : 'text-left'
                  }`}>
                    {formatTime(message.timestamp)}
                  </span>
                </div>
              </div>
            </div>
          ))}

          {/* Loading indicator */}
          {isLoading && (
            <div className="flex justify-start mb-4">
              <div className="flex mr-3">
                <div className="w-8 h-8 rounded-full bg-gradient-to-r from-orange-500 to-red-600 flex items-center justify-center">
                  <SparklesIcon className="h-4 w-4 text-white" />
                </div>
              </div>
              <div className="bg-white px-4 py-2 rounded-2xl shadow-md border">
                <div className="flex items-center space-x-2">
                  <div className="flex space-x-1">
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                  </div>
                  <span className="text-sm text-gray-500">Pensando...</span>
                </div>
              </div>
            </div>
          )}

          {/* Error message */}
          {error && (
            <div className="flex justify-center mb-4">
              <div className="bg-red-50 border border-red-200 rounded-lg px-4 py-3 flex items-center">
                <ExclamationTriangleIcon className="h-5 w-5 text-red-600 mr-2" />
                <span className="text-red-700 text-sm">{error}</span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Input Area */}
        <div className="p-6 bg-white border-t border-gray-200">
          <form onSubmit={sendMessage} className="flex items-end space-x-3">
            <div className="flex-1">
              <textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Digite sua pergunta sobre doenças raras..."
                className="w-full p-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-transparent resize-none"
                rows={2}
                disabled={isLoading}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    sendMessage(e);
                  }
                }}
              />
            </div>
            <button
              type="submit"
              disabled={!input.trim() || isLoading}
              className="bg-gradient-to-r from-orange-600 to-red-600 text-white p-3 rounded-xl hover:shadow-lg transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <PaperAirplaneIcon className="h-5 w-5" />
            </button>
          </form>
          <p className="text-xs text-gray-500 mt-2 text-center">
            Use Shift+Enter para nova linha • O GPT pode ocasionalmente gerar informações incorretas
          </p>
        </div>
      </div>
    </div>
  );
}
