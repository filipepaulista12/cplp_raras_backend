'use client';

import { useState, useEffect, useCallback } from 'react';

interface AccessibilitySettings {
  fontSize: 'small' | 'normal' | 'large' | 'xlarge';
  contrast: 'normal' | 'high';
  colorBlind: boolean;
  reduceMotion: boolean;
  screenReader: boolean;
}

export default function AccessibilityPanel() {
  const [isOpen, setIsOpen] = useState(false);
  const [isClient, setIsClient] = useState(false);
  const [settings, setSettings] = useState<AccessibilitySettings>({
    fontSize: 'normal',
    contrast: 'normal',
    colorBlind: false,
    reduceMotion: false,
    screenReader: false,
  });

  // Aplicar configurações ao DOM
  const applySettings = useCallback((newSettings: AccessibilitySettings) => {
    if (typeof window === 'undefined') return; // Verificar se estamos no cliente
    
    const root = document.documentElement;
    
    // Tamanho da fonte
    root.classList.remove('text-small', 'text-normal', 'text-large', 'text-xlarge');
    root.classList.add(`text-${newSettings.fontSize}`);
    
    // Alto contraste
    if (newSettings.contrast === 'high') {
      root.classList.add('high-contrast');
    } else {
      root.classList.remove('high-contrast');
    }
    
    // Daltonismo
    if (newSettings.colorBlind) {
      root.classList.add('color-blind-friendly');
    } else {
      root.classList.remove('color-blind-friendly');
    }
    
    // Reduzir movimento
    if (newSettings.reduceMotion) {
      root.classList.add('reduce-motion');
    } else {
      root.classList.remove('reduce-motion');
    }
  }, []);

  // Verificar se estamos no cliente para evitar problemas de hidratação
  useEffect(() => {
    setIsClient(true);
  }, []);

  // Carregar configurações salvas
  useEffect(() => {
    if (!isClient) return;
    
    const saved = localStorage.getItem('accessibility-settings');
    if (saved) {
      try {
        const parsedSettings = JSON.parse(saved);
        setSettings(parsedSettings);
        applySettings(parsedSettings);
      } catch (error) {
        console.warn('Erro ao carregar configurações de acessibilidade:', error);
      }
    }
  }, [isClient, applySettings]);

  // Atualizar configuração
  const updateSetting = <K extends keyof AccessibilitySettings>(
    key: K,
    value: AccessibilitySettings[K]
  ) => {
    const newSettings = { ...settings, [key]: value };
    setSettings(newSettings);
    applySettings(newSettings);
    
    if (isClient) {
      try {
        localStorage.setItem('accessibility-settings', JSON.stringify(newSettings));
      } catch (error) {
        console.warn('Erro ao salvar configurações de acessibilidade:', error);
      }
    }
  };

  const resetSettings = () => {
    const defaultSettings: AccessibilitySettings = {
      fontSize: 'normal',
      contrast: 'normal',
      colorBlind: false,
      reduceMotion: false,
      screenReader: false,
    };
    setSettings(defaultSettings);
    applySettings(defaultSettings);
    
    if (isClient) {
      try {
        localStorage.setItem('accessibility-settings', JSON.stringify(defaultSettings));
      } catch (error) {
        console.warn('Erro ao resetar configurações de acessibilidade:', error);
      }
    }
  };

  return (
    <>
      {/* Botão de acessibilidade flutuante */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-6 right-6 z-50 w-14 h-14 bg-gradient-to-br from-blue-600 to-purple-600 text-white rounded-full shadow-lg hover:shadow-xl transition-all duration-200 transform hover:scale-110 focus:outline-none focus:ring-4 focus:ring-blue-300"
        aria-label="Abrir painel de acessibilidade"
        title="Configurações de Acessibilidade"
      >
        <span className="text-2xl" role="img" aria-label="Acessibilidade">
          ♿
        </span>
      </button>

      {/* Painel de acessibilidade */}
      {isOpen && (
        <div className="fixed inset-0 z-40 overflow-hidden">
          {/* Overlay */}
          <div 
            className="fixed inset-0 bg-black bg-opacity-50"
            onClick={() => setIsOpen(false)}
            aria-hidden="true"
          />
          
          {/* Painel lateral */}
          <div className="fixed right-0 top-0 h-full w-80 bg-white shadow-2xl transform transition-transform duration-300 overflow-y-auto">
            <div className="p-6">
              {/* Cabeçalho */}
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold text-gray-900">
                  🔧 Acessibilidade
                </h2>
                <button
                  onClick={() => setIsOpen(false)}
                  className="p-2 text-gray-400 hover:text-gray-600 focus:outline-none focus:ring-2 focus:ring-blue-500 rounded-lg"
                  aria-label="Fechar painel"
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>

              {/* Tamanho da fonte */}
              <div className="mb-6">
                <label className="block text-sm font-semibold text-gray-700 mb-3">
                  📝 Tamanho da Fonte
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { value: 'small' as const, label: 'Pequeno' },
                    { value: 'normal' as const, label: 'Normal' },
                    { value: 'large' as const, label: 'Grande' },
                    { value: 'xlarge' as const, label: 'Muito Grande' }
                  ].map(({ value, label }) => (
                    <button
                      key={value}
                      onClick={() => updateSetting('fontSize', value)}
                      className={`p-2 text-sm border rounded-lg transition-colors ${
                        settings.fontSize === value
                          ? 'bg-blue-600 text-white border-blue-600'
                          : 'bg-white text-gray-700 border-gray-300 hover:border-blue-300'
                      }`}
                    >
                      {label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Contraste */}
              <div className="mb-6">
                <label className="block text-sm font-semibold text-gray-700 mb-3">
                  🌓 Contraste
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => updateSetting('contrast', 'normal')}
                    className={`p-2 text-sm border rounded-lg transition-colors ${
                      settings.contrast === 'normal'
                        ? 'bg-blue-600 text-white border-blue-600'
                        : 'bg-white text-gray-700 border-gray-300 hover:border-blue-300'
                    }`}
                  >
                    Normal
                  </button>
                  <button
                    onClick={() => updateSetting('contrast', 'high')}
                    className={`p-2 text-sm border rounded-lg transition-colors ${
                      settings.contrast === 'high'
                        ? 'bg-blue-600 text-white border-blue-600'
                        : 'bg-white text-gray-700 border-gray-300 hover:border-blue-300'
                    }`}
                  >
                    Alto
                  </button>
                </div>
              </div>

              {/* Opções adicionais */}
              <div className="space-y-4 mb-6">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-gray-700">
                    🎨 Modo Daltonismo
                  </span>
                  <button
                    onClick={() => updateSetting('colorBlind', !settings.colorBlind)}
                    className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 ${
                      settings.colorBlind ? 'bg-blue-600' : 'bg-gray-200'
                    }`}
                    role="switch"
                    aria-checked={settings.colorBlind}
                  >
                    <span
                      className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                        settings.colorBlind ? 'translate-x-6' : 'translate-x-1'
                      }`}
                    />
                  </button>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-gray-700">
                    🎬 Reduzir Animações
                  </span>
                  <button
                    onClick={() => updateSetting('reduceMotion', !settings.reduceMotion)}
                    className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 ${
                      settings.reduceMotion ? 'bg-blue-600' : 'bg-gray-200'
                    }`}
                    role="switch"
                    aria-checked={settings.reduceMotion}
                  >
                    <span
                      className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                        settings.reduceMotion ? 'translate-x-6' : 'translate-x-1'
                      }`}
                    />
                  </button>
                </div>
              </div>

              {/* Atalhos de teclado */}
              <div className="mb-6 p-4 bg-gray-50 rounded-lg">
                <h3 className="text-sm font-semibold text-gray-700 mb-3">
                  ⌨️ Atalhos de Teclado
                </h3>
                <div className="space-y-2 text-xs text-gray-600">
                  <div className="flex justify-between">
                    <span>Pular para conteúdo:</span>
                    <kbd className="px-2 py-1 bg-white rounded border">Tab</kbd>
                  </div>
                  <div className="flex justify-between">
                    <span>Aumentar fonte:</span>
                    <kbd className="px-2 py-1 bg-white rounded border">Ctrl + +</kbd>
                  </div>
                  <div className="flex justify-between">
                    <span>Diminuir fonte:</span>
                    <kbd className="px-2 py-1 bg-white rounded border">Ctrl + -</kbd>
                  </div>
                </div>
              </div>

              {/* Botão de reset */}
              <button
                onClick={resetSettings}
                className="w-full p-3 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors font-medium"
              >
                🔄 Restaurar Padrão
              </button>

              {/* Informações adicionais */}
              <div className="mt-6 p-4 bg-blue-50 rounded-lg">
                <h3 className="text-sm font-semibold text-blue-900 mb-2">
                  ℹ️ Sobre Acessibilidade
                </h3>
                <p className="text-xs text-blue-800 leading-relaxed">
                  Este site foi desenvolvido seguindo as diretrizes WCAG 2.1 para garantir 
                  acesso universal às informações sobre doenças raras na CPLP.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
