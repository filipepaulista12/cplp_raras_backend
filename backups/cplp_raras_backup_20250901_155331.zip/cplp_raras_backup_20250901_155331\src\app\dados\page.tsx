import { Metadata } from 'next';
import { ResearchDataDashboard } from '@/components/research/ResearchDataDashboard';

export const metadata: Metadata = {
  title: 'Base de Dados | CPLP-Raras',
  description: 'Explore nossa base de dados sobre doenças raras nos países de língua portuguesa, incluindo informações do GARD e protocolos clínicos do PCDT.',
  keywords: ['doenças raras', 'CPLP', 'GARD', 'PCDT', 'base de dados', 'pesquisa médica'],
};

export default function DataPage() {
  return (
    <main className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50">
      <div className="container mx-auto px-4 py-12">
        {/* Hero Section */}
        <section className="text-center mb-12">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              Base de Dados
              <span className="text-blue-600 block">CPLP-Raras</span>
            </h1>
            <p className="text-xl text-gray-600 mb-8 leading-relaxed">
              Acesse nossa base de dados consolidada sobre doenças raras, 
              coletada automaticamente de fontes confiáveis para apoiar 
              a pesquisa e o cuidado nos países de língua portuguesa.
            </p>
            <div className="flex flex-wrap justify-center gap-4 text-sm text-gray-500">
              <span className="flex items-center gap-2">
                <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                Dados Internacionais (GARD-NIH)
              </span>
              <span className="flex items-center gap-2">
                <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                Protocolos Brasileiros (PCDT)
              </span>
              <span className="flex items-center gap-2">
                <div className="w-3 h-3 bg-purple-500 rounded-full"></div>
                Atualização Automática
              </span>
            </div>
          </div>
        </section>

        {/* Dashboard */}
        <section>
          <ResearchDataDashboard className="max-w-7xl mx-auto" />
        </section>

        {/* Informações Adicionais */}
        <section className="mt-16 max-w-4xl mx-auto">
          <div className="bg-white rounded-lg shadow-lg p-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">
              Sobre Nossa Base de Dados
            </h2>
            
            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-lg font-semibold text-gray-800 mb-3">
                  🔬 GARD - NIH
                </h3>
                <p className="text-gray-600 mb-4">
                  O Genetic and Rare Diseases Information Center (GARD) é um programa 
                  do National Center for Advancing Translational Sciences (NCATS) e 
                  faz parte dos National Institutes of Health (NIH) dos Estados Unidos.
                </p>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• Informações sobre mais de 6.000 doenças raras</li>
                  <li>• Jornadas diagnósticas detalhadas</li>
                  <li>• Recursos para pacientes e famílias</li>
                  <li>• Pesquisas e estudos clínicos</li>
                </ul>
              </div>

              <div>
                <h3 className="text-lg font-semibold text-gray-800 mb-3">
                  📄 PCDT - Ministério da Saúde
                </h3>
                <p className="text-gray-600 mb-4">
                  Os Protocolos Clínicos e Diretrizes Terapêuticas (PCDT) são 
                  documentos oficiais do Sistema Único de Saúde (SUS) que 
                  estabelecem critérios para diagnóstico e tratamento.
                </p>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• Protocolos oficiais do SUS</li>
                  <li>• Diretrizes baseadas em evidências</li>
                  <li>• Critérios de diagnóstico e tratamento</li>
                  <li>• Acesso a medicamentos especializados</li>
                </ul>
              </div>
            </div>

            <div className="mt-8 p-4 bg-blue-50 rounded-lg border border-blue-200">
              <h4 className="font-semibold text-blue-800 mb-2">
                🤖 Coleta Automatizada
              </h4>
              <p className="text-blue-700 text-sm">
                Nossa base de dados é atualizada automaticamente através de 
                scripts especializados que coletam informações das fontes oficiais, 
                garantindo dados sempre atualizados e confiáveis para a comunidade 
                CPLP-Raras.
              </p>
            </div>
          </div>
        </section>

        {/* Call to Action */}
        <section className="mt-16 text-center">
          <div className="bg-gradient-to-r from-blue-600 to-green-600 rounded-lg p-8 text-white">
            <h2 className="text-2xl font-bold mb-4">
              Contribua com o Projeto CPLP-Raras
            </h2>
            <p className="text-blue-100 mb-6 max-w-2xl mx-auto">
              Nossos dados estão disponíveis para pesquisadores, profissionais 
              de saúde e organizações que trabalham com doenças raras nos 
              países de língua portuguesa.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <button className="bg-white text-blue-600 px-6 py-2 rounded-lg font-semibold hover:bg-blue-50 transition-colors">
                Solicitar Acesso aos Dados
              </button>
              <button className="border border-white text-white px-6 py-2 rounded-lg font-semibold hover:bg-white hover:text-blue-600 transition-colors">
                Saiba Mais sobre o Projeto
              </button>
            </div>
          </div>
        </section>
      </div>
    </main>
  );
}
