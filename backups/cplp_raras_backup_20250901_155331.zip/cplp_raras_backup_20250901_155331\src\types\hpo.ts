export interface HPOTerm {
  id: string; // HP:0000001
  label_en: string;
  definition_en: string;
  synonyms_en: string[];
  parents: string[];
  category?: string;
  
  // Campos de tradução
  label_pt?: string;
  definition_pt?: string;
  synonyms_pt: string[];
  
  // IA suggestion (readonly)
  ai_label_pt?: string;
  ai_definition_pt?: string;
  
  // Status de revisão
  status: 'candidate' | 'under_review' | 'official';
  
  // Metadados
  created_at: string;
  updated_at: string;
}

export interface Translation {
  id: string;
  term_id: string;
  translator: string;
  translation_date: string;
  
  // Campos traduzidos
  label_pt: string;
  definition_pt: string;
  synonyms_pt: string[];
  
  // Avaliação
  likert_score: number; // 1-5
  comments: string;
  
  // Status
  is_final: boolean;
}

export interface Translator {
  id: string;
  name: string;
  bio: string;
  expertise: string[];
  contributions: number;
}

export interface BabelonTSVRow {
  id: string;
  label_en: string;
  label_pt: string;
  definition_en: string;
  definition_pt: string;
  status: string;
  translator: string;
  review_date: string;
}

export interface SynonymsTSVRow {
  id: string;
  synonym_pt: string;
  translator: string;
  review_date: string;
}

export interface HPOStats {
  total: number;
  candidate: number;
  under_review: number;
  official: number;
  avg_likert: number;
}
