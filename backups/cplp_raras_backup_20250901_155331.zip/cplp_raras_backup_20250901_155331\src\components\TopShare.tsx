'use client';

import { useState } from 'react';
import { Share2, X, Copy, Check } from 'lucide-react';

interface TopShareProps {
  title?: string;
  description?: string;
}

export default function TopShare({ title, description }: TopShareProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [copied, setCopied] = useState(false);

  const shareData = {
    title: title || 'CPLP-Raras | Rede de Pesquisa em Doenças Raras',
    text: description || 'Fortalecer a resposta dos países da CPLP às doenças raras através de cooperação científica',
    url: typeof window !== 'undefined' ? window.location.href : ''
  };

  const handleNativeShare = async () => {
    if (navigator.share && typeof navigator.share === 'function') {
      try {
        await navigator.share(shareData);
      } catch (error) {
        console.log('Compartilhamento cancelado');
      }
    }
  };

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(shareData.url);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (error) {
      console.error('Erro ao copiar link:', error);
    }
  };

  const socialShares = [
    {
      name: 'WhatsApp',
      url: `https://wa.me/?text=${encodeURIComponent(`${shareData.title} - ${shareData.url}`)}`,
      color: 'hover:bg-green-50 hover:text-green-600',
      icon: '📱'
    },
    {
      name: 'Twitter',
      url: `https://twitter.com/intent/tweet?text=${encodeURIComponent(shareData.title)}&url=${encodeURIComponent(shareData.url)}`,
      color: 'hover:bg-blue-50 hover:text-blue-600',
      icon: '🐦'
    },
    {
      name: 'LinkedIn',
      url: `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(shareData.url)}`,
      color: 'hover:bg-blue-50 hover:text-blue-700',
      icon: '💼'
    },
    {
      name: 'Facebook',
      url: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareData.url)}`,
      color: 'hover:bg-blue-50 hover:text-blue-800',
      icon: '👥'
    }
  ];

  // Detectar se é mobile
  const isMobile = typeof window !== 'undefined' && 
    ('ontouchstart' in window || navigator.maxTouchPoints > 0);

  return (
    <div className="relative">
      {/* Botão discreto no topo */}
      <div className="flex justify-end mb-4">
        <button
          onClick={() => {
            if (isMobile && typeof navigator.share === 'function') {
              handleNativeShare();
            } else {
              setIsOpen(!isOpen);
            }
          }}
          className="flex items-center gap-2 text-sm font-medium text-white hover:text-white 
                   bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 
                   px-4 py-2.5 rounded-full transition-all duration-200
                   border-0 shadow-lg hover:shadow-xl
                   backdrop-blur-sm"
          aria-label="Compartilhar página"
        >
          <Share2 size={18} />
          <span className="hidden sm:inline">Compartilhar</span>
        </button>
      </div>

      {/* Menu dropdown para desktop */}
      {isOpen && !isMobile && (
        <div className="absolute top-12 right-0 z-50 bg-white rounded-lg shadow-lg border border-gray-200 p-4 min-w-[280px]">
          {/* Header */}
          <div className="flex items-center justify-between mb-3">
            <span className="text-sm font-medium text-gray-700">Compartilhar</span>
            <button
              onClick={() => setIsOpen(false)}
              className="p-1 hover:bg-gray-100 rounded"
              aria-label="Fechar menu"
            >
              <X size={16} />
            </button>
          </div>

          {/* Copiar link */}
          <button
            onClick={handleCopyLink}
            className="w-full flex items-center gap-3 p-2 hover:bg-gray-50 rounded-lg mb-2 transition-colors"
          >
            {copied ? <Check size={16} className="text-green-600" /> : <Copy size={16} />}
            <span className="text-sm">{copied ? 'Link copiado!' : 'Copiar link'}</span>
          </button>

          {/* Divisor */}
          <div className="border-t border-gray-100 my-2"></div>

          {/* Redes sociais */}
          <div className="grid grid-cols-2 gap-2">
            {socialShares.map((social) => (
              <a
                key={social.name}
                href={social.url}
                target="_blank"
                rel="noopener noreferrer"
                className={`flex items-center gap-2 p-2 rounded-lg transition-colors text-sm ${social.color}`}
              >
                <span>{social.icon}</span>
                <span>{social.name}</span>
              </a>
            ))}
          </div>
        </div>
      )}

      {/* Overlay para fechar menu */}
      {isOpen && (
        <div
          className="fixed inset-0 z-40"
          onClick={() => setIsOpen(false)}
          aria-hidden="true"
        />
      )}
    </div>
  );
}
