import Link from 'next/link';
import Image from 'next/image';
import { ArrowLeftIcon } from '@heroicons/react/24/outline';
import { getImageSrc } from '@/lib/imageUtils';
import TopShare from '@/components/TopShare';

const countries = [
  { name: 'Brasil', flag: '🇧🇷', status: 'active', description: 'Coordenação geral do projeto' },
  { name: 'Portugal', flag: '🇵🇹', status: 'active', description: 'Parceria estratégica' },
  { name: 'Angola', flag: '🇦🇴', status: 'active', description: 'Representação regional' },
  { name: 'Moçambique', flag: '🇲🇿', status: 'active', description: 'Colaboração científica' },
  { name: 'Guiné-Bissau', flag: '🇬🇼', status: 'active', description: 'Rede de pesquisa' },
  { name: 'Cabo Verde', flag: '🇨🇻', status: 'expanding', description: 'Buscamos ampliar participação' },
  { name: 'Timor-Leste', flag: '🇹🇱', status: 'expanding', description: 'Buscamos ampliar participação' },
  { name: 'Guiné Equatorial', flag: '🇬🇶', status: 'expanding', description: 'Buscamos ampliar participação' },
  { name: 'São Tomé e Príncipe', flag: '🇸🇹', status: 'expanding', description: 'Buscamos ampliar participação' },
];

const researchers = [
  // Brasil - Coordenação
  {
    name: 'Prof. Dr. Domingos Alves',
    country: 'Brasil',
    role: 'Coordenador Geral',
    institution: 'LIS/USP',
    orcid: '0000-0002-0800-5872',
    photo: '/images/domingos.jpg',
    bio: 'Coordenador do projeto e do LIS/USP. Especialista em saúde digital e redes colaborativas em saúde.',
    type: 'coordinator'
  },
  {
    name: 'Profa. Dra. Têmis M. Félix',
    country: 'Brasil',
    role: 'Coordenadora da Rede RARAS',
    institution: 'Rede RARAS',
    orcid: '0000-0002-8401-6821',
    photo: '/images/temis.jpg',
    bio: 'Coordenadora da Rede RARAS. Referência nacional em genética médica e políticas públicas para doenças raras.',
    type: 'coordinator'
  },
  {
    name: 'Profa. Dra. Ida Schwartz',
    country: 'Brasil',
    role: 'Presidente da SBGM',
    institution: 'UFRGS',
    orcid: '0000-0002-7933-6687',
    photo: '/images/ida-schwartz.jpg',
    bio: 'Presidente da SBGM. Professora titular na UFRGS e coordenadora do Instituto Nacional de Doenças Raras (INRaras), atua em erros inatos do metabolismo e avaliação de tecnologias em genética clínica.',
    type: 'coordinator'
  },
  {
    name: 'Prof. Dr. Natan Monsores',
    country: 'Brasil',
    role: 'Coordenador-Geral de Doenças Raras',
    institution: 'Ministério da Saúde',
    orcid: '0000-0002-1234-5678',
    photo: '/images/natan.jpg',
    bio: 'Pesquisador em saúde pública e doenças raras, com experiência em epidemiologia e análise de dados em saúde. Atualmente é o Coordenador-Geral de Doenças Raras do Ministério da Saúde.',
    type: 'coordinator'
  },
  // Portugal
  {
    name: 'Prof. Dr. José Alberto Freitas',
    country: 'Portugal',
    role: 'Professor Associado',
    institution: 'FMUP/CINTESIS/RISE-Health',
    orcid: '0000-0003-2113-9653',
    photo: '/images/alberto.png',
    bio: 'Professor associado na FMUP e coordenador do grupo 2D4H no CINTESIS@RISE. Atua em ciência de dados em saúde, qualidade de dados, codificação clínica e machine learning aplicado a sistemas de saúde.',
    type: 'researcher'
  },
  {
    name: 'Prof. Dr. Rui Pedro Charters Lopes Rijo',
    country: 'Portugal',
    role: 'Professor',
    institution: 'Politécnico de Leiria/INESC Coimbra',
    orcid: '0000-0002-9348-0474',
    photo: '/images/ruirijo.jpg',
    bio: 'Professor no Politécnico de Leiria e investigador no INESC Coimbra. Atua em gestão de projetos, engenharia de software e sistemas de informação em saúde.',
    type: 'researcher'
  },
    {
    name: 'Prof. Dr. Júlio C. Botelho de Souza',
    country: 'Portugal',
    role: 'Professor e Investigador',
    institution: 'ISEP - Instituto Superior de Engenharia do Porto',
    orcid: '0000-0002-8576-1903',
    photo: '/images/julio.jpg',
    bio: 'Professor e investigador no ISEP e na rede RISE. Atua em ciência de dados, saúde digital, economia da saúde e codificação clínica.',
    type: 'researcher'
  },
  // Angola
  {
    name: 'Dr. Tomás Sanjuluca',
    country: 'Angola',
    role: 'Docente em Informática Médica',
    institution: 'Universidade de Angola',
    orcid: '0000-0003-2229-4292',
    photo: '/images/thomaz-angola.jpg',
    bio: 'Docente em informática médica. Atua em bioestatística, planejamento em saúde e gestão de informação científica.',
    type: 'researcher'
  },
  // Guiné-Bissau
  {
    name: 'MSc. Adulai G. Rodrigues',
    country: 'Guiné-Bissau',
    role: 'Gestor de Dados em Saúde',
    institution: 'Sistema de Saúde da Guiné-Bissau',
    orcid: '0009-0003-3994-5925',
    photo: '/images/adulai.jpg',
    bio: 'Gestor de dados em saúde. Atua na coordenação de sistemas de informação em saúde e controle da tuberculose.',
    type: 'researcher'
  },
  // Moçambique
  {
    name: 'Dr. Luís F. A. Madeira',
    country: 'Moçambique',
    role: 'Fundador do Serviço de Genética Médica',
    institution: 'Hospital Central de Maputo',
    orcid: '',
    photo: '/images/luismadeira.jpg',
    bio: 'Fundador do Serviço de Genética Médica no Hospital Central de Maputo. Atua em genética, pediatria e ensino superior.',
    type: 'researcher'
  },
  {
    name: 'MSc. Olimpio M. Zavale',
    country: 'Moçambique',
    role: 'Estatístico',
    institution: 'Instituto Nacional de Estadística (INE)',
    orcid: '0000-0002-9180-6602',
    photo: '/images/olimpio-mz.jpg',
    bio: 'Especialista em desenho e implementação de inquéritos, coleta de dados em saúde e controle de qualidade. Atua na Health Research for Development.',
    type: 'researcher'
  },
  {
    name: 'Dr.a Yumna Khalid Cassam',
    country: 'Moçambique',
    role: 'Docente e Médica',
    institution: 'Universidade Eduardo Mondlane/Hospital Central de Maputo',
    orcid: '0009-0002-5992-4227',
    photo: '/api/placeholder/200/200',
    bio: 'Docente na Faculdade de Medicina da Universidade Eduardo Mondlane e médica no Hospital Central de Maputo. Atua nas áreas de genética médica e anatomia patológica.',
    type: 'collaborator'
  }
];



export default function Team() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Breadcrumb */}
      <div className="bg-white border-b">
        <div className="mx-auto max-w-7xl px-4 py-4 sm:px-6 lg:px-8">
          <Link 
            href="/"
            className="inline-flex items-center text-blue-600 hover:text-blue-800 transition-colors"
          >
            <ArrowLeftIcon className="h-4 w-4 mr-2" />
            Voltar ao Início
          </Link>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        
        {/* Compartilhamento no topo */}
        <TopShare 
          title="Equipe CPLP-Raras"
          description="Conheça a equipe multidisciplinar e internacional do projeto CPLP-Raras"
        />
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            🧬 Equipe do Projeto
          </h1>
          <div className="w-32 h-1 bg-gradient-to-r from-blue-600 to-green-600 mx-auto mb-8"></div>
          <p className="text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed">
            O projeto CPLP-Raras reúne uma equipe multidisciplinar de pesquisadores e instituições 
            de diversos países da Comunidade dos Países de Língua Portuguesa (CPLP). Nosso objetivo 
            é fortalecer a cooperação internacional e ampliar a rede de colaboração científica em 
            doenças raras.
          </p>
        </div>

        {/* Países Representados */}
        <section className="mb-16">
          <div className="bg-white rounded-2xl shadow-lg p-8 md:p-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">
              🌍 Países Representados na Equipe
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
              {countries.map((country) => (
                <div
                  key={country.name}
                  className={`border rounded-xl p-6 transition-all duration-300 ${
                    country.status === 'active'
                      ? 'border-green-200 bg-green-50 hover:shadow-md'
                      : 'border-orange-200 bg-orange-50 hover:shadow-md'
                  }`}
                >
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center space-x-3">
                      <span className="text-3xl">{country.flag}</span>
                      <h3 className="text-lg font-semibold text-gray-900">{country.name}</h3>
                    </div>
                    <span className="text-2xl">
                      {country.status === 'active' ? '💠' : '⭐️'}
                    </span>
                  </div>
                  <p className="text-gray-600 text-sm">{country.description}</p>
                </div>
              ))}
            </div>

            <div className="flex justify-center space-x-8 text-sm text-gray-600">
              <div className="flex items-center space-x-2">
                <span className="text-xl">💠</span>
                <span>Já na rede</span>
              </div>
              <div className="flex items-center space-x-2">
                <span className="text-xl">⭐️</span>
                <span>Buscamos ampliar</span>
              </div>
            </div>
          </div>
        </section>

        {/* Call to Action para Participação */}
        <section className="mb-16">
          <div className="bg-gradient-to-r from-blue-600 to-green-600 rounded-2xl p-8 text-white text-center">
            <h2 className="text-2xl md:text-3xl font-bold mb-4">
              🔍 Junte-se à Rede CPLP-Raras!
            </h2>
            <p className="text-xl mb-2 opacity-90">
              Sua instituição representa Cabo Verde, Timor-Leste, Guiné Equatorial ou São Tomé e Príncipe?
            </p>
            <p className="text-lg mb-6 opacity-90">
              💌 Fale com a equipe e integre a Rede CPLP-Raras!
            </p>
            <Link
              href="/contato"
              className="inline-block bg-white text-blue-600 px-8 py-3 rounded-lg font-semibold hover:bg-blue-50 transition-colors"
            >
              Entre em Contato
            </Link>
          </div>
        </section>

        {/* Pesquisadores Principais por País */}
        <section className="mb-16">
          <div className="bg-white rounded-2xl shadow-lg p-8 md:p-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">
              👨‍🔬 Pesquisadores Principais por País
            </h2>
            
            <div className="space-y-12">
              {/* Brasil - Coordenação */}
              <div>
                <h3 className="text-2xl font-semibold text-gray-900 mb-6 flex items-center">
                  <span className="text-3xl mr-3">🇧🇷</span>
                  Brasil
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  {researchers.filter(r => r.country === 'Brasil' && (r.type === 'coordinator' || r.type === 'researcher')).map((researcher, index) => (
                    <div key={index} className="bg-gradient-to-br from-blue-50 to-blue-100 border border-blue-200 rounded-xl p-6 text-center hover:shadow-md transition-shadow">
                      <div className="w-24 h-24 rounded-full mx-auto mb-4 border-4 border-blue-200 overflow-hidden">
                        <Image 
                          src={getImageSrc(researcher.photo)} 
                          alt={researcher.name}
                          width={96}
                          height={96}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <h4 className="font-semibold text-gray-900 mb-1">{researcher.name}</h4>
                      <p className="text-sm text-blue-600 font-medium mb-2">{researcher.role}</p>
                      <p className="text-xs text-gray-600 mb-2">{researcher.institution}</p>
                      {researcher.orcid && (
                        <a 
                          href={`https://orcid.org/${researcher.orcid}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center text-xs text-green-600 hover:text-green-800 mb-2"
                        >
                          <Image 
                            src="https://info.orcid.org/wp-content/uploads/2019/11/orcid_16x16.png" 
                            className="w-3 h-3 mr-1" 
                            alt="ORCID"
                            width={12}
                            height={12}
                          />
                          {researcher.orcid}
                        </a>
                      )}
                      <p className="text-xs text-gray-600 mt-3 leading-relaxed">{researcher.bio}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Outros Países */}
              {['Portugal', 'Angola', 'Guiné-Bissau', 'Moçambique'].map(country => {
                const countryResearchers = researchers.filter(r => r.country === country && r.type === 'researcher');
                if (countryResearchers.length === 0) return null;
                
                const countryFlag = country === 'Portugal' ? '🇵🇹' : 
                                  country === 'Angola' ? '🇦🇴' : 
                                  country === 'Guiné-Bissau' ? '🇬🇼' : '🇲🇿';
                
                return (
                  <div key={country}>
                    <h3 className="text-2xl font-semibold text-gray-900 mb-6 flex items-center">
                      <span className="text-3xl mr-3">{countryFlag}</span>
                      {country}
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                      {countryResearchers.map((researcher, index) => (
                        <div key={index} className="bg-gradient-to-br from-blue-50 to-blue-100 border border-blue-200 rounded-xl p-6 hover:shadow-md transition-shadow">
                          <div className="flex items-start space-x-4">
                            <div className="w-16 h-16 rounded-full border-2 border-blue-200 overflow-hidden flex-shrink-0">
                              <Image 
                                src={getImageSrc(researcher.photo)} 
                                alt={researcher.name}
                                width={64}
                                height={64}
                                className="w-full h-full object-cover"
                              />
                            </div>
                            <div className="flex-1">
                              <h4 className="font-semibold text-gray-900 mb-1">{researcher.name}</h4>
                              <p className="text-sm text-blue-600 font-medium mb-1">{researcher.role}</p>
                              <p className="text-xs text-gray-600 mb-2">{researcher.institution}</p>
                              {researcher.orcid && (
                                <a 
                                  href={`https://orcid.org/${researcher.orcid}`}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="inline-flex items-center text-xs text-green-600 hover:text-green-800 mb-2"
                                >
                                  <Image 
                                    src="https://info.orcid.org/wp-content/uploads/2019/11/orcid_16x16.png" 
                                    className="w-3 h-3 mr-1" 
                                    alt="ORCID"
                                    width={12}
                                    height={12}
                                  />
                                  {researcher.orcid}
                                </a>
                              )}
                              <p className="text-xs text-gray-600 leading-relaxed">{researcher.bio}</p>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </section>

        {/* Links para outras seções */}
        <section className="mb-16">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Link href="/equipe/colaboradores" className="bg-gradient-to-br from-green-50 to-emerald-100 border border-green-200 rounded-xl p-8 text-center hover:shadow-lg transition-all duration-200 transform hover:scale-105">
              <div className="text-4xl mb-4">🤝</div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Colaboradores</h3>
              <p className="text-gray-600 text-sm">Força-tarefa de colaboradores voluntários do projeto</p>
              <div className="mt-4 text-green-600 font-semibold">Ver Colaboradores →</div>
            </Link>

            <Link href="/equipe/parceiros" className="bg-gradient-to-br from-purple-50 to-violet-100 border border-purple-200 rounded-xl p-8 text-center hover:shadow-lg transition-all duration-200 transform hover:scale-105">
              <div className="text-4xl mb-4">🏢</div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Parceiros</h3>
              <p className="text-gray-600 text-sm">Instituições e organizações parceiras</p>
              <div className="mt-4 text-purple-600 font-semibold">Ver Parceiros →</div>
            </Link>

            <Link href="/equipe/instituicoes" className="bg-gradient-to-br from-orange-50 to-amber-100 border border-orange-200 rounded-xl p-8 text-center hover:shadow-lg transition-all duration-200 transform hover:scale-105">
              <div className="text-4xl mb-4">🏛️</div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Instituições</h3>
              <p className="text-gray-600 text-sm">Universidades e centros de pesquisa envolvidos</p>
              <div className="mt-4 text-orange-600 font-semibold">Ver Instituições →</div>
            </Link>
          </div>
        </section>

        {/* Áreas de Expertise */}
        <section>
          <div className="bg-white rounded-2xl shadow-lg p-8 md:p-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">
              🎓 Áreas de Expertise da Equipe
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Competências Clínicas</h3>
                <div className="space-y-3">
                  <div className="flex items-center space-x-3">
                    <span className="w-2 h-2 bg-blue-600 rounded-full"></span>
                    <span className="text-gray-700">Genética Médica</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <span className="w-2 h-2 bg-blue-600 rounded-full"></span>
                    <span className="text-gray-700">Pediatria Especializada</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <span className="w-2 h-2 bg-blue-600 rounded-full"></span>
                    <span className="text-gray-700">Neurologia</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <span className="w-2 h-2 bg-blue-600 rounded-full"></span>
                    <span className="text-gray-700">Metabolismo Hereditário</span>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Competências Técnicas</h3>
                <div className="space-y-3">
                  <div className="flex items-center space-x-3">
                    <span className="w-2 h-2 bg-green-600 rounded-full"></span>
                    <span className="text-gray-700">Bioinformática</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <span className="w-2 h-2 bg-green-600 rounded-full"></span>
                    <span className="text-gray-700">Gestão de Dados de Saúde</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <span className="w-2 h-2 bg-green-600 rounded-full"></span>
                    <span className="text-gray-700">Epidemiologia</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <span className="w-2 h-2 bg-green-600 rounded-full"></span>
                    <span className="text-gray-700">Saúde Digital</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
