'use client';

import { useState, useEffect } from 'react';
import { EyeIcon, ChatBubbleLeftRightIcon } from '@heroicons/react/24/outline';
import AnalyticsPanel from './AnalyticsPanel';

interface InteractionStats {
  totalVisits: number;
  totalFeedback: number;
  uniqueVisitors: number;
  lastVisit: string;
}

export default function InteractionCounter() {
  const [stats, setStats] = useState<InteractionStats>({
    totalVisits: 0,
    totalFeedback: 0,
    uniqueVisitors: 0,
    lastVisit: ''
  });
  const [isVisible, setIsVisible] = useState(false);
  const [showAnalytics, setShowAnalytics] = useState(false);

  useEffect(() => {
    // Incrementar visitas quando a página carrega
    const incrementVisit = () => {
      const today = new Date().toDateString();
      const visitKey = 'cplp-visits';
      const uniqueVisitorKey = 'cplp-unique-visitor';
      const lastVisitKey = 'cplp-last-visit';
      const feedbackCountKey = 'cplp-feedback-count';

      // Total de visitas
      const currentVisits = localStorage.getItem(visitKey) || '0';
      const newVisitCount = parseInt(currentVisits) + 1;
      localStorage.setItem(visitKey, newVisitCount.toString());

      // Visitante único (baseado no dia)
      const lastVisit = localStorage.getItem(lastVisitKey);
      let uniqueVisitors = parseInt(localStorage.getItem('cplp-unique-visitors') || '0');
      
      if (lastVisit !== today) {
        uniqueVisitors += 1;
        localStorage.setItem('cplp-unique-visitors', uniqueVisitors.toString());
      }
      
      localStorage.setItem(lastVisitKey, today);

      // Total de feedbacks
      const feedbackCount = parseInt(localStorage.getItem(feedbackCountKey) || '0');

      setStats({
        totalVisits: newVisitCount,
        totalFeedback: feedbackCount,
        uniqueVisitors: uniqueVisitors,
        lastVisit: today
      });
    };

    incrementVisit();

    // Atualizar contador de feedback periodicamente
    const updateFeedbackCount = () => {
      const feedbackCount = parseInt(localStorage.getItem('cplp-feedback-count') || '0');
      setStats(prev => ({
        ...prev,
        totalFeedback: feedbackCount
      }));
    };

    const interval = setInterval(updateFeedbackCount, 5000); // Atualiza a cada 5 segundos

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="fixed bottom-6 left-6 z-40">
      <div className="relative">
        {/* Contador compacto */}
        <button
          onClick={() => setIsVisible(!isVisible)}
          className="bg-white border border-gray-200 shadow-lg rounded-full p-3 hover:shadow-xl transition-all duration-300 transform hover:scale-105 group"
          aria-label="Ver estatísticas do site"
        >
          <EyeIcon className="h-5 w-5 text-gray-600 group-hover:text-orange-600 transition-colors" />
          
          {/* Badge com número de visitas */}
          <div className="absolute -top-2 -right-2 bg-orange-600 text-white text-xs rounded-full h-6 w-6 flex items-center justify-center font-bold">
            {stats.totalVisits > 999 ? '999+' : stats.totalVisits}
          </div>
        </button>

        {/* Painel expandido */}
        {isVisible && (
          <div className="absolute bottom-16 left-0 bg-white rounded-2xl shadow-xl border border-gray-200 p-4 min-w-[280px] transform transition-all duration-300 animate-in slide-in-from-bottom">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-semibold text-gray-900 flex items-center">
                📊 Estatísticas do Site
              </h3>
              <button
                onClick={() => setIsVisible(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                ✕
              </button>
            </div>
            
            <div className="space-y-3">
              <div className="flex items-center justify-between py-2 px-3 bg-blue-50 rounded-lg">
                <div className="flex items-center space-x-2">
                  <EyeIcon className="h-4 w-4 text-blue-600" />
                  <span className="text-sm font-medium text-blue-800">Total de Visitas</span>
                </div>
                <span className="text-sm font-bold text-blue-600">
                  {stats.totalVisits.toLocaleString('pt-BR')}
                </span>
              </div>

              <div className="flex items-center justify-between py-2 px-3 bg-green-50 rounded-lg">
                <div className="flex items-center space-x-2">
                  <div className="w-4 h-4 bg-green-600 rounded-full flex items-center justify-center">
                    <span className="text-xs text-white">👤</span>
                  </div>
                  <span className="text-sm font-medium text-green-800">Visitantes Únicos</span>
                </div>
                <span className="text-sm font-bold text-green-600">
                  {stats.uniqueVisitors.toLocaleString('pt-BR')}
                </span>
              </div>

              <div className="flex items-center justify-between py-2 px-3 bg-orange-50 rounded-lg">
                <div className="flex items-center space-x-2">
                  <ChatBubbleLeftRightIcon className="h-4 w-4 text-orange-600" />
                  <span className="text-sm font-medium text-orange-800">Feedbacks</span>
                </div>
                <span className="text-sm font-bold text-orange-600">
                  {stats.totalFeedback.toLocaleString('pt-BR')}
                </span>
              </div>
            </div>

            <div className="mt-3 pt-3 border-t border-gray-200">
              <p className="text-xs text-gray-500 text-center">
                🕒 Última visita: {new Date(stats.lastVisit).toLocaleDateString('pt-BR')}
              </p>
            </div>

            {/* Link para ver mais detalhes */}
            <div className="mt-3">
              <button
                onClick={() => {
                  setShowAnalytics(true);
                  setIsVisible(false);
                }}
                className="w-full text-xs bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-700 hover:to-amber-700 text-white py-2 px-3 rounded-lg transition-colors font-medium"
              >
                🔍 Ver Analytics Completo
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Painel de Analytics */}
      <AnalyticsPanel 
        isOpen={showAnalytics} 
        onClose={() => setShowAnalytics(false)} 
      />
    </div>
  );
}
