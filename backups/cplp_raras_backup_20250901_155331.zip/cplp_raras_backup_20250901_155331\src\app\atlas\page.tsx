import type { Metadata } from 'next';
import Link from 'next/link';
import AtlasSearch from '@/components/atlas/AtlasSearch';

export const metadata: Metadata = {
  title: 'Atlas CPLP-RARAS | Base de Dados de Doenças Raras',
  description: 'Sistema de busca e informações sobre doenças raras para os países da CPLP. Pesquise por sintomas, categorias e centros de referência.',
  keywords: 'doenças raras, atlas, CPLP, pesquisa, sintomas, genética, diagnóstico',
};

export default function AtlasPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Breadcrumb */}
      <div className="bg-white border-b">
        <div className="mx-auto max-w-7xl px-4 py-4 sm:px-6 lg:px-8">
          <nav className="flex" aria-label="Navegação por migalhas de pão">
            <ol className="inline-flex items-center space-x-1 md:space-x-3" role="list">
              <li role="listitem">
                <Link 
                  href="/" 
                  className="text-blue-600 hover:text-blue-800 focus:outline-none focus:ring-2 focus:ring-blue-500 rounded-sm"
                  aria-label="Voltar à página inicial"
                >
                  Início
                </Link>
              </li>
              <li role="listitem" aria-current="page">
                <div className="flex items-center">
                  <span className="mx-2 text-gray-400" aria-hidden="true">/</span>
                  <span className="text-gray-500">Atlas CPLP-RARAS</span>
                </div>
              </li>
            </ol>
          </nav>
        </div>
      </div>

      {/* Header Section */}
      <div className="bg-gradient-to-br from-blue-600 via-purple-600 to-pink-600 text-white">
        <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              <span role="img" aria-label="Atlas médico" className="mr-4">🗺️</span>
              Atlas CPLP-RARAS
            </h1>
            <div className="w-32 h-1 bg-white mx-auto mb-8 opacity-80"></div>
            <p className="text-xl md:text-2xl mb-8 max-w-4xl mx-auto leading-relaxed opacity-90">
              Base de dados colaborativa de doenças raras para os países da 
              Comunidade dos Países de Língua Portuguesa
            </p>
            
            {/* Stats Cards */}
            <div className="grid md:grid-cols-3 gap-6 mt-12 max-w-4xl mx-auto">
              <div className="bg-white bg-opacity-10 backdrop-blur rounded-xl p-6">
                <div className="text-3xl font-bold text-white mb-2">3+</div>
                <div className="text-sm text-blue-100">Doenças Catalogadas</div>
              </div>
              <div className="bg-white bg-opacity-10 backdrop-blur rounded-xl p-6">
                <div className="text-3xl font-bold text-white mb-2">9</div>
                <div className="text-sm text-blue-100">Países da CPLP</div>
              </div>
              <div className="bg-white bg-opacity-10 backdrop-blur rounded-xl p-6">
                <div className="text-3xl font-bold text-white mb-2">2</div>
                <div className="text-sm text-blue-100">Idiomas Suportados</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Search Component */}
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <AtlasSearch />
      </div>

      {/* Info Sections */}
      <div className="bg-white py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-8">
            {/* Para Pacientes */}
            <div className="text-center p-8 bg-gradient-to-br from-blue-50 to-purple-50 rounded-2xl border border-blue-200">
              <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <span className="text-white text-2xl" role="img" aria-label="Paciente">👤</span>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Para Pacientes e Famílias</h3>
              <p className="text-gray-600 leading-relaxed mb-6">
                Encontre informações confiáveis sobre sintomas, causas e centros de referência 
                próximos para doenças raras em seu país.
              </p>
              <div className="space-y-2 text-sm text-gray-500">
                <div>• Sintomas por sistema corporal</div>
                <div>• Centros de referência por país</div>
                <div>• Informações em português</div>
              </div>
            </div>

            {/* Para Profissionais */}
            <div className="text-center p-8 bg-gradient-to-br from-green-50 to-blue-50 rounded-2xl border border-green-200">
              <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <span className="text-white text-2xl" role="img" aria-label="Médico">👨‍⚕️</span>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Para Profissionais de Saúde</h3>
              <p className="text-gray-600 leading-relaxed mb-6">
                Acesse dados clínicos estruturados, códigos HPO e informações genéticas 
                para auxiliar no diagnóstico diferencial.
              </p>
              <div className="space-y-2 text-sm text-gray-500">
                <div>• Códigos HPO padronizados</div>
                <div>• Frequência de sintomas</div>
                <div>• Dados genéticos atualizados</div>
              </div>
            </div>

            {/* Para Pesquisadores */}
            <div className="text-center p-8 bg-gradient-to-br from-purple-50 to-pink-50 rounded-2xl border border-purple-200">
              <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-pink-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <span className="text-white text-2xl" role="img" aria-label="Pesquisador">🔬</span>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Para Pesquisadores</h3>
              <p className="text-gray-600 leading-relaxed mb-6">
                Base de dados estruturada seguindo princípios FAIR, com API REST 
                para integração com sistemas de pesquisa.
              </p>
              <div className="space-y-2 text-sm text-gray-500">
                <div>• Dados estruturados FAIR</div>
                <div>• API REST disponível</div>
                <div>• Integração com REDCap</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Technical Info */}
      <div className="bg-gradient-to-r from-gray-50 to-blue-50 py-16">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Tecnologia e Padrões
            </h2>
            <p className="text-gray-600 leading-relaxed">
              Desenvolvido seguindo as melhores práticas internacionais para dados médicos
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
              <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                <span className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center mr-3">
                  <span className="text-blue-600 text-sm font-bold">HPO</span>
                </span>
                Human Phenotype Ontology
              </h3>
              <p className="text-gray-600 text-sm leading-relaxed">
                Utilizamos códigos HPO padronizados para garantir interoperabilidade 
                com sistemas internacionais de saúde e pesquisa.
              </p>
            </div>

            <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
              <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                <span className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center mr-3">
                  <span className="text-green-600 text-xs font-bold">FAIR</span>
                </span>
                Princípios FAIR
              </h3>
              <p className="text-gray-600 text-sm leading-relaxed">
                Dados Encontráveis, Acessíveis, Interoperáveis e Reutilizáveis 
                seguindo padrões internacionais de dados científicos.
              </p>
            </div>

            <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
              <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                <span className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center mr-3">
                  <span className="text-purple-600 text-xs font-bold">API</span>
                </span>
                REDCap Integration
              </h3>
              <p className="text-gray-600 text-sm leading-relaxed">
                Preparado para integração futura com bancos de dados REDCap 
                via API REST para coleta e análise de dados em tempo real.
              </p>
            </div>

            <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
              <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                <span className="w-8 h-8 bg-pink-100 rounded-lg flex items-center justify-center mr-3">
                  <span className="text-pink-600 text-xs font-bold">AI</span>
                </span>
                IA & Segunda Opinião
              </h3>
              <p className="text-gray-600 text-sm leading-relaxed">
                Arquitetura preparada para integração com sistemas de IA para 
                segunda opinião formativa e suporte ao diagnóstico.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Call to Action */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 py-16">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white mb-6">
            Contribua para o Atlas CPLP-RARAS
          </h2>
          <p className="text-xl text-blue-100 mb-8 leading-relaxed">
            Ajude-nos a expandir esta base de dados colaborativa com informações 
            sobre doenças raras em sua região.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              href="/contato"
              className="inline-flex items-center px-8 py-3 bg-white text-blue-600 font-semibold rounded-lg hover:bg-blue-50 transition-colors focus:outline-none focus:ring-4 focus:ring-white focus:ring-opacity-50"
            >
              <span role="img" aria-label="Contato" className="mr-2">📧</span>
              Entre em Contato
            </Link>
            <Link
              href="/sobre"
              className="inline-flex items-center px-8 py-3 border-2 border-white text-white font-semibold rounded-lg hover:bg-white hover:text-blue-600 transition-colors focus:outline-none focus:ring-4 focus:ring-white focus:ring-opacity-50"
            >
              <span role="img" aria-label="Informações" className="mr-2">ℹ️</span>
              Saiba Mais
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
