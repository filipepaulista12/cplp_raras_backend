import { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Política de Privacidade | CPLP-Raras',
  description: 'Política de privacidade e tratamento de dados do website CPLP-Raras',
};

export default function PoliticaPrivacidade() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white py-16">
      <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-2xl shadow-xl p-8 md:p-12">
          <div className="text-center mb-12">
            <div className="inline-flex items-center space-x-3 mb-4">
              <div className="w-12 h-12 bg-gradient-to-br from-pink-500 to-purple-600 rounded-full flex items-center justify-center">
                <span className="text-white text-2xl">🔒</span>
              </div>
              <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-pink-600 via-purple-600 to-blue-600 bg-clip-text text-transparent">
                Política de Privacidade
              </h1>
            </div>
            <div className="w-24 h-1 bg-gradient-to-r from-pink-600 via-purple-500 to-blue-600 mx-auto mb-6 rounded-full"></div>
            <p className="text-gray-600 text-lg">
              Última atualização: {new Date().toLocaleDateString('pt-BR')}
            </p>
          </div>

          <div className="prose prose-lg max-w-none">
            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4 flex items-center">
                <span className="w-8 h-8 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center mr-3">
                  <span className="text-white text-sm">1</span>
                </span>
                Introdução
              </h2>
              <p className="text-gray-700 leading-relaxed mb-4">
                A rede <strong>CPLP-Raras</strong> (Comunidade dos Países de Língua Portuguesa - Doenças Raras) 
                está comprometida com a proteção da privacidade e dos dados pessoais dos usuários deste website. 
                Esta Política de Privacidade explica como coletamos, usamos, armazenamos e protegemos suas informações.
              </p>
              <p className="text-gray-700 leading-relaxed">
                Ao utilizar nosso website, você concorda com a coleta e uso de informações de acordo com esta política.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4 flex items-center">
                <span className="w-8 h-8 bg-gradient-to-br from-green-500 to-green-600 rounded-full flex items-center justify-center mr-3">
                  <span className="text-white text-sm">2</span>
                </span>
                Informações que Coletamos
              </h2>
              <div className="bg-gradient-to-r from-green-50 to-blue-50 rounded-xl p-6 mb-4">
                <h3 className="text-lg font-semibold text-gray-900 mb-3">2.1 Dados de Navegação</h3>
                <ul className="list-disc list-inside text-gray-700 space-y-2">
                  <li>Endereço IP</li>
                  <li>Tipo de navegador e versão</li>
                  <li>Sistema operacional</li>
                  <li>Páginas visitadas</li>
                  <li>Tempo de permanência no site</li>
                  <li>Data e hora das visitas</li>
                  <li>URL de referência</li>
                </ul>
              </div>
              <div className="bg-gradient-to-r from-purple-50 to-pink-50 rounded-xl p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-3">2.2 Dados de Contato (quando fornecidos)</h3>
                <ul className="list-disc list-inside text-gray-700 space-y-2">
                  <li>Nome</li>
                  <li>E-mail</li>
                  <li>Instituição de origem</li>
                  <li>Área de pesquisa</li>
                  <li>Mensagens enviadas através de formulários</li>
                </ul>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4 flex items-center">
                <span className="w-8 h-8 bg-gradient-to-br from-purple-500 to-purple-600 rounded-full flex items-center justify-center mr-3">
                  <span className="text-white text-sm">3</span>
                </span>
                Como Utilizamos suas Informações
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-white border border-gray-200 rounded-xl p-6 shadow-sm">
                  <h3 className="text-lg font-semibold text-gray-900 mb-3 flex items-center">
                    <span className="text-2xl mr-2">📊</span>
                    Análise e Melhorias
                  </h3>
                  <ul className="list-disc list-inside text-gray-700 space-y-1 text-sm">
                    <li>Analisar o uso do website</li>
                    <li>Melhorar a experiência do usuário</li>
                    <li>Identificar problemas técnicos</li>
                    <li>Otimizar o conteúdo</li>
                  </ul>
                </div>
                <div className="bg-white border border-gray-200 rounded-xl p-6 shadow-sm">
                  <h3 className="text-lg font-semibold text-gray-900 mb-3 flex items-center">
                    <span className="text-2xl mr-2">🤝</span>
                    Comunicação
                  </h3>
                  <ul className="list-disc list-inside text-gray-700 space-y-1 text-sm">
                    <li>Responder a consultas</li>
                    <li>Facilitar colaborações</li>
                    <li>Compartilhar atualizações relevantes</li>
                    <li>Divulgar eventos científicos</li>
                  </ul>
                </div>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4 flex items-center">
                <span className="w-8 h-8 bg-gradient-to-br from-pink-500 to-pink-600 rounded-full flex items-center justify-center mr-3">
                  <span className="text-white text-sm">4</span>
                </span>
                Ferramentas de Monitoramento
              </h2>
              <div className="bg-gradient-to-r from-pink-50 via-purple-50 to-blue-50 rounded-xl p-6 border border-pink-200">
                <h3 className="text-lg font-semibold text-gray-900 mb-3">4.1 Umami Analytics</h3>
                <p className="text-gray-700 mb-3">
                  Utilizamos o <strong>Umami Analytics</strong>, uma ferramenta de análise web que respeita a privacidade, para:
                </p>
                <ul className="list-disc list-inside text-gray-700 space-y-2 mb-4">
                  <li>Monitorar o tráfego do website de forma anônima</li>
                  <li>Entender quais conteúdos são mais relevantes</li>
                  <li>Melhorar o SEO e a experiência do usuário</li>
                  <li>Não utilizar cookies invasivos</li>
                </ul>
                <div className="bg-white/60 backdrop-blur-sm rounded-lg p-4 border border-pink-200/50">
                  <p className="text-sm text-gray-600">
                    <strong>Nota:</strong> O Umami não coleta dados pessoais identificáveis e é compatível com GDPR/LGPD.
                  </p>
                </div>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4 flex items-center">
                <span className="w-8 h-8 bg-gradient-to-br from-orange-500 to-orange-600 rounded-full flex items-center justify-center mr-3">
                  <span className="text-white text-sm">5</span>
                </span>
                Compartilhamento de Dados
              </h2>
              <div className="bg-orange-50 rounded-xl p-6 border border-orange-200">
                <p className="text-gray-700 mb-4">
                  <strong>Não vendemos, alugamos ou compartilhamos</strong> seus dados pessoais com terceiros para fins comerciais.
                </p>
                <p className="text-gray-700">
                  Dados podem ser compartilhados apenas:
                </p>
                <ul className="list-disc list-inside text-gray-700 space-y-2 mt-3">
                  <li>Com sua autorização expressa</li>
                  <li>Para cumprir obrigações legais</li>
                  <li>Com parceiros acadêmicos para fins de pesquisa científica (dados anonimizados)</li>
                  <li>Entre instituições da rede CPLP-Raras para fins do projeto</li>
                </ul>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4 flex items-center">
                <span className="w-8 h-8 bg-gradient-to-br from-red-500 to-red-600 rounded-full flex items-center justify-center mr-3">
                  <span className="text-white text-sm">6</span>
                </span>
                Seus Direitos
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-red-50 rounded-xl p-4 border border-red-200">
                  <h3 className="font-semibold text-gray-900 mb-2">📧 Acesso e Portabilidade</h3>
                  <p className="text-sm text-gray-700">Solicitar acesso aos seus dados e recebê-los em formato estruturado</p>
                </div>
                <div className="bg-yellow-50 rounded-xl p-4 border border-yellow-200">
                  <h3 className="font-semibold text-gray-900 mb-2">✏️ Retificação</h3>
                  <p className="text-sm text-gray-700">Corrigir dados pessoais incorretos ou desatualizados</p>
                </div>
                <div className="bg-gray-50 rounded-xl p-4 border border-gray-200">
                  <h3 className="font-semibold text-gray-900 mb-2">🗑️ Exclusão</h3>
                  <p className="text-sm text-gray-700">Solicitar a remoção de seus dados pessoais</p>
                </div>
                <div className="bg-blue-50 rounded-xl p-4 border border-blue-200">
                  <h3 className="font-semibold text-gray-900 mb-2">⏸️ Limitação</h3>
                  <p className="text-sm text-gray-700">Restringir o processamento de seus dados</p>
                </div>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4 flex items-center">
                <span className="w-8 h-8 bg-gradient-to-br from-indigo-500 to-indigo-600 rounded-full flex items-center justify-center mr-3">
                  <span className="text-white text-sm">7</span>
                </span>
                Segurança dos Dados
              </h2>
              <div className="bg-indigo-50 rounded-xl p-6 border border-indigo-200">
                <p className="text-gray-700 mb-4">
                  Implementamos medidas técnicas e organizacionais apropriadas para proteger seus dados:
                </p>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="text-center">
                    <div className="w-12 h-12 bg-indigo-500 rounded-full flex items-center justify-center mx-auto mb-2">
                      <span className="text-white text-xl">🔐</span>
                    </div>
                    <h4 className="font-semibold text-gray-900 text-sm">Criptografia</h4>
                    <p className="text-xs text-gray-600">HTTPS/SSL</p>
                  </div>
                  <div className="text-center">
                    <div className="w-12 h-12 bg-indigo-500 rounded-full flex items-center justify-center mx-auto mb-2">
                      <span className="text-white text-xl">🛡️</span>
                    </div>
                    <h4 className="font-semibold text-gray-900 text-sm">Proteção</h4>
                    <p className="text-xs text-gray-600">Acesso restrito</p>
                  </div>
                  <div className="text-center">
                    <div className="w-12 h-12 bg-indigo-500 rounded-full flex items-center justify-center mx-auto mb-2">
                      <span className="text-white text-xl">💾</span>
                    </div>
                    <h4 className="font-semibold text-gray-900 text-sm">Backup</h4>
                    <p className="text-xs text-gray-600">Seguro</p>
                  </div>
                </div>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4 flex items-center">
                <span className="w-8 h-8 bg-gradient-to-br from-teal-500 to-teal-600 rounded-full flex items-center justify-center mr-3">
                  <span className="text-white text-sm">8</span>
                </span>
                Contato
              </h2>
              <div className="bg-gradient-to-r from-teal-50 to-cyan-50 rounded-xl p-6 border border-teal-200">
                <p className="text-gray-700 mb-4">
                  Para exercer seus direitos ou esclarecer dúvidas sobre esta Política de Privacidade, entre em contato:
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex items-center space-x-3">
                    <span className="text-2xl">📧</span>
                    <div>
                      <p className="font-semibold text-gray-900">Email</p>
                      <p className="text-sm text-gray-600">[Informações disponíveis no site]</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <span className="text-2xl">📱</span>
                    <div>
                      <p className="font-semibold text-gray-900">Redes Sociais</p>
                      <p className="text-sm text-gray-600">@rarasporti (Instagram)</p>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4 flex items-center">
                <span className="w-8 h-8 bg-gradient-to-br from-violet-500 to-violet-600 rounded-full flex items-center justify-center mr-3">
                  <span className="text-white text-sm">9</span>
                </span>
                Alterações na Política
              </h2>
              <div className="bg-violet-50 rounded-xl p-6 border border-violet-200">
                <p className="text-gray-700">
                  Esta Política de Privacidade pode ser atualizada periodicamente. Recomendamos que você a revise 
                  regularmente. As alterações entrarão em vigor na data de publicação da versão revisada.
                </p>
              </div>
            </section>

            <div className="bg-gradient-to-r from-pink-100 via-purple-100 to-blue-100 rounded-2xl p-8 text-center border border-pink-200">
              <div className="w-16 h-16 bg-gradient-to-br from-pink-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-white text-2xl">🤝</span>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">
                Compromisso com a Privacidade
              </h3>
              <p className="text-gray-700">
                A rede CPLP-Raras está comprometida com a transparência e proteção dos dados pessoais, 
                seguindo as melhores práticas de privacidade e as legislações aplicáveis.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
