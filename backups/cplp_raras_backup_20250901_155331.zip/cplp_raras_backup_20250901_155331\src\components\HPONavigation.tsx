'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { useHPOStore } from '@/store/hpoStore'

const HPONavigation = () => {
  const pathname = usePathname()
  const { currentTranslator, setCurrentTranslator, translators } = useHPOStore()
  
  const navItems = [
    { href: '/hpo', label: 'Início', icon: '🏠' },
    { href: '/hpo/upload', label: 'Upload HPO', icon: '📂' },
    { href: '/hpo/translate', label: 'Traduzir', icon: '📝' },
    { href: '/hpo/dashboard', label: 'Dashboard', icon: '📊' },
    { href: '/hpo/history', label: 'Histórico', icon: '📚' },
    { href: '/hpo/export', label: 'Exportar', icon: '📦' },
  ]
  
  return (
    <nav className="bg-white shadow-lg border-b border-gray-200">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div className="flex items-center space-x-4">
            <div className="text-2xl font-bold text-blue-600">
              🧬 HPO Translator CPLP
            </div>
          </div>
          
          {/* Menu principal */}
          <div className="hidden md:flex items-center space-x-8">
            {navItems.map(item => (
              <Link
                key={item.href}
                href={item.href}
                className={`flex items-center space-x-2 px-3 py-2 rounded-lg transition-colors ${
                  pathname === item.href
                    ? 'bg-blue-100 text-blue-700'
                    : 'text-gray-600 hover:text-blue-600 hover:bg-gray-100'
                }`}
              >
                <span>{item.icon}</span>
                <span>{item.label}</span>
              </Link>
            ))}
          </div>
          
          {/* Seletor de tradutor */}
          <div className="flex items-center space-x-4">
            <span className="text-sm text-gray-600">Tradutor:</span>
            <select
              value={currentTranslator}
              onChange={(e) => setCurrentTranslator(e.target.value)}
              className="border border-gray-300 rounded-md px-3 py-1 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            >
              {translators.map(translator => (
                <option key={translator.id} value={translator.name}>
                  {translator.name}
                </option>
              ))}
            </select>
          </div>
        </div>
        
        {/* Menu mobile */}
        <div className="md:hidden pb-4">
          <div className="flex flex-wrap gap-2">
            {navItems.map(item => (
              <Link
                key={item.href}
                href={item.href}
                className={`flex items-center space-x-1 px-2 py-1 rounded text-sm transition-colors ${
                  pathname === item.href
                    ? 'bg-blue-100 text-blue-700'
                    : 'text-gray-600 hover:text-blue-600 hover:bg-gray-100'
                }`}
              >
                <span>{item.icon}</span>
                <span>{item.label}</span>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </nav>
  )
}

export default HPONavigation
