/**
 * 🪝 HOOKS ORPHANET SIMPLES - CPLP RARAS
 * 
 * Versão simplificada dos hooks para evitar problemas de hidratação
 * Fornece dados estáticos inicialmente
 */

import { useState, useEffect } from 'react';
import { OrphanetStats } from '../types/orphanet';

export function useOrphanetStatsSimple() {
  const [stats, setStats] = useState<OrphanetStats>({
    total_diseases: 9876,
    active_diseases: 8765,
    total_phenotypes: 23456,
    total_genes: 12345,
    total_mappings: 15678,
    languages_available: ['pt', 'en', 'fr', 'es'],
    last_updated: new Date(),
    orphanet_version: '2024.1'
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // Carregar dados reais após a hidratação
    const loadRealStats = async () => {
      try {
        setLoading(true);
        const response = await fetch('/api/orphanet/stats');
        const data = await response.json();
        
        if (data.success) {
          setStats(data.data);
        }
      } catch (err) {
        console.log('Usando dados estáticos');
      } finally {
        setLoading(false);
      }
    };

    // Aguardar um pouco antes de carregar dados reais
    const timer = setTimeout(loadRealStats, 1000);
    return () => clearTimeout(timer);
  }, []);

  return { stats, loading, error };
}
