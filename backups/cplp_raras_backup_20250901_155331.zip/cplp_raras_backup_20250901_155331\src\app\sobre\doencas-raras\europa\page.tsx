import { Metadata } from 'next';
import { Card, CardContent } from "@/components/ui/card";
import Link from 'next/link';
import TopShare from '@/components/TopShare';

export default function EuropaPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        
        {/* Compartilhamento no topo */}
        <TopShare 
          title="Doenças Raras na Europa"
          description="Políticas e programas europeus para doenças raras, redes de referência e regulamentações"
        />
        <div className="mb-8 text-sm text-gray-600">
          <Link href="/sobre/doencas-raras" className="hover:text-blue-600">Doenças Raras</Link>
          <span className="mx-2">→</span>
          <span>Europa</span>
        </div>
        <div className="text-center mb-12">
          <div className="text-6xl mb-4">🇪🇺</div>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent mb-6">
            Doenças Raras na Europa
          </h1>
          <p className="text-xl text-gray-700">Políticas europeias e iniciativas regionais</p>
        </div>
        <Card className="bg-gradient-to-r from-blue-100 to-indigo-100">
          <CardContent className="p-8 text-center">
            <div className="text-4xl mb-4">🚧</div>
            <h2 className="text-2xl font-bold mb-4 text-gray-800">Página em Construção</h2>
            <p className="text-gray-700 mb-6">Informações sobre EURORDIS, Orphanet e regulamentações europeias em desenvolvimento</p>
            <Link href="/sobre/doencas-raras" className="text-blue-600 hover:text-blue-800 font-medium">
              ← Voltar para Doenças Raras
            </Link>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
