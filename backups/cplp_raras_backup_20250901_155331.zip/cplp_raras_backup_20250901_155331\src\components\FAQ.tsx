'use client';

import { useState } from 'react';
import Image from 'next/image';
import { ChevronDownIcon } from '@heroicons/react/24/outline';
import { getImageSrc } from '@/lib/imageUtils';

const faqs = [
  {
    question: "O que são doenças raras?",
    answer: "Doenças raras são condições que afetam um pequeno número de pessoas em comparação com a população geral. A definição varia entre países, mas geralmente considera-se rara uma doença que afeta menos de 1 em 2.000 pessoas. Existem entre 6.000 e 8.000 doenças raras conhecidas, afetando cerca de 300 milhões de pessoas mundialmente."
  },
  {
    question: "Qual é o objetivo da rede CPLP-Raras?",
    answer: "A rede CPLP-Raras visa fortalecer a resposta dos países da Comunidade dos Países de Língua Portuguesa às doenças raras por meio do mapeamento informacional, uso de tecnologias em saúde digital e promoção de cooperação científica, educacional e clínica entre os países membros."
  },
  {
    question: "Quais países participam da CPLP-Raras?",
    answer: "Participam os oito países membros da CPLP: Angola, Brasil, Cabo Verde, Guiné-Bissau, Guiné Equatorial, Moçambique, Portugal, São Tomé e Príncipe, e Timor-Leste. Cada país contribui com suas experiências e conhecimentos específicos."
  },
  {
    question: "Como os grupos de trabalho funcionam?",
    answer: "Os seis grupos de trabalho (GTs) abordam diferentes aspectos: GT1 - Mapeamento de recursos; GT2 - Plataformas digitais; GT3 - Rede de pesquisa; GT4 - Protocolos e algoritmos; GT5 - Conscientização social; GT6 - Sustentabilidade. Cada GT tem objetivos específicos e trabalha de forma colaborativa."
  },
  {
    question: "Como posso me envolver no projeto?",
    answer: "Profissionais de saúde, pesquisadores e organizações interessadas podem participar através dos grupos de trabalho, colaborações científicas, ou entrando em contato conosco. Valorizamos a participação multidisciplinar e internacional para fortalecer a rede."
  }
];

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const toggleFAQ = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section className="py-16 bg-gradient-to-b from-pink-50 to-white">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
          {/* Left side - Image */}
          <div className="relative">
            <div className="relative rounded-2xl overflow-hidden shadow-2xl">
              <Image
                src={getImageSrc("/images/faq.png")}
                alt="Frequently Asked Questions - Doenças Raras"
                width={600}
                height={400}
                className="object-cover w-full h-full"
                priority
              />
              <div className="absolute inset-0 bg-gradient-to-t from-purple-900/50 to-transparent"></div>
              <div className="absolute bottom-6 left-6 right-6">
                <div className="bg-white/90 backdrop-blur-sm rounded-xl p-4">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-gradient-to-br from-pink-500 to-purple-600 rounded-full flex items-center justify-center">
                      <span className="text-white font-bold text-lg">🦓</span>
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900">CPLP-Raras</h3>
                      <p className="text-sm text-gray-600">Doenças Raras</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right side - FAQ */}
          <div>
            <div className="text-center lg:text-left mb-8">
              <div className="inline-flex items-center space-x-3 mb-4">
                <div className="w-12 h-12 bg-gradient-to-br from-pink-500 to-purple-600 rounded-full flex items-center justify-center">
                  <span className="text-white text-xl">❓</span>
                </div>
                <h2 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-pink-600 via-purple-600 to-blue-600 bg-clip-text text-transparent">
                  Perguntas Frequentes
                </h2>
              </div>
              <p className="text-lg text-gray-600">
                Esclareça suas dúvidas sobre doenças raras e o projeto CPLP-Raras
              </p>
            </div>

            <div className="space-y-4">
              {faqs.map((faq, index) => (
                <div
                  key={index}
                  className="bg-white rounded-2xl shadow-lg border border-pink-100 overflow-hidden transition-all duration-200 hover:shadow-xl"
                >
                  <button
                    className="w-full px-6 py-4 text-left flex items-center justify-between hover:bg-pink-50 transition-colors duration-200"
                    onClick={() => toggleFAQ(index)}
                  >
                    <h3 className="font-semibold text-gray-900 pr-4">
                      {faq.question}
                    </h3>
                    <ChevronDownIcon
                      className={`h-5 w-5 text-pink-600 transition-transform duration-200 flex-shrink-0 ${
                        openIndex === index ? 'rotate-180' : ''
                      }`}
                    />
                  </button>
                  
                  {openIndex === index && (
                    <div className="px-6 pb-4">
                      <div className="border-t border-pink-100 pt-4">
                        <p className="text-gray-600 leading-relaxed">
                          {faq.answer}
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>

            <div className="mt-8 text-center lg:text-left">
              <div className="bg-gradient-to-r from-pink-50 to-purple-50 rounded-2xl p-6 border border-pink-200">
                <h3 className="font-semibold text-gray-900 mb-2">
                  Não encontrou sua resposta?
                </h3>
                <p className="text-gray-600 mb-4">
                  Entre em contato conosco para mais informações sobre doenças raras e nossos projetos.
                </p>
                <a
                  href="/contato"
                  className="inline-flex items-center px-4 py-2 bg-gradient-to-r from-pink-500 to-purple-600 text-white font-medium rounded-full hover:from-pink-600 hover:to-purple-700 transition-all duration-200 transform hover:scale-105"
                >
                  Fale Conosco
                  <svg className="ml-2 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
                  </svg>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
