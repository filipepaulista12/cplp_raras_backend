-- =====================================================================================
-- ESQUEMA SQL COMPLETO PARA O SISTEMA GARD BRASILEIRO
-- =====================================================================================
-- Base de dados para réplica fiel de https://rarediseases.info.nih.gov/diseases
-- Adaptado para países da CPLP com foco em qualidade médica
-- =====================================================================================

-- Extensões necessárias
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm"; -- Para busca fuzzy

-- =====================================================================================
-- 1. TABELAS DE REFERÊNCIA (ENUMS E LOOKUPS)
-- =====================================================================================

-- Categorias de doenças (baseado no GARD)
CREATE TABLE disease_categories (
    id SERIAL PRIMARY KEY,
    code VARCHAR(50) UNIQUE NOT NULL,
    name_pt VARCHAR(200) NOT NULL,
    name_en VARCHAR(200) NOT NULL,
    description TEXT,
    color_hex VARCHAR(7), -- Para UI
    icon VARCHAR(50), -- Para UI
    sort_order INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Países da CPLP
CREATE TABLE cplp_countries (
    id SERIAL PRIMARY KEY,
    code VARCHAR(3) UNIQUE NOT NULL, -- ISO 3166-1
    name VARCHAR(100) NOT NULL,
    flag_emoji VARCHAR(10),
    population BIGINT,
    healthcare_system TEXT,
    rare_disease_policy TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Padrões de herança genética
CREATE TABLE inheritance_patterns (
    id SERIAL PRIMARY KEY,
    code VARCHAR(50) UNIQUE NOT NULL,
    name_pt VARCHAR(100) NOT NULL,
    name_en VARCHAR(100) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Status de informação
CREATE TYPE info_status AS ENUM (
    'draft',
    'under_review',
    'reviewed',
    'published',
    'needs_update',
    'archived'
);

-- Tipos de prevalência
CREATE TYPE prevalence_type AS ENUM (
    'point',
    'birth',
    'lifetime',
    'unknown'
);

-- =====================================================================================
-- 2. TABELA PRINCIPAL DE DOENÇAS
-- =====================================================================================

CREATE TABLE diseases (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    gard_br_id VARCHAR(20) UNIQUE NOT NULL, -- Formato: GARD-BR-XXXX
    gard_original_id VARCHAR(20), -- Referência ao GARD original se aplicável
    
    -- Identificação
    name_pt VARCHAR(500) NOT NULL,
    name_en VARCHAR(500),
    synonyms TEXT[], -- Array de sinônimos
    
    -- Classificação
    category_id INTEGER REFERENCES disease_categories(id),
    subcategory VARCHAR(200),
    
    -- Códigos de referência
    orpha_code VARCHAR(20),
    icd10_codes VARCHAR(50)[],
    icd11_codes VARCHAR(50)[],
    omim_codes VARCHAR(20)[],
    
    -- Informações epidemiológicas
    prevalence_value VARCHAR(200), -- "1 em 10.000", "< 1/1.000.000", etc.
    prevalence_type prevalence_type DEFAULT 'point',
    age_of_onset VARCHAR(200),
    
    -- Genética
    inheritance_pattern_id INTEGER REFERENCES inheritance_patterns(id),
    genes_involved VARCHAR(50)[], -- Array de símbolos de genes
    chromosomal_location VARCHAR(100),
    
    -- Metadados
    info_status info_status DEFAULT 'draft',
    quality_score INTEGER DEFAULT 0 CHECK (quality_score >= 0 AND quality_score <= 100),
    last_medical_review DATE,
    next_review_due DATE,
    
    -- Auditoria
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by UUID, -- Referência ao usuário
    updated_by UUID,
    
    -- Índices de busca
    search_vector tsvector,
    
    CONSTRAINT valid_gard_br_id CHECK (gard_br_id ~ '^GARD-BR-[0-9]{4}$')
);

-- =====================================================================================
-- 3. CONTEÚDO DETALHADO DAS DOENÇAS
-- =====================================================================================

CREATE TABLE disease_content (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    disease_id UUID REFERENCES diseases(id) ON DELETE CASCADE,
    
    -- Conteúdo principal
    summary TEXT, -- Resumo/Definição
    detailed_description TEXT,
    
    -- Seções estruturadas
    symptoms TEXT[], -- Lista de sintomas
    signs TEXT[], -- Lista de sinais clínicos
    causes TEXT, -- Causas e etiologia
    pathophysiology TEXT, -- Fisiopatologia
    
    -- Diagnóstico
    diagnostic_criteria TEXT[],
    diagnostic_tests TEXT[],
    differential_diagnosis TEXT[],
    
    -- Tratamento
    treatment_options TEXT[],
    management_guidelines TEXT,
    medications TEXT[],
    therapies TEXT[],
    
    -- Prognóstico
    prognosis TEXT,
    life_expectancy VARCHAR(200),
    quality_of_life_impact TEXT,
    
    -- Recursos
    patient_resources TEXT[],
    family_resources TEXT[],
    professional_resources TEXT[],
    
    -- Metadados de conteúdo
    content_version INTEGER DEFAULT 1,
    language_code VARCHAR(5) DEFAULT 'pt-BR',
    medical_reviewer VARCHAR(200),
    reviewed_at TIMESTAMP,
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =====================================================================================
-- 4. RELACIONAMENTOS E ASSOCIAÇÕES
-- =====================================================================================

-- Ensaios clínicos relacionados
CREATE TABLE disease_clinical_trials (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    disease_id UUID REFERENCES diseases(id) ON DELETE CASCADE,
    
    trial_id VARCHAR(50), -- NCT number ou similar
    title VARCHAR(500),
    description TEXT,
    status VARCHAR(50),
    phase VARCHAR(20),
    location VARCHAR(200),
    country_code VARCHAR(3),
    contact_info TEXT,
    
    start_date DATE,
    estimated_completion DATE,
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    source VARCHAR(100), -- clinicaltrials.gov, EudraCT, etc.
    source_url TEXT
);

-- Organizações de apoio
CREATE TABLE disease_support_organizations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    disease_id UUID REFERENCES diseases(id) ON DELETE CASCADE,
    
    name VARCHAR(300) NOT NULL,
    description TEXT,
    organization_type VARCHAR(100), -- patient_association, research_foundation, etc.
    
    contact_info JSONB, -- Estrutura flexível para contatos
    website TEXT,
    social_media JSONB,
    
    country_id INTEGER REFERENCES cplp_countries(id),
    languages VARCHAR(10)[], -- Idiomas suportados
    
    services_offered TEXT[],
    target_audience VARCHAR(100), -- patients, families, professionals, etc.
    
    verified BOOLEAN DEFAULT FALSE,
    last_verified DATE,
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Publicações científicas
CREATE TABLE disease_publications (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    disease_id UUID REFERENCES diseases(id) ON DELETE CASCADE,
    
    pubmed_id VARCHAR(20),
    doi VARCHAR(200),
    title VARCHAR(1000) NOT NULL,
    authors TEXT[],
    journal VARCHAR(300),
    publication_date DATE,
    abstract TEXT,
    
    study_type VARCHAR(100), -- case_report, clinical_trial, review, etc.
    evidence_level INTEGER, -- 1-5 baseado em medicina baseada em evidências
    language_code VARCHAR(5),
    
    is_open_access BOOLEAN DEFAULT FALSE,
    full_text_url TEXT,
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Especialistas e centros de referência
CREATE TABLE disease_specialists (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    disease_id UUID REFERENCES diseases(id) ON DELETE CASCADE,
    
    specialist_type VARCHAR(100), -- doctor, center, clinic, hospital
    name VARCHAR(300) NOT NULL,
    specialty VARCHAR(200),
    
    contact_info JSONB,
    address JSONB,
    country_id INTEGER REFERENCES cplp_countries(id),
    
    accepts_new_patients BOOLEAN DEFAULT TRUE,
    languages VARCHAR(10)[],
    telemedicine_available BOOLEAN DEFAULT FALSE,
    
    verification_status VARCHAR(50) DEFAULT 'pending',
    verified_by VARCHAR(200),
    verified_at TIMESTAMP,
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =====================================================================================
-- 5. DADOS REGIONAIS CPLP
-- =====================================================================================

-- Epidemiologia regional
CREATE TABLE disease_epidemiology_cplp (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    disease_id UUID REFERENCES diseases(id) ON DELETE CASCADE,
    country_id INTEGER REFERENCES cplp_countries(id),
    
    estimated_cases INTEGER,
    prevalence_per_100k DECIMAL(10,4),
    incidence_per_100k_year DECIMAL(10,4),
    
    data_source VARCHAR(200),
    data_quality VARCHAR(50), -- high, medium, low, estimated
    collection_date DATE,
    
    notes TEXT,
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Disponibilidade de medicamentos por país
CREATE TABLE disease_medications_availability (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    disease_id UUID REFERENCES diseases(id) ON DELETE CASCADE,
    country_id INTEGER REFERENCES cplp_countries(id),
    
    medication_name VARCHAR(300) NOT NULL,
    generic_name VARCHAR(300),
    
    availability_status VARCHAR(50), -- available, restricted, unavailable, unknown
    regulatory_status VARCHAR(100),
    reimbursement_status VARCHAR(100),
    
    cost_info TEXT,
    access_conditions TEXT[],
    prescription_requirements TEXT[],
    
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    data_source VARCHAR(200)
);

-- =====================================================================================
-- 6. SISTEMA DE VERSIONING E AUDITORIA
-- =====================================================================================

-- Histórico de mudanças
CREATE TABLE disease_audit_log (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    disease_id UUID REFERENCES diseases(id) ON DELETE CASCADE,
    
    action VARCHAR(50) NOT NULL, -- create, update, delete, publish, review
    table_affected VARCHAR(100),
    old_values JSONB,
    new_values JSONB,
    
    changed_by UUID, -- Referência ao usuário
    changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    change_reason TEXT,
    
    ip_address INET,
    user_agent TEXT
);

-- Fontes e referências
CREATE TABLE disease_references (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    disease_id UUID REFERENCES diseases(id) ON DELETE CASCADE,
    
    reference_type VARCHAR(50), -- guideline, study, database, expert_opinion
    title VARCHAR(500) NOT NULL,
    authors TEXT[],
    source VARCHAR(300),
    url TEXT,
    publication_date DATE,
    access_date DATE,
    
    reliability_score INTEGER CHECK (reliability_score >= 1 AND reliability_score <= 5),
    notes TEXT,
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =====================================================================================
-- 7. ÍNDICES PARA PERFORMANCE
-- =====================================================================================

-- Índices principais
CREATE INDEX idx_diseases_gard_br_id ON diseases(gard_br_id);
CREATE INDEX idx_diseases_category ON diseases(category_id);
CREATE INDEX idx_diseases_status ON diseases(info_status);
CREATE INDEX idx_diseases_name_pt ON diseases USING gin(name_pt gin_trgm_ops);
CREATE INDEX idx_diseases_synonyms ON diseases USING gin(synonyms);

-- Índices de busca textual
CREATE INDEX idx_diseases_search ON diseases USING gin(search_vector);
CREATE INDEX idx_disease_content_symptoms ON disease_content USING gin(symptoms);

-- Índices geográficos
CREATE INDEX idx_specialists_country ON disease_specialists(country_id);
CREATE INDEX idx_epidemiology_country ON disease_epidemiology_cplp(country_id);

-- =====================================================================================
-- 8. TRIGGERS PARA AUTOMAÇÃO
-- =====================================================================================

-- Trigger para atualizar search_vector
CREATE OR REPLACE FUNCTION update_disease_search_vector() RETURNS TRIGGER AS $$
BEGIN
    NEW.search_vector := 
        setweight(to_tsvector('portuguese', COALESCE(NEW.name_pt,'')), 'A') ||
        setweight(to_tsvector('english', COALESCE(NEW.name_en,'')), 'B') ||
        setweight(to_tsvector('portuguese', array_to_string(NEW.synonyms, ' ')), 'B');
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_update_disease_search 
    BEFORE INSERT OR UPDATE ON diseases 
    FOR EACH ROW EXECUTE FUNCTION update_disease_search_vector();

-- Trigger para updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column() RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_diseases_updated_at 
    BEFORE UPDATE ON diseases 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER trigger_disease_content_updated_at 
    BEFORE UPDATE ON disease_content 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- =====================================================================================
-- 9. DADOS INICIAIS (SEED DATA)
-- =====================================================================================

-- Inserir categorias de doenças
INSERT INTO disease_categories (code, name_pt, name_en, description, color_hex, sort_order) VALUES
('birth_defects', 'Defeitos Congênitos', 'Birth Defects', 'Malformações presentes ao nascimento', '#FF6B6B', 1),
('blood_diseases', 'Doenças do Sangue', 'Blood Diseases', 'Distúrbios hematológicos', '#4ECDC4', 2),
('cancer', 'Cancro/Câncer', 'Cancer', 'Neoplasias malignas raras', '#45B7D1', 3),
('endocrine', 'Doenças Endócrinas', 'Endocrine Diseases', 'Distúrbios hormonais', '#96CEB4', 4),
('gastrointestinal', 'Doenças Gastrointestinais', 'Gastrointestinal Diseases', 'Distúrbios digestivos', '#FFEAA7', 5),
('genetic', 'Doenças Genéticas', 'Genetic Diseases', 'Distúrbios genéticos hereditários', '#DDA0DD', 6),
('infectious', 'Doenças Infecciosas', 'Infectious Diseases', 'Infecções raras', '#FFB347', 7),
('kidney', 'Doenças Renais', 'Kidney Diseases', 'Nefropatias raras', '#87CEEB', 8),
('neurological', 'Doenças Neurológicas', 'Neurological Diseases', 'Distúrbios do sistema nervoso', '#F0E68C', 9),
('respiratory', 'Doenças Respiratórias', 'Respiratory Diseases', 'Pneumopatias raras', '#98FB98', 10),
('skin', 'Doenças da Pele', 'Skin Diseases', 'Dermatoses raras', '#F5DEB3', 11),
('urinary_reproductive', 'Doenças Urinárias e Reprodutivas', 'Urinary and Reproductive Diseases', 'Distúrbios genitourinários', '#FFE4E1', 12);

-- Inserir países da CPLP
INSERT INTO cplp_countries (code, name, flag_emoji, population) VALUES
('BRA', 'Brasil', '🇧🇷', 215000000),
('PRT', 'Portugal', '🇵🇹', 10300000),
('AGO', 'Angola', '🇦🇴', 32900000),
('MOZ', 'Moçambique', '🇲🇿', 31300000),
('CPV', 'Cabo Verde', '🇨🇻', 560000),
('GNB', 'Guiné-Bissau', '🇬🇼', 2000000),
('STP', 'São Tomé e Príncipe', '🇸🇹', 220000),
('TLS', 'Timor-Leste', '🇹🇱', 1300000),
('GNQ', 'Guiné Equatorial', '🇬🇶', 1400000);

-- Inserir padrões de herança
INSERT INTO inheritance_patterns (code, name_pt, name_en, description) VALUES
('autosomal_dominant', 'Autossómica Dominante', 'Autosomal Dominant', 'Apenas uma cópia alterada do gene é suficiente'),
('autosomal_recessive', 'Autossómica Recessiva', 'Autosomal Recessive', 'Duas cópias alteradas do gene são necessárias'),
('x_linked', 'Ligada ao X', 'X-linked', 'Gene localizado no cromossoma X'),
('y_linked', 'Ligada ao Y', 'Y-linked', 'Gene localizado no cromossoma Y'),
('mitochondrial', 'Mitocondrial', 'Mitochondrial', 'Herança através do DNA mitocondrial'),
('complex', 'Complexa', 'Complex', 'Padrão de herança multifatorial'),
('sporadic', 'Esporádica', 'Sporadic', 'Casos isolados sem padrão familiar'),
('unknown', 'Desconhecida', 'Unknown', 'Padrão de herança não determinado');

-- =====================================================================================
-- 10. FUNCTIONS ÚTEIS
-- =====================================================================================

-- Função para gerar próximo GARD-BR ID
CREATE OR REPLACE FUNCTION generate_next_gard_br_id() RETURNS VARCHAR(20) AS $$
DECLARE
    next_num INTEGER;
    next_id VARCHAR(20);
BEGIN
    SELECT COALESCE(MAX(CAST(SUBSTRING(gard_br_id FROM 9) AS INTEGER)), 0) + 1 
    INTO next_num 
    FROM diseases;
    
    next_id := 'GARD-BR-' || LPAD(next_num::TEXT, 4, '0');
    RETURN next_id;
END;
$$ LANGUAGE plpgsql;

-- Função de busca avançada
CREATE OR REPLACE FUNCTION search_diseases(
    search_term TEXT DEFAULT NULL,
    category_filter INTEGER DEFAULT NULL,
    country_filter INTEGER DEFAULT NULL,
    inheritance_filter INTEGER DEFAULT NULL,
    status_filter info_status DEFAULT NULL,
    limit_count INTEGER DEFAULT 50,
    offset_count INTEGER DEFAULT 0
) RETURNS TABLE (
    disease_id UUID,
    gard_br_id VARCHAR(20),
    name_pt VARCHAR(500),
    category_name VARCHAR(200),
    prevalence_value VARCHAR(200),
    rank REAL
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        d.id,
        d.gard_br_id,
        d.name_pt,
        dc.name_pt as category_name,
        d.prevalence_value,
        CASE 
            WHEN search_term IS NOT NULL THEN ts_rank(d.search_vector, plainto_tsquery('portuguese', search_term))
            ELSE 0
        END as rank
    FROM diseases d
    LEFT JOIN disease_categories dc ON d.category_id = dc.id
    WHERE 
        (search_term IS NULL OR d.search_vector @@ plainto_tsquery('portuguese', search_term))
        AND (category_filter IS NULL OR d.category_id = category_filter)
        AND (inheritance_filter IS NULL OR d.inheritance_pattern_id = inheritance_filter)
        AND (status_filter IS NULL OR d.info_status = status_filter)
        AND (country_filter IS NULL OR EXISTS (
            SELECT 1 FROM disease_epidemiology_cplp dec 
            WHERE dec.disease_id = d.id AND dec.country_id = country_filter
        ))
    ORDER BY 
        CASE WHEN search_term IS NOT NULL THEN rank END DESC,
        d.name_pt ASC
    LIMIT limit_count OFFSET offset_count;
END;
$$ LANGUAGE plpgsql;

-- =====================================================================================
-- COMENTÁRIOS FINAIS
-- =====================================================================================

-- Este schema foi projetado para:
-- 1. Suportar toda a funcionalidade do GARD original
-- 2. Adicionar recursos específicos para países da CPLP  
-- 3. Garantir qualidade e auditoria de dados médicos
-- 4. Permitir busca avançada e multilíngue
-- 5. Facilitar integração com outras APIs médicas
-- 6. Suportar workflow editorial e controle de qualidade

COMMENT ON DATABASE IS 'GARD Brasileiro - Sistema de Informação sobre Doenças Raras para países da CPLP';
