const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();

async function checkSchema() {
    console.log("🔍 VERIFICANDO ESTRUTURA DAS TABELAS");
    console.log("====================================");
    
    try {
        // Verificar uma associação HPO
        const sampleHPO = await prisma.hPOPhenotypeAssociation.findFirst({
            select: {
                id: true,
                orphaDiseaseId: true,
                hpoTermId: true,
                frequencyTerm: true,
                evidence: true
            }
        });
        
        console.log("📋 Estrutura HPOPhenotypeAssociation:");
        console.log(JSON.stringify(sampleHPO, null, 2));
        
        // Contar registros
        const hpoCount = await prisma.hPOPhenotypeAssociation.count();
        console.log(`\n📊 Total HPO associations: ${hpoCount.toLocaleString()}`);
        
        // Verificar doenças com mais fenótipos usando o campo correto
        const richestDiseases = await prisma.hPOPhenotypeAssociation.groupBy({
            by: ['orphaDiseaseId'],
            _count: {
                orphaDiseaseId: true
            },
            orderBy: {
                _count: {
                    orphaDiseaseId: 'desc'
                }
            },
            take: 3
        });
        
        console.log("\n💎 Doenças com mais fenótipos:");
        for (const disease of richestDiseases) {
            console.log(`   ${disease.orphaDiseaseId}: ${disease._count.orphaDiseaseId} fenótipos`);
        }
        
    } catch (error) {
        console.log(`❌ Erro: ${error.message}`);
    } finally {
        await prisma.$disconnect();
    }
}

checkSchema();
