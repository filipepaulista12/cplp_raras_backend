'use client';

import { useState } from 'react';
import { sendContactForm, openEmailClient, getSpecificContact, validateFormData, type ContactFormData } from '@/lib/emailService';

export default function Contact() {
  const [formData, setFormData] = useState<ContactFormData>({
    name: '',
    email: '',
    institution: '',
    subject: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [statusMessage, setStatusMessage] = useState<string>('');

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validação
    const errors = validateFormData(formData);
    if (errors.length > 0) {
      alert('Por favor, corrija os seguintes erros:\n' + errors.join('\n'));
      return;
    }

    setIsSubmitting(true);
    setSubmitStatus('idle');

    try {
      const result = await sendContactForm(formData);
      
      if (result.success) {
        setSubmitStatus('success');
        setStatusMessage(result.message);
        
        // Reset form apenas se o email foi realmente enviado
        if (result.emailSent) {
          setFormData({
            name: '',
            email: '',
            institution: '',
            subject: '',
            message: ''
          });
        }
      } else {
        setSubmitStatus('error');
        setStatusMessage('Erro ao enviar mensagem');
      }
    } catch (error) {
      setSubmitStatus('error');
      setStatusMessage('Erro inesperado ao enviar formulário');
      console.error('Erro ao enviar formulário:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleQuickContact = (type: string) => {
    const contact = getSpecificContact(type);
    openEmailClient(contact);
  };

  return (
    <section className="bg-gradient-to-br from-gray-900 via-purple-900 to-pink-900 text-white py-16">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <div className="inline-flex items-center space-x-3 mb-4">
            <div className="w-12 h-12 bg-gradient-to-br from-pink-500 to-purple-600 rounded-full flex items-center justify-center">
              <span className="text-white text-2xl">💬</span>
            </div>
            <h2 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-pink-300 to-purple-300 bg-clip-text text-transparent">
              Entre em Contato
            </h2>
          </div>
          <div className="w-24 h-1 bg-gradient-to-r from-pink-400 via-purple-400 to-blue-400 mx-auto mb-8 rounded-full"></div>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Conecte-se conosco e faça parte da rede CPLP-Raras
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
          <div>
            <h3 className="text-2xl font-bold mb-6 text-pink-200">Informações de Contato</h3>
            <div className="space-y-6">
              <div className="flex items-center space-x-4 p-4 bg-white/10 rounded-xl backdrop-blur-sm border border-pink-200/20">
                <div className="w-12 h-12 bg-gradient-to-br from-pink-500 to-purple-600 rounded-lg flex items-center justify-center">
                  <span className="text-white text-xl">📧</span>
                </div>
                <div className="flex-1">
                  <p className="text-gray-300 text-sm">Email Principal</p>
                  <button
                    onClick={() => handleQuickContact('colaboracao')}
                    className="text-lg font-semibold text-pink-200 hover:text-pink-100 transition-colors underline"
                  >
                    cplp@raras.org.br
                  </button>
                </div>
              </div>
              
              <div className="flex items-center space-x-4 p-4 bg-white/10 rounded-xl backdrop-blur-sm border border-pink-200/20">
                <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-green-600 rounded-lg flex items-center justify-center">
                  <span className="text-white text-xl">🌐</span>
                </div>
                <div>
                  <p className="text-gray-300 text-sm">Website</p>
                  <p className="text-lg font-semibold text-blue-200">www.cplp-raras.org</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-4 p-4 bg-white/10 rounded-xl backdrop-blur-sm border border-pink-200/20">
                <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-600 rounded-lg flex items-center justify-center">
                  <span className="text-white text-xl">🦓</span>
                </div>
                <div>
                  <p className="text-gray-300 text-sm">Foco</p>
                  <p className="text-lg font-semibold text-purple-200">Doenças Raras - CPLP</p>
                </div>
              </div>
              
              {/* Botões de Contato Rápido */}
              <div className="mt-8">
                <h4 className="text-lg font-semibold mb-4 text-pink-200">Contato Rápido</h4>
                <div className="grid grid-cols-1 gap-3">
                  <button
                    onClick={() => handleQuickContact('colaboracao')}
                    className="flex items-center space-x-3 p-3 bg-gradient-to-r from-blue-600 to-blue-700 rounded-lg hover:from-blue-700 hover:to-blue-800 transition-all duration-200"
                  >
                    <span className="text-xl">🤝</span>
                    <span className="font-medium">Quero Colaborar</span>
                  </button>
                  
                  <button
                    onClick={() => handleQuickContact('pesquisa')}
                    className="flex items-center space-x-3 p-3 bg-gradient-to-r from-purple-600 to-purple-700 rounded-lg hover:from-purple-700 hover:to-purple-800 transition-all duration-200"
                  >
                    <span className="text-xl">🔬</span>
                    <span className="font-medium">Pesquisa Científica</span>
                  </button>
                  
                  <button
                    onClick={() => handleQuickContact('suporte')}
                    className="flex items-center space-x-3 p-3 bg-gradient-to-r from-green-600 to-green-700 rounded-lg hover:from-green-700 hover:to-green-800 transition-all duration-200"
                  >
                    <span className="text-xl">💡</span>
                    <span className="font-medium">Suporte Técnico</span>
                  </button>
                </div>
              </div>

              {/* Social Media Section */}
              <div className="mt-8">
                <h4 className="text-lg font-semibold mb-4 text-pink-200">Siga-nos nas Redes Sociais</h4>
                <div className="flex space-x-4">
                  <a
                    href="https://instagram.com/rarasporti"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="group flex items-center space-x-3 p-4 bg-gradient-to-br from-pink-500 to-purple-600 rounded-xl hover:from-pink-600 hover:to-purple-700 transition-all duration-200 transform hover:scale-105 shadow-lg hover:shadow-xl"
                  >
                    <svg className="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M12.017 0C5.396 0 .029 5.367.029 11.987c0 6.621 5.367 11.988 11.988 11.988s11.987-5.367 11.987-11.988C24.004 5.367 18.637.001 12.017.001zM8.449 16.988c-1.297 0-2.448-.611-3.197-1.559-.326-.414-.518-.937-.518-1.507 0-1.347 1.094-2.441 2.441-2.441s2.441 1.094 2.441 2.441c0 .57-.192 1.093-.518 1.507-.749.948-1.9 1.559-3.197 1.559zm7.138 0c-1.297 0-2.448-.611-3.197-1.559-.326-.414-.518-.937-.518-1.507 0-1.347 1.094-2.441 2.441-2.441s2.441 1.094 2.441 2.441c0 .57-.192 1.093-.518 1.507-.749.948-1.9 1.559-3.197 1.559z"/>
                    </svg>
                    <div className="text-left">
                      <p className="text-white font-semibold text-sm">Instagram</p>
                      <p className="text-pink-100 text-xs">@rarasporti</p>
                    </div>
                  </a>
                  
                  <a
                    href="https://www.facebook.com/profile.php?id=61578726425301"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="group flex items-center space-x-3 p-4 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl hover:from-blue-600 hover:to-blue-700 transition-all duration-200 transform hover:scale-105 shadow-lg hover:shadow-xl"
                  >
                    <svg className="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                    </svg>
                    <div className="text-left">
                      <p className="text-white font-semibold text-sm">Facebook</p>
                      <p className="text-blue-100 text-xs">CPLP-Raras</p>
                    </div>
                  </a>
                </div>
              </div>
            </div>
          </div>
          
          <div className="bg-gray-800 rounded-xl p-8">
            <h3 className="text-xl font-bold mb-6">Quer colaborar conosco? Preencha o formulário abaixo</h3>
            
            {/* Status Messages */}
            {submitStatus === 'success' && (
              <div className="mb-6 p-4 bg-green-600 rounded-lg">
                <p className="text-white font-medium">✅ {statusMessage}</p>
              </div>
            )}
            
            {submitStatus === 'error' && (
              <div className="mb-6 p-4 bg-red-600 rounded-lg">
                <p className="text-white font-medium">❌ {statusMessage || 'Erro ao enviar mensagem. Tente novamente ou use o email direto.'}</p>
              </div>
            )}
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-300 mb-2">
                  Nome *
                </label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  required
                  value={formData.name}
                  onChange={handleInputChange}
                  className="w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Seu nome completo"
                />
              </div>
              
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-300 mb-2">
                  Email *
                </label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  required
                  value={formData.email}
                  onChange={handleInputChange}
                  className="w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="seu@email.com"
                />
              </div>
              
              <div>
                <label htmlFor="institution" className="block text-sm font-medium text-gray-300 mb-2">
                  Instituição
                </label>
                <input
                  type="text"
                  id="institution"
                  name="institution"
                  value={formData.institution}
                  onChange={handleInputChange}
                  className="w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Sua instituição"
                />
              </div>
              
              <div>
                <label htmlFor="subject" className="block text-sm font-medium text-gray-300 mb-2">
                  Assunto *
                </label>
                <input
                  type="text"
                  id="subject"
                  name="subject"
                  required
                  value={formData.subject}
                  onChange={handleInputChange}
                  className="w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Assunto da sua mensagem"
                />
              </div>
              
              <div>
                <label htmlFor="message" className="block text-sm font-medium text-gray-300 mb-2">
                  Mensagem *
                </label>
                <textarea
                  id="message"
                  name="message"
                  required
                  rows={4}
                  value={formData.message}
                  onChange={handleInputChange}
                  className="w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Sua mensagem ou dúvida"
                ></textarea>
              </div>
              
              <button
                type="submit"
                disabled={isSubmitting}
                className={`w-full py-3 rounded-lg font-semibold transition-all duration-200 ${
                  isSubmitting 
                    ? 'bg-gray-600 cursor-not-allowed text-gray-300' 
                    : 'bg-gradient-to-r from-blue-600 to-green-600 text-white hover:opacity-90 hover:scale-105'
                }`}
              >
                {isSubmitting ? '⏳ Enviando...' : '📧 Enviar Mensagem'}
              </button>
              
              <p className="text-xs text-gray-400 mt-3 text-center">
                * Campos obrigatórios. Sua mensagem será enviada para nossa equipe.
              </p>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}
