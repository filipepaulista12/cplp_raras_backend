#!/usr/bin/env node

/**
 * Script de Teste Simples - GARD-BR SQLite
 */

const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();

async function main() {
  console.log('🧬 Testando base de dados GARD-BR...\n');

  try {
    // Testar categorias
    console.log('1. Testando categorias...');
    const category = await prisma.diseaseCategory.create({
      data: {
        code: 'TEST',
        namePt: 'Categoria Teste',
        nameEn: 'Test Category',
        description: 'Categoria para teste',
        sortOrder: 1
      }
    });
    console.log(`   ✅ Categoria criada: ${category.namePt}`);

    // Testar países
    console.log('2. Testando países...');
    const country = await prisma.cPLPCountry.create({
      data: {
        code: 'BR',
        name: 'Brasil',
        flagEmoji: '🇧🇷',
        population: 215000000
      }
    });
    console.log(`   ✅ País criado: ${country.name}`);

    // Testar doença simples
    console.log('3. Testando doenças...');
    const disease = await prisma.disease.create({
      data: {
        gardBrId: 'GARD-BR-TEST-001',
        namePt: 'Doença Teste',
        nameEn: 'Test Disease',
        categoryId: category.id,
        infoStatus: 'draft'
      }
    });
    console.log(`   ✅ Doença criada: ${disease.namePt}`);

    // Estatísticas
    console.log('\n📊 Estatísticas:');
    const stats = {
      categories: await prisma.diseaseCategory.count(),
      countries: await prisma.cPLPCountry.count(),
      diseases: await prisma.disease.count()
    };

    Object.entries(stats).forEach(([key, value]) => {
      console.log(`   ${key}: ${value}`);
    });

    console.log('\n✅ Teste da base de dados bem-sucedido!');
    console.log('🚀 Sistema GARD-BR funcionando com SQLite');
    
  } catch (error) {
    console.error('❌ Erro:', error.message);
  } finally {
    await prisma.$disconnect();
  }
}

main();
