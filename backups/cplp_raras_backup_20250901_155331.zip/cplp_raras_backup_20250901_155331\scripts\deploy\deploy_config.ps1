# Configurações do Servidor SFTP - MANTENHA ESTE ARQUIVO PRIVADO!
# Este arquivo contém credenciais sensíveis e NÃO deve ser commitado

# Configurações do servidor
$ServerIP = "200.144.254.4"
$ServerPort = "22"
$Username = "ubuntu"
$Password = "vFpyJS4FA"
$RemotePath = "/var/www/html/filipe"
$FinalURL = "https://ciis.fmrp.usp.br/filipe/"

# ATENÇÃO: Este arquivo está no .gitignore
# Não compartilhe este arquivo publicamente!
