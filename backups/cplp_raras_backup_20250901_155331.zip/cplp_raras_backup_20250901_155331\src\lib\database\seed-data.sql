-- =====================================================================================
-- DADOS DE EXEMPLO (SEED) PARA O SISTEMA GARD BRASILEIRO
-- =====================================================================================
-- Dataset inicial com doenças raras prevalentes na CPLP
-- Dados estruturados para popular o sistema e testes
-- =====================================================================================

-- =====================================================================================
-- 1. DADOS DE EXEMPLO DE DOENÇAS
-- =====================================================================================

-- Síndrome de Marfan
INSERT INTO diseases (
    gard_br_id, name_pt, name_en, synonyms, 
    category_id, orpha_code, icd10_codes, 
    prevalence_value, prevalence_type, inheritance_pattern_id, 
    genes_involved, info_status, quality_score
) VALUES (
    'GARD-BR-0001', 
    'Síndrome de Marfan', 
    'Marfan syndrome',
    ARRAY['Síndrome de Marfan', 'Marfan syndrome', 'Aracnodactilia', 'Doença de Marfan'],
    (SELECT id FROM disease_categories WHERE code = 'genetic'),
    'ORPHA:558',
    ARRAY['Q87.4'],
    '1 em 5.000 a 10.000',
    'point',
    (SELECT id FROM inheritance_patterns WHERE code = 'autosomal_dominant'),
    ARRAY['FBN1'],
    'published',
    95
);

-- Fibrose Cística
INSERT INTO diseases (
    gard_br_id, name_pt, name_en, synonyms, 
    category_id, orpha_code, icd10_codes, 
    prevalence_value, inheritance_pattern_id, 
    genes_involved, info_status, quality_score
) VALUES (
    'GARD-BR-0002',
    'Fibrose Cística',
    'Cystic fibrosis',
    ARRAY['Fibrose Cística', 'Mucoviscidose', 'Cystic fibrosis', 'CF'],
    (SELECT id FROM disease_categories WHERE code = 'genetic'),
    'ORPHA:586',
    ARRAY['E84.0', 'E84.1', 'E84.8', 'E84.9'],
    '1 em 2.500 a 3.000 nascimentos',
    (SELECT id FROM inheritance_patterns WHERE code = 'autosomal_recessive'),
    ARRAY['CFTR'],
    'published',
    98
);

-- Anemia Falciforme
INSERT INTO diseases (
    gard_br_id, name_pt, name_en, synonyms, 
    category_id, orpha_code, icd10_codes, 
    prevalence_value, inheritance_pattern_id, 
    genes_involved, info_status, quality_score
) VALUES (
    'GARD-BR-0003',
    'Anemia Falciforme',
    'Sickle cell disease',
    ARRAY['Anemia Falciforme', 'Doença Falciforme', 'Sickle cell disease', 'SCD'],
    (SELECT id FROM disease_categories WHERE code = 'blood_diseases'),
    'ORPHA:232',
    ARRAY['D57.0', 'D57.1', 'D57.2', 'D57.3'],
    'Varia por região - alta prevalência na África e Brasil',
    (SELECT id FROM inheritance_patterns WHERE code = 'autosomal_recessive'),
    ARRAY['HBB'],
    'published',
    92
);

-- Doença de Huntington
INSERT INTO diseases (
    gard_br_id, name_pt, name_en, synonyms, 
    category_id, orpha_code, icd10_codes, 
    prevalence_value, inheritance_pattern_id, 
    genes_involved, info_status, quality_score
) VALUES (
    'GARD-BR-0004',
    'Doença de Huntington',
    'Huntington disease',
    ARRAY['Doença de Huntington', 'Coreia de Huntington', 'Huntington disease', 'HD'],
    (SELECT id FROM disease_categories WHERE code = 'neurological'),
    'ORPHA:399',
    ARRAY['G10'],
    '5 a 10 por 100.000',
    (SELECT id FROM inheritance_patterns WHERE code = 'autosomal_dominant'),
    ARRAY['HTT'],
    'published',
    90
);

-- Distrofia Muscular de Duchenne
INSERT INTO diseases (
    gard_br_id, name_pt, name_en, synonyms, 
    category_id, orpha_code, icd10_codes, 
    prevalence_value, inheritance_pattern_id, 
    genes_involved, info_status, quality_score
) VALUES (
    'GARD-BR-0005',
    'Distrofia Muscular de Duchenne',
    'Duchenne muscular dystrophy',
    ARRAY['Distrofia Muscular de Duchenne', 'DMD', 'Duchenne muscular dystrophy'],
    (SELECT id FROM disease_categories WHERE code = 'neurological'),
    'ORPHA:98896',
    ARRAY['G71.0'],
    '1 em 3.500 a 5.000 nascimentos masculinos',
    (SELECT id FROM inheritance_patterns WHERE code = 'x_linked'),
    ARRAY['DMD'],
    'published',
    94
);

-- =====================================================================================
-- 2. CONTEÚDO DETALHADO DAS DOENÇAS
-- =====================================================================================

-- Conteúdo para Síndrome de Marfan
INSERT INTO disease_content (
    disease_id,
    summary,
    symptoms,
    causes,
    diagnostic_criteria,
    treatment_options,
    prognosis,
    content_version,
    medical_reviewer
) VALUES (
    (SELECT id FROM diseases WHERE gard_br_id = 'GARD-BR-0001'),
    'A síndrome de Marfan é uma doença hereditária do tecido conjuntivo que afeta principalmente o sistema cardiovascular, esquelético e ocular. É causada por mutações no gene FBN1 que codifica a fibrilina-1.',
    ARRAY[
        'Estatura alta e constituição longilínea',
        'Aracnodactilia (dedos longos)',
        'Hipermobilidade articular',
        'Dilatação da raiz aórtica',
        'Luxação do cristalino',
        'Deformidades torácicas (pectus)',
        'Miopia',
        'Estrias cutâneas',
        'Dura-máter ectásica'
    ],
    'A síndrome de Marfan é causada por mutações no gene FBN1 localizado no cromossoma 15q21.1. Este gene codifica a fibrilina-1, uma glicoproteína essencial para a formação de microfibrilas que são componentes importantes da matriz extracelular.',
    ARRAY[
        'Critérios de Ghent revisados (2010)',
        'História familiar positiva',
        'Características esqueléticas (razão envergadura/altura >1,05)',
        'Envolvimento cardiovascular (dilatação aórtica)',
        'Luxação do cristalino',
        'Teste genético molecular (mutação FBN1)'
    ],
    ARRAY[
        'Ecocardiograma anual para monitorização cardiovascular',
        'Cirurgia profilática da aorta quando indicada',
        'Correção cirúrgica de deformidades esqueléticas graves',
        'Tratamento da luxação do cristalino',
        'Beta-bloqueadores para proteção cardiovascular',
        'Losartan como alternativa aos beta-bloqueadores',
        'Aconselhamento genético',
        'Restrições de atividade física intensa'
    ],
    'O prognóstico melhorou significativamente com o diagnóstico precoce e tratamento adequado. A expectativa de vida aproxima-se da normal quando há seguimento médico apropriado e intervenções preventivas.',
    1,
    'Dr. Especialista em Genética Médica'
);

-- Conteúdo para Fibrose Cística
INSERT INTO disease_content (
    disease_id,
    summary,
    symptoms,
    causes,
    diagnostic_criteria,
    treatment_options,
    prognosis
) VALUES (
    (SELECT id FROM diseases WHERE gard_br_id = 'GARD-BR-0002'),
    'A fibrose cística é uma doença genética multissistémica caracterizada pela produção de secreções espessas e pegajosas que afetam principalmente os pulmões, pâncreas e sistema digestivo.',
    ARRAY[
        'Tosse persistente com expetorações espessas',
        'Infeções pulmonares recorrentes',
        'Dispneia e sibilância',
        'Insuficiência pancreática',
        'Má absorção e desnutrição',
        'Suor salgado',
        'Pólipos nasais',
        'Infertilidade masculina',
        'Oclusão intestinal meconial em recém-nascidos'
    ],
    'Causada por mutações no gene CFTR (Cystic Fibrosis Transmembrane Conductance Regulator) que codifica uma proteína canal de cloro essencial para o transporte iónico através das membranas celulares.',
    ARRAY[
        'Teste do suor (cloro >60 mmol/L)',
        'Teste genético (mutações CFTR)',
        'Diferença de potencial nasal',
        'Rastreio neonatal (tripsinogénio imunoreativo)',
        'História clínica compatible',
        'História familiar'
    ],
    ARRAY[
        'Fisioterapia respiratória diária',
        'Moduladores CFTR (ivacaftor, lumacaftor, tezacaftor)',
        'Enzimas pancreáticas',
        'Suplementação vitamínica',
        'Antibióticos para infeções pulmonares',
        'Broncodilatadores e mucolíticos',
        'Transplante pulmonar em casos avançados',
        'Suporte nutricional'
    ],
    'O prognóstico tem melhorado dramaticamente com os novos tratamentos. A mediana de sobrevida atual é superior a 40 anos nos países desenvolvidos.'
);

-- =====================================================================================
-- 3. ENSAIOS CLÍNICOS EXEMPLO
-- =====================================================================================

INSERT INTO disease_clinical_trials (
    disease_id,
    trial_id,
    title,
    description,
    status,
    phase,
    location,
    country_code,
    source
) VALUES 
(
    (SELECT id FROM diseases WHERE gard_br_id = 'GARD-BR-0001'),
    'NCT04139031',
    'Estudo da Progressão da Dilatação Aórtica na Síndrome de Marfan',
    'Estudo observacional longitudinal para avaliar fatores preditivos da progressão da dilatação aórtica em doentes com síndrome de Marfan.',
    'Active, not recruiting',
    'Observational',
    'São Paulo, Brasil',
    'BRA',
    'clinicaltrials.gov'
),
(
    (SELECT id FROM diseases WHERE gard_br_id = 'GARD-BR-0002'),
    'NCT04038047',
    'Eficácia do Elexacaftor/Tezacaftor/Ivacaftor em Fibrose Cística',
    'Estudo de fase 3 avaliando a combinação tripla em doentes com fibrose cística com pelo menos uma mutação F508del.',
    'Completed',
    'Phase 3',
    'Lisboa, Portugal',
    'PRT',
    'clinicaltrials.gov'
);

-- =====================================================================================
-- 4. ORGANIZAÇÕES DE APOIO
-- =====================================================================================

INSERT INTO disease_support_organizations (
    disease_id,
    name,
    description,
    organization_type,
    contact_info,
    website,
    country_id,
    languages,
    services_offered,
    verified
) VALUES 
(
    (SELECT id FROM diseases WHERE gard_br_id = 'GARD-BR-0001'),
    'Associação Nacional Síndrome de Marfan',
    'Organização de apoio a doentes e famílias afetados pela síndrome de Marfan no Brasil.',
    'patient_association',
    '{"email": "contato@marfan.org.br", "phone": "+55 11 1234-5678"}',
    'https://www.marfan.org.br',
    (SELECT id FROM cplp_countries WHERE code = 'BRA'),
    ARRAY['pt'],
    ARRAY['Apoio psicológico', 'Informação médica', 'Grupos de apoio', 'Eventos educativos'],
    true
),
(
    (SELECT id FROM diseases WHERE gard_br_id = 'GARD-BR-0002'),
    'Associação Portuguesa de Fibrose Cística',
    'Organização de apoio a doentes com fibrose cística e suas famílias em Portugal.',
    'patient_association',
    '{"email": "geral@fibrosecistica.pt", "phone": "+351 21 123 4567"}',
    'https://www.fibrosecistica.pt',
    (SELECT id FROM cplp_countries WHERE code = 'PRT'),
    ARRAY['pt'],
    ARRAY['Apoio social', 'Fisioterapia', 'Aconselhamento', 'Equipamentos médicos'],
    true
);

-- =====================================================================================
-- 5. ESPECIALISTAS E CENTROS DE REFERÊNCIA
-- =====================================================================================

INSERT INTO disease_specialists (
    disease_id,
    specialist_type,
    name,
    specialty,
    contact_info,
    country_id,
    accepts_new_patients,
    languages,
    verification_status,
    verified_at
) VALUES 
(
    (SELECT id FROM diseases WHERE gard_br_id = 'GARD-BR-0001'),
    'center',
    'Centro de Genética Médica - Hospital das Clínicas FMUSP',
    'Genética Médica e Doenças do Tecido Conjuntivo',
    '{"phone": "+55 11 2661-0000", "email": "genetica.hc@usp.br"}',
    (SELECT id FROM cplp_countries WHERE code = 'BRA'),
    true,
    ARRAY['pt'],
    'verified',
    CURRENT_DATE
),
(
    (SELECT id FROM diseases WHERE gard_br_id = 'GARD-BR-0002'),
    'center',
    'Unidade de Fibrose Cística - Centro Hospitalar Lisboa Norte',
    'Pneumologia Pediátrica e Fibrose Cística',
    '{"phone": "+351 21 780 5000", "email": "fibrose.cisticahsm@chln.min-saude.pt"}',
    (SELECT id FROM cplp_countries WHERE code = 'PRT'),
    true,
    ARRAY['pt'],
    'verified',
    CURRENT_DATE
);

-- =====================================================================================
-- 6. DADOS EPIDEMIOLÓGICOS POR PAÍS CPLP
-- =====================================================================================

INSERT INTO disease_epidemiology_cplp (
    disease_id,
    country_id,
    estimated_cases,
    prevalence_per_100k,
    data_source,
    data_quality,
    collection_date
) VALUES 
-- Síndrome de Marfan no Brasil
(
    (SELECT id FROM diseases WHERE gard_br_id = 'GARD-BR-0001'),
    (SELECT id FROM cplp_countries WHERE code = 'BRA'),
    25000,
    12.0,
    'Registro Brasileiro de Doenças Raras',
    'medium',
    '2023-01-01'
),
-- Fibrose Cística em Portugal
(
    (SELECT id FROM diseases WHERE gard_br_id = 'GARD-BR-0002'),
    (SELECT id FROM cplp_countries WHERE code = 'PRT'),
    800,
    7.8,
    'Registo Nacional de Fibrose Cística',
    'high',
    '2023-12-31'
),
-- Anemia Falciforme em Angola
(
    (SELECT id FROM diseases WHERE gard_br_id = 'GARD-BR-0003'),
    (SELECT id FROM cplp_countries WHERE code = 'AGO'),
    150000,
    450.0,
    'Ministério da Saúde de Angola',
    'low',
    '2022-12-31'
);

-- =====================================================================================
-- 7. DISPONIBILIDADE DE MEDICAMENTOS
-- =====================================================================================

INSERT INTO disease_medications_availability (
    disease_id,
    country_id,
    medication_name,
    generic_name,
    availability_status,
    regulatory_status,
    reimbursement_status,
    access_conditions,
    data_source
) VALUES 
-- Losartan para Síndrome de Marfan no Brasil
(
    (SELECT id FROM diseases WHERE gard_br_id = 'GARD-BR-0001'),
    (SELECT id FROM cplp_countries WHERE code = 'BRA'),
    'Losartan',
    'Losartan potássico',
    'available',
    'Aprovado pela ANVISA',
    'Reembolsado pelo SUS',
    ARRAY['Prescrição médica', 'Diagnóstico confirmado'],
    'ANVISA'
),
-- Ivacaftor para Fibrose Cística em Portugal
(
    (SELECT id FROM diseases WHERE gard_br_id = 'GARD-BR-0002'),
    (SELECT id FROM cplp_countries WHERE code = 'PRT'),
    'Kalydeco',
    'Ivacaftor',
    'available',
    'Aprovado pelo EMA',
    'Reembolsado pelo SNS',
    ARRAY['Mutação G551D confirmada', 'Prescrição hospitalar'],
    'INFARMED'
);

-- =====================================================================================
-- 8. PUBLICAÇÕES CIENTÍFICAS RELEVANTES
-- =====================================================================================

INSERT INTO disease_publications (
    disease_id,
    pubmed_id,
    doi,
    title,
    authors,
    journal,
    publication_date,
    study_type,
    evidence_level,
    language_code,
    is_open_access
) VALUES 
(
    (SELECT id FROM diseases WHERE gard_br_id = 'GARD-BR-0001'),
    '31738386',
    '10.1016/j.jacc.2019.09.009',
    'The 2017 International Classification of the Marfan Syndrome',
    ARRAY['Loeys BL', 'Dietz HC', 'Braverman AC', 'Callewaert BL'],
    'Journal of the American College of Cardiology',
    '2019-11-12',
    'review',
    2,
    'en',
    false
),
(
    (SELECT id FROM diseases WHERE gard_br_id = 'GARD-BR-0002'),
    '31751430',
    '10.1056/NEJMoa1908639',
    'Elexacaftor-Tezacaftor-Ivacaftor for Cystic Fibrosis',
    ARRAY['Heijerman HG', 'McKone EF', 'Downey DG'],
    'New England Journal of Medicine',
    '2019-11-07',
    'clinical_trial',
    1,
    'en',
    false
);

-- =====================================================================================
-- 9. REFERÊNCIAS E FONTES
-- =====================================================================================

INSERT INTO disease_references (
    disease_id,
    reference_type,
    title,
    authors,
    source,
    url,
    publication_date,
    reliability_score
) VALUES 
(
    (SELECT id FROM diseases WHERE gard_br_id = 'GARD-BR-0001'),
    'guideline',
    'Diretrizes Brasileiras para Diagnóstico e Tratamento da Síndrome de Marfan',
    ARRAY['Sociedade Brasileira de Cardiologia'],
    'Arquivos Brasileiros de Cardiologia',
    'https://www.scielo.br/j/abc/a/marfan-guidelines',
    '2022-01-01',
    5
),
(
    (SELECT id FROM diseases WHERE gard_br_id = 'GARD-BR-0002'),
    'database',
    'Cystic Fibrosis Foundation Patient Registry',
    ARRAY['Cystic Fibrosis Foundation'],
    'CFF Patient Registry',
    'https://www.cff.org/Research/Researcher-Resources/Patient-Registry/',
    '2023-01-01',
    5
);

-- =====================================================================================
-- COMENTÁRIOS FINAIS
-- =====================================================================================

-- Este dataset inicial fornece:
-- ✓ 5 doenças raras bem documentadas e prevalentes na CPLP
-- ✓ Conteúdo médico completo para cada doença
-- ✓ Ensaios clínicos ativos/recentes
-- ✓ Organizações de apoio verificadas
-- ✓ Centros de referência especializados
-- ✓ Dados epidemiológicos regionais
-- ✓ Informações sobre disponibilidade de medicamentos
-- ✓ Publicações científicas relevantes
-- ✓ Referências confiáveis

-- Para expansão:
-- 1. Adicionar mais doenças por categoria
-- 2. Incluir dados de todos os países CPLP
-- 3. Expandir informações sobre medicamentos órfãos
-- 4. Adicionar mais ensaios clínicos regionais
-- 5. Incluir tradições de medicina tradicional quando relevante

COMMENT ON SCHEMA public IS 'Dataset inicial do GARD Brasileiro com doenças raras prevalentes nos países da CPLP';

-- =====================================================================================
-- VALIDAÇÃO DOS DADOS INSERIDOS
-- =====================================================================================

-- Verificar se todos os dados foram inseridos corretamente
SELECT 
    d.gard_br_id,
    d.name_pt,
    dc.name_pt as category,
    CASE WHEN content.id IS NOT NULL THEN 'SIM' ELSE 'NÃO' END as tem_conteudo,
    COUNT(ct.id) as ensaios_clinicos,
    COUNT(org.id) as organizacoes,
    COUNT(spec.id) as especialistas
FROM diseases d
LEFT JOIN disease_categories dc ON d.category_id = dc.id  
LEFT JOIN disease_content content ON d.id = content.disease_id
LEFT JOIN disease_clinical_trials ct ON d.id = ct.disease_id
LEFT JOIN disease_support_organizations org ON d.id = org.disease_id
LEFT JOIN disease_specialists spec ON d.id = spec.disease_id
GROUP BY d.id, d.gard_br_id, d.name_pt, dc.name_pt, content.id
ORDER BY d.gard_br_id;
