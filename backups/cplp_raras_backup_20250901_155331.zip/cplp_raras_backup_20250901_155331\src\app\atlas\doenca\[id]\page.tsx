import { notFound } from 'next/navigation';
import type { Metadata } from 'next';
import Link from 'next/link';
import DiseaseDetail from '@/components/atlas/DiseaseDetail';
import diseasesData from '@/data/diseases.json';

interface PageProps {
  params: Promise<{
    id: string;
  }>;
}

// Gerar metadata dinâmica
export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { id } = await params;
  const disease = diseasesData.diseases.find(d => d.id === id);
  
  if (!disease) {
    return {
      title: 'Doença não encontrada | Atlas CPLP-RARAS',
    };
  }

  return {
    title: `${disease.name.pt} (${disease.acronym}) | Atlas CPLP-RARAS`,
    description: `Informações completas sobre ${disease.name.pt}: sintomas, causas, centros de referência e dados clínicos para os países da CPLP.`,
    keywords: `${disease.name.pt}, ${disease.acronym}, ${disease.synonyms.pt.join(', ')}, doenças raras, CPLP`,
  };
}

// Gerar rotas estáticas para todas as doenças
export function generateStaticParams() {
  return diseasesData.diseases.map((disease) => ({
    id: disease.id,
  }));
}

export default async function DiseasePage({ params }: PageProps) {
  const { id } = await params;
  const disease = diseasesData.diseases.find(d => d.id === id);

  if (!disease) {
    notFound();
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Breadcrumb */}
      <div className="bg-white border-b">
        <div className="mx-auto max-w-7xl px-4 py-4 sm:px-6 lg:px-8">
          <nav className="flex" aria-label="Navegação por migalhas de pão">
            <ol className="inline-flex items-center space-x-1 md:space-x-3" role="list">
              <li role="listitem">
                <Link 
                  href="/" 
                  className="text-blue-600 hover:text-blue-800 focus:outline-none focus:ring-2 focus:ring-blue-500 rounded-sm"
                  aria-label="Voltar à página inicial"
                >
                  Início
                </Link>
              </li>
              <li role="listitem">
                <div className="flex items-center">
                  <span className="mx-2 text-gray-400" aria-hidden="true">/</span>
                  <Link 
                    href="/atlas" 
                    className="text-blue-600 hover:text-blue-800 focus:outline-none focus:ring-2 focus:ring-blue-500 rounded-sm"
                    aria-label="Voltar ao Atlas CPLP-RARAS"
                  >
                    Atlas CPLP-RARAS
                  </Link>
                </div>
              </li>
              <li role="listitem" aria-current="page">
                <div className="flex items-center">
                  <span className="mx-2 text-gray-400" aria-hidden="true">/</span>
                  <span className="text-gray-500">{disease.name.pt}</span>
                </div>
              </li>
            </ol>
          </nav>
        </div>
      </div>

      {/* Componente de detalhes da doença */}
      <DiseaseDetail disease={disease} />
    </div>
  );
}
