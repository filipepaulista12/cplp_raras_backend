'use client';

import { useState } from 'react';

export default function MapeamentoFormulario() {
  const [isVisible, setIsVisible] = useState(true);

  if (!isVisible) {
    return null;
  }

  return (
    <div className="bg-gradient-to-r from-pink-500 via-purple-600 to-blue-600 py-4 px-4 shadow-lg relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute inset-0 bg-gradient-to-r from-white/5 to-white/10"></div>
      </div>
      
      <div className="mx-auto max-w-7xl flex items-center justify-between relative z-10">
        <div className="flex items-center space-x-4 flex-1">
          {/* Icon */}
          <div className="hidden sm:flex w-12 h-12 bg-white/20 backdrop-blur-sm rounded-full items-center justify-center">
            <span className="text-2xl">🗺️</span>
          </div>
          
          {/* Content */}
          <div className="flex-1">
            <div className="flex flex-col sm:flex-row sm:items-center sm:space-x-4">
              <div className="flex items-center space-x-2 mb-2 sm:mb-0">
                <span className="bg-white/20 backdrop-blur-sm text-white text-xs font-bold px-2 py-1 rounded-full">
                  GT1 - ATIVO
                </span>
                <h3 className="text-white font-bold text-lg">
                  Mapeamento Colaborativo CPLP-Raras
                </h3>
              </div>
              <p className="text-white/90 text-sm">
                🔍 Ajude-nos a identificar pessoas e instituições na rede! 
                <span className="hidden sm:inline">  Indique um contato.</span>
              </p>
            </div>
          </div>
        </div>
        
        {/* CTA Button */}
        <div className="flex items-center space-x-3">
          <a
            href="https://redcap.link/cplpDR"
            target="_blank"
            rel="noopener noreferrer"
            className="bg-white text-purple-600 hover:bg-gray-100 font-semibold px-6 py-3 rounded-lg transition-all duration-200 transform hover:scale-105 shadow-lg flex items-center space-x-2 group"
          >
            <span>Participar</span>
            <svg className="w-4 h-4 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
            </svg>
          </a>
          
          {/* Close button */}
          <button
            onClick={() => setIsVisible(false)}
            className="text-white/70 hover:text-white p-2 rounded-full hover:bg-white/10 transition-colors"
            title="Fechar banner"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
      </div>
    </div>
  );
}
