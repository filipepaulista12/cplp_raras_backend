'use client'

import React, { useState, useEffect } from 'react'
import { X, MessageCircle, Star } from 'lucide-react'
import { sendContactForm, openEmailClient } from '@/lib/emailService'

interface FeedbackModalProps {
  isOpen: boolean
  onClose: () => void
}

interface FeedbackData {
  name: string
  email: string
  rating: number
  category: string
  message: string
}

const categories = [
  'Sugestão',
  'Avaliação', 
  'Reportar Erro'
]

export const FeedbackModal: React.FC<FeedbackModalProps> = ({ isOpen, onClose }) => {
  const [formData, setFormData] = useState<FeedbackData>({
    name: '',
    email: '',
    rating: 0,
    category: '',
    message: ''
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'success' | 'error'>('idle')

  // Reset form when modal opens
  useEffect(() => {
    if (isOpen) {
      setFormData({
        name: '',
        email: '',
        rating: 0,
        category: '',
        message: ''
      })
      setSubmitStatus('idle')
    }
  }, [isOpen])

  const handleInputChange = (field: keyof FeedbackData, value: string | number) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    // Validação básica
    if (!formData.message || !formData.category) {
      alert('Por favor, preencha a categoria e mensagem!')
      return
    }

    // SOLUÇÃO SIMPLES: Abrir email direto
    const emailBody = `
FEEDBACK CPLP-RARAS

Tipo: ${formData.category}
${formData.name ? `Nome: ${formData.name}` : ''}
${formData.email ? `Email: ${formData.email}` : ''}

Mensagem:
${formData.message}
    `.trim()

    const subject = `[FEEDBACK CPLP-RARAS] ${formData.category}`
    const mailtoLink = `mailto:cplp@raras.org.br?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(emailBody)}`
    
    // Abrir cliente de email
    window.location.href = mailtoLink
    
    // Fechar modal
    onClose()
  }

  const handleRatingClick = (rating: number) => {
    setFormData(prev => ({ ...prev, rating }))
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-md max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center p-6 border-b">
          <div className="flex items-center gap-2">
            <MessageCircle className="text-blue-600" size={24} />
            <h2 className="text-xl font-semibold text-gray-900">
              Envie seu Feedback
            </h2>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition-colors"
          >
            <X size={24} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {/* Name Field */}
          <div>
            <label htmlFor="feedback-name" className="block text-sm font-medium text-gray-700 mb-1">
              Nome *
            </label>
            <input
              id="feedback-name"
              type="text"
              value={formData.name}
              onChange={(e) => handleInputChange('name', e.target.value)}
              placeholder="Seu nome"
              required
              className="flex h-10 w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          {/* Email Field */}
          <div>
            <label htmlFor="feedback-email" className="block text-sm font-medium text-gray-700 mb-1">
              Email *
            </label>
            <input
              id="feedback-email"
              type="email"
              value={formData.email}
              onChange={(e) => handleInputChange('email', e.target.value)}
              placeholder="seu@email.com"
              required
              className="flex h-10 w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          {/* Rating */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Avaliação *
            </label>
            <div className="flex gap-1">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  type="button"
                  onClick={() => handleRatingClick(star)}
                  className={`p-1 rounded transition-colors ${
                    star <= formData.rating 
                      ? 'text-yellow-500 hover:text-yellow-600' 
                      : 'text-gray-300 hover:text-gray-400'
                  }`}
                >
                  <Star 
                    size={24} 
                    fill={star <= formData.rating ? 'currentColor' : 'none'}
                  />
                </button>
              ))}
              {formData.rating > 0 && (
                <span className="ml-2 text-sm text-gray-600 self-center">
                  {formData.rating}/5 estrelas
                </span>
              )}
            </div>
          </div>

          {/* Category */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Categoria *
            </label>
            <div className="flex flex-wrap gap-2">
              {categories.map((category) => (
                <button
                  key={category}
                  type="button"
                  onClick={() => handleInputChange('category', category)}
                  className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium cursor-pointer hover:bg-blue-100 transition-colors ${
                    formData.category === category 
                      ? 'bg-blue-600 text-white' 
                      : 'bg-gray-100 text-gray-800 border border-gray-300'
                  }`}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>

          {/* Message */}
          <div>
            <label htmlFor="feedback-message" className="block text-sm font-medium text-gray-700 mb-1">
              Mensagem *
            </label>
            <textarea
              id="feedback-message"
              value={formData.message}
              onChange={(e) => handleInputChange('message', e.target.value)}
              placeholder="Compartilhe seu feedback, sugestões ou relate problemas..."
              rows={4}
              required
              className="flex min-h-[80px] w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          {/* Submit Status */}
          {submitStatus === 'success' && (
            <div className="bg-green-50 border border-green-200 rounded-md p-3">
              <p className="text-green-800 text-sm">
                ✅ Feedback enviado com sucesso! Obrigado pela sua contribuição.
              </p>
            </div>
          )}

          {submitStatus === 'error' && (
            <div className="bg-red-50 border border-red-200 rounded-md p-3">
              <p className="text-red-800 text-sm">
                ❌ Erro ao enviar feedback. Tente novamente ou entre em contato diretamente.
              </p>
            </div>
          )}

          {/* Submit Button */}
          <button
            type="submit"
            className="w-full bg-orange-500 hover:bg-orange-600 text-white font-medium py-2 px-4 rounded-md transition-colors"
          >
            Enviar Feedback
          </button>
        </form>

        <div className="px-6 pb-6">
          <p className="text-xs text-gray-500 text-center">
            Seu feedback é importante para melhorar a plataforma CPLP-Raras
          </p>
        </div>
      </div>
    </div>
  )
}
