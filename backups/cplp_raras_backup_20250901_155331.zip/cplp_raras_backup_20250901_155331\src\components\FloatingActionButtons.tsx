'use client';

import { useState } from 'react';
import { 
  ChatBubbleLeftRightIcon,
  AdjustmentsHorizontalIcon,
  Bars3Icon,
  XMarkIcon,
  EyeIcon
} from '@heroicons/react/24/outline';
import FeedbackSystem from './FeedbackSystem';

export default function FloatingActionButtons() {
  const [isExpanded, setIsExpanded] = useState(false);
  const [showFeedback, setShowFeedback] = useState(false);

  const toggleExpanded = () => {
    setIsExpanded(!isExpanded);
  };

  const openAccessibility = () => {
    // Simular clique no botão de acessibilidade existente
    const accessibilityButton = document.querySelector('[aria-label="Abrir painel de acessibilidade"]') as HTMLButtonElement;
    if (accessibilityButton) {
      accessibilityButton.click();
    }
  };

  const openAnalytics = () => {
    // Simular clique no contador de interações
    const counterButton = document.querySelector('[aria-label="Ver estatísticas do site"]') as HTMLButtonElement;
    if (counterButton) {
      counterButton.click();
      setIsExpanded(false);
    }
  };

  return (
    <>
      {/* Container Principal */}
      <div className="fixed bottom-6 right-6 z-50">
        <div className="flex flex-col items-end space-y-3">
          
          {/* Botões Expandidos */}
          {isExpanded && (
            <div className="flex flex-col space-y-3 animate-in slide-in-from-bottom duration-200">
              
              {/* Botão de Analytics (movido para o submenu) */}
              <button
                onClick={openAnalytics}
                className="bg-purple-600 hover:bg-purple-700 text-white p-3 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 group"
                aria-label="Ver estatísticas"
                title="Estatísticas do Site"
              >
                <EyeIcon className="h-5 w-5 group-hover:animate-pulse" />
              </button>

              {/* Botão de Feedback */}
              <button
                onClick={() => {
                  setShowFeedback(true);
                  setIsExpanded(false);
                }}
                className="bg-green-600 hover:bg-green-700 text-white p-3 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 group"
                aria-label="Enviar feedback"
                title="Enviar Feedback"
              >
                <ChatBubbleLeftRightIcon className="h-5 w-5 group-hover:animate-pulse" />
              </button>
            </div>
          )}

          {/* Botão de Acessibilidade - SEMPRE VISÍVEL */}
          <button
            onClick={openAccessibility}
            className="bg-blue-600 hover:bg-blue-700 text-white p-3 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 group"
            aria-label="Configurações de acessibilidade"
            title="Acessibilidade"
          >
                  <span className="text-2xl" role="img" aria-label="Acessibilidade">
          ♿
        </span>
          </button>

          {/* Botão Principal (Menu) */}
          <button
            onClick={toggleExpanded}
            className={`bg-gradient-to-r from-orange-600 to-amber-600 text-white p-4 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 ${
              isExpanded ? 'rotate-45' : ''
            }`}
            aria-label={isExpanded ? 'Fechar menu' : 'Abrir menu de funcionalidades'}
            title="Menu de Funcionalidades"
          >
            {isExpanded ? (
              <XMarkIcon className="h-6 w-6" />
            ) : (
              <Bars3Icon className="h-6 w-6" />
            )}
          </button>
        </div>

        {/* Labels flutuantes quando expandido */}
        {isExpanded && (
          <div className="absolute bottom-24 right-16 flex flex-col space-y-3 text-right animate-in slide-in-from-right duration-200">
            <span className="bg-purple-600 text-white px-3 py-1 rounded-lg text-sm font-medium shadow-lg">
              Estatísticas
            </span>
            <span className="bg-green-600 text-white px-3 py-1 rounded-lg text-sm font-medium shadow-lg">
              Feedback
            </span>
          </div>
        )}
      </div>

      {/* Modal de Feedback */}
      {showFeedback && (
        <FeedbackSystem 
          isOpen={showFeedback} 
          onClose={() => setShowFeedback(false)} 
        />
      )}
    </>
  );
}
