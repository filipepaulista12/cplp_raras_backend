'use client';

import { 
  SparklesIcon, 
  AcademicCapIcon, 
  ChatBubbleLeftRightIcon,
  ExclamationTriangleIcon,
  EnvelopeIcon,
  GlobeAltIcon,
  ArrowTopRightOnSquareIcon
} from '@heroicons/react/24/outline';
import Link from 'next/link';

export default function GPTEducativoPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-orange-50 to-red-100">
      {/* Hero Section */}
      <section className="relative py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center">
            <div className="inline-flex items-center px-4 py-2 bg-green-100 text-green-700 rounded-full text-sm font-medium mb-6">
              <SparklesIcon className="h-4 w-4 mr-2" />
              ✨ Disponível Agora - Em Aprimoramento
            </div>
            
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              <span className="bg-gradient-to-r from-orange-600 via-red-600 to-pink-600 bg-clip-text text-transparent">
                Raras GPT Educativo
              </span>
            </h1>
            
            <p className="text-xl md:text-2xl text-gray-600 mb-8 max-w-3xl mx-auto">
              Assistente de inteligência artificial especializado em doenças raras para educação médica continuada da CPLP
            </p>

            {/* Propósito e Disclaimer */}
            <div className="max-w-4xl mx-auto mb-12">
              <div className="bg-white rounded-2xl shadow-lg border border-blue-200 p-6 md:p-8">
                <div className="flex items-start space-x-4">
                  <div className="flex-shrink-0">
                    <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                      <ExclamationTriangleIcon className="h-6 w-6 text-blue-600" />
                    </div>
                  </div>
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold text-gray-900 mb-3">
                      🎯 Propósito e Limitações
                    </h3>
                    <div className="text-gray-700 leading-relaxed space-y-3">
                      <p>
                        <strong>Apoia profissionais da saúde, estudantes e gestores da CPLP</strong> com informações 
                        educativas e baseadas em evidências sobre doenças raras, respeitando as realidades locais 
                        e promovendo o uso de recursos colaborativos.
                      </p>
                      <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                        <p className="text-yellow-800 font-medium">
                          ⚠️ <strong>Importante:</strong> Não fornece diagnóstico, aconselhamento clínico ou tratamento individualizado. 
                          Sempre consulte profissionais de saúde qualificados para decisões clínicas.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Chat Interface */}
            <div className="mb-12">
              <div className="text-center mb-8">
                <h3 className="text-2xl font-bold text-gray-900 mb-4">
                  💬 Acesse o GPT Educativo
                </h3>
                <p className="text-lg text-gray-600 max-w-2xl mx-auto mb-4">
                  Clique no botão abaixo para abrir o chat especializado em doenças raras da CPLP
                </p>
              </div>
              
              {/* Interface do Chat */}
              <div className="max-w-5xl mx-auto">
                <div className="bg-white rounded-2xl shadow-2xl border border-gray-200 overflow-hidden">
                  {/* Header */}
                  <div className="bg-gradient-to-r from-orange-500 to-red-600 px-6 py-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <div className="w-3 h-3 bg-white/30 rounded-full mr-2"></div>
                        <div className="w-3 h-3 bg-white/30 rounded-full mr-2"></div>
                        <div className="w-3 h-3 bg-white/30 rounded-full mr-4"></div>
                        <span className="text-white font-bold">GPT Educativo CPLP-Raras</span>
                      </div>
                      <div className="flex items-center text-white/80 text-sm">
                        <div className="w-2 h-2 bg-green-400 rounded-full mr-2 animate-pulse"></div>
                        Disponível
                      </div>
                    </div>
                  </div>
                  
                  {/* Área central */}
                  <div className="p-8 bg-gray-50 min-h-[400px] flex items-center justify-center">
                    <div className="text-center max-w-md">
                      <SparklesIcon className="h-20 w-20 text-orange-500 mx-auto mb-4" />
                      <h4 className="text-2xl font-bold text-gray-900 mb-3">
                        Pronto para Conversar!
                      </h4>
                      <p className="text-gray-600 mb-6">
                        Abra o GPT Educativo em uma nova janela para ter acesso completo ao chat especializado
                      </p>
                      
                      {/* Botão principal */}
                      <a
                        href="https://chatgpt.com/g/g-68682fab869481918d65a8815554bf92-raras-gpt-educativo-e-colaborativo-da-cplp"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center px-8 py-4 bg-gradient-to-r from-orange-600 to-red-600 text-white font-bold text-lg rounded-2xl shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300 mb-4"
                      >
                        <ChatBubbleLeftRightIcon className="h-6 w-6 mr-3" />
                        Abrir GPT Educativo
                        <ArrowTopRightOnSquareIcon className="h-5 w-5 ml-2" />
                      </a>
                      
                      <p className="text-sm text-gray-500">
                        Abre em nova janela • Gratuito • Histórico salvo na sua conta
                      </p>
                    </div>
                  </div>
                  
                  {/* Exemplo de conversa */}
                  <div className="p-6 bg-white border-t">
                    <div className="space-y-4 max-w-2xl mx-auto">
                      <div className="text-center mb-4">
                        <span className="text-sm text-gray-500">Exemplo de conversa:</span>
                      </div>
                      
                      <div className="flex justify-end">
                        <div className="bg-blue-600 text-white rounded-2xl px-4 py-2 max-w-xs">
                          <p className="text-sm">Quais são os sintomas principais da síndrome de Marfan?</p>
                        </div>
                      </div>
                      
                      <div className="flex justify-start">
                        <div className="flex">
                          <div className="w-8 h-8 bg-gradient-to-r from-orange-500 to-red-600 rounded-full flex items-center justify-center mr-3 flex-shrink-0">
                            <SparklesIcon className="h-4 w-4 text-white" />
                          </div>
                          <div className="bg-gray-100 rounded-2xl px-4 py-2 max-w-md">
                            <p className="text-sm text-gray-800">
                              A síndrome de Marfan apresenta manifestações multissistêmicas:<br/>
                              🫀 Cardiovasculares: Dilatação aórtica<br/>
                              👁️ Oculares: Luxação do cristalino<br/>
                              🦴 Esqueléticas: Estatura alta, aracnodactilia...
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                
                {/* Cards informativos */}
                <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 text-center">
                    <div className="text-blue-600 text-2xl mb-2">🚀</div>
                    <div className="font-semibold text-blue-900 mb-1">Acesso Imediato</div>
                    <div className="text-blue-800">Clique e comece a conversar</div>
                  </div>
                  
                  <div className="bg-green-50 border border-green-200 rounded-lg p-4 text-center">
                    <div className="text-green-600 text-2xl mb-2">💾</div>
                    <div className="font-semibold text-green-900 mb-1">Histórico Salvo</div>
                    <div className="text-green-800">Conversas ficam na sua conta</div>
                  </div>
                  
                  <div className="bg-purple-50 border border-purple-200 rounded-lg p-4 text-center">
                    <div className="text-purple-600 text-2xl mb-2">🎯</div>
                    <div className="font-semibold text-purple-900 mb-1">Especializado</div>
                    <div className="text-purple-800">Focado em doenças raras CPLP</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <SparklesIcon className="h-16 w-16 text-orange-600 mx-auto mb-6" />
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Recursos Disponíveis
            </h2>
            <p className="text-lg text-gray-600">
              Funcionalidades educativas em constante aprimoramento
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100">
              <div className="text-3xl mb-4">🎓</div>
              <h3 className="text-lg font-bold text-gray-900 mb-3">Educação Médica</h3>
              <p className="text-gray-600">Conteúdo adaptado para diferentes níveis de conhecimento</p>
            </div>
            
            <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100">
              <div className="text-3xl mb-4">💬</div>
              <h3 className="text-lg font-bold text-gray-900 mb-3">Conversação Natural</h3>
              <p className="text-gray-600">Interface intuitiva para perguntas e respostas</p>
            </div>
            
            <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100">
              <div className="text-3xl mb-4">🌍</div>
              <h3 className="text-lg font-bold text-gray-900 mb-3">Foco CPLP</h3>
              <p className="text-gray-600">Especializado em realidades lusófonas</p>
            </div>
            
            <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100">
              <div className="text-3xl mb-4">📚</div>
              <h3 className="text-lg font-bold text-gray-900 mb-3">Base Atualizada</h3>
              <p className="text-gray-600">Literatura médica e protocolos recentes</p>
            </div>
            
            <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100">
              <div className="text-3xl mb-4">🔍</div>
              <h3 className="text-lg font-bold text-gray-900 mb-3">Casos Clínicos</h3>
              <p className="text-gray-600">Simulações para aprendizado prático</p>
            </div>
            
            <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100">
              <div className="text-3xl mb-4">📊</div>
              <h3 className="text-lg font-bold text-gray-900 mb-3">Acompanhamento</h3>
              <p className="text-gray-600">Histórico de aprendizado personalizado</p>
            </div>
          </div>
        </div>
      </section>

      {/* Público-Alvo */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-white/50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <AcademicCapIcon className="h-16 w-16 text-blue-600 mx-auto mb-6" />
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Público-Alvo CPLP</h2>
            <p className="text-lg text-gray-600 mb-6">
              Desenvolvido especificamente para apoiar a comunidade lusófona
            </p>
            
            <div className="max-w-4xl mx-auto mb-8">
              <div className="bg-gradient-to-r from-blue-50 to-green-50 border-l-4 border-blue-500 rounded-lg p-6">
                <div className="flex items-start space-x-4">
                  <div className="flex-shrink-0">
                    <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                      <span className="text-blue-600 font-bold">🎯</span>
                    </div>
                  </div>
                  <div className="flex-1 text-left">
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">
                      Missão Educativa
                    </h3>
                    <p className="text-gray-700">
                      <strong>Apoia profissionais da saúde, estudantes e gestores da CPLP</strong> com 
                      informações educativas e baseadas em evidências sobre doenças raras, respeitando 
                      as realidades locais e promovendo o uso de recursos colaborativos.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-white rounded-2xl shadow-lg p-8 border border-gray-100">
              <h3 className="text-xl font-bold text-gray-900 mb-4">Profissionais da Saúde</h3>
              <p className="text-gray-600">Apoio ao diagnóstico diferencial e protocolos terapêuticos</p>
            </div>
            
            <div className="bg-white rounded-2xl shadow-lg p-8 border border-gray-100">
              <h3 className="text-xl font-bold text-gray-900 mb-4">Estudantes</h3>
              <p className="text-gray-600">Aprendizado interativo sobre doenças raras com casos práticos</p>
            </div>
            
            <div className="bg-white rounded-2xl shadow-lg p-8 border border-gray-100">
              <h3 className="text-xl font-bold text-gray-900 mb-4">Gestores</h3>
              <p className="text-gray-600">Informações para políticas públicas e recursos de saúde</p>
            </div>
            
            <div className="bg-white rounded-2xl shadow-lg p-8 border border-gray-100">
              <h3 className="text-xl font-bold text-gray-900 mb-4">Pesquisadores</h3>
              <p className="text-gray-600">Acesso a literatura atualizada e dados colaborativos</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer CTA */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <div className="bg-gradient-to-r from-orange-600 to-red-600 rounded-3xl shadow-2xl p-8 md:p-12 text-white">
            <h2 className="text-3xl font-bold mb-6">🌟 Comece Agora</h2>
            <p className="text-xl opacity-90 mb-8">
              Explore o conhecimento especializado em doenças raras com inteligência artificial
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-6">
              <a
                href="https://chatgpt.com/g/g-68682fab869481918d65a8815554bf92-raras-gpt-educativo-e-colaborativo-da-cplp"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center px-8 py-4 bg-white text-orange-600 font-bold text-lg rounded-2xl shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300"
              >
                <ChatBubbleLeftRightIcon className="h-6 w-6 mr-3" />
                Acessar GPT Educativo
                <ArrowTopRightOnSquareIcon className="h-5 w-5 ml-2" />
              </a>
              
              <Link
                href="/sobre"
                className="inline-flex items-center px-8 py-4 border-2 border-white text-white font-bold text-lg rounded-2xl hover:bg-white hover:text-orange-600 transition-all duration-300"
              >
                Saiba Mais sobre CPLP-Raras
              </Link>
            </div>
            
            {/* Disclaimer final */}
            <div className="bg-white/10 rounded-lg p-4">
              <p className="text-white/90 text-sm">
                💡 <strong>Lembre-se:</strong> Este é um recurso educativo para apoio à aprendizagem. 
                Para questões clínicas específicas, sempre busque orientação de profissionais de saúde qualificados.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
