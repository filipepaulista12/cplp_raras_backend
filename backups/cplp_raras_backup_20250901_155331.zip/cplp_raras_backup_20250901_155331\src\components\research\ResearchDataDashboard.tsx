'use client';

import React, { useState, useEffect } from 'react';
import type { ResearchData, GardData, PCDTData } from '@/types/research-data';

interface ResearchDataDashboardProps {
  className?: string;
}

export function ResearchDataDashboard({ className = '' }: ResearchDataDashboardProps) {
  const [researchData, setResearchData] = useState<ResearchData | null>(null);
  const [gardData, setGardData] = useState<GardData | null>(null);
  const [pcdtData, setPcdtData] = useState<PCDTData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const loadData = async () => {
      try {
        setLoading(true);
        
        // Carregar dados de pesquisa consolidados
        const researchResponse = await fetch('/api/research-data');
        if (!researchResponse.ok) {
          throw new Error('Erro ao carregar dados de pesquisa');
        }
        const research = await researchResponse.json();
        setResearchData(research);

        // Carregar dados GARD
        const gardResponse = await fetch('/api/gard-data');
        if (gardResponse.ok) {
          const gard = await gardResponse.json();
          setGardData(gard);
        }

        // Carregar dados PCDT
        const pcdtResponse = await fetch('/api/pcdt-data');
        if (pcdtResponse.ok) {
          const pcdt = await pcdtResponse.json();
          setPcdtData(pcdt);
        }

      } catch (err) {
        console.error('Erro ao carregar dados:', err);
        setError(err instanceof Error ? err.message : 'Erro desconhecido');
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, []);

  if (loading) {
    return (
      <div className={`${className} flex items-center justify-center min-h-64`}>
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Carregando dados de pesquisa...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className={`${className} bg-red-50 border border-red-200 rounded-lg p-6`}>
        <h3 className="text-red-800 font-semibold mb-2">Erro ao Carregar Dados</h3>
        <p className="text-red-600">{error}</p>
      </div>
    );
  }

  if (!researchData) {
    return (
      <div className={`${className} bg-yellow-50 border border-yellow-200 rounded-lg p-6`}>
        <h3 className="text-yellow-800 font-semibold mb-2">Dados Não Disponíveis</h3>
        <p className="text-yellow-600">Os dados de pesquisa não estão disponíveis no momento.</p>
      </div>
    );
  }

  const formatDate = (dateString: string) => {
    try {
      return new Date(dateString).toLocaleDateString('pt-BR', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
    } catch {
      return 'Data inválida';
    }
  };

  return (
    <div className={`space-y-6 ${className}`}>
      {/* Header */}
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-gray-900 mb-2">
          Base de Dados CPLP-Raras
        </h2>
        <p className="text-gray-600 max-w-2xl mx-auto">
          {researchData.descricao}
        </p>
        <p className="text-sm text-gray-500 mt-2">
          Última atualização: {formatDate(researchData.atualizado_em)}
        </p>
      </div>

      {/* Estatísticas Principais */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {/* Card 1 */}
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
          <div className="px-6 py-4 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-medium text-gray-900">Total de Recursos</h3>
              <div className="h-4 w-4 bg-blue-100 rounded">📊</div>
            </div>
          </div>
          <div className="px-6 py-4">
            <div className="text-2xl font-bold">{researchData.estatisticas.total_recursos}</div>
            <p className="text-xs text-gray-500">Dados e protocolos coletados</p>
          </div>
        </div>

        {/* Card 2 */}
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
          <div className="px-6 py-4 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-medium text-gray-900">Recursos Relevantes</h3>
              <div className="h-4 w-4 bg-green-100 rounded">📈</div>
            </div>
          </div>
          <div className="px-6 py-4">
            <div className="text-2xl font-bold">{researchData.estatisticas.recursos_relevantes}</div>
            <p className="text-xs text-gray-500">Especificamente sobre doenças raras</p>
          </div>
        </div>

        {/* Card 3 */}
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
          <div className="px-6 py-4 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-medium text-gray-900">Idiomas</h3>
              <div className="h-4 w-4 bg-purple-100 rounded">🌍</div>
            </div>
          </div>
          <div className="px-6 py-4">
            <div className="text-2xl font-bold">{researchData.estatisticas.cobertura_linguistica.length}</div>
            <p className="text-xs text-gray-500">{researchData.estatisticas.cobertura_linguistica.join(', ')}</p>
          </div>
        </div>

        {/* Card 4 */}
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
          <div className="px-6 py-4 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-medium text-gray-900">Países CPLP</h3>
              <div className="h-4 w-4 bg-orange-100 rounded">👥</div>
            </div>
          </div>
          <div className="px-6 py-4">
            <div className="text-2xl font-bold">{researchData.estatisticas.paises_cplp_cobertura.length}</div>
            <p className="text-xs text-gray-500">Países de língua portuguesa</p>
          </div>
        </div>
      </div>

      {/* Fontes de Dados */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* GARD */}
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
          <div className="px-6 py-4 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
                  <span className="text-blue-600">🔬</span>
                  {researchData.fontes.gard.nome}
                </h3>
                <p className="text-sm text-gray-600 mt-1">
                  {gardData?.descricao || 'Base de dados de doenças raras do NIH'}
                </p>
              </div>
              <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                researchData.fontes.gard.status === 'ativo' 
                  ? 'bg-green-100 text-green-800' 
                  : 'bg-gray-100 text-gray-800'
              }`}>
                {researchData.fontes.gard.status}
              </span>
            </div>
          </div>
          <div className="px-6 py-4">
            <div className="space-y-4">
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Itens coletados:</span>
                <span className="font-semibold">{researchData.fontes.gard.total_itens}</span>
              </div>
              
              {gardData && (
                <div className="space-y-2">
                  <p className="text-sm text-gray-600">Última coleta:</p>
                  <p className="text-xs text-gray-500">{formatDate(gardData.atualizado_em)}</p>
                </div>
              )}

              <button 
                className="w-full inline-flex items-center justify-center rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 transition-colors"
                onClick={() => window.open(gardData?.url_origem || 'https://rarediseases.info.nih.gov', '_blank')}
              >
                <span className="mr-2">🔗</span>
                Visitar GARD
              </button>
            </div>
          </div>
        </div>

        {/* PCDT */}
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
          <div className="px-6 py-4 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
                  <span className="text-green-600">📄</span>
                  {researchData.fontes.pcdt.nome}
                </h3>
                <p className="text-sm text-gray-600 mt-1">
                  {pcdtData?.descricao || 'Protocolos oficiais do Ministério da Saúde do Brasil'}
                </p>
              </div>
              <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                researchData.fontes.pcdt.status === 'ativo' 
                  ? 'bg-green-100 text-green-800' 
                  : 'bg-gray-100 text-gray-800'
              }`}>
                {researchData.fontes.pcdt.status}
              </span>
            </div>
          </div>
          <div className="px-6 py-4">
            <div className="space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Total de PDFs:</span>
                  <span className="font-semibold">{researchData.fontes.pcdt.total_pdfs}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">PDFs relevantes:</span>
                  <span className="font-semibold text-green-600">{researchData.fontes.pcdt.pdfs_relevantes}</span>
                </div>
              </div>

              {pcdtData && (
                <div className="space-y-2">
                  <p className="text-sm text-gray-600">Última coleta:</p>
                  <p className="text-xs text-gray-500">{formatDate(pcdtData.atualizado_em)}</p>
                </div>
              )}

              <button 
                className="w-full inline-flex items-center justify-center rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 transition-colors"
                onClick={() => window.open(pcdtData?.url_origem || 'https://www.gov.br/saude/pt-br/assuntos/pcdt', '_blank')}
              >
                <span className="mr-2">🔗</span>
                Visitar PCDT
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Áreas de Pesquisa */}
      <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
        <div className="px-6 py-4 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900">Áreas de Pesquisa Abrangidas</h3>
          <p className="text-sm text-gray-600 mt-1">Principais áreas de foco do projeto CPLP-Raras</p>
        </div>
        <div className="px-6 py-4">
          <div className="flex flex-wrap gap-2">
            {researchData.areas_pesquisa.map((area, index) => (
              <span key={index} className="inline-flex items-center px-2.5 py-0.5 rounded-full text-sm border border-gray-300 text-gray-700 bg-white">
                {area}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Países CPLP */}
      <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
        <div className="px-6 py-4 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900">Cobertura CPLP</h3>
          <p className="text-sm text-gray-600 mt-1">Países de Língua Portuguesa abrangidos pelo projeto</p>
        </div>
        <div className="px-6 py-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
            {researchData.estatisticas.paises_cplp_cobertura.map((pais, index) => (
              <div key={index} className="text-sm p-2 bg-gray-50 rounded border text-center">
                {pais}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
