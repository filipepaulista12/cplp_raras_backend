import Link from 'next/link';
import TopShare from '@/components/TopShare';
import Image from 'next/image';
import { getImageSrc } from '@/lib/imageUtils';

export default function GT3() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Breadcrumb Navigation */}
      <div className="bg-white border-b">
        <div className="mx-auto max-w-7xl px-4 py-4 sm:px-6 lg:px-8">
          <nav className="flex" aria-label="Navegação por migalhas de pão">
            <ol className="inline-flex items-center space-x-1 md:space-x-3" role="list">
              <li role="listitem">
                <Link 
                  href="/" 
                  className="text-blue-600 hover:text-blue-800 focus:outline-none focus:ring-2 focus:ring-blue-500 rounded-sm"
                  aria-label="Voltar à página inicial"
                >
                  Início
                </Link>
              </li>
              <li role="listitem">
                <div className="flex items-center">
                  <span className="mx-2 text-gray-400" aria-hidden="true">/</span>
                  <Link 
                    href="/grupos-trabalho" 
                    className="text-blue-600 hover:text-blue-800 focus:outline-none focus:ring-2 focus:ring-blue-500 rounded-sm"
                    aria-label="Voltar à página dos grupos de trabalho"
                  >
                    Grupos de Trabalho
                  </Link>
                </div>
              </li>
              <li aria-current="page" role="listitem">
                <div className="flex items-center">
                  <span className="mx-2 text-gray-400" aria-hidden="true">/</span>
                  <span className="text-gray-500">GT3 - Rede Colaborativa</span>
                </div>
              </li>
            </ol>
          </nav>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        
        {/* Compartilhamento no topo */}
        <TopShare 
          title="GT3 - Rede Colaborativa"
          description="Construção de rede colaborativa internacional para pesquisa em doenças raras entre países da CPLP"
        />
        {/* Header Section */}
        <header className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            <span role="img" aria-label="Ícone de pesquisa" className="mr-3">🔍</span>
            GT3 – Rede Colaborativa de Pesquisa
          </h1>
          <div 
            className="w-32 h-1 bg-gradient-to-r from-purple-500 to-purple-600 mx-auto mb-8"
            role="presentation"
            aria-hidden="true"
          ></div>
          <p className="text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed">
            Rede de pesquisa da CPLP voltada ao avanço científico que conecta investigadores 
            para fortalecer a produção de conhecimento e inovação em doenças raras.
          </p>
        </header>

        {/* Main Content */}
        <section className="mb-16" aria-labelledby="gt3-description">
          <div className="bg-white rounded-2xl shadow-lg p-8 md:p-12">
            <div className="text-center mb-8">
              <Image 
                src={getImageSrc("/images/GT3.png")} 
                alt="Diagrama ilustrativo do GT3 - Rede Colaborativa de Pesquisa mostrando conexões entre pesquisadores dos países da CPLP" 
                width={600} 
                height={400} 
                className="rounded-lg shadow-md mx-auto"
                priority
              />
              <p className="sr-only">
                Imagem ilustrativa do Grupo de Trabalho 3, mostrando uma rede de conexões 
                entre pesquisadores dos diferentes países da CPLP trabalhando em colaboração 
                para pesquisas sobre doenças raras.
              </p>
            </div>
            
            <div 
              className="bg-purple-50 border-l-4 border-purple-600 p-6"
              role="note"
              aria-labelledby="gt3-mission"
            >
              <h2 id="gt3-mission" className="sr-only">Missão do GT3</h2>
              <p className="text-lg text-gray-700 leading-relaxed">
                O GT3 estabelece conexões estratégicas entre pesquisadores dos países da CPLP, 
                facilitando colaborações científicas e promovendo o intercâmbio de conhecimento 
                para fortalecer a capacidade investigativa em doenças raras.
              </p>
            </div>
          </div>
        </section>

        {/* Objetivos Específicos */}
        <section className="mb-16" aria-labelledby="objetivos-gt3">
          <div className="bg-white rounded-2xl shadow-lg p-8 md:p-12">
            <h2 id="objetivos-gt3" className="text-3xl font-bold text-gray-900 mb-8 text-center">
              Objetivos da Rede Colaborativa
            </h2>
            
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              <div className="bg-gradient-to-br from-purple-50 to-blue-50 p-6 rounded-xl border border-purple-100">
                <div className="text-3xl mb-4" role="img" aria-label="Conexão">🤝</div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Conexões Estratégicas</h3>
                <p className="text-gray-600">
                  Facilitar o estabelecimento de parcerias entre pesquisadores e instituições 
                  dos países da CPLP.
                </p>
              </div>
              
              <div className="bg-gradient-to-br from-blue-50 to-green-50 p-6 rounded-xl border border-blue-100">
                <div className="text-3xl mb-4" role="img" aria-label="Conhecimento">📚</div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Intercâmbio de Conhecimento</h3>
                <p className="text-gray-600">
                  Promover a troca de experiências, metodologias e descobertas científicas 
                  entre os membros da rede.
                </p>
              </div>
              
              <div className="bg-gradient-to-br from-green-50 to-purple-50 p-6 rounded-xl border border-green-100">
                <div className="text-3xl mb-4" role="img" aria-label="Capacitação">⚡</div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Fortalecimento Investigativo</h3>
                <p className="text-gray-600">
                  Aumentar a capacidade de pesquisa em doenças raras através da colaboração 
                  e recursos compartilhados.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Call to Action */}
        <section className="text-center" aria-labelledby="cta-gt3">
          <div className="bg-gradient-to-r from-purple-600 to-blue-600 rounded-2xl p-8 text-white">
            <h2 id="cta-gt3" className="text-2xl font-bold mb-4">Conecte-se à Rede</h2>
            <p className="text-xl mb-6 opacity-90">
              Pesquisador em doenças raras? Junte-se à nossa rede colaborativa!
            </p>
            <Link 
              href="/equipe" 
              className="inline-block bg-white text-purple-600 px-8 py-3 rounded-lg font-semibold hover:bg-purple-50 transition-colors focus:outline-none focus:ring-4 focus:ring-white focus:ring-opacity-50"
              aria-label="Conhecer a equipe de pesquisadores da rede CPLP-Raras"
            >
              Conheça a Equipe
            </Link>
          </div>
        </section>
      </div>
    </div>
  );
}
