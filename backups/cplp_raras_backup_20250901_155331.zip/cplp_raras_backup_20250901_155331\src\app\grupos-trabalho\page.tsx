import Link from 'next/link';
import { ArrowLeftIcon } from '@heroicons/react/24/outline';
import TopShare from '@/components/TopShare';

const workingGroups = [
  {
    id: 'gt1',
    title: 'GT1 – Mapeamento de Recursos',
    icon: '🗺️',
    description: 'Identificação de centros, profissionais e recursos para doenças raras nos países da CPLP.',
    color: 'from-blue-500 to-blue-600',
    borderColor: 'border-blue-200',
    bgColor: 'bg-blue-50',
    activities: [
      'Mapear centros especializados',
      'Catalogar profissionais da área',
      'Levantar recursos diagnósticos',
      'Documentar tratamentos disponíveis',
      'Avaliar sistemas de saúde'
    ]
  },
  {
    id: 'gt2',
    title: 'GT2 – Plataformas Digitais',
    icon: '💻',
    description: 'Desenvolvimento de ferramentas digitais para registro de casos e apoio clínico.',
    color: 'from-green-500 to-green-600',
    borderColor: 'border-green-200',
    bgColor: 'bg-green-50',
    activities: [
      'Configurar formulários REDCap',
      'Organizar bases de dados',
      'Treinar usuários das ferramentas',
      'Documentar processos digitais',
      'Criar manuais de uso'
    ]
  },
  {
    id: 'gt3',
    title: 'GT3 – Rede de Pesquisa',
    icon: '�',
    description: 'Conectar pesquisadores da CPLP para projetos colaborativos em doenças raras.',
    color: 'from-purple-500 to-purple-600',
    borderColor: 'border-purple-200',
    bgColor: 'bg-purple-50',
    activities: [
      'Identificar pesquisadores ativos',
      'Facilitar parcerias entre países',
      'Coordenar projetos conjuntos',
      'Compartilhar metodologias',
      'Publicar resultados colaborativos'
    ]
  },
  {
    id: 'gt4',
    title: 'GT4 – Protocolos e Dados',
    icon: '📊',
    description: 'Padronização de coleta de dados e desenvolvimento de algoritmos de análise.',
    color: 'from-orange-500 to-orange-600',
    borderColor: 'border-orange-200',
    bgColor: 'bg-orange-50',
    activities: [
      'Definir campos obrigatórios',
      'Padronizar formulários',
      'Organizar dados coletados',
      'Criar relatórios básicos',
      'Validar informações'
    ]
  },
  {
    id: 'gt5',
    title: 'GT5 – Educação e Capacitação',
    icon: '🎓',
    description: 'Treinamento de profissionais e conscientização sobre doenças raras.',
    color: 'from-pink-500 to-pink-600',
    borderColor: 'border-pink-200',
    bgColor: 'bg-pink-50',
    activities: [
      'Criar materiais educativos',
      'Treinar profissionais de saúde',
      'Organizar workshops',
      'Desenvolver cursos online',
      'Capacitar multiplicadores locais'
    ]
  },
  {
    id: 'gt6',
    title: 'GT6 – Comunicação e Sustentabilidade',
    icon: '�',
    description: 'Divulgação de resultados e planejamento da continuidade do projeto.',
    color: 'from-teal-500 to-teal-600',
    borderColor: 'border-teal-200',
    bgColor: 'bg-teal-50',
    activities: [
      'Comunicar resultados obtidos',
      'Engajar stakeholders',
      'Planejar sustentabilidade',
      'Estabelecer parcerias',
      'Documentar lições aprendidas'
    ]
  }
];

export default function WorkingGroupsPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Breadcrumb */}
      <div className="bg-white border-b">
        <div className="mx-auto max-w-7xl px-4 py-4 sm:px-6 lg:px-8">
          <Link 
            href="/"
            className="inline-flex items-center text-blue-600 hover:text-blue-800 transition-colors"
          >
            <ArrowLeftIcon className="h-4 w-4 mr-2" />
            Voltar ao Início
          </Link>
        </div>
      </div>

      <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6 lg:px-8">
        <TopShare 
          title="Grupos de Trabalho - CPLP-Raras"
          description="Conheça os grupos de trabalho especializados da rede CPLP-Raras: mapeamento de recursos, plataformas digitais e estudos colaborativos em doenças raras."
        />
        {/* Header */}
        <div className="text-center mb-10">
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Grupos de Trabalho
          </h1>
          <div className="w-24 h-1 bg-gradient-to-r from-blue-600 to-green-600 mx-auto mb-6"></div>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            O projeto está organizado em 6 grupos de trabalho, cada um com atividades específicas.
          </p>
        </div>

        {/* Working Groups Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-12">
          {workingGroups.map((group) => (
            <div
              key={group.id}
              className={`bg-white rounded-xl shadow-sm border ${group.borderColor} hover:shadow-md transition-shadow`}
            >
              {/* Header */}
              <div className={`bg-gradient-to-r ${group.color} p-5 text-white`}>
                <div className="flex items-center space-x-3">
                  <span className="text-3xl">{group.icon}</span>
                  <h2 className="text-xl font-bold">
                    {group.title}
                  </h2>
                </div>
              </div>
              
              {/* Content */}
              <div className="p-5">
                <p className="text-gray-700 mb-5">
                  {group.description}
                </p>
                
                <h3 className="text-base font-semibold text-gray-900 mb-3">
                  Principais Atividades:
                </h3>
                
                <ul className="space-y-2 mb-5">
                  {group.activities.slice(0, 3).map((activity, index) => (
                    <li key={index} className="flex items-start">
                      <span className="text-blue-600 mr-2 mt-1">•</span>
                      <span className="text-gray-600 text-sm">{activity}</span>
                    </li>
                  ))}
                </ul>
                
                <Link
                  href={`/grupos-trabalho/${group.id}`}
                  className={`inline-flex items-center text-sm font-semibold bg-gradient-to-r ${group.color} bg-clip-text text-transparent hover:opacity-80 transition-opacity`}
                >
                  Ver detalhes
                  <svg
                    className="ml-2 w-4 h-4"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M9 5l7 7-7 7"
                    />
                  </svg>
                </Link>
              </div>
            </div>
          ))}
        </div>

        {/* Overview */}
        <div className="bg-white rounded-xl shadow-sm p-6 mb-8">
          <h2 className="text-xl font-semibold text-gray-900 mb-4 text-center">
            Como Funcionam os Grupos
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="bg-blue-100 rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-3">
                <span className="text-lg font-bold text-blue-600">1</span>
              </div>
              <h3 className="text-base font-semibold text-gray-900 mb-2">Coleta</h3>
              <p className="text-gray-600 text-sm">
                Identificação e levantamento de informações nos países da CPLP.
              </p>
            </div>

            <div className="text-center">
              <div className="bg-green-100 rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-3">
                <span className="text-lg font-bold text-green-600">2</span>
              </div>
              <h3 className="text-base font-semibold text-gray-900 mb-2">Análise</h3>
              <p className="text-gray-600 text-sm">
                Processamento e organização dos dados coletados.
              </p>
            </div>

            <div className="text-center">
              <div className="bg-purple-100 rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-3">
                <span className="text-lg font-bold text-purple-600">3</span>
              </div>
              <h3 className="text-base font-semibold text-gray-900 mb-2">Aplicação</h3>
              <p className="text-gray-600 text-sm">
                Desenvolvimento de ferramentas e recursos práticos.
              </p>
            </div>
          </div>
        </div>

        {/* Call to Action */}
        <div className="bg-gradient-to-r from-blue-600 to-green-600 rounded-xl p-6 text-white text-center">
          <h2 className="text-xl font-bold mb-3">Participar do Projeto</h2>
          <p className="text-lg mb-5 opacity-90">
            Interessado em contribuir? Entre em contato conosco.
          </p>
          <Link
            href="/contato"
            className="inline-block bg-white text-blue-600 px-6 py-3 rounded-lg font-semibold hover:bg-blue-50 transition-colors"
          >
            Fale Conosco
          </Link>
        </div>
      </div>
    </div>
  );
}
