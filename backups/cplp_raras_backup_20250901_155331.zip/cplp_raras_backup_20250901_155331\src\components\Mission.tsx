'use client';

import { useLanguage } from '@/contexts/LanguageContext';

export default function Mission() {
  const { t } = useLanguage();
  return (
    <section className="bg-gradient-to-b from-gray-50 to-white py-16">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <div className="inline-flex items-center space-x-3 mb-4">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-green-600 rounded-full flex items-center justify-center">
              <span className="text-white text-2xl">🎯</span>
            </div>
            <h2 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-green-600 bg-clip-text text-transparent">
              {t('about.mission')}
            </h2>
          </div>
          <div className="w-24 h-1 bg-gradient-to-r from-blue-600 via-purple-500 to-green-600 mx-auto mb-8 rounded-full"></div>
          <p className="text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed">
            {t('about.mission-text')}
          </p>
        </div>
        
        {/* Mapeamento GT1 - Seção destacada */}
        <div className="bg-gradient-to-r from-blue-50 via-indigo-50 to-purple-50 rounded-2xl p-8 mb-12 border border-blue-200">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-center">
            <div className="lg:col-span-2">
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-14 h-14 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-full flex items-center justify-center">
                  <span className="text-white text-2xl">🗺️</span>
                </div>
                <div>
                  <div className="flex items-center space-x-2 mb-1">
                    <span className="bg-blue-500 text-white text-xs font-bold px-2 py-1 rounded-full">GT1</span>
                    <h3 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
                      Mapeamento Colaborativo
                    </h3>
                  </div>
                  <p className="text-sm text-gray-600">Grupo de Trabalho 1 - Mapeamento e Caracterização</p>
                </div>
              </div>
              <p className="text-gray-700 leading-relaxed mb-4">
                <strong>Participe do nosso mapeamento!</strong> Estamos identificando pessoas e instituições 
                envolvidas com doenças raras, genética médica, saúde pública e saúde digital na CPLP. 
                Utilizamos o <strong>método snowball</strong> - onde um participante indica outros, 
                formando uma rede de contatos colaborativa.
              </p>
              <div className="bg-white/60 backdrop-blur-sm rounded-xl p-4 mb-4 border border-blue-200/50">
                <h4 className="font-semibold text-gray-900 mb-2 flex items-center">
                  <span className="text-lg mr-2">📋</span>
                  Como funciona:
                </h4>
                <ul className="text-sm text-gray-700 space-y-1">
                  <li>• <strong>Responda</strong> o formulário com suas informações profissionais</li>
                  <li>• <strong>Indique</strong> colegas e instituições que trabalham com doenças raras</li>
                  <li>• <strong>Ajude</strong> a expandir nossa rede de colaboração internacional</li>
                  <li>• <strong>Contribua</strong> para fortalecer a pesquisa nos países da CPLP</li>
                </ul>
              </div>
            </div>
            <div className="text-center">
              <div className="bg-white rounded-2xl p-6 shadow-lg border border-blue-200">
                <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-white text-2xl">📝</span>
                </div>
                <h4 className="text-lg font-bold text-gray-900 mb-3">Formulário Ativo</h4>
                <p className="text-sm text-gray-600 mb-4">
                  Tempo estimado: 5-10 minutos
                </p>
                <a
                  href="https://redcap.link/cplpDR"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center bg-gradient-to-r from-blue-500 to-indigo-600 text-white font-semibold px-6 py-3 rounded-lg hover:from-blue-600 hover:to-indigo-700 transition-all duration-200 transform hover:scale-105 shadow-lg group"
                >
                  <span>Participar Agora</span>
                  <svg className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                  </svg>
                </a>
                <p className="text-xs text-gray-500 mt-3">
                  Plataforma segura RedCap
                </p>
              </div>
            </div>
          </div>
        </div>
        
        {/* Pesquisa Colaborativa destacada */}
        <div className="bg-gradient-to-r from-pink-50 via-purple-50 to-blue-50 rounded-2xl p-8 mb-12 border border-pink-200">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
            <div>
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-12 h-12 bg-gradient-to-br from-pink-500 to-purple-600 rounded-full flex items-center justify-center">
                  <span className="text-white text-xl">🧬</span>
                </div>
                <h3 className="text-2xl font-bold bg-gradient-to-r from-pink-600 to-purple-600 bg-clip-text text-transparent">
                  Pesquisa Colaborativa
                </h3>
              </div>
              <p className="text-gray-700 leading-relaxed mb-4">
                Conectando pesquisadores e especialistas dos países da CPLP para enfrentar 
                os desafios das doenças raras através de uma rede internacional de colaboração científica.
              </p>
              <div className="flex items-center space-x-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-pink-600">5</div>
                  <div className="text-xs text-gray-600">Países</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-purple-600">6</div>
                  <div className="text-xs text-gray-600">GTs</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600">+</div>
                  <div className="text-xs text-gray-600">Rede</div>
                </div>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-white/60 backdrop-blur-sm rounded-xl p-4 text-center border border-pink-200/50">
                <span className="text-3xl mb-2 block">🌍</span>
                <p className="text-sm text-gray-700">Rede Internacional</p>
              </div>
              <div className="bg-white/60 backdrop-blur-sm rounded-xl p-4 text-center border border-purple-200/50">
                <span className="text-3xl mb-2 block">🔬</span>
                <p className="text-sm text-gray-700">Pesquisa Avançada</p>
              </div>
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-white rounded-xl p-8 shadow-lg hover:shadow-xl transition-all duration-200 border border-blue-100 hover:border-blue-200">
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
                <span className="text-2xl text-white">🗺️</span>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">
                Mapeamento Informacional
              </h3>
              <p className="text-gray-600">
                Levantamento de dados, iniciativas e recursos existentes sobre doenças raras nos países da CPLP.
              </p>
            </div>
          </div>
          
          <div className="bg-white rounded-xl p-8 shadow-lg hover:shadow-xl transition-all duration-200 border border-green-100 hover:border-green-200">
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-green-600 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
                <span className="text-2xl text-white">💻</span>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">
                Tecnologias em Saúde Digital
              </h3>
              <p className="text-gray-600">
                Desenvolvimento de ferramentas digitais para apoio à decisão clínica e registro de casos.
              </p>
            </div>
          </div>
          
          <div className="bg-white rounded-xl p-8 shadow-lg hover:shadow-xl transition-all duration-200 border border-purple-100 hover:border-purple-200">
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
                <span className="text-2xl text-white">🤝</span>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">
                Cooperação Científica
              </h3>
              <p className="text-gray-600">
                Promoção da colaboração entre pesquisadores, clínicos e organizações dos países da CPLP.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
