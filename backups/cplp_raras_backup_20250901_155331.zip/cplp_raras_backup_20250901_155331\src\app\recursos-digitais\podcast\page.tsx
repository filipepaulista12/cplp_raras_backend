'use client';

import { Metadata } from 'next';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import Link from 'next/link';
import { useState, useEffect } from 'react';
import TopShare from '@/components/TopShare';

// Interface para episódios do RSS
interface RSSEpisode {
  title: string;
  description: string;
  pubDate: string;
  duration: string;
  link: string;
  guid: string;
}

export default function PodcastPage() {
  const [showEmbedPlayer, setShowEmbedPlayer] = useState(false);
  const [rssEpisodes, setRssEpisodes] = useState<RSSEpisode[]>([]);
  const [loadingRSS, setLoadingRSS] = useState(true);

  // Função para buscar episódios do RSS
  useEffect(() => {
    const fetchRSSEpisodes = async () => {
      try {
        // Usando um proxy CORS para acessar o RSS
        const proxyUrl = 'https://api.allorigins.win/raw?url=';
        const rssUrl = 'https://anchor.fm/s/10893f02c/podcast/rss';
        
        const response = await fetch(proxyUrl + encodeURIComponent(rssUrl));
        const xmlText = await response.text();
        
        // Parse simples do XML (em produção, usar uma biblioteca como xml2js)
        const parser = new DOMParser();
        const xmlDoc = parser.parseFromString(xmlText, 'text/xml');
        const items = xmlDoc.querySelectorAll('item');
        
        const episodes: RSSEpisode[] = Array.from(items).slice(0, 6).map(item => {
          // Tenta extrair duração de diferentes tags
          let duration = 
            item.querySelector('itunes\\:duration')?.textContent ||
            item.querySelector('duration')?.textContent ||
            item.querySelector('podcast\\:duration')?.textContent ||
            'Duração não disponível';
          
          // Se a duração está em segundos, converte para mm:ss
          if (duration && !isNaN(Number(duration))) {
            const totalSeconds = parseInt(duration);
            const minutes = Math.floor(totalSeconds / 60);
            const seconds = totalSeconds % 60;
            duration = `${minutes}:${seconds.toString().padStart(2, '0')}`;
          }
          
          return {
            title: item.querySelector('title')?.textContent || 'Sem título',
            description: item.querySelector('description')?.textContent?.replace(/<[^>]*>/g, '').substring(0, 150) + '...' || 'Sem descrição',
            pubDate: item.querySelector('pubDate')?.textContent || '',
            duration: duration,
            link: item.querySelector('link')?.textContent || '',
            guid: item.querySelector('guid')?.textContent || ''
          };
        });
        
        setRssEpisodes(episodes);
      } catch (error) {
        console.error('Erro ao buscar RSS:', error);
        // Fallback para dados estáticos em caso de erro
        setRssEpisodes([
          {
            title: "O futuro do cuidado em doenças raras",
            description: "Discussão sobre inovações e perspectivas futuras no cuidado de doenças raras nos países da CPLP...",
            pubDate: "Fri, 25 Aug 2025 10:00:00 GMT",
            duration: "28:45",
            link: "https://open.spotify.com/show/7lHPJGjhWTmthZxZJ0IAJX",
            guid: "episode-20"
          },
          {
            title: "Políticas Públicas em Angola",
            description: "Análise das políticas de saúde para doenças raras implementadas em Angola e seus resultados...",
            pubDate: "Mon, 21 Aug 2025 15:30:00 GMT",
            duration: "32:12",
            link: "https://open.spotify.com/show/7lHPJGjhWTmthZxZJ0IAJX",
            guid: "episode-19"
          },
          {
            title: "Avanços no Brasil",
            description: "Novidades em pesquisa e tratamento de doenças raras no sistema de saúde brasileiro...",
            pubDate: "Wed, 16 Aug 2025 09:15:00 GMT",
            duration: "26:30",
            link: "https://open.spotify.com/show/7lHPJGjhWTmthZxZJ0IAJX",
            guid: "episode-18"
          }
        ]);
      } finally {
        setLoadingRSS(false);
      }
    };

    fetchRSSEpisodes();
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-blue-50 to-purple-50">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* Breadcrumb */}
        <div className="mb-6 text-sm text-gray-600">
          <Link href="/recursos-digitais" className="hover:text-blue-600">Recursos Digitais</Link>
          <span className="mx-2">→</span>
          <span>Podcast CPLP-Raras</span>
        </div>

        {/* Compartilhamento no topo */}
        <TopShare 
          title="🎙️ Podcast CPLP-Raras" 
          description="Conectando os países de língua portuguesa através de conversas sobre doenças raras, saúde pública e inovação médica."
        />

        {/* Header */}
        <div className="text-center mb-10">
          <div className="text-6xl mb-4">🎧</div>
          <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-green-600 via-blue-600 to-purple-600 bg-clip-text text-transparent mb-6">
            Podcast CPLP-Raras
          </h1>
          <p className="text-xl text-gray-700 max-w-3xl mx-auto leading-relaxed mb-6">
            Conversas semanais sobre doenças raras na Comunidade dos Países de Língua Portuguesa
          </p>
          
          {/* Importante sobre IA */}
          <div className="max-w-4xl mx-auto mb-6 bg-gradient-to-r from-yellow-50 to-orange-50 border border-yellow-200 rounded-lg p-4">
            <div className="flex items-center justify-center gap-3 mb-2">
              <span className="text-2xl">🤖</span>
              <h3 className="font-bold text-lg text-gray-800">Conteúdo Inteligente e Validado</h3>
            </div>
            <p className="text-sm text-gray-700 text-center leading-relaxed">
              <strong>Todo conteúdo é gerado com Inteligência Artificial</strong> baseado em evidências científicas 
              e <strong>validado por especialistas</strong> em doenças raras da comunidade CPLP.
            </p>
          </div>
          <div className="flex justify-center items-center gap-4 flex-wrap">
            <Badge className="bg-green-100 text-green-800 text-sm px-4 py-2">
              📅 Episódios Semanais
            </Badge>
            <Badge className="bg-blue-100 text-blue-800 text-sm px-4 py-2">
              🌍 Conteúdo Lusófono
            </Badge>
            <Badge className="bg-purple-100 text-purple-800 text-sm px-4 py-2">
              🏥 Foco em Doenças Raras
            </Badge>
          </div>
        </div>

        {/* Player Section */}
        <Card className="mb-8 bg-gradient-to-r from-green-100 to-blue-100">
          <CardContent className="p-8">
            <h2 className="text-2xl font-bold text-center mb-6 text-gray-800">
              🎵 Ouça o Podcast
            </h2>
            
            <div className="flex flex-col lg:flex-row items-center justify-center gap-6">
              
              {/* Spotify Embed Player */}
              <div className="w-full lg:w-2/3">
                {showEmbedPlayer ? (
                  <div className="bg-white rounded-lg p-4 shadow-md">
                    <iframe 
                      style={{borderRadius: '12px'}} 
                      src="https://open.spotify.com/embed/show/7lHPJGjhWTmthZxZJ0IAJX?utm_source=generator&theme=0" 
                      width="100%" 
                      height="352" 
                      frameBorder="0" 
                      allowFullScreen 
                      allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" 
                      loading="lazy"
                      title="Podcast CPLP-Raras no Spotify"
                    />
                  </div>
                ) : (
                  <div className="bg-white rounded-lg p-8 shadow-md text-center">
                    <div className="text-4xl mb-4">🎧</div>
                    <h3 className="text-lg font-semibold text-gray-800 mb-4">
                      Player do Spotify
                    </h3>
                    <p className="text-gray-600 mb-6">
                      Clique no botão abaixo para carregar o player integrado do Spotify
                    </p>
                    <button
                      onClick={() => setShowEmbedPlayer(true)}
                      className="bg-green-600 hover:bg-green-700 text-white font-semibold py-3 px-6 rounded-lg transition-colors duration-200"
                    >
                      📻 Carregar Player
                    </button>
                  </div>
                )}
              </div>

              {/* Spotify Direct Link */}
              <div className="w-full lg:w-1/3">
                <div className="bg-gradient-to-br from-green-600 to-green-700 text-white p-6 rounded-xl text-center shadow-lg">
                  <div className="text-3xl mb-4">🟢</div>
                  <h3 className="text-xl font-bold mb-4">Ouça no Spotify</h3>
                  <p className="text-green-100 mb-6 text-sm">
                    Acesse diretamente no aplicativo do Spotify para a melhor experiência
                  </p>
                  <a
                    href="https://open.spotify.com/show/7lHPJGjhWTmthZxZJ0IAJX?si=qWmnQRsYSjCM0tsKcm618Q"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 bg-white text-green-600 font-semibold py-3 px-6 rounded-lg hover:bg-green-50 transition-colors duration-200"
                  >
                    <span>🎧</span>
                    Abrir no Spotify
                  </a>
                </div>
              </div>

            </div>
          </CardContent>
        </Card>

        {/* Sobre o Podcast */}
        <Card className="mb-8">
          <CardContent className="p-8">
            <h2 className="text-3xl font-bold text-center mb-8 text-gray-800">
              📋 Sobre o Podcast
            </h2>
            
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              <div className="bg-blue-50 p-6 rounded-lg text-center">
                <div className="text-3xl mb-3">📅</div>
                <h3 className="font-bold text-lg text-blue-800 mb-2">Frequência</h3>
                <p className="text-blue-700 font-semibold">Episódios Regulares</p>
                <p className="text-sm text-blue-600 mt-2">Conforme disponibilidade</p>
              </div>
              
              <div className="bg-green-50 p-6 rounded-lg text-center">
                <div className="text-3xl mb-3">🌍</div>
                <h3 className="font-bold text-lg text-green-800 mb-2">Alcance</h3>
                <p className="text-green-700 font-semibold">9 Países da CPLP</p>
                <p className="text-sm text-green-600 mt-2">Conteúdo em português</p>
              </div>
              
              <div className="bg-purple-50 p-6 rounded-lg text-center">
                <div className="text-3xl mb-3">🎯</div>
                <h3 className="font-bold text-lg text-purple-800 mb-2">Foco</h3>
                <p className="text-purple-700 font-semibold">Doenças Raras</p>
                <p className="text-sm text-purple-600 mt-2">Saúde, educação e comunidade</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Lista de Episódios */}
        <Card className="mb-8">
          <CardContent className="p-8">
            <h2 className="text-3xl font-bold text-center mb-8 text-gray-800">
              📂 Episódios Recentes
            </h2>
            
            {loadingRSS ? (
              <div className="text-center py-8">
                <div className="text-4xl mb-4">🔄</div>
                <p className="text-gray-600">Carregando episódios...</p>
              </div>
            ) : (
              <div className="space-y-4">
                {rssEpisodes.map((episodio, index) => (
                  <div key={index} className="flex items-center justify-between p-6 bg-gradient-to-r from-white to-gray-50 rounded-lg border-l-4 border-blue-400 hover:shadow-md transition-shadow">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-blue-600 text-white rounded-full flex items-center justify-center font-bold">
                        {rssEpisodes.length - index}
                      </div>
                      <div>
                        <h3 className="font-semibold text-lg text-gray-800">{episodio.title}</h3>
                        <p className="text-gray-600 text-sm mt-1">{episodio.description}</p>
                        <div className="flex items-center gap-4 mt-2 text-xs text-gray-500">
                          <span>📅 {new Date(episodio.pubDate).toLocaleDateString('pt-BR')}</span>
                          <span>⏱️ {episodio.duration}</span>
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <a
                        href={episodio.link || "https://open.spotify.com/show/7lHPJGjhWTmthZxZJ0IAJX"}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-2 text-green-600 hover:text-green-800 font-medium text-sm"
                      >
                        ▶️ Ouvir
                      </a>
                    </div>
                  </div>
                ))}
              </div>
            )}
            
            <div className="text-center mt-8">
              <p className="text-gray-600 mb-4">
                {rssEpisodes.length > 0 ? `${rssEpisodes.length} episódios mais recentes` : 'Mais episódios disponíveis no Spotify'}
              </p>
              <a
                href="https://open.spotify.com/show/7lHPJGjhWTmthZxZJ0IAJX?si=qWmnQRsYSjCM0tsKcm618Q"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white font-semibold py-3 px-6 rounded-lg transition-colors duration-200"
              >
                🎧 Ver Todos os Episódios
              </a>
            </div>
          </CardContent>
        </Card>

        {/* Inscreva-se */}
        <Card className="bg-gradient-to-r from-purple-100 to-pink-100">
          <CardContent className="p-8 text-center">
            <h2 className="text-2xl font-bold mb-4 text-gray-800">
              📱 Não Perca Nenhum Episódio
            </h2>
            <p className="text-gray-700 mb-6 max-w-2xl mx-auto">
              Siga o podcast no Spotify para receber notificações sempre que um novo episódio for lançado. 
              Novos episódios disponibilizados regularmente!
            </p>
            
            <div className="flex justify-center gap-4 flex-wrap">
              <a
                href="https://open.spotify.com/show/7lHPJGjhWTmthZxZJ0IAJX?si=qWmnQRsYSjCM0tsKcm618Q"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white font-semibold py-3 px-6 rounded-lg transition-colors duration-200"
              >
                ➕ Seguir no Spotify
              </a>
              
              <a
                href="/contato"
                className="inline-flex items-center gap-2 bg-purple-600 hover:bg-purple-700 text-white font-semibold py-3 px-6 rounded-lg transition-colors duration-200"
              >
                💬 Sugerir Temas
              </a>
            </div>
            
            <div className="mt-6 grid md:grid-cols-3 gap-4 text-sm text-gray-600">
              <div>
                <span className="font-semibold">📧 Newsletter:</span>
                <p>Resumos dos episódios por email</p>
              </div>
              <div>
                <span className="font-semibold">🔔 Notificações:</span>
                <p>Alertas de novos lançamentos</p>
              </div>
              <div>
                <span className="font-semibold">💡 Participação:</span>
                <p>Envie suas perguntas e sugestões</p>
              </div>
            </div>
          </CardContent>
        </Card>

      </div>
    </div>
  );
}
