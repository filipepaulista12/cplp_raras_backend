import type { Metadata } from 'next'
import HPONavigation from '@/components/HPONavigation'

export const metadata: Metadata = {
  title: 'HPO Translator CPLP',
  description: 'Plataforma colaborativa para tradução da Human Phenotype Ontology para português',
  keywords: 'HPO, ontologia, tradução, fenótipos, doenças raras, CPLP'
}

export default function HPOLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <div className="min-h-screen bg-gray-50">
      <HPONavigation />
      <main className="container mx-auto px-4 py-8">
        {children}
      </main>
    </div>
  )
}
