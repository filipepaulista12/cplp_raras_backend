'use client'

import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { HPOTerm, Translation, Translator, HPOStats } from '@/types/hpo';

interface HPOStore {
  // Estado
  terms: HPOTerm[];
  translations: Translation[];
  translators: Translator[];
  currentTranslator: string;
  
  // Ações
  setTerms: (terms: HPOTerm[]) => void;
  addTranslation: (translation: Translation) => void;
  updateTranslation: (id: string, updates: Partial<Translation>) => void;
  getTermById: (id: string) => HPOTerm | undefined;
  getTranslationsByTerm: (termId: string) => Translation[];
  setCurrentTranslator: (translator: string) => void;
  updateTermStatus: (termId: string, status: HPOTerm['status']) => void;
  
  // Estatísticas
  getStats: () => HPOStats;
}

export const useHPOStore = create<HPOStore>()(
  persist(
    (set, get) => ({
      terms: [],
      translations: [],
      translators: [
        {
          id: '1',
          name: 'Dr. Ana Silva',
          bio: 'Geneticista clínica, especialista em doenças raras',
          expertise: ['genética', 'dismorfologia'],
          contributions: 0
        },
        {
          id: '2', 
          name: 'Prof. Carlos Santos',
          bio: 'Neurologista pediátrico, pesquisador em fenótipos neurológicos',
          expertise: ['neurologia', 'pediatria'],
          contributions: 0
        },
        {
          id: '3',
          name: 'Dra. Maria Oliveira',
          bio: 'Bioinformática, especialista em ontologias médicas',
          expertise: ['bioinformática', 'ontologias'],
          contributions: 0
        }
      ],
      currentTranslator: 'Dr. Ana Silva',
      
      setTerms: (terms) => set({ terms }),
      
      addTranslation: (translation) => set((state) => {
        const newTranslations = [...state.translations, translation];
        
        // Atualizar status do termo se necessário
        const termTranslations = newTranslations.filter(t => t.term_id === translation.term_id);
        const updatedTerms = state.terms.map(term => {
          if (term.id === translation.term_id) {
            let newStatus = term.status;
            if (termTranslations.length >= 2 && term.status === 'candidate') {
              newStatus = 'under_review';
            }
            if (termTranslations.some(t => t.is_final)) {
              newStatus = 'official';
            }
            
            return {
              ...term,
              status: newStatus,
              updated_at: new Date().toISOString()
            };
          }
          return term;
        });
        
        return {
          translations: newTranslations,
          terms: updatedTerms
        };
      }),
      
      updateTranslation: (id, updates) => set((state) => ({
        translations: state.translations.map(t => 
          t.id === id ? { ...t, ...updates } : t
        )
      })),
      
      getTermById: (id) => get().terms.find(term => term.id === id),
      
      getTranslationsByTerm: (termId) => 
        get().translations.filter(t => t.term_id === termId),
      
      setCurrentTranslator: (translator) => set({ currentTranslator: translator }),
      
      updateTermStatus: (termId, status) => set((state) => ({
        terms: state.terms.map(term =>
          term.id === termId 
            ? { ...term, status, updated_at: new Date().toISOString() }
            : term
        )
      })),
      
      getStats: () => {
        const { terms, translations } = get();
        const total = terms.length;
        const candidate = terms.filter(t => t.status === 'candidate').length;
        const under_review = terms.filter(t => t.status === 'under_review').length;
        const official = terms.filter(t => t.status === 'official').length;
        
        const scores = translations.map(t => t.likert_score).filter(s => s > 0);
        const avg_likert = scores.length > 0 
          ? Number((scores.reduce((a, b) => a + b, 0) / scores.length).toFixed(1))
          : 0;
        
        return { total, candidate, under_review, official, avg_likert };
      }
    }),
    {
      name: 'hpo-translator-storage',
    }
  )
);
