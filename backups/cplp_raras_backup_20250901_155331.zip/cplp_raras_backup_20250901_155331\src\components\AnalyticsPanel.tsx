'use client';

import { useState } from 'react';
import { useInteractionData } from '@/hooks/useInteractionData';
import { 
  ChartBarIcon, 
  ChatBubbleLeftRightIcon,
  StarIcon,
  EyeIcon,
  ArrowDownTrayIcon,
  TrashIcon,
  XMarkIcon
} from '@heroicons/react/24/outline';
import { StarIcon as StarSolid } from '@heroicons/react/24/solid';

interface AnalyticsPanelProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function AnalyticsPanel({ isOpen, onClose }: AnalyticsPanelProps) {
  const { data, exportData, clearData } = useInteractionData();
  const [activeTab, setActiveTab] = useState<'overview' | 'feedback' | 'details'>('overview');

  if (!isOpen) return null;

  const formatDate = (timestamp: string) => {
    return new Date(timestamp).toLocaleString('pt-BR');
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      <div className="flex min-h-full items-center justify-center p-4">
        <div 
          className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity"
          onClick={onClose}
        />
        
        <div className="relative bg-white rounded-2xl shadow-xl max-w-6xl w-full max-h-[90vh] overflow-hidden">
          {/* Header */}
          <div className="bg-gradient-to-r from-orange-600 to-amber-600 px-6 py-4 text-white">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold flex items-center">
                <ChartBarIcon className="h-6 w-6 mr-2" />
                Analytics CPLP-Raras
              </h2>
              <button
                onClick={onClose}
                className="text-white hover:text-gray-200 transition-colors"
              >
                <XMarkIcon className="h-6 w-6" />
              </button>
            </div>
            
            {/* Tabs */}
            <div className="mt-4 flex space-x-4">
              {[
                { id: 'overview', label: 'Visão Geral', icon: ChartBarIcon },
                { id: 'feedback', label: 'Feedbacks', icon: ChatBubbleLeftRightIcon },
                { id: 'details', label: 'Detalhes', icon: EyeIcon }
              ].map((tab) => {
                const Icon = tab.icon;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id as any)}
                    className={`flex items-center px-4 py-2 rounded-lg transition-colors ${
                      activeTab === tab.id
                        ? 'bg-white text-orange-600'
                        : 'text-white hover:bg-white hover:bg-opacity-20'
                    }`}
                  >
                    <Icon className="h-4 w-4 mr-2" />
                    {tab.label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Content */}
          <div className="p-6 max-h-[calc(90vh-200px)] overflow-y-auto">
            
            {/* Overview Tab */}
            {activeTab === 'overview' && (
              <div className="space-y-6">
                {/* Estatísticas principais */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="bg-blue-50 border border-blue-200 rounded-xl p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-blue-600 font-medium">Total de Visitas</p>
                        <p className="text-3xl font-bold text-blue-800">
                          {data.totalVisits.toLocaleString('pt-BR')}
                        </p>
                      </div>
                      <EyeIcon className="h-12 w-12 text-blue-600 opacity-50" />
                    </div>
                  </div>

                  <div className="bg-green-50 border border-green-200 rounded-xl p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-green-600 font-medium">Visitantes Únicos</p>
                        <p className="text-3xl font-bold text-green-800">
                          {data.uniqueVisitors.toLocaleString('pt-BR')}
                        </p>
                      </div>
                      <div className="h-12 w-12 bg-green-600 rounded-full flex items-center justify-center text-white text-2xl">
                        👤
                      </div>
                    </div>
                  </div>

                  <div className="bg-orange-50 border border-orange-200 rounded-xl p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-orange-600 font-medium">Total Feedbacks</p>
                        <p className="text-3xl font-bold text-orange-800">
                          {data.totalFeedback.toLocaleString('pt-BR')}
                        </p>
                      </div>
                      <ChatBubbleLeftRightIcon className="h-12 w-12 text-orange-600 opacity-50" />
                    </div>
                  </div>
                </div>

                {/* Feedback por tipo */}
                <div className="bg-white border border-gray-200 rounded-xl p-6">
                  <h3 className="text-xl font-bold text-gray-900 mb-4">📊 Feedback por Tipo</h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {Object.entries(data.feedbackByType).map(([type, count]) => (
                      <div key={type} className="bg-gray-50 rounded-lg p-4">
                        <div className="flex items-center justify-between">
                          <span className="font-medium capitalize text-gray-700">{
                            type === 'suggestion' ? '💡 Sugestões' :
                            type === 'rating' ? '⭐ Avaliações' :
                            '🚨 Erros'
                          }</span>
                          <span className="text-2xl font-bold text-gray-900">{count}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Rating médio */}
                {data.averageRating > 0 && (
                  <div className="bg-white border border-gray-200 rounded-xl p-6">
                    <h3 className="text-xl font-bold text-gray-900 mb-4">⭐ Avaliação Média</h3>
                    <div className="flex items-center space-x-4">
                      <div className="flex">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <StarSolid
                            key={star}
                            className={`h-8 w-8 ${
                              star <= Math.round(data.averageRating)
                                ? 'text-yellow-400'
                                : 'text-gray-300'
                            }`}
                          />
                        ))}
                      </div>
                      <span className="text-3xl font-bold text-gray-900">
                        {data.averageRating.toFixed(1)}
                      </span>
                      <span className="text-gray-500">
                        ({Object.values(data.feedbackByType).reduce((a, b) => a + b, 0)} avaliações)
                      </span>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Feedback Tab */}
            {activeTab === 'feedback' && (
              <div className="space-y-6">
                <h3 className="text-xl font-bold text-gray-900">📝 Feedbacks Recentes</h3>
                
                {data.recentFeedback.length === 0 ? (
                  <div className="text-center py-12">
                    <ChatBubbleLeftRightIcon className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-500">Nenhum feedback recebido ainda</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {data.recentFeedback.map((feedback) => (
                      <div key={feedback.id} className="bg-white border border-gray-200 rounded-xl p-4">
                        <div className="flex items-start justify-between mb-2">
                          <div className="flex items-center space-x-2">
                            <span className={`px-2 py-1 rounded text-xs font-medium ${
                              feedback.type === 'suggestion' ? 'bg-blue-100 text-blue-800' :
                              feedback.type === 'rating' ? 'bg-yellow-100 text-yellow-800' :
                              'bg-red-100 text-red-800'
                            }`}>
                              {feedback.type === 'suggestion' ? '💡 Sugestão' :
                               feedback.type === 'rating' ? '⭐ Avaliação' :
                               '🚨 Erro'}
                            </span>
                            <span className="px-2 py-1 bg-gray-100 text-gray-800 text-xs rounded">
                              {feedback.category}
                            </span>
                            {feedback.rating && (
                              <div className="flex">
                                {[1, 2, 3, 4, 5].map((star) => (
                                  <StarSolid
                                    key={star}
                                    className={`h-4 w-4 ${
                                      star <= feedback.rating!
                                        ? 'text-yellow-400'
                                        : 'text-gray-300'
                                    }`}
                                  />
                                ))}
                              </div>
                            )}
                          </div>
                          <span className="text-sm text-gray-500">
                            {formatDate(feedback.timestamp)}
                          </span>
                        </div>
                        
                        <p className="text-gray-700 mb-2">{feedback.message}</p>
                        
                        <div className="flex items-center justify-between text-sm text-gray-500">
                          <span>Página: <code className="bg-gray-100 px-1 rounded">{feedback.page}</code></span>
                          {feedback.email && (
                            <span>📧 {feedback.email}</span>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Details Tab */}
            {activeTab === 'details' && (
              <div className="space-y-6">
                <h3 className="text-xl font-bold text-gray-900">🔍 Dados Detalhados</h3>
                
                {/* Feedback por categoria */}
                <div className="bg-white border border-gray-200 rounded-xl p-6">
                  <h4 className="font-bold text-gray-900 mb-4">Feedback por Categoria</h4>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    {Object.entries(data.feedbackByCategory).map(([category, count]) => (
                      <div key={category} className="bg-gray-50 rounded-lg p-3">
                        <div className="text-sm font-medium text-gray-700">{category}</div>
                        <div className="text-xl font-bold text-gray-900">{count}</div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Informações técnicas */}
                <div className="bg-white border border-gray-200 rounded-xl p-6">
                  <h4 className="font-bold text-gray-900 mb-4">ℹ️ Informações do Sistema</h4>
                  <div className="space-y-2 text-sm">
                    <p><strong>Dados salvos em:</strong> localStorage do navegador</p>
                    <p><strong>Último carregamento:</strong> {new Date().toLocaleString('pt-BR')}</p>
                    <p><strong>Chaves de armazenamento:</strong></p>
                    <ul className="ml-4 space-y-1 text-xs text-gray-600">
                      <li>• cplp-visits (total de visitas)</li>
                      <li>• cplp-unique-visitors (visitantes únicos)</li>
                      <li>• cplp-feedback (dados de feedback)</li>
                      <li>• cplp-feedback-count (contador de feedback)</li>
                    </ul>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Footer com ações */}
          <div className="border-t border-gray-200 px-6 py-4 bg-gray-50">
            <div className="flex items-center justify-between">
              <div className="text-sm text-gray-500">
                Dados atualizados em tempo real • Total: {data.totalVisits + data.totalFeedback} interações
              </div>
              <div className="flex space-x-3">
                <button
                  onClick={exportData}
                  className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  <ArrowDownTrayIcon className="h-4 w-4 mr-2" />
                  Exportar Dados
                </button>
                <button
                  onClick={clearData}
                  className="flex items-center px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
                >
                  <TrashIcon className="h-4 w-4 mr-2" />
                  Limpar Dados
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
