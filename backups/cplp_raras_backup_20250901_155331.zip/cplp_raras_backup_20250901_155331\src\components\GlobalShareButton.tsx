'use client';

import ShareButton from './ShareButton';
import { usePathname } from 'next/navigation';

interface PageTitles {
  [key: string]: {
    title: string;
    description: string;
    hashtags: string[];
  }
}

export default function GlobalShareButton() {
  const pathname = usePathname();

  // Configurações específicas por página
  const pageTitles: PageTitles = {
    '/': {
      title: 'CPLP-Raras - Plataforma sobre Doenças Raras',
      description: 'Plataforma colaborativa sobre doenças raras nos países de língua portuguesa (CPLP).',
      hashtags: ['DoençasRaras', 'CPLP', 'Saúde']
    },
    '/sobre/cplp': {
      title: '🌍 CPLP - Comunidade dos Países de Língua Portuguesa',
      description: 'Conheça a CPLP e a distribuição global do idioma português nos países membros.',
      hashtags: ['CPLP', 'PaísesLusófonos', 'LínguaPortuguesa', 'DoençasRaras']
    },
    '/recursos-digitais/podcast': {
      title: '🎙️ Podcast CPLP-Raras',
      description: 'Conectando os países de língua portuguesa através de conversas sobre doenças raras.',
      hashtags: ['DoençasRaras', 'CPLP', 'Podcast', 'Saúde', 'PaísesLusófonos']
    },
    '/grupos-trabalho/gt1': {
      title: '🔬 GT1 - Grupo de Trabalho 1 | CPLP-Raras',
      description: 'Pesquisa e desenvolvimento em doenças raras no âmbito da CPLP.',
      hashtags: ['GT1', 'DoençasRaras', 'CPLP', 'Pesquisa']
    },
    '/grupos-trabalho/gt2': {
      title: '🏥 GT2 - Grupo de Trabalho 2 | CPLP-Raras',
      description: 'Políticas públicas e assistência em doenças raras nos países da CPLP.',
      hashtags: ['GT2', 'DoençasRaras', 'CPLP', 'PolíticasPublicas']
    },
    '/contato': {
      title: '📧 Contato | CPLP-Raras',
      description: 'Entre em contato com a equipe da plataforma CPLP-Raras.',
      hashtags: ['Contato', 'CPLP', 'DoençasRaras']
    },
    '/equipe': {
      title: '👥 Equipe | CPLP-Raras',
      description: 'Conheça a equipe multidisciplinar da plataforma CPLP-Raras.',
      hashtags: ['Equipe', 'CPLP', 'DoençasRaras', 'Especialistas']
    }
  };

  // Configuração padrão para páginas não mapeadas
  const getPageConfig = () => {
    const config = pageTitles[pathname];
    if (config) return config;

    // Gerar título baseado no pathname
    const segments = pathname.split('/').filter(Boolean);
    const lastSegment = segments[segments.length - 1];
    const pageTitle = lastSegment 
      ? lastSegment.replace(/-/g, ' ').replace(/\b\w/g, l => l.toUpperCase())
      : 'CPLP-Raras';

    return {
      title: `${pageTitle} | CPLP-Raras`,
      description: 'Conteúdo sobre doenças raras na Comunidade dos Países de Língua Portuguesa.',
      hashtags: ['DoençasRaras', 'CPLP', 'Saúde']
    };
  };

  const { title, description, hashtags } = getPageConfig();

  return (
    <ShareButton 
      title={title}
      description={description}
      hashtags={hashtags}
    />
  );
}
