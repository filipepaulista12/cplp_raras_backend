# Script Simples de Configuracao da Base de Dados GARD-BR
# ========================================================

Write-Host "Configurando Base de Dados GARD-BR..." -ForegroundColor Green

# Tentar senhas comuns
$passwords = @("postgres", "admin", "password", "123456", "")

Write-Host "Testando conexoes PostgreSQL..." -ForegroundColor Yellow

foreach ($pwd in $passwords) {
    $env:PGPASSWORD = $pwd
    Write-Host "Tentando senha: '$pwd'" -ForegroundColor Yellow
    
    try {
        $result = & "C:\Program Files\PostgreSQL\17\bin\psql" -U postgres -d postgres -h localhost -p 5432 -c "SELECT 1;" -t -q 2>&1
        
        if ($LASTEXITCODE -eq 0) {
            Write-Host "SUCESSO! Senha funcionou: '$pwd'" -ForegroundColor Green
            
            # Criar base de dados
            Write-Host "Criando base de dados orphanet_db..." -ForegroundColor Yellow
            & "C:\Program Files\PostgreSQL\17\bin\createdb" -U postgres -h localhost -p 5432 orphanet_db 2>$null
            
            # Atualizar .env
            $databaseUrl = "postgresql://postgres:$pwd@localhost:5432/orphanet_db"
            $envPath = ".env"
            
            if (Test-Path $envPath) {
                (Get-Content $envPath) -replace 'DATABASE_URL=.*', "DATABASE_URL=`"$databaseUrl`"" | Set-Content $envPath
                Write-Host "Arquivo .env atualizado" -ForegroundColor Green
            }
            
            Write-Host "Configuracao concluida!" -ForegroundColor Green
            Write-Host "Execute: npx prisma db push" -ForegroundColor Cyan
            exit 0
        }
    } catch {
        Write-Host "Senha '$pwd' falhou" -ForegroundColor Red
    }
}

Write-Host "NENHUMA senha funcionou. Configure manualmente o PostgreSQL." -ForegroundColor Red
