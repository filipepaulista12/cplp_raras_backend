# 🔐 SCRIPT DE CONFIGURAÇÃO POSTGRESQL - EXECUTAR COMO ADMINISTRADOR
# =================================================================

Write-Host "🚀 Configurando PostgreSQL para CPLP-RARAS..." -ForegroundColor Green
Write-Host ""

# Verificar se está executando como Administrador
$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")

if (-not $isAdmin) {
    Write-Host "❌ ERRO: Este script deve ser executado como Administrador!" -ForegroundColor Red
    Write-Host "   Clique com botão direito no PowerShell > Executar como Administrador" -ForegroundColor Yellow
    Read-Host "Pressione Enter para sair"
    exit 1
}

Write-Host "✅ Executando como Administrador" -ForegroundColor Green

try {
    # 1. Parar serviço PostgreSQL
    Write-Host "1. Parando serviço PostgreSQL..." -ForegroundColor Yellow
    Stop-Service postgresql-x64-17 -ErrorAction Stop
    Write-Host "   ✅ Serviço parado" -ForegroundColor Green
    
    # 2. Fazer backup da configuração atual
    Write-Host "2. Fazendo backup da configuração..." -ForegroundColor Yellow
    $configPath = "C:\Program Files\PostgreSQL\17\data\pg_hba.conf"
    $backupPath = "$configPath.backup"
    
    if (Test-Path $configPath) {
        Copy-Item $configPath $backupPath -Force
        Write-Host "   ✅ Backup criado: $backupPath" -ForegroundColor Green
    } else {
        Write-Host "   ⚠️ Arquivo de configuração não encontrado em $configPath" -ForegroundColor Yellow
    }
    
    # 3. Aplicar nova configuração
    Write-Host "3. Aplicando configuração trust..." -ForegroundColor Yellow
    $tempConfig = "C:\Users\up739088\Desktop\aplicaçoes,sites,etc\cplp_raras\scripts\pg_hba_temp.conf"
    
    if (Test-Path $tempConfig) {
        Copy-Item $tempConfig $configPath -Force
        Write-Host "   ✅ Nova configuração aplicada" -ForegroundColor Green
    } else {
        Write-Host "   ❌ Arquivo temporário não encontrado: $tempConfig" -ForegroundColor Red
        throw "Arquivo de configuração temporária não encontrado"
    }
    
    # 4. Reiniciar serviço
    Write-Host "4. Reiniciando serviço PostgreSQL..." -ForegroundColor Yellow
    Start-Service postgresql-x64-17 -ErrorAction Stop
    Start-Sleep -Seconds 3
    Write-Host "   ✅ Serviço reiniciado" -ForegroundColor Green
    
    # 5. Testar conexão
    Write-Host "5. Testando conexão..." -ForegroundColor Yellow
    $psqlPath = "C:\Program Files\PostgreSQL\17\bin\psql.exe"
    
    if (Test-Path $psqlPath) {
        Write-Host "   Tentando conectar sem senha..." -ForegroundColor Cyan
        $testResult = & $psqlPath -h localhost -U postgres -d postgres -c "SELECT 'CONNECTION_SUCCESS' as status;" 2>&1
        
        if ($testResult -match "CONNECTION_SUCCESS") {
            Write-Host "   ✅ SUCESSO! Conectado sem senha" -ForegroundColor Green
            
            # 6. Definir nova senha
            Write-Host "6. Definindo nova senha..." -ForegroundColor Yellow
            $newPassword = "cplp_raras_2024"
            $passwordResult = & $psqlPath -h localhost -U postgres -d postgres -c "ALTER USER postgres PASSWORD '$newPassword';" 2>&1
            
            if ($passwordResult -notmatch "ERROR") {
                Write-Host "   ✅ Nova senha definida: $newPassword" -ForegroundColor Green
                
                # 7. Restaurar configuração original
                Write-Host "7. Restaurando configuração segura..." -ForegroundColor Yellow
                if (Test-Path $backupPath) {
                    Copy-Item $backupPath $configPath -Force
                    Restart-Service postgresql-x64-17
                    Write-Host "   ✅ Configuração restaurada" -ForegroundColor Green
                }
                
                # 8. Testar com nova senha
                Write-Host "8. Testando com nova senha..." -ForegroundColor Yellow
                $env:PGPASSWORD = $newPassword
                $finalTest = & $psqlPath -h localhost -U postgres -d postgres -c "SELECT 'FINAL_SUCCESS' as status;" 2>&1
                
                if ($finalTest -match "FINAL_SUCCESS") {
                    Write-Host "   ✅ PERFEITO! Autenticação com senha funcionando" -ForegroundColor Green
                    
                    # 9. Atualizar arquivo .env
                    Write-Host "9. Atualizando arquivo .env..." -ForegroundColor Yellow
                    $envPath = "C:\Users\up739088\Desktop\aplicaçoes,sites,etc\cplp_raras\.env"
                    
                    if (Test-Path $envPath) {
                        $envContent = Get-Content $envPath -Raw
                        $envContent = $envContent -replace 'DB_PASSWORD=.*', "DB_PASSWORD=$newPassword"
                        $envContent = $envContent -replace 'postgresql://postgres:.*@', "postgresql://postgres:$newPassword@"
                        Set-Content $envPath $envContent
                        Write-Host "   ✅ Arquivo .env atualizado" -ForegroundColor Green
                    }
                    
                    Write-Host ""
                    Write-Host "🎉 CONFIGURAÇÃO CONCLUÍDA COM SUCESSO!" -ForegroundColor Green
                    Write-Host "📋 Credenciais PostgreSQL:" -ForegroundColor Cyan
                    Write-Host "   Usuário: postgres" -ForegroundColor White
                    Write-Host "   Senha: $newPassword" -ForegroundColor White
                    Write-Host "   Host: localhost:5432" -ForegroundColor White
                    Write-Host ""
                    Write-Host "🚀 Agora você pode executar:" -ForegroundColor Yellow
                    Write-Host "   npx prisma db push" -ForegroundColor White
                    Write-Host "   node scripts/populate-database.ts" -ForegroundColor White
                    
                } else {
                    Write-Host "   ❌ Falha no teste final" -ForegroundColor Red
                    Write-Host "   Teste manual: psql -h localhost -U postgres" -ForegroundColor Yellow
                }
                
            } else {
                Write-Host "   ❌ Erro ao definir senha" -ForegroundColor Red
                Write-Host $passwordResult -ForegroundColor Red
            }
            
        } else {
            Write-Host "   ❌ Falha na conexão inicial" -ForegroundColor Red
            Write-Host $testResult -ForegroundColor Red
        }
    } else {
        Write-Host "   ❌ psql.exe não encontrado em $psqlPath" -ForegroundColor Red
    }

} catch {
    Write-Host "❌ ERRO: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host ""
    Write-Host "🔄 Tentando restaurar configuração original..." -ForegroundColor Yellow
    
    try {
        if (Test-Path $backupPath) {
            Copy-Item $backupPath $configPath -Force
            Start-Service postgresql-x64-17 -ErrorAction SilentlyContinue
            Write-Host "✅ Configuração original restaurada" -ForegroundColor Green
        }
    } catch {
        Write-Host "⚠️ Não foi possível restaurar automaticamente" -ForegroundColor Yellow
    }
}

Write-Host ""
Write-Host "Pressione qualquer tecla para sair..." -ForegroundColor Gray
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
