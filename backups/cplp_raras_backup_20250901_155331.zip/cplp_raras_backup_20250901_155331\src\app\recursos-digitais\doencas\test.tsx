'use client';

export default function TestPage() {
  return (
    <div className="min-h-screen bg-white p-8">
      <h1 className="text-3xl font-bold text-blue-600 mb-6">
        Teste - Sistema Híbrido de Doenças Raras
      </h1>
      
      <div className="bg-blue-50 p-6 rounded-lg">
        <p className="text-lg text-gray-700">
          ✅ Página funcionando!
        </p>
        <p className="text-sm text-gray-600 mt-2">
          Sistema híbrido com 11 tipos de filtros está pronto para implementação.
        </p>
      </div>
    </div>
  );
}
