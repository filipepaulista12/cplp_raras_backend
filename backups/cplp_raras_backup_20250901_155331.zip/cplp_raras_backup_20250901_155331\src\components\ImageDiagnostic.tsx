'use client';

import Image from 'next/image';
import { getImageSrc } from '@/lib/imageUtils';
import { useState, useEffect } from 'react';

interface ImageStatus {
  src: string;
  name: string;
  status: 'loading' | 'success' | 'error';
  fullPath: string;
}

const testImages = [
  { name: 'Background', src: '/images/background.png' },
  { name: 'FAQ', src: '/images/faq.png' },
  { name: 'GT1', src: '/images/GT1.png' },
  { name: 'GT2', src: '/images/GT2.png.png' },
  { name: 'GT3', src: '/images/GT3.png' },
  { name: 'GT4', src: '/images/GT4.png' },
  { name: 'GT5', src: '/images/GT5.png' },
  { name: 'GT6', src: '/images/GT6.png' },
  { name: 'USP Logo', src: '/images/logo-usp.png' },
  { name: 'UFRGS Logo', src: '/images/logo-ufrgs.png' },
  { name: 'UnB Logo', src: '/images/logo-unb.svg' },
  { name: 'Ida Schwartz', src: '/images/ida-schwartz.jpg' },
];

export default function ImageDiagnostic() {
  const [imageStatuses, setImageStatuses] = useState<ImageStatus[]>(
    testImages.map(img => ({
      src: img.src,
      name: img.name,
      status: 'loading' as const,
      fullPath: getImageSrc(img.src)
    }))
  );

  const updateImageStatus = (src: string, status: 'success' | 'error') => {
    setImageStatuses(prev => 
      prev.map(img => 
        img.src === src ? { ...img, status } : img
      )
    );
  };

  const testDirectURL = async (fullPath: string) => {
    try {
      const response = await fetch(fullPath, { method: 'HEAD' });
      return response.ok;
    } catch {
      return false;
    }
  };

  const handleTestDirectAccess = async (img: ImageStatus) => {
    const isAccessible = await testDirectURL(img.fullPath);
    console.log(`Direct access test for ${img.name}: ${img.fullPath} - ${isAccessible ? 'OK' : 'FAILED'}`);
  };

  const successCount = imageStatuses.filter(img => img.status === 'success').length;
  const errorCount = imageStatuses.filter(img => img.status === 'error').length;
  const loadingCount = imageStatuses.filter(img => img.status === 'loading').length;

  return (
    <div className="p-6 bg-gray-50 m-4 rounded-lg border">
      <div className="mb-6">
        <h2 className="text-xl font-bold text-gray-800 mb-2">🔍 Diagnóstico de Imagens</h2>
        <div className="flex space-x-4 text-sm">
          <span className="text-green-600">✅ Sucesso: {successCount}</span>
          <span className="text-red-600">❌ Erro: {errorCount}</span>
          <span className="text-yellow-600">⏳ Carregando: {loadingCount}</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {imageStatuses.map((img, index) => (
          <div key={index} className={`border p-3 rounded-lg ${
            img.status === 'success' ? 'bg-green-50 border-green-200' :
            img.status === 'error' ? 'bg-red-50 border-red-200' :
            'bg-yellow-50 border-yellow-200'
          }`}>
            <div className="mb-2">
              <p className="text-sm font-medium text-gray-900">{img.name}</p>
              <p className="text-xs text-gray-500 break-all mb-1">{img.src}</p>
              <p className="text-xs text-blue-600 break-all">{img.fullPath}</p>
            </div>

            <div className="relative w-full h-24 bg-gray-100 rounded mb-2">
              <Image
                src={img.fullPath}
                alt={img.name}
                fill
                className="object-contain rounded"
                onLoad={() => {
                  updateImageStatus(img.src, 'success');
                  console.log(`✅ ${img.name} carregou com sucesso`);
                }}
                onError={(e) => {
                  updateImageStatus(img.src, 'error');
                  console.error(`❌ Erro ao carregar ${img.name}: ${img.fullPath}`);
                  console.error('Evento de erro:', e);
                }}
              />
            </div>

            <div className="flex justify-between items-center">
              <span className={`text-xs px-2 py-1 rounded ${
                img.status === 'success' ? 'bg-green-100 text-green-700' :
                img.status === 'error' ? 'bg-red-100 text-red-700' :
                'bg-yellow-100 text-yellow-700'
              }`}>
                {img.status === 'success' ? '✅ OK' :
                 img.status === 'error' ? '❌ Erro' :
                 '⏳ ...'
                }
              </span>
              
              <button
                onClick={() => handleTestDirectAccess(img)}
                className="text-xs text-blue-600 hover:text-blue-800 underline"
              >
                Testar URL
              </button>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
        <h3 className="font-medium text-blue-900 mb-2">💡 Instruções de Teste:</h3>
        <ol className="text-sm text-blue-800 space-y-1">
          <li>1. Abra o console do navegador (F12)</li>
          <li>2. Observe as mensagens de sucesso (✅) e erro (❌)</li>
          <li>3. Clique em "Testar URL" para verificar acesso direto</li>
          <li>4. URLs que falham: verificar se existem no servidor em /var/www/html/filipe/images/</li>
        </ol>
      </div>
    </div>
  );
}
