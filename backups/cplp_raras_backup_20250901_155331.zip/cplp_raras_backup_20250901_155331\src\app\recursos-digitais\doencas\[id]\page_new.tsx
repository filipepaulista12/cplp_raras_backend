import { notFound } from 'next/navigation';
import DoencaClientWrapper from './DoencaClientWrapper';

// Dados mock das doenças
const MOCK_DISEASE_DATA: { [key: string]: any } = {
  'gard-br-0001': {
    id: 'gard-br-0001',
    gard_br_id: 'GARD-BR-0001',
    name_pt: 'Síndrome de Marfan',
    name_en: 'Marfan Syndrome',
    synonyms: ['Aracnodactilia', 'Doença de Marfan', 'Síndrome de Marfan-Achard'],
    category: 'Doenças Genéticas',
    orpha_code: 'ORPHA558',
    icd10_code: 'Q87.4',
    prevalence: '1 em 5.000 a 10.000 pessoas',
    inheritance_pattern: 'Autossómica dominante',
    age_of_onset: 'Todas as idades',
    last_updated: '2024-12-15',
    
    summary: `A Síndrome de Marfan é uma doença hereditária do tecido conjuntivo que afeta principalmente o sistema cardiovascular, esquelético e ocular. É causada por mutações no gene FBN1, que codifica a fibrilina-1, uma proteína essencial para a formação de fibras elásticas nos tecidos conjuntivos.`,
    
    symptoms: [
      'Estatura alta e constituição longilínea',
      'Aracnodactilia (dedos longos e finos)',
      'Hiperflexibilidade articular',
      'Escoliose ou cifose',
      'Pectus carinatum ou pectus excavatum',
      'Dilatação da raiz aórtica',
      'Prolapso da válvula mitral',
      'Subluxação do cristalino',
      'Miopia',
      'Pele elástica',
      'Estrias cutâneas'
    ],
    
    causes: `A Síndrome de Marfan é causada por mutações no gene FBN1, localizado no cromossomo 15. Este gene codifica a fibrilina-1, uma glicoproteína que é um componente importante das microfibras elásticas presentes no tecido conjuntivo. As mutações resultam na produção de fibrilina-1 defeituosa ou em quantidades reduzidas, afetando a integridade estrutural de vários tecidos.`,
    
    diagnosis: `O diagnóstico da Síndrome de Marfan baseia-se nos critérios de Ghent revisados, que incluem características clínicas dos sistemas cardiovascular, ocular, esquelético e tegumentar. Testes genéticos podem identificar mutações no gene FBN1, confirmando o diagnóstico. Exames complementares incluem ecocardiograma, exame oftalmológico completo e radiografias do esqueleto.`,
    
    treatment: `Não existe cura para a Síndrome de Marfan, mas o tratamento visa prevenir complicações e melhorar a qualidade de vida. Inclui monitorização cardiovascular regular, restrição de atividades físicas intensas, correção cirúrgica de problemas cardíacos quando necessário, correção oftalmológica, fisioterapia para problemas esqueléticos, e aconselhamento genético para famílias afetadas.`,
    
    prognosis: `O prognóstico varia significativamente dependendo do grau de envolvimento dos diferentes sistemas, especialmente o cardiovascular. Com diagnóstico precoce e acompanhamento médico adequado, muitos pacientes podem ter uma expectativa de vida próxima do normal. As complicações cardiovasculares, particularmente a dilatação aórtica, são a principal causa de morbidade e mortalidade.`,
    
    support_organizations: [],
    clinical_trials: [],
    recent_articles: [],
    patient_resources: [],
    expert_reviewers: ['Dr. João Silva - Cardiologista', 'Dra. Maria Santos - Geneticista'],
    sources: ['Orphanet', 'GeneReviews', 'Ghent Nosology']
  },
  'gard-br-0002': {
    id: 'gard-br-0002',
    gard_br_id: 'GARD-BR-0002', 
    name_pt: 'Fibrose Cística',
    name_en: 'Cystic Fibrosis',
    synonyms: ['Mucoviscidose', 'Fibrose Quística'],
    category: 'Doenças Genéticas',
    orpha_code: 'ORPHA586',
    icd10_code: 'E84',
    prevalence: '1 em 2.500 a 3.500 nascidos vivos (população caucasiana)',
    inheritance_pattern: 'Autossómica recessiva',
    age_of_onset: 'Nascimento/infância',
    last_updated: '2024-12-15',
    
    summary: `A Fibrose Cística é uma doença genética multissistêmica que afeta principalmente os pulmões e o sistema digestivo. É causada por mutações no gene CFTR, resultando na produção de muco espesso e pegajoso que obstrui vias aéreas e ductos pancreáticos.`,
    
    symptoms: [
      'Tosse persistente com muco espesso',
      'Infeções pulmonares recorrentes',
      'Falta de ar',
      'Suor salgado',
      'Problemas digestivos',
      'Má absorção de nutrientes',
      'Crescimento deficiente',
      'Pólipos nasais',
      'Infertilidade masculina'
    ],
    
    causes: `A Fibrose Cística é causada por mutações no gene CFTR (Cystic Fibrosis Transmembrane Conductance Regulator). As mutações resultam numa proteína CFTR defeituosa ou ausente, que regula o transporte de cloreto através das membranas celulares.`,
    
    diagnosis: `O diagnóstico inclui teste do pezinho (screening neonatal), teste do suor, e análise genética. O teste do suor mede a concentração de cloreto no suor - valores elevados indicam Fibrose Cística.`,
    
    treatment: `O tratamento é multidisciplinar e inclui fisioterapia respiratória, antibióticos para infeções, enzimas pancreáticas, suplementos nutricionais, broncodilatadores, e medicamentos moduladores do CFTR como ivacaftor e lumacaftor/ivacaftor.`,
    
    prognosis: `O prognóstico tem melhorado significativamente com os avanços no tratamento. A mediana de sobrevida atualmente ultrapassa os 40 anos em países desenvolvidos, com muitos pacientes vivendo até à idade adulta.`,
    
    support_organizations: [],
    clinical_trials: [],
    recent_articles: [],
    patient_resources: [],
    expert_reviewers: ['Dr. Carlos Pneumo - Pneumologista', 'Dra. Ana Pediatra - Pediatra'],
    sources: ['Cystic Fibrosis Foundation', 'European Cystic Fibrosis Society']
  }
};

interface Props {
  params: { id: string };
}

export default function DoencaIndividualPage({ params }: Props) {
  const disease = MOCK_DISEASE_DATA[params.id];
  
  if (!disease) {
    return notFound();
  }

  return <DoencaClientWrapper disease={disease} />;
}

// Função necessária para Next.js 15 static export
export async function generateStaticParams() {
  const diseaseIds = Object.keys(MOCK_DISEASE_DATA);
  
  return diseaseIds.map((id) => ({
    id: id,
  }));
}
