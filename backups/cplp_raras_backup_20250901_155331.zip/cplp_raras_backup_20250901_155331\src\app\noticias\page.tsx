import Link from 'next/link';
import { ArrowLeftIcon } from '@heroicons/react/24/outline';

const allNews = [
  {
    id: 1,
    title: "Projeto CPLP-Raras Recebe Financiamento Adicional",
    date: "5 de Agosto, 2024",
    category: "Financiamento",
    summary: "Nova verba permitirá expansão das atividades para mais dois países da CPLP.",
    content: "O projeto CPLP-Raras foi contemplado com financiamento adicional que permitirá a expansão das atividades de pesquisa para Cabo Verde e Timor-Leste. Os recursos serão utilizados para capacitação de equipes locais e implementação de plataformas digitais.",
    featured: true,
    image: "💰"
  },
  {
    id: 2,
    title: "Publicação de Protocolo de Coleta de Dados",
    date: "28 de Julho, 2024",
    category: "Pesquisa",
    summary: "Documento técnico estabelece diretrizes padronizadas para todos os países participantes.",
    content: "Foi publicado o protocolo oficial para coleta de dados sobre doenças raras nos países da CPLP. O documento estabelece diretrizes padronizadas que garantem a qualidade e comparabilidade dos dados coletados.",
    featured: false,
    image: "📋"
  },
  {
    id: 3,
    title: "Primeira Reunião Virtual dos GTs",
    date: "15 de Julho, 2024",
    category: "Evento",
    summary: "Grupos de trabalho se reuniram para definir cronograma e metas do segundo semestre.",
    content: "Os seis grupos de trabalho do projeto realizaram sua primeira reunião virtual conjunta, definindo estratégias e cronograma para o segundo semestre de 2024.",
    featured: false,
    image: "🤝"
  },
  {
    id: 4,
    title: "Implementação de Plataforma REDCap Concluída",
    date: "10 de Julho, 2024",
    category: "Tecnologia",
    summary: "Sistema de coleta de dados já está operacional em todos os países participantes.",
    content: "A implementação da plataforma REDCap foi concluída com sucesso em todos os países participantes do projeto, permitindo o início da coleta sistemática de dados.",
    featured: false,
    image: "💻"
  },
  {
    id: 5,
    title: "Parceria com Organização Internacional de Doenças Raras",
    date: "25 de Junho, 2024",
    category: "Parceria",
    summary: "Acordo de cooperação amplia rede de colaboração científica.",
    content: "O projeto CPLP-Raras firmou parceria estratégica com a Organização Internacional de Doenças Raras, ampliando as oportunidades de colaboração científica e intercâmbio de conhecimento.",
    featured: false,
    image: "🌐"
  },
  {
    id: 6,
    title: "Capacitação de Pesquisadores em Angola",
    date: "20 de Junho, 2024",
    category: "Capacitação",
    summary: "Workshop presencial treinou 25 pesquisadores locais.",
    content: "Foi realizado em Luanda um workshop de capacitação que treinou 25 pesquisadores angolanos nas metodologias e ferramentas do projeto CPLP-Raras.",
    featured: false,
    image: "🎓"
  }
];

const categories = ["Todos", "Financiamento", "Pesquisa", "Evento", "Tecnologia", "Parceria", "Capacitação"];

export default function News() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Breadcrumb */}
      <div className="bg-white border-b">
        <div className="mx-auto max-w-7xl px-4 py-4 sm:px-6 lg:px-8">
          <Link 
            href="/"
            className="inline-flex items-center text-blue-600 hover:text-blue-800 transition-colors"
          >
            <ArrowLeftIcon className="h-4 w-4 mr-2" />
            Voltar ao Início
          </Link>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            📰 Notícias CPLP-Raras
          </h1>
          <div className="w-32 h-1 bg-gradient-to-r from-blue-600 to-green-600 mx-auto mb-8"></div>
          <p className="text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed">
            Acompanhe as últimas novidades, atualizações e marcos importantes do projeto CPLP-Raras.
          </p>
        </div>

        {/* Categories Filter */}
        <div className="mb-8">
          <div className="bg-white rounded-xl shadow-sm p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Filtrar por categoria:</h3>
            <div className="flex flex-wrap gap-2">
              {categories.map((category) => (
                <button
                  key={category}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                    category === "Todos"
                      ? "bg-blue-600 text-white"
                      : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                  }`}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Featured News */}
        <section className="mb-12">
          {allNews.filter(news => news.featured).map((news) => (
            <div key={news.id} className="bg-white rounded-2xl shadow-lg overflow-hidden">
              <div className="bg-gradient-to-r from-blue-600 to-green-600 p-6 text-white">
                <div className="flex items-center space-x-3 mb-4">
                  <span className="text-3xl">{news.image}</span>
                  <span className="bg-white/20 px-3 py-1 rounded-full text-sm font-medium">
                    Destaque
                  </span>
                </div>
                <h2 className="text-2xl md:text-3xl font-bold mb-3">
                  {news.title}
                </h2>
                <div className="flex items-center space-x-4 text-blue-100">
                  <span>📅 {news.date}</span>
                  <span className="bg-white/20 px-2 py-1 rounded text-sm">
                    {news.category}
                  </span>
                </div>
              </div>
              <div className="p-6">
                <p className="text-lg text-gray-700 mb-4">
                  {news.content}
                </p>
                <button className="text-blue-600 hover:text-blue-800 font-medium">
                  Leia mais →
                </button>
              </div>
            </div>
          ))}
        </section>

        {/* All News Grid */}
        <section className="mb-16">
          <h2 className="text-2xl font-bold text-gray-900 mb-8">Todas as Notícias</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {allNews.filter(news => !news.featured).map((news) => (
              <article key={news.id} className="bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow overflow-hidden">
                <div className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-3xl">{news.image}</span>
                    <span className="bg-gray-100 text-gray-700 px-2 py-1 rounded text-sm">
                      {news.category}
                    </span>
                  </div>
                  
                  <h3 className="text-lg font-semibold text-gray-900 mb-3 line-clamp-2">
                    {news.title}
                  </h3>
                  
                  <p className="text-gray-600 text-sm mb-4">
                    📅 {news.date}
                  </p>
                  
                  <p className="text-gray-700 mb-4 line-clamp-3">
                    {news.summary}
                  </p>
                  
                  <button className="text-blue-600 hover:text-blue-800 font-medium text-sm">
                    Leia mais →
                  </button>
                </div>
              </article>
            ))}
          </div>
        </section>

        {/* Newsletter Subscription */}
        <section className="mb-16">
          <div className="bg-gradient-to-r from-blue-600 to-green-600 rounded-2xl p-8 text-white text-center">
            <h2 className="text-2xl font-bold mb-4">
              📧 Receba Nossas Notícias
            </h2>
            <p className="text-xl mb-6 opacity-90">
              Inscreva-se em nossa newsletter e seja o primeiro a saber das novidades do projeto.
            </p>
            <div className="max-w-md mx-auto flex flex-col sm:flex-row gap-4">
              <input
                type="email"
                placeholder="Digite seu e-mail"
                className="flex-1 px-4 py-3 rounded-lg text-gray-900 focus:outline-none focus:ring-2 focus:ring-white"
              />
              <button className="bg-white text-blue-600 px-6 py-3 rounded-lg font-semibold hover:bg-blue-50 transition-colors">
                Inscrever-se
              </button>
            </div>
          </div>
        </section>

        {/* Social Media */}
        <section>
          <div className="bg-white rounded-2xl shadow-lg p-8 text-center">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              🌐 Siga-nos nas Redes Sociais
            </h2>
            <p className="text-lg text-gray-600 mb-6">
              Acompanhe nossas atividades e interaja conosco nas redes sociais.
            </p>
            <div className="flex justify-center space-x-6">
              <button className="bg-blue-600 text-white p-3 rounded-full hover:bg-blue-700 transition-colors">
                <span className="text-xl">📘</span>
              </button>
              <button className="bg-blue-400 text-white p-3 rounded-full hover:bg-blue-500 transition-colors">
                <span className="text-xl">🐦</span>
              </button>
              <button className="bg-blue-800 text-white p-3 rounded-full hover:bg-blue-900 transition-colors">
                <span className="text-xl">💼</span>
              </button>
              <button className="bg-green-600 text-white p-3 rounded-full hover:bg-green-700 transition-colors">
                <span className="text-xl">📱</span>
              </button>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
