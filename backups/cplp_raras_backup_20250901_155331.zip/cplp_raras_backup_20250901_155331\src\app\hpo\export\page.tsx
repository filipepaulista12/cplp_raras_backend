'use client'

import { useHPOStore } from '@/store/hpoStore'
import { useEffect, useState } from 'react'
import Papa from 'papaparse'
import type { BabelonTSVRow } from '@/types/hpo'

export default function ExportPage() {
  const { terms, translations, getStats, setTerms } = useHPOStore()
  const [isLoaded, setIsLoaded] = useState(false)
  const [exportFormat, setExportFormat] = useState<'babelon' | 'xliff' | 'json' | 'csv'>('babelon')
  const [includeStatus, setIncludeStatus] = useState<'all' | 'final' | 'review'>('all')
  const [isExporting, setIsExporting] = useState(false)
  const stats = getStats()
  
  useEffect(() => {
    if (terms.length === 0 && !isLoaded) {
      fetch('/hpo-sample.json')
        .then(res => res.json())
        .then(data => {
          setTerms(data.terms)
          setIsLoaded(true)
        })
        .catch(err => console.error('Erro ao carregar dados:', err))
    } else {
      setIsLoaded(true)
    }
  }, [terms.length, setTerms, isLoaded])
  
  const filterTranslations = () => {
    switch (includeStatus) {
      case 'final':
        return translations.filter(t => t.is_final)
      case 'review':
        return translations.filter(t => !t.is_final)
      default:
        return translations
    }
  }
  
  const generateBabelonTSV = () => {
    const filteredTranslations = filterTranslations()
    
    const babelonRows: BabelonTSVRow[] = filteredTranslations.map(translation => {
      const term = terms.find(t => t.id === translation.term_id)
      
      return {
        subject_id: translation.term_id,
        subject_label: term?.label_en || '',
        predicate_id: 'rdfs:label',
        object_id: translation.label_pt,
        object_label: translation.label_pt,
        object_language: 'pt',
        object_datatype: '',
        object_category: '',
        confidence: translation.likert_score / 5, // Normaliza para 0-1
        translator: translation.translator,
        translation_date: translation.translation_date,
        source: 'HPO-CPLP-Translator',
        comment: translation.comments || '',
        subject_source: 'HPO',
        object_source: 'HPO-CPLP',
        mapping_justification: translation.is_final ? 'manual_curation' : 'preliminary_translation'
      }
    })
    
    // Adiciona definições como linhas separadas
    filteredTranslations.forEach(translation => {
      if (translation.definition_pt) {
        const term = terms.find(t => t.id === translation.term_id)
        babelonRows.push({
          subject_id: translation.term_id,
          subject_label: term?.label_en || '',
          predicate_id: 'obo:IAO_0000115', // definition predicate
          object_id: translation.definition_pt,
          object_label: translation.definition_pt,
          object_language: 'pt',
          object_datatype: '',
          object_category: '',
          confidence: translation.likert_score / 5,
          translator: translation.translator,
          translation_date: translation.translation_date,
          source: 'HPO-CPLP-Translator',
          comment: translation.comments || '',
          subject_source: 'HPO',
          object_source: 'HPO-CPLP',
          mapping_justification: translation.is_final ? 'manual_curation' : 'preliminary_translation'
        })
      }
    })
    
    return Papa.unparse(babelonRows, {
      delimiter: '\t',
      header: true,
      skipEmptyLines: true
    })
  }
  
  const generateXLIFF = () => {
    const filteredTranslations = filterTranslations()
    
    const xliffHeader = `<?xml version="1.0" encoding="UTF-8"?>
<xliff version="2.1" xmlns="urn:oasis:names:tc:xliff:document:2.1">
  <file id="hpo-translations" source-language="en" target-language="pt">
    <header>
      <tool tool-id="hpo-cplp-translator" tool-name="HPO CPLP Translator" tool-version="1.0"/>
      <note category="description">HPO ontology translations to Portuguese for CPLP countries</note>
    </header>
    <body>`
    
    const xliffUnits = filteredTranslations.map(translation => {
      const term = terms.find(t => t.id === translation.term_id)
      
      return `      <unit id="${translation.term_id}">
        <originalData>
          <data id="hpo-id">${translation.term_id}</data>
          <data id="translator">${translation.translator}</data>
          <data id="translation-date">${translation.translation_date}</data>
          <data id="likert-score">${translation.likert_score}</data>
          <data id="is-final">${translation.is_final}</data>
        </originalData>
        <segment id="${translation.term_id}-label" state="${translation.is_final ? 'final' : 'new'}">
          <source>${escapeXML(term?.label_en || '')}</source>
          <target>${escapeXML(translation.label_pt)}</target>
          ${translation.comments ? `<note category="comment">${escapeXML(translation.comments)}</note>` : ''}
        </segment>
        ${translation.definition_pt ? `
        <segment id="${translation.term_id}-definition" state="${translation.is_final ? 'final' : 'new'}">
          <source>${escapeXML(term?.definition_en || '')}</source>
          <target>${escapeXML(translation.definition_pt)}</target>
        </segment>` : ''}
      </unit>`
    }).join('\\n')
    
    const xliffFooter = `    </body>
  </file>
</xliff>`
    
    return xliffHeader + '\\n' + xliffUnits + '\\n' + xliffFooter
  }
  
  const generateJSON = () => {
    const filteredTranslations = filterTranslations()
    
    return JSON.stringify({
      metadata: {
        generated_by: 'HPO-CPLP-Translator',
        generated_at: new Date().toISOString(),
        source_language: 'en',
        target_language: 'pt',
        total_translations: filteredTranslations.length,
        total_terms: terms.length,
        filter_applied: includeStatus,
        statistics: stats
      },
      terms: terms.map(term => ({
        ...term,
        translations: filteredTranslations.filter(t => t.term_id === term.id)
      })).filter(term => term.translations.length > 0)
    }, null, 2)
  }
  
  const generateCSV = () => {
    const filteredTranslations = filterTranslations()
    
    const csvData = filteredTranslations.map(translation => {
      const term = terms.find(t => t.id === translation.term_id)
      
      return {
        hpo_id: translation.term_id,
        label_en: term?.label_en || '',
        label_pt: translation.label_pt,
        definition_en: term?.definition_en || '',
        definition_pt: translation.definition_pt,
        synonyms_pt: translation.synonyms_pt.join('; '),
        translator: translation.translator,
        translation_date: translation.translation_date,
        likert_score: translation.likert_score,
        is_final: translation.is_final ? 'Yes' : 'No',
        comments: translation.comments || ''
      }
    })
    
    return Papa.unparse(csvData, {
      header: true,
      skipEmptyLines: true
    })
  }
  
  const escapeXML = (text: string) => {
    return text
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&apos;')
  }
  
  const downloadFile = (content: string, filename: string, mimeType: string) => {
    const blob = new Blob([content], { type: mimeType })
    const url = URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.download = filename
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
    URL.revokeObjectURL(url)
  }
  
  const handleExport = async () => {
    setIsExporting(true)
    
    try {
      let content: string
      let filename: string
      let mimeType: string
      
      const timestamp = new Date().toISOString().split('T')[0]
      const statusSuffix = includeStatus === 'all' ? 'complete' : includeStatus === 'final' ? 'final' : 'review'
      
      switch (exportFormat) {
        case 'babelon':
          content = generateBabelonTSV()
          filename = `hpo-translations-${statusSuffix}-${timestamp}.tsv`
          mimeType = 'text/tab-separated-values'
          break
        case 'xliff':
          content = generateXLIFF()
          filename = `hpo-translations-${statusSuffix}-${timestamp}.xliff`
          mimeType = 'application/xml'
          break
        case 'json':
          content = generateJSON()
          filename = `hpo-translations-${statusSuffix}-${timestamp}.json`
          mimeType = 'application/json'
          break
        case 'csv':
          content = generateCSV()
          filename = `hpo-translations-${statusSuffix}-${timestamp}.csv`
          mimeType = 'text/csv'
          break
        default:
          throw new Error('Formato de exportação não suportado')
      }
      
      downloadFile(content, filename, mimeType)
      
    } catch (error) {
      console.error('Erro na exportação:', error)
      alert('Erro ao gerar arquivo de exportação')
    } finally {
      setIsExporting(false)
    }
  }
  
  if (!isLoaded) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="text-gray-500">Carregando dados...</div>
      </div>
    )
  }
  
  const filteredCount = filterTranslations().length
  const filteredTermCount = new Set(filterTranslations().map(t => t.term_id)).size
  
  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">
          📥 Exportar Traduções
        </h1>
        <p className="text-gray-600">
          Exporte as traduções em formatos compatíveis com repositórios de ontologia e ferramentas de tradução.
        </p>
      </div>
      
      {/* Estatísticas de exportação */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6 text-center">
          <div className="text-2xl font-bold text-blue-600 mb-2">
            {translations.length}
          </div>
          <div className="text-gray-600 text-sm">Total de Traduções</div>
        </div>
        
        <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6 text-center">
          <div className="text-2xl font-bold text-green-600 mb-2">
            {translations.filter(t => t.is_final).length}
          </div>
          <div className="text-gray-600 text-sm">Finalizadas</div>
        </div>
        
        <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6 text-center">
          <div className="text-2xl font-bold text-yellow-600 mb-2">
            {translations.filter(t => !t.is_final).length}
          </div>
          <div className="text-gray-600 text-sm">Em Revisão</div>
        </div>
        
        <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6 text-center">
          <div className="text-2xl font-bold text-purple-600 mb-2">
            {new Set(translations.map(t => t.term_id)).size}
          </div>
          <div className="text-gray-600 text-sm">Termos Únicos</div>
        </div>
      </div>
      
      {/* Configurações de exportação */}
      <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6 mb-8">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">
          ⚙️ Configurações de Exportação
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Formato */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Formato de Exportação
            </label>
            <select
              value={exportFormat}
              onChange={(e) => setExportFormat(e.target.value as any)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="babelon">Babelon TSV (Padrão HPOIE)</option>
              <option value="xliff">XLIFF 2.1 (Translation Memory)</option>
              <option value="json">JSON (Estruturado)</option>
              <option value="csv">CSV (Planilha)</option>
            </select>
          </div>
          
          {/* Status */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Incluir Status
            </label>
            <select
              value={includeStatus}
              onChange={(e) => setIncludeStatus(e.target.value as any)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="all">Todas as traduções</option>
              <option value="final">Apenas finalizadas</option>
              <option value="review">Apenas em revisão</option>
            </select>
          </div>
        </div>
        
        {/* Preview da seleção */}
        <div className="mt-4 p-4 bg-gray-50 rounded-md">
          <p className="text-sm text-gray-700">
            <strong>Será exportado:</strong> {filteredCount} traduções de {filteredTermCount} termos únicos
          </p>
        </div>
      </div>
      
      {/* Descrição dos formatos */}
      <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6 mb-8">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">
          📋 Formatos de Exportação
        </h3>
        
        <div className="space-y-4">
          <div className={`p-4 rounded-lg border-l-4 ${exportFormat === 'babelon' ? 'border-blue-500 bg-blue-50' : 'border-gray-300 bg-gray-50'}`}>
            <h4 className="font-medium text-gray-900">Babelon TSV</h4>
            <p className="text-sm text-gray-600 mt-1">
              Formato padrão do HPOIE para submissão ao repositório oficial da HPO. 
              Compatível com workflows de ontologia biomédica.
            </p>
          </div>
          
          <div className={`p-4 rounded-lg border-l-4 ${exportFormat === 'xliff' ? 'border-green-500 bg-green-50' : 'border-gray-300 bg-gray-50'}`}>
            <h4 className="font-medium text-gray-900">XLIFF 2.1</h4>
            <p className="text-sm text-gray-600 mt-1">
              XML Localization Interchange File Format. Padrão da indústria de tradução, 
              compatível com CAT Tools e Translation Memory systems.
            </p>
          </div>
          
          <div className={`p-4 rounded-lg border-l-4 ${exportFormat === 'json' ? 'border-purple-500 bg-purple-50' : 'border-gray-300 bg-gray-50'}`}>
            <h4 className="font-medium text-gray-900">JSON Estruturado</h4>
            <p className="text-sm text-gray-600 mt-1">
              Formato estruturado com metadados completos. Ideal para integração com APIs 
              e processamento programático.
            </p>
          </div>
          
          <div className={`p-4 rounded-lg border-l-4 ${exportFormat === 'csv' ? 'border-yellow-500 bg-yellow-50' : 'border-gray-300 bg-gray-50'}`}>
            <h4 className="font-medium text-gray-900">CSV</h4>
            <p className="text-sm text-gray-600 mt-1">
              Formato de planilha universalmente compatível. Ideal para análise em Excel, 
              Google Sheets ou outras ferramentas de dados tabulares.
            </p>
          </div>
        </div>
      </div>
      
      {/* Botão de exportação */}
      <div className="text-center">
        <button
          onClick={handleExport}
          disabled={isExporting || filteredCount === 0}
          className={`inline-flex items-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-white ${
            isExporting || filteredCount === 0
              ? 'bg-gray-400 cursor-not-allowed'
              : 'bg-blue-600 hover:bg-blue-700'
          } transition-colors`}
        >
          {isExporting ? (
            <>
              <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Exportando...
            </>
          ) : (
            <>
              📥 Exportar {exportFormat.toUpperCase()} 
              {filteredCount > 0 && ` (${filteredCount} traduções)`}
            </>
          )}
        </button>
      </div>
      
      {filteredCount === 0 && (
        <div className="mt-4 text-center text-gray-500">
          Nenhuma tradução encontrada com os filtros selecionados
        </div>
      )}
    </div>
  )
}
