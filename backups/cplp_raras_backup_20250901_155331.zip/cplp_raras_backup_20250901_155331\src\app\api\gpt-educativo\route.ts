import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  try {
    const { message, context } = await request.json();

    if (!message || !message.trim()) {
      return NextResponse.json(
        { error: 'Mensagem não pode estar vazia' },
        { status: 400 }
      );
    }

    // Configuração para usar o GPT personalizado da CPLP-Raras
    const systemPrompt = `Você é o GPT Educativo da CPLP especializado em doenças raras. 

CARACTERÍSTICAS:
- Especialista em doenças raras com foco na comunidade CPLP (Brasil, Portugal, Angola, Moçambique, etc.)
- Linguagem científica mas acessível, adaptada ao nível do usuário
- Sempre mencione quando necessário consultar profissionais de saúde
- Foque em informações baseadas em evidências
- Considere os protocolos de saúde dos países da CPLP

CONTEXTO ATUAL: ${context || 'doenças raras CPLP'}

DIRETRIZES:
1. Seja preciso e educativo
2. Use exemplos práticos quando possível
3. Mencione recursos específicos da CPLP quando relevante
4. Sempre indique limitações das informações fornecidas
5. Encoraje consulta médica para casos específicos`;

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4o', // Usando o modelo mais atual
        messages: [
          {
            role: 'system',
            content: systemPrompt
          },
          {
            role: 'user',
            content: message
          }
        ],
        max_tokens: 1000,
        temperature: 0.7,
        top_p: 0.9,
      }),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      console.error('OpenAI API Error:', errorData);
      
      if (response.status === 401) {
        return NextResponse.json(
          { error: 'Configuração da API incorreta' },
          { status: 500 }
        );
      }
      
      if (response.status === 429) {
        return NextResponse.json(
          { error: 'Muitas solicitações. Tente novamente em alguns segundos.' },
          { status: 429 }
        );
      }
      
      return NextResponse.json(
        { error: 'Erro no serviço de IA. Tente novamente.' },
        { status: 500 }
      );
    }

    const data = await response.json();
    
    if (!data.choices || !data.choices[0] || !data.choices[0].message) {
      return NextResponse.json(
        { error: 'Resposta inválida do serviço de IA' },
        { status: 500 }
      );
    }

    return NextResponse.json({
      message: data.choices[0].message.content,
      usage: data.usage
    });

  } catch (error) {
    console.error('API Error:', error);
    return NextResponse.json(
      { error: 'Erro interno do servidor' },
      { status: 500 }
    );
  }
}
