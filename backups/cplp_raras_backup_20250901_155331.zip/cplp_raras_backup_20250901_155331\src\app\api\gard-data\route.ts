import { NextResponse } from 'next/server';
import path from 'path';
import fs from 'fs';
import type { GardData } from '@/types/research-data';

export const dynamic = 'force-static';

export async function GET() {
  try {
    // Caminho para o arquivo de dados GARD
    const dataPath = path.join(process.cwd(), 'src', 'data', 'gard_data.json');
    
    // Verificar se o arquivo existe
    if (!fs.existsSync(dataPath)) {
      return NextResponse.json(
        { error: 'Dados GARD não encontrados' }, 
        { status: 404 }
      );
    }

    // Ler o arquivo
    const fileContent = fs.readFileSync(dataPath, 'utf-8');
    const data: GardData = JSON.parse(fileContent);

    // Retornar os dados
    return NextResponse.json(data);

  } catch (error) {
    console.error('Erro ao carregar dados GARD:', error);
    return NextResponse.json(
      { error: 'Erro interno do servidor' }, 
      { status: 500 }
    );
  }
}
