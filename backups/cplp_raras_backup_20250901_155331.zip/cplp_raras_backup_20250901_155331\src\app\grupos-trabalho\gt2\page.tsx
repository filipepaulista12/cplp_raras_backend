import Link from 'next/link';
import Image from 'next/image';
import { getImageSrc } from '@/lib/imageUtils';
import TopShare from '@/components/TopShare';

export default function GT2() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Breadcrumb */}
      <div className="bg-white border-b">
        <div className="mx-auto max-w-7xl px-4 py-4 sm:px-6 lg:px-8">
          <nav className="flex" aria-label="Breadcrumb">
            <ol className="inline-flex items-center space-x-1 md:space-x-3">
              <li className="inline-flex items-center">
                <Link href="/" className="text-blue-600 hover:text-blue-800">Início</Link>
              </li>
              <li><div className="flex items-center"><span className="mx-2 text-gray-400">/</span><Link href="/grupos-trabalho" className="text-blue-600 hover:text-blue-800">Grupos de Trabalho</Link></div></li>
              <li aria-current="page"><div className="flex items-center"><span className="mx-2 text-gray-400">/</span><span className="text-gray-500">GT2 - Plataformas Digitais</span></div></li>
            </ol>
          </nav>
        </div>
      </div>

      <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6 lg:px-8">
        
        {/* Compartilhamento no topo */}
        <TopShare 
          title="GT2 - Plataformas Digitais"
          description="Ferramentas digitais para apoio à decisão clínica e fortalecimento da saúde digital nos países da CPLP"
        />
        
        {/* Header */}
        <div className="text-center mb-10">
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            GT2 – Plataformas Digitais
          </h1>
          <div className="w-24 h-1 bg-gradient-to-r from-green-500 to-green-600 mx-auto mb-6"></div>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Ferramentas digitais para apoio à decisão clínica, registro de casos, 
            e fortalecimento da saúde digital nos países da CPLP.
          </p>
        </div>

        {/* Content Card */}
        <div className="bg-white rounded-xl shadow-sm p-8 mb-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
            
            {/* Imagem */}
            <div className="order-2 lg:order-1">
              <div className="relative">
                <Image 
                  src={getImageSrc("/images/GT2.png.png")} 
                  alt="GT2 - Plataformas Digitais" 
                  width={500} 
                  height={350} 
                  className="rounded-lg shadow-md w-full h-auto"
                />
              </div>
            </div>

            {/* Conteúdo */}
            <div className="order-1 lg:order-2">
              <div className="flex items-center mb-6">
                <div className="bg-green-100 rounded-full p-3 mr-4">
                  <span className="text-3xl">💻</span>
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-gray-900">Objetivo</h2>
                  <div className="text-green-600 font-medium">Soluções Tecnológicas</div>
                </div>
              </div>

              <p className="text-gray-700 leading-relaxed mb-6">
                O GT2 desenvolve e implementa soluções tecnológicas avançadas para apoiar 
                pesquisadores, profissionais de saúde e gestores públicos no manejo de 
                doenças raras, ampliando a capacidade local de resposta aos desafios 
                específicos da área.
              </p>

              {/* Features */}
              <div className="space-y-3">
                <div className="flex items-center text-gray-700">
                  <span className="text-green-600 mr-3">•</span>
                  <span className="text-sm">Plataformas REDCap personalizadas</span>
                </div>
                <div className="flex items-center text-gray-700">
                  <span className="text-green-600 mr-3">•</span>
                  <span className="text-sm">Repositórios FAIR para dados</span>
                </div>
                <div className="flex items-center text-gray-700">
                  <span className="text-green-600 mr-3">•</span>
                  <span className="text-sm">APIs para integração de sistemas</span>
                </div>
                <div className="flex items-center text-gray-700">
                  <span className="text-green-600 mr-3">•</span>
                  <span className="text-sm">Ferramentas de apoio à decisão clínica</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Call to Action */}
        <div className="bg-gradient-to-r from-green-600 to-blue-600 rounded-xl p-6 text-white text-center">
          <h2 className="text-xl font-bold mb-3">Plataformas em Desenvolvimento</h2>
          <p className="text-lg mb-5 opacity-90">
            REDCap, Repositórios FAIR, APIs de dados e ferramentas de apoio clínico.
          </p>
          <Link 
            href="/sobre/ferramentas" 
            className="inline-block bg-white text-green-600 px-6 py-3 rounded-lg font-semibold hover:bg-green-50 transition-colors"
          >
            Conheça as Ferramentas
          </Link>
        </div>
      </div>
    </div>
  );
}
