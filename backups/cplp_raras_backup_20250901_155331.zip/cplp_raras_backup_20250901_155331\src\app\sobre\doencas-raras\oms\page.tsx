import { Metadata } from 'next';
import { Card, CardContent } from "@/components/ui/card";
import Link from 'next/link';
import TopShare from '@/components/TopShare';

export const metadata: Metadata = {
  title: 'OMS e Doenças Raras | CPLP-Raras',
  description: 'Diretrizes e políticas da Organização Mundial da Saúde para doenças raras.',
};

export default function OMSPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-cyan-50 via-blue-50 to-purple-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="mb-8 text-sm text-gray-600">
          <Link href="/sobre/doencas-raras" className="hover:text-blue-600">Doenças Raras</Link>
          <span className="mx-2">→</span>
          <span>OMS</span>
        </div>
        <div className="text-center mb-12">
          <div className="text-6xl mb-4">🏥</div>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-cyan-600 to-blue-600 bg-clip-text text-transparent mb-6">
            Organização Mundial da Saúde (OMS)
          </h1>
          <p className="text-xl text-gray-700">Diretrizes globais para doenças raras</p>
        </div>
        <Card className="bg-gradient-to-r from-cyan-100 to-blue-100">
          <CardContent className="p-8 text-center">
            <div className="text-4xl mb-4">🚧</div>
            <h2 className="text-2xl font-bold mb-4 text-gray-800">Página em Construção</h2>
            <p className="text-gray-700 mb-6">Conteúdo sobre diretrizes da OMS em desenvolvimento</p>
            <Link href="/sobre/doencas-raras" className="text-blue-600 hover:text-blue-800 font-medium">
              ← Voltar para Doenças Raras
            </Link>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
