'use client';

import { useLanguage } from '@/contexts/LanguageContext';
import Link from 'next/link';
import TopShare from '@/components/TopShare';

export default function RecursosDigitaisPage() {
  const { t } = useLanguage();

  const recursos = [
    {
      title: t('nav.diseases-database'),
      description: 'Base de conhecimento sobre doenças raras desenvolvida pelo GT2 - Plataformas Digitais',
      href: '/recursos-digitais/doencas',
      icon: '🧬',
      status: 'development',
      gradient: 'from-blue-500 to-purple-600',
      gt: 'GT2'
    },
    {
      title: t('nav.public-data'),
      description: 'Repositório de dados mapeados pelo GT1 - Mapeamento de Recursos na CPLP',
      href: '/recursos-digitais/dados-publicos',
      icon: '📊',
      status: 'development',
      gradient: 'from-green-500 to-teal-600',
      gt: 'GT1'
    },
    {
      title: t('nav.sof'),
      description: 'Sistema de Orientação diagnóstica desenvolvido pelo GT4 - Protocolos e Algoritmos',
      href: '/recursos-digitais/sof',
      icon: '🩺',
      status: 'planning',
      gradient: 'from-purple-500 to-pink-600',
      gt: 'GT4'
    },
    {
      title: t('nav.educational-gpt'),
      description: 'Ferramenta educativa do GT5 - Conscientização Social e GT6 - Disseminação',
      href: '/recursos-digitais/gpt-educativo',
      icon: '🤖',
      status: 'planning',
      gradient: 'from-orange-500 to-red-600',
      gt: 'GT5/GT6'
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100">
      {/* Hero Section */}
      <section className="relative py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          
          {/* Compartilhamento no topo */}
          <TopShare 
            title="Recursos Digitais CPLP-Raras"
            description="Ferramentas digitais e plataformas desenvolvidas pela rede CPLP-Raras para apoio à pesquisa em doenças raras"
          />
          
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              <span className="bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">
                {t('nav.digital-resources')}
              </span>
            </h1>
            <p className="text-xl md:text-2xl text-gray-600 mb-8 max-w-3xl mx-auto">
              {t('resources.subtitle')}
            </p>
          </div>
        </div>
      </section>

      {/* Recursos Grid */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 gap-8">
            {recursos.map((recurso, index) => (
              <div
                key={index}
                className="group relative bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 border border-gray-100"
              >
                <div className="absolute top-4 right-4 z-10 flex flex-col items-end space-y-2">
                  <span className="bg-gradient-to-r from-gray-600 to-gray-700 text-white px-3 py-1 rounded-full text-xs font-medium">
                    {recurso.gt}
                  </span>
                  {recurso.status === 'development' && (
                    <span className="bg-gradient-to-r from-yellow-500 to-orange-500 text-white px-3 py-1 rounded-full text-sm font-medium">
                      {t('common.under-development')}
                    </span>
                  )}
                  {recurso.status === 'planning' && (
                    <span className="bg-gradient-to-r from-orange-500 to-red-500 text-white px-3 py-1 rounded-full text-sm font-medium">
                      {t('common.in-planning')}
                    </span>
                  )}
                </div>
                
                <div className="p-8">
                  <div className="flex items-center mb-6">
                    <div className={`w-16 h-16 bg-gradient-to-br ${recurso.gradient} rounded-2xl flex items-center justify-center text-2xl shadow-lg group-hover:scale-110 transition-transform duration-300`}>
                      {recurso.icon}
                    </div>
                    <div className="ml-4">
                      <h3 className="text-2xl font-bold text-gray-900 mb-2">
                        {recurso.title}
                      </h3>
                    </div>
                  </div>
                  
                  <p className="text-gray-600 mb-6 text-lg leading-relaxed">
                    {recurso.description}
                  </p>
                  
                  {recurso.status === 'development' ? (
                    <Link
                      href={recurso.href}
                      className={`inline-flex items-center px-6 py-3 bg-gradient-to-r ${recurso.gradient} text-white font-medium rounded-xl hover:shadow-lg transition-all duration-200 transform hover:scale-105`}
                    >
                      Ver Progresso
                      <svg className="ml-2 w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                      </svg>
                    </Link>
                  ) : (
                    <div className="inline-flex items-center px-6 py-3 bg-gray-100 text-gray-500 font-medium rounded-xl cursor-not-allowed">
                      {recurso.status === 'planning' ? 'Em Planejamento' : t('common.under-development')}
                      <svg className="ml-2 w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                      </svg>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Grupos de Trabalho Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-blue-50 to-purple-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Conexão com os Grupos de Trabalho
            </h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Cada recurso digital é desenvolvido em colaboração direta com os Grupos de Trabalho específicos da rede CPLP-Raras
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 text-center">
              <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-teal-600 rounded-xl flex items-center justify-center mx-auto mb-4">
                <span className="text-white font-bold">GT1</span>
              </div>
              <h3 className="font-bold text-gray-900 mb-2">Mapeamento</h3>
              <p className="text-sm text-gray-600 mb-3">Dados Públicos</p>
              <Link href="/grupos-trabalho/gt1" className="text-green-600 hover:text-green-700 text-sm font-medium">
                Ver GT1 →
              </Link>
            </div>

            <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 text-center">
              <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-600 rounded-xl flex items-center justify-center mx-auto mb-4">
                <span className="text-white font-bold">GT2</span>
              </div>
              <h3 className="font-bold text-gray-900 mb-2">Plataformas</h3>
              <p className="text-sm text-gray-600 mb-3">Base de Doenças</p>
              <Link href="/grupos-trabalho/gt2" className="text-blue-600 hover:text-blue-700 text-sm font-medium">
                Ver GT2 →
              </Link>
            </div>

            <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 text-center">
              <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-pink-600 rounded-xl flex items-center justify-center mx-auto mb-4">
                <span className="text-white font-bold">GT4</span>
              </div>
              <h3 className="font-bold text-gray-900 mb-2">Protocolos</h3>
              <p className="text-sm text-gray-600 mb-3">Sistema SOF</p>
              <Link href="/grupos-trabalho/gt4" className="text-purple-600 hover:text-purple-700 text-sm font-medium">
                Ver GT4 →
              </Link>
            </div>

            <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 text-center">
              <div className="w-12 h-12 bg-gradient-to-r from-orange-500 to-red-600 rounded-xl flex items-center justify-center mx-auto mb-4">
                <span className="text-white font-bold">GT5/6</span>
              </div>
              <h3 className="font-bold text-gray-900 mb-2">Educação</h3>
              <p className="text-sm text-gray-600 mb-3">GPT Educativo</p>
              <Link href="/grupos-trabalho/gt5" className="text-orange-600 hover:text-orange-700 text-sm font-medium">
                Ver GT5 →
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Roadmap Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-white/50">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-8">
            Roadmap de Desenvolvimento
          </h2>
          <div className="space-y-6">
            <div className="flex items-center justify-between bg-white rounded-xl p-6 shadow-sm border border-gray-100">
              <div className="flex items-center">
                <div className="w-4 h-4 bg-yellow-500 rounded-full mr-4"></div>
                <span className="text-lg font-medium">Base de Doenças Raras (GT2)</span>
              </div>
              <span className="text-yellow-600 font-medium">🚧 Em Desenvolvimento</span>
            </div>
            <div className="flex items-center justify-between bg-white rounded-xl p-6 shadow-sm border border-gray-100">
              <div className="flex items-center">
                <div className="w-4 h-4 bg-yellow-500 rounded-full mr-4"></div>
                <span className="text-lg font-medium">Repositório de Dados Públicos (GT1)</span>
              </div>
              <span className="text-yellow-600 font-medium">🚧 Em Desenvolvimento</span>
            </div>
            <div className="flex items-center justify-between bg-white rounded-xl p-6 shadow-sm border border-gray-100">
              <div className="flex items-center">
                <div className="w-4 h-4 bg-orange-500 rounded-full mr-4"></div>
                <span className="text-lg font-medium">Sistema SOF (GT4)</span>
              </div>
              <span className="text-orange-600 font-medium">� Planejamento - Q2 2025</span>
            </div>
            <div className="flex items-center justify-between bg-white rounded-xl p-6 shadow-sm border border-gray-100">
              <div className="flex items-center">
                <div className="w-4 h-4 bg-orange-500 rounded-full mr-4"></div>
                <span className="text-lg font-medium">GPT Educativo (GT5/GT6)</span>
              </div>
              <span className="text-orange-600 font-medium">� Planejamento - Q3 2025</span>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
