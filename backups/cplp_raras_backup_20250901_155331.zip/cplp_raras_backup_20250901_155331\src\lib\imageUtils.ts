/**
 * Utility functions for handling image paths with basePath
 */

// Para domínio raiz raras-cplp.org, sem basePath
const basePath = '';

/**
 * Adds the basePath prefix to image paths for production
 * @param imagePath - The image path (e.g., "/images/logo.png")
 * @returns The full path with basePath if needed
 */
export function getImagePath(imagePath: string): string {
  // Para domínio raiz, retorna path original
  if (imagePath.startsWith('http')) {
    return imagePath;
  }
  
  return imagePath;
}

/**
 * Custom Image component that handles basePath correctly
 */
export function getImageSrc(src: string): string {
  return getImagePath(src);
}
