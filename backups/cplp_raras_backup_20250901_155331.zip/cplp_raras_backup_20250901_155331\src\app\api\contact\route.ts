import { NextRequest, NextResponse } from 'next/server';
import { Resend } from 'resend';

interface ContactFormData {
  name: string;
  email: string;
  institution?: string;
  country?: string;
  subject: string;
  message: string;
}

// Inicializar Resend apenas se a API key estiver configurada
const resend = process.env.RESEND_API_KEY ? new Resend(process.env.RESEND_API_KEY) : null;

export async function POST(request: NextRequest) {
  try {
    const formData: ContactFormData = await request.json();

    // Validação básica
    if (!formData.name || !formData.email || !formData.subject || !formData.message) {
      return NextResponse.json(
        { error: 'Campos obrigatórios não preenchidos' },
        { status: 400 }
      );
    }

    const timestamp = new Date().toISOString();
    const logData = {
      timestamp,
      ...formData
    };

    // Log dos dados recebidos (sempre fazer o log)
    console.log('📧 Formulário de contato recebido:', logData);
    
    // Identificar se é feedback
    const isFeedback = formData.subject && formData.subject.includes('Feedback CPLP-Raras');
    if (isFeedback) {
      console.log('🗣️ FEEDBACK DETECTADO - Processando especialmente...');
    }

    // Tentar enviar via Resend se estiver configurado
    let emailSent = false;
    if (resend && process.env.RESEND_FROM_EMAIL && process.env.CONTACT_EMAIL) {
      try {
        const result = await resend.emails.send({
          from: `CPLP-Raras <${process.env.RESEND_FROM_EMAIL}>`,
          to: [process.env.CONTACT_EMAIL],
          subject: `[CPLP-Raras] ${formData.subject}`,
          html: formatEmailTemplate(formData),
          replyTo: formData.email
        });

        if (result.data) {
          console.log('✅ Email enviado com sucesso via Resend:', result.data.id);
          emailSent = true;
        }
      } catch (emailError) {
        console.error('❌ Erro ao enviar via Resend:', emailError);
        // Continua sem falhar - o log já foi feito
      }
    }

    // Resposta baseada no status do envio
    return NextResponse.json({
      success: true,
      emailSent,
      message: emailSent 
        ? 'Mensagem enviada com sucesso! Entraremos em contato em breve.'
        : 'Mensagem registrada! Entre em contato diretamente via email se for urgente.',
      fallbackInfo: !emailSent ? {
        email: process.env.CONTACT_EMAIL || 'cplp@raras.org.br',
        subject: `[CPLP-Raras] ${formData.subject}`,
        body: formatFormDataForEmail(formData)
      } : undefined
    });

  } catch (error) {
    console.error('❌ Erro ao processar formulário:', error);
    
    return NextResponse.json(
      { 
        error: 'Erro interno do servidor',
        fallback: {
          email: 'cplp@raras.org.br',
          message: 'Use o email direto se houver problemas com o formulário'
        }
      },
      { status: 500 }
    );
  }
}

/**
 * Formata dados do formulário para email simples
 */
function formatFormDataForEmail(data: ContactFormData): string {
  return `
Mensagem enviada via formulário CPLP-Raras

Nome: ${data.name}
Email: ${data.email}
Instituição: ${data.institution || 'Não informado'}
País: ${data.country || 'Não informado'}
Assunto: ${data.subject}

Mensagem:
${data.message}

---
Enviado em: ${new Date().toLocaleString('pt-BR')}
  `.trim();
}

/**
 * Formata dados do formulário em template HTML para email
 */
function formatEmailTemplate(data: ContactFormData): string {
  return `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <title>Contato CPLP-Raras</title>
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 8px 8px 0 0; }
        .content { background: #f9f9f9; padding: 20px; border: 1px solid #ddd; }
        .field { margin-bottom: 15px; }
        .label { font-weight: bold; color: #555; }
        .value { background: white; padding: 10px; border-radius: 4px; border: 1px solid #eee; }
        .footer { text-align: center; padding: 15px; font-size: 12px; color: #666; }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h2>🩺 Nova mensagem via CPLP-Raras</h2>
        </div>
        <div class="content">
          <div class="field">
            <div class="label">Nome:</div>
            <div class="value">${data.name}</div>
          </div>
          <div class="field">
            <div class="label">Email:</div>
            <div class="value">${data.email}</div>
          </div>
          ${data.institution ? `
          <div class="field">
            <div class="label">Instituição:</div>
            <div class="value">${data.institution}</div>
          </div>
          ` : ''}
          ${data.country ? `
          <div class="field">
            <div class="label">País:</div>
            <div class="value">${data.country}</div>
          </div>
          ` : ''}
          <div class="field">
            <div class="label">Assunto:</div>
            <div class="value">${data.subject}</div>
          </div>
          <div class="field">
            <div class="label">Mensagem:</div>
            <div class="value" style="white-space: pre-wrap;">${data.message}</div>
          </div>
        </div>
        <div class="footer">
          Enviado em ${new Date().toLocaleString('pt-BR')} via www.cplp-raras.org
        </div>
      </div>
    </body>
    </html>
  `;
}
