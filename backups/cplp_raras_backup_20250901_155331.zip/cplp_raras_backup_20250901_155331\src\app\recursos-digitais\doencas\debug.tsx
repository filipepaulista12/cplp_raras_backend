'use client';

// Página de debug simples para testar se a rota funciona
export default function DoencasDebug() {
  return (
    <div className="min-h-screen bg-white p-8">
      <h1 className="text-4xl font-bold text-blue-600 mb-4">
        🩺 GARD Brasileiro - Debug
      </h1>
      <div className="space-y-4">
        <p className="text-lg text-gray-700">
          ✅ Página carregada com sucesso!
        </p>
        <p className="text-sm text-gray-500">
          URL: /recursos-digitais/doencas
        </p>
        <p className="text-sm text-gray-500">
          Data: {new Date().toLocaleString('pt-BR')}
        </p>
        
        <div className="bg-green-50 border border-green-200 rounded-lg p-4">
          <h2 className="font-medium text-green-800 mb-2">Status do Sistema:</h2>
          <ul className="text-sm text-green-700 space-y-1">
            <li>✅ Next.js 15 funcionando</li>
            <li>✅ TypeScript compilando</li>
            <li>✅ Tailwind CSS ativo</li>
            <li>✅ Roteamento correto</li>
          </ul>
        </div>

        <div className="mt-8">
          <h3 className="text-lg font-medium mb-2">Próximos passos:</h3>
          <ol className="text-sm text-gray-600 space-y-1 list-decimal list-inside">
            <li>Confirmar se esta página debug aparece</li>
            <li>Voltar para a implementação completa GARD</li>
            <li>Testar funcionalidades específicas</li>
          </ol>
        </div>
      </div>
    </div>
  );
}
