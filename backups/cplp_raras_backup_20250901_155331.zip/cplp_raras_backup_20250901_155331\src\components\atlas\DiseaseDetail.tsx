'use client';

import { useState } from 'react';
import Link from 'next/link';
import { 
  HeartIcon, 
  CpuChipIcon as NervousSystemIcon,
  EyeIcon,
  MapPinIcon,
  DocumentTextIcon,
  GlobeAltIcon,
  InformationCircleIcon
} from '@heroicons/react/24/outline';

interface Disease {
  id: string;
  name: { pt: string; en: string };
  acronym: string;
  synonyms: { pt: string[]; en: string[] };
  category: { pt: string; en: string };
  prevalence: string;
  ageOfOnset: { pt: string; en: string };
  causes: {
    genetic: { pt: string; en: string };
    inheritance: { pt: string; en: string };
  };
  symptoms: Array<{
    system: { pt: string; en: string };
    symptoms: Array<{
      name: { pt: string; en: string };
      frequency: string;
      hpoId: string;
    }>;
  }>;
  referencesCenters: {
    [country: string]: Array<{
      name: string;
      city: string;
      contact: string;
    }>;
  };
}

interface DiseaseDetailProps {
  disease: Disease;
}

export default function DiseaseDetail({ disease }: DiseaseDetailProps) {
  const [language, setLanguage] = useState<'pt' | 'en'>('pt');
  const [activeTab, setActiveTab] = useState<'overview' | 'symptoms' | 'causes' | 'centers'>('overview');

  // Ícones para sistemas corporais
  const getSystemIcon = (systemName: string) => {
    const name = systemName.toLowerCase();
    if (name.includes('cardiovascular') || name.includes('coração')) {
      return <HeartIcon className="h-5 w-5" />;
    } else if (name.includes('nervoso') || name.includes('nervous') || name.includes('neuro')) {
      return <NervousSystemIcon className="h-5 w-5" />;
    } else if (name.includes('endócrino') || name.includes('endocrine')) {
      return <EyeIcon className="h-5 w-5" />;
    }
    return <InformationCircleIcon className="h-5 w-5" />;
  };

  // Função para determinar cor da frequência
  const getFrequencyColor = (frequency: string) => {
    const percent = parseInt(frequency.replace(/[^\d]/g, ''));
    if (percent >= 80) return 'bg-red-100 text-red-800 border-red-200';
    if (percent >= 50) return 'bg-orange-100 text-orange-800 border-orange-200';
    if (percent >= 20) return 'bg-yellow-100 text-yellow-800 border-yellow-200';
    return 'bg-blue-100 text-blue-800 border-blue-200';
  };

  const tabs = [
    { 
      id: 'overview', 
      label: { pt: 'Visão Geral', en: 'Overview' },
      icon: <InformationCircleIcon className="h-4 w-4" />
    },
    { 
      id: 'symptoms', 
      label: { pt: 'Sintomas', en: 'Symptoms' },
      icon: <DocumentTextIcon className="h-4 w-4" />
    },
    { 
      id: 'causes', 
      label: { pt: 'Causas', en: 'Causes' },
      icon: <NervousSystemIcon className="h-4 w-4" />
    },
    { 
      id: 'centers', 
      label: { pt: 'Centros de Referência', en: 'Reference Centers' },
      icon: <MapPinIcon className="h-4 w-4" />
    },
  ];

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
      {/* Header da doença */}
      <div className="bg-gradient-to-br from-blue-600 via-purple-600 to-pink-600 rounded-2xl p-8 text-white mb-8">
        <div className="flex justify-between items-start">
          <div className="flex-1">
            <div className="flex items-center mb-4">
              <h1 className="text-3xl md:text-4xl font-bold mr-4">
                {disease.name[language]}
              </h1>
              <span className="px-4 py-2 bg-white bg-opacity-20 rounded-full text-lg font-semibold">
                {disease.acronym}
              </span>
            </div>
            
            <div className="grid md:grid-cols-3 gap-4 mb-6">
              <div className="bg-white bg-opacity-10 rounded-lg p-4">
                <div className="text-sm text-blue-100 mb-1">
                  {language === 'pt' ? 'Categoria' : 'Category'}
                </div>
                <div className="font-semibold">{disease.category[language]}</div>
              </div>
              <div className="bg-white bg-opacity-10 rounded-lg p-4">
                <div className="text-sm text-blue-100 mb-1">
                  {language === 'pt' ? 'Prevalência' : 'Prevalence'}
                </div>
                <div className="font-semibold">{disease.prevalence}</div>
              </div>
              <div className="bg-white bg-opacity-10 rounded-lg p-4">
                <div className="text-sm text-blue-100 mb-1">
                  {language === 'pt' ? 'Idade de Início' : 'Age of Onset'}
                </div>
                <div className="font-semibold">{disease.ageOfOnset[language]}</div>
              </div>
            </div>

            {disease.synonyms[language].length > 0 && (
              <div className="bg-white bg-opacity-10 rounded-lg p-4">
                <div className="text-sm text-blue-100 mb-2">
                  {language === 'pt' ? 'Sinônimos' : 'Synonyms'}
                </div>
                <div className="flex flex-wrap gap-2">
                  {disease.synonyms[language].map((synonym, index) => (
                    <span
                      key={index}
                      className="px-3 py-1 bg-white bg-opacity-20 rounded-full text-sm"
                    >
                      {synonym}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Seletor de idioma */}
          <div className="ml-6">
            <div className="flex bg-white bg-opacity-20 rounded-lg p-1">
              <button
                onClick={() => setLanguage('pt')}
                className={`px-3 py-1 rounded-md text-sm font-medium transition-colors ${
                  language === 'pt' 
                    ? 'bg-white text-blue-600' 
                    : 'text-white hover:bg-white hover:bg-opacity-20'
                }`}
              >
                🇵🇹 PT
              </button>
              <button
                onClick={() => setLanguage('en')}
                className={`px-3 py-1 rounded-md text-sm font-medium transition-colors ${
                  language === 'en' 
                    ? 'bg-white text-blue-600' 
                    : 'text-white hover:bg-white hover:bg-opacity-20'
                }`}
              >
                🇺🇸 EN
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Navegação por tabs */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 mb-8">
        <div className="border-b border-gray-200">
          <nav className="flex space-x-8 px-6" aria-label="Tabs">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as 'overview' | 'symptoms' | 'causes' | 'centers')}
                className={`flex items-center space-x-2 py-4 px-1 border-b-2 font-medium text-sm ${
                  activeTab === tab.id
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                {tab.icon}
                <span>{tab.label[language]}</span>
              </button>
            ))}
          </nav>
        </div>

        {/* Conteúdo das tabs */}
        <div className="p-6">
          {/* Tab: Visão Geral */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
                <h3 className="text-lg font-semibold text-blue-900 mb-4">
                  {language === 'pt' ? 'Sobre a Doença' : 'About the Disease'}
                </h3>
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-medium text-gray-900 mb-2">
                      {language === 'pt' ? 'Informações Básicas' : 'Basic Information'}
                    </h4>
                    <ul className="space-y-2 text-sm text-gray-600">
                      <li><strong>ID:</strong> {disease.id}</li>
                      <li><strong>{language === 'pt' ? 'Nome oficial' : 'Official name'}:</strong> {disease.name[language]}</li>
                      <li><strong>{language === 'pt' ? 'Sigla' : 'Acronym'}:</strong> {disease.acronym}</li>
                      <li><strong>{language === 'pt' ? 'Categoria' : 'Category'}:</strong> {disease.category[language]}</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-900 mb-2">
                      {language === 'pt' ? 'Epidemiologia' : 'Epidemiology'}
                    </h4>
                    <ul className="space-y-2 text-sm text-gray-600">
                      <li><strong>{language === 'pt' ? 'Prevalência' : 'Prevalence'}:</strong> {disease.prevalence}</li>
                      <li><strong>{language === 'pt' ? 'Idade de início' : 'Age of onset'}:</strong> {disease.ageOfOnset[language]}</li>
                      <li><strong>{language === 'pt' ? 'Padrão de herança' : 'Inheritance pattern'}:</strong> {disease.causes.inheritance[language]}</li>
                    </ul>
                  </div>
                </div>
              </div>

              {/* Nota sobre dados */}
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                <div className="flex">
                  <InformationCircleIcon className="h-5 w-5 text-yellow-600 mt-0.5 mr-3 flex-shrink-0" />
                  <div className="text-sm text-yellow-800">
                    <p className="font-medium mb-1">
                      {language === 'pt' ? 'Nota sobre os dados' : 'Note about the data'}
                    </p>
                    <p>
                      {language === 'pt' 
                        ? 'As informações apresentadas são baseadas em literatura científica e bancos de dados internacionais. Para casos específicos, consulte sempre um profissional de saúde qualificado.'
                        : 'The information presented is based on scientific literature and international databases. For specific cases, always consult a qualified healthcare professional.'
                      }
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Tab: Sintomas */}
          {activeTab === 'symptoms' && (
            <div className="space-y-6">
              <div className="mb-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  {language === 'pt' ? 'Sintomas por Sistema Corporal' : 'Symptoms by Body System'}
                </h3>
                <p className="text-gray-600 text-sm">
                  {language === 'pt' 
                    ? 'Os sintomas são organizados por sistema corporal com suas respectivas frequências. Códigos HPO são fornecidos para interoperabilidade.'
                    : 'Symptoms are organized by body system with their respective frequencies. HPO codes are provided for interoperability.'
                  }
                </p>
              </div>

              {disease.symptoms.map((systemGroup, index) => (
                <div key={index} className="bg-white border border-gray-200 rounded-lg overflow-hidden">
                  <div className="bg-gray-50 px-6 py-4 border-b border-gray-200">
                    <h4 className="text-lg font-medium text-gray-900 flex items-center">
                      {getSystemIcon(systemGroup.system[language])}
                      <span className="ml-3">{systemGroup.system[language]}</span>
                      <span className="ml-2 text-sm text-gray-500">
                        ({systemGroup.symptoms.length} {language === 'pt' ? 'sintomas' : 'symptoms'})
                      </span>
                    </h4>
                  </div>
                  
                  <div className="p-6">
                    <div className="grid gap-4">
                      {systemGroup.symptoms.map((symptom, symIndex) => (
                        <div key={symIndex} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                          <div className="flex-1">
                            <div className="font-medium text-gray-900">
                              {symptom.name[language]}
                            </div>
                            <div className="text-sm text-gray-500 mt-1">
                              HPO: <code className="bg-white px-2 py-1 rounded text-xs font-mono">{symptom.hpoId}</code>
                            </div>
                          </div>
                          <div className="ml-4">
                            <span className={`px-3 py-1 rounded-full text-sm font-medium border ${getFrequencyColor(symptom.frequency)}`}>
                              {symptom.frequency}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              ))}

              {/* Legenda de frequência */}
              <div className="bg-gray-50 rounded-lg p-4">
                <h4 className="font-medium text-gray-900 mb-3">
                  {language === 'pt' ? 'Legenda de Frequência' : 'Frequency Legend'}
                </h4>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
                  <div className="flex items-center">
                    <span className="w-4 h-4 bg-red-100 border border-red-200 rounded mr-2"></span>
                    <span>80-100% ({language === 'pt' ? 'Muito comum' : 'Very common'})</span>
                  </div>
                  <div className="flex items-center">
                    <span className="w-4 h-4 bg-orange-100 border border-orange-200 rounded mr-2"></span>
                    <span>50-79% ({language === 'pt' ? 'Comum' : 'Common'})</span>
                  </div>
                  <div className="flex items-center">
                    <span className="w-4 h-4 bg-yellow-100 border border-yellow-200 rounded mr-2"></span>
                    <span>20-49% ({language === 'pt' ? 'Ocasional' : 'Occasional'})</span>
                  </div>
                  <div className="flex items-center">
                    <span className="w-4 h-4 bg-blue-100 border border-blue-200 rounded mr-2"></span>
                    <span>&lt;20% ({language === 'pt' ? 'Raro' : 'Rare'})</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Tab: Causas */}
          {activeTab === 'causes' && (
            <div className="space-y-6">
              <div className="bg-green-50 border border-green-200 rounded-lg p-6">
                <h3 className="text-lg font-semibold text-green-900 mb-4 flex items-center">
                  <NervousSystemIcon className="h-5 w-5 mr-2" />
                  {language === 'pt' ? 'Informações Genéticas' : 'Genetic Information'}
                </h3>
                
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-medium text-gray-900 mb-3">
                      {language === 'pt' ? 'Base Genética' : 'Genetic Basis'}
                    </h4>
                    <p className="text-gray-700 leading-relaxed">
                      {disease.causes.genetic[language]}
                    </p>
                  </div>
                  
                  <div>
                    <h4 className="font-medium text-gray-900 mb-3">
                      {language === 'pt' ? 'Padrão de Herança' : 'Inheritance Pattern'}
                    </h4>
                    <p className="text-gray-700 leading-relaxed">
                      {disease.causes.inheritance[language]}
                    </p>
                  </div>
                </div>
              </div>

              {/* Nota sobre aconselhamento genético */}
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
                <h4 className="font-medium text-blue-900 mb-3">
                  {language === 'pt' ? 'Aconselhamento Genético' : 'Genetic Counseling'}
                </h4>
                <p className="text-blue-800 text-sm leading-relaxed">
                  {language === 'pt' 
                    ? 'Recomenda-se aconselhamento genético para famílias afetadas ou com histórico da doença. Um geneticista pode fornecer informações específicas sobre riscos de recorrência e opções de testagem.'
                    : 'Genetic counseling is recommended for affected families or those with a history of the disease. A geneticist can provide specific information about recurrence risks and testing options.'
                  }
                </p>
              </div>
            </div>
          )}

          {/* Tab: Centros de Referência */}
          {activeTab === 'centers' && (
            <div className="space-y-6">
              <div className="mb-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  {language === 'pt' ? 'Centros de Referência na CPLP' : 'Reference Centers in CPLP'}
                </h3>
                <p className="text-gray-600 text-sm">
                  {language === 'pt' 
                    ? 'Lista de centros especializados nos países da CPLP que oferecem diagnóstico e tratamento para esta condição.'
                    : 'List of specialized centers in CPLP countries that offer diagnosis and treatment for this condition.'
                  }
                </p>
              </div>

              {Object.entries(disease.referencesCenters).map(([country, centers]) => (
                <div key={country} className="bg-white border border-gray-200 rounded-lg overflow-hidden">
                  <div className="bg-gradient-to-r from-blue-50 to-purple-50 px-6 py-4 border-b border-gray-200">
                    <h4 className="text-lg font-medium text-gray-900 flex items-center">
                      <GlobeAltIcon className="h-5 w-5 mr-2 text-blue-600" />
                      {country === 'brasil' ? 'Brasil' : 
                       country === 'portugal' ? 'Portugal' : 
                       country.charAt(0).toUpperCase() + country.slice(1)}
                      <span className="ml-2 text-sm text-gray-500">
                        ({centers.length} {language === 'pt' ? 'centro(s)' : 'center(s)'})
                      </span>
                    </h4>
                  </div>
                  
                  <div className="p-6">
                    <div className="grid gap-4">
                      {centers.map((center, index) => (
                        <div key={index} className="bg-gray-50 rounded-lg p-4">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <h5 className="font-medium text-gray-900 mb-1">
                                {center.name}
                              </h5>
                              <div className="flex items-center text-sm text-gray-600 mb-2">
                                <MapPinIcon className="h-4 w-4 mr-1" />
                                {center.city}
                              </div>
                              <div className="text-sm text-blue-600">
                                <a href={`mailto:${center.contact}`} className="hover:text-blue-800">
                                  {center.contact}
                                </a>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              ))}

              {/* Nota sobre centros */}
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                <div className="flex">
                  <InformationCircleIcon className="h-5 w-5 text-yellow-600 mt-0.5 mr-3 flex-shrink-0" />
                  <div className="text-sm text-yellow-800">
                    <p className="font-medium mb-1">
                      {language === 'pt' ? 'Como usar estas informações' : 'How to use this information'}
                    </p>
                    <p>
                      {language === 'pt' 
                        ? 'Entre em contato diretamente com os centros para verificar disponibilidade, procedimentos de encaminhamento e cobertura do sistema de saúde local.'
                        : 'Contact centers directly to verify availability, referral procedures, and local health system coverage.'
                      }
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Footer com links úteis */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="text-center">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">
            {language === 'pt' ? 'Links Úteis' : 'Useful Links'}
          </h3>
          <div className="flex flex-wrap justify-center gap-4">
            <a
              href={`https://hpo.jax.org/app/browse/disease/MONDO:0005148`}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center px-4 py-2 bg-blue-100 text-blue-800 rounded-lg hover:bg-blue-200 transition-colors text-sm"
            >
              <span className="mr-2">🔗</span>
              Human Phenotype Ontology
            </a>
            <a
              href={`https://www.orpha.net/`}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center px-4 py-2 bg-green-100 text-green-800 rounded-lg hover:bg-green-200 transition-colors text-sm"
            >
              <span className="mr-2">🌐</span>
              Orphanet
            </a>
            <Link
              href="/atlas"
              className="inline-flex items-center px-4 py-2 bg-purple-100 text-purple-800 rounded-lg hover:bg-purple-200 transition-colors text-sm"
            >
              <span className="mr-2">🔙</span>
              {language === 'pt' ? 'Voltar ao Atlas' : 'Back to Atlas'}
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
