import Link from 'next/link';
import TopShare from '@/components/TopShare';

export default function ProjetosCadastrados() {
  // Dados mockados temporários - serão substituídos por dados reais do REDCap
  const projetos: any[] = [
    // Array vazio por enquanto - será populado quando houver projetos reais cadastrados
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Breadcrumb */}
      <div className="bg-white border-b">
        <div className="mx-auto max-w-7xl px-4 py-4 sm:px-6 lg:px-8">
          
          {/* Compartilhamento no topo */}
          <TopShare 
            title="Projetos CPLP-Raras"
            description="Projetos de pesquisa em doenças raras cadastrados na rede CPLP-Raras"
          />
          
          <nav className="flex" aria-label="Breadcrumb">
            <ol className="inline-flex items-center space-x-1 md:space-x-3">
              <li className="inline-flex items-center">
                <Link href="/" className="text-blue-600 hover:text-blue-800">
                  Início
                </Link>
              </li>
              <li aria-current="page">
                <div className="flex items-center">
                  <span className="mx-2 text-gray-400">/</span>
                  <span className="text-gray-500">Projetos</span>
                </div>
              </li>
            </ol>
          </nav>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            📚 Projetos de Pesquisa
          </h1>
          <div className="w-32 h-1 bg-gradient-to-r from-blue-600 to-green-600 mx-auto mb-8"></div>
          <p className="text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed">
            Conheça os projetos de pesquisa em doenças raras desenvolvidos pelos países da CPLP.
          </p>
        </div>

        {/* Ações */}
        <div className="flex justify-between items-center mb-8">
          <div className="text-sm text-gray-600">
            {projetos.length === 0 ? 'Nenhum projeto cadastrado ainda' : `${projetos.length} projeto(s) encontrado(s)`}
          </div>
          <Link
            href="/projetos/cadastrar"
            className="inline-flex items-center px-6 py-3 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 transition-colors shadow-md"
          >
            <span className="text-lg mr-2">+</span>
            Cadastrar Novo Projeto
          </Link>
        </div>

        {/* Lista de Projetos */}
        {projetos.length === 0 ? (
          /* Estado vazio */
          <div className="bg-white rounded-2xl shadow-lg p-12 text-center">
            <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <span className="text-4xl text-gray-400">📋</span>
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              Nenhum Projeto Cadastrado
            </h2>
            <p className="text-lg text-gray-600 mb-8 max-w-2xl mx-auto">
              Seja o primeiro a cadastrar um projeto de pesquisa em doenças raras 
              e contribua para o fortalecimento da rede colaborativa da CPLP.
            </p>
            <div className="space-y-4">
              <Link
                href="/projetos/cadastrar"
                className="inline-block bg-blue-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors"
              >
                Cadastrar Primeiro Projeto
              </Link>
              <div className="text-center">
                <Link
                  href="/sobre/ferramentas"
                  className="inline-block text-blue-600 hover:text-blue-800 font-medium"
                >
                  ← Voltar para Ferramentas
                </Link>
              </div>
            </div>
          </div>
        ) : (
          /* Lista de projetos (quando houver dados) */
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {projetos.map((projeto, index) => (
              <div key={index} className="bg-white rounded-2xl shadow-lg p-6 hover:shadow-xl transition-shadow">
                <div className="flex items-start justify-between mb-4">
                  <span className="inline-flex items-center px-3 py-1 rounded-full text-sm bg-blue-100 text-blue-800 font-medium">
                    {projeto.pais}
                  </span>
                  <span className="text-sm text-gray-500">
                    {projeto.area_doenca}
                  </span>
                </div>
                
                <h3 className="text-xl font-bold text-gray-900 mb-3 line-clamp-2">
                  {projeto.titulo}
                </h3>
                
                <p className="text-gray-600 mb-4 line-clamp-3">
                  {projeto.descricao}
                </p>
                
                <div className="border-t pt-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-900">
                        {projeto.responsavel}
                      </p>
                      <p className="text-sm text-gray-600">
                        {projeto.instituicao}
                      </p>
                    </div>
                    <button className="text-blue-600 hover:text-blue-800 font-medium text-sm">
                      Ver detalhes →
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Informações sobre futuras estatísticas */}
        <div className="mt-16 bg-gradient-to-r from-blue-600 to-green-600 rounded-2xl p-8 text-white text-center">
          <h2 className="text-2xl font-bold mb-4">
            📊 Estatísticas em Breve
          </h2>
          <p className="text-xl mb-6 opacity-90 max-w-3xl mx-auto">
            Assim que tivermos projetos cadastrados, mostraremos estatísticas detalhadas 
            sobre a distribuição por país, área de pesquisa e outras métricas relevantes.
          </p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-8">
            <div className="bg-white bg-opacity-20 rounded-lg p-4">
              <div className="text-2xl font-bold">--</div>
              <div className="text-sm opacity-90">Projetos Ativos</div>
            </div>
            <div className="bg-white bg-opacity-20 rounded-lg p-4">
              <div className="text-2xl font-bold">--</div>
              <div className="text-sm opacity-90">Países Participantes</div>
            </div>
            <div className="bg-white bg-opacity-20 rounded-lg p-4">
              <div className="text-2xl font-bold">--</div>
              <div className="text-sm opacity-90">Áreas de Pesquisa</div>
            </div>
            <div className="bg-white bg-opacity-20 rounded-lg p-4">
              <div className="text-2xl font-bold">--</div>
              <div className="text-sm opacity-90">Colaborações</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
