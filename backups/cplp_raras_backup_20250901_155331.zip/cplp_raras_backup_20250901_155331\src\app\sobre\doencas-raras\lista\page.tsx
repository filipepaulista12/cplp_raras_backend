import { Metadata } from 'next';
import { Card, CardContent } from "@/components/ui/card";
import Link from 'next/link';

export const metadata: Metadata = {
  title: 'Lista de Doenças Raras | CPLP-Raras',
  description: 'Lista completa e categorizada de doenças raras reconhecidas mundialmente, com definições e classificações.',
  keywords: 'lista doenças raras, classificação, categorias, órfãs, CID',
};

export default function ListaDoencasPage() {
  const categorias = [
    {
      nome: "Doenças Genéticas",
      exemplos: ["Fibrose Cística", "Doença de Huntington", "Síndrome de Marfan", "Distrofia Muscular"],
      cor: "bg-blue-100 border-blue-400",
      icon: "🧬"
    },
    {
      nome: "Doenças Autoimunes",
      exemplos: ["Esclerose Lateral Amiotrófica", "Miastenia Gravis", "Síndrome de Sjögren", "Polimiosite"],
      cor: "bg-green-100 border-green-400",
      icon: "🛡️"
    },
    {
      nome: "Cânceres Raros",
      exemplos: ["Sarcoma", "Tumores Neuroendócrinos", "Leucemia Rara", "Câncer Orbital"],
      cor: "bg-red-100 border-red-400",
      icon: "🔬"
    },
    {
      nome: "Doenças Metabólicas",
      exemplos: ["Doença de Gaucher", "Mucopolissacaridoses", "Doença de Pompe", "Fenilcetonúria"],
      cor: "bg-purple-100 border-purple-400",
      icon: "⚗️"
    },
    {
      nome: "Doenças Neurológicas",
      exemplos: ["Atrofia Muscular Espinhal", "Doença de Parkinson Juvenil", "Epilepsia Rara", "Ataxias"],
      cor: "bg-yellow-100 border-yellow-400",
      icon: "🧠"
    },
    {
      nome: "Malformações Congênitas",
      exemplos: ["Espinha Bífida", "Anencefalia", "Cardiopatias Complexas", "Fissuras Raras"],
      cor: "bg-pink-100 border-pink-400",
      icon: "👶"
    }
  ];

  const estatisticas = [
    { label: "Doenças Raras Conhecidas", valor: "7.000+", icon: "📊" },
    { label: "Pessoas Afetadas Globalmente", valor: "300M+", icon: "🌍" },
    { label: "Origem Genética", valor: "80%", icon: "🧬" },
    { label: "Manifestação na Infância", valor: "50%", icon: "👶" }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        
        {/* Breadcrumb */}
        <div className="mb-8 text-sm text-gray-600">
          <Link href="/sobre/doencas-raras" className="hover:text-blue-600">Doenças Raras</Link>
          <span className="mx-2">→</span>
          <span>Lista de Doenças</span>
        </div>

        {/* Header */}
        <div className="text-center mb-12">
          <div className="text-6xl mb-4">📋</div>
          <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent mb-6">
            Lista de Doenças Raras
          </h1>
          <p className="text-xl text-gray-700 max-w-3xl mx-auto leading-relaxed">
            Classificação e categorização das principais doenças raras reconhecidas mundialmente
          </p>
        </div>

        {/* Estatísticas */}
        <div className="grid md:grid-cols-4 gap-6 mb-12">
          {estatisticas.map((stat, index) => (
            <Card key={index} className="bg-gradient-to-br from-white to-gray-50">
              <CardContent className="p-6 text-center">
                <div className="text-3xl mb-2">{stat.icon}</div>
                <div className="text-2xl font-bold text-gray-800 mb-1">{stat.valor}</div>
                <p className="text-sm text-gray-600">{stat.label}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Definição */}
        <Card className="mb-12 bg-gradient-to-r from-blue-100 to-purple-100">
          <CardContent className="p-8">
            <h2 className="text-2xl font-bold mb-6 text-center text-gray-800">
              🔍 Definição de Doença Rara
            </h2>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="text-center">
                <h3 className="font-bold text-lg text-blue-600 mb-2">Europa</h3>
                <p className="text-sm text-gray-700">Menos de 1 em 2.000 pessoas</p>
              </div>
              <div className="text-center">
                <h3 className="font-bold text-lg text-purple-600 mb-2">Estados Unidos</h3>
                <p className="text-sm text-gray-700">Menos de 200.000 pessoas afetadas</p>
              </div>
              <div className="text-center">
                <h3 className="font-bold text-lg text-pink-600 mb-2">Brasil</h3>
                <p className="text-sm text-gray-700">Até 65 em 100.000 pessoas</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Categorias Principais */}
        <div className="mb-12">
          <h2 className="text-3xl font-bold text-center mb-8 text-gray-800">
            🗂️ Categorias Principais
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {categorias.map((categoria, index) => (
              <Card key={index} className={`border-l-4 ${categoria.cor} hover:shadow-lg transition-shadow`}>
                <CardContent className="p-6">
                  <div className="flex items-center gap-3 mb-4">
                    <span className="text-2xl">{categoria.icon}</span>
                    <h3 className="font-bold text-lg text-gray-800">{categoria.nome}</h3>
                  </div>
                  <div className="space-y-2">
                    {categoria.exemplos.map((exemplo, i) => (
                      <div key={i} className="text-sm text-gray-600 bg-white p-2 rounded">
                        • {exemplo}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Recursos e Bases de Dados */}
        <Card className="mb-12">
          <CardContent className="p-8">
            <h2 className="text-2xl font-bold mb-6 text-center text-gray-800">
              🗄️ Principais Bases de Dados
            </h2>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="bg-blue-50 p-6 rounded-lg">
                <h3 className="font-bold text-lg text-blue-800 mb-3">
                  🌐 Bases Internacionais
                </h3>
                <ul className="space-y-2 text-sm text-gray-700">
                  <li>• <strong>Orphanet:</strong> Base europeia com 6.000+ doenças</li>
                  <li>• <strong>GARD:</strong> Centro americano de informações</li>
                  <li>• <strong>OMIM:</strong> Herança mendeliana online</li>
                  <li>• <strong>ICD-11:</strong> Classificação internacional da OMS</li>
                </ul>
              </div>
              <div className="bg-green-50 p-6 rounded-lg">
                <h3 className="font-bold text-lg text-green-800 mb-3">
                  🇧🇷 Bases Nacionais
                </h3>
                <ul className="space-y-2 text-sm text-gray-700">
                  <li>• <strong>DATASUS:</strong> Sistema do Ministério da Saúde</li>
                  <li>• <strong>CID-10:</strong> Classificação brasileira</li>
                  <li>• <strong>PCDT:</strong> Protocolos clínicos nacionais</li>
                  <li>• <strong>RENAME:</strong> Lista de medicamentos essenciais</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Características Comuns */}
        <Card className="mb-12">
          <CardContent className="p-8">
            <h2 className="text-2xl font-bold mb-6 text-center text-gray-800">
              ⚡ Características Comuns
            </h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="text-center p-4 bg-red-50 rounded-lg">
                <div className="text-3xl mb-2">⏱️</div>
                <h3 className="font-bold text-red-700 mb-2">Diagnóstico Tardio</h3>
                <p className="text-sm text-gray-600">Média de 4-8 anos para diagnóstico correto</p>
              </div>
              <div className="text-center p-4 bg-blue-50 rounded-lg">
                <div className="text-3xl mb-2">💊</div>
                <h3 className="font-bold text-blue-700 mb-2">Poucos Tratamentos</h3>
                <p className="text-sm text-gray-600">90% não possuem tratamento aprovado</p>
              </div>
              <div className="text-center p-4 bg-green-50 rounded-lg">
                <div className="text-3xl mb-2">👨‍⚕️</div>
                <h3 className="font-bold text-green-700 mb-2">Especialização</h3>
                <p className="text-sm text-gray-600">Requer médicos especialistas</p>
              </div>
              <div className="text-center p-4 bg-purple-50 rounded-lg">
                <div className="text-3xl mb-2">💰</div>
                <h3 className="font-bold text-purple-700 mb-2">Alto Custo</h3>
                <p className="text-sm text-gray-600">Tratamentos frequentemente caros</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Links Úteis */}
        <Card className="bg-gradient-to-r from-purple-100 to-pink-100">
          <CardContent className="p-8">
            <h2 className="text-2xl font-bold mb-6 text-center text-gray-800">
              🔗 Recursos para Consulta
            </h2>
            <div className="grid md:grid-cols-3 gap-6 text-center">
              <div className="bg-white p-4 rounded-lg">
                <h3 className="font-bold text-gray-800 mb-2">Para Profissionais</h3>
                <p className="text-sm text-gray-600 mb-3">Diretrizes clínicas e protocolos</p>
                <button className="text-blue-600 text-sm font-medium hover:text-blue-800">
                  Acessar Recursos →
                </button>
              </div>
              <div className="bg-white p-4 rounded-lg">
                <h3 className="font-bold text-gray-800 mb-2">Para Pacientes</h3>
                <p className="text-sm text-gray-600 mb-3">Informações em linguagem simples</p>
                <button className="text-purple-600 text-sm font-medium hover:text-purple-800">
                  Ver Materiais →
                </button>
              </div>
              <div className="bg-white p-4 rounded-lg">
                <h3 className="font-bold text-gray-800 mb-2">Para Pesquisadores</h3>
                <p className="text-sm text-gray-600 mb-3">Bases de dados e literatura</p>
                <button className="text-pink-600 text-sm font-medium hover:text-pink-800">
                  Explorar Dados →
                </button>
              </div>
            </div>
          </CardContent>
        </Card>

      </div>
    </div>
  );
}
