import Link from 'next/link';
import TopShare from '@/components/TopShare';

export default function ToolsPlatforms() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Breadcrumb */}
      <div className="bg-white border-b">
        <div className="mx-auto max-w-7xl px-4 py-4 sm:px-6 lg:px-8">
          <nav className="flex" aria-label="Breadcrumb">
            <ol className="inline-flex items-center space-x-1 md:space-x-3">
              <li className="inline-flex items-center">
                <Link href="/" className="text-blue-600 hover:text-blue-800">
                  Início
                </Link>
              </li>
              <li>
                <div className="flex items-center">
                  <span className="mx-2 text-gray-400">/</span>
                  <Link href="/sobre" className="text-blue-600 hover:text-blue-800">
                    Sobre
                  </Link>
                </div>
              </li>
              <li aria-current="page">
                <div className="flex items-center">
                  <span className="mx-2 text-gray-400">/</span>
                  <span className="text-gray-500">Ferramentas</span>
                </div>
              </li>
            </ol>
          </nav>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        
        {/* Compartilhamento no topo */}
        <TopShare 
          title="Ferramentas e Plataformas"
          description="Ferramentas e tecnologias utilizadas no projeto CPLP-Raras"
        />
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            🧰 Ferramentas e Plataformas
          </h1>
          <div className="w-32 h-1 bg-gradient-to-r from-blue-600 to-green-600 mx-auto mb-8"></div>
          <p className="text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed">
            Conheça as ferramentas tecnológicas e plataformas digitais que sustentam o projeto CPLP-Raras.
          </p>
        </div>

        {/* REDCap */}
        <section className="mb-16">
          <div className="bg-white rounded-2xl shadow-lg p-8 md:p-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-8">
              📊 REDCap (Research Electronic Data Capture)
            </h2>
            
            <p className="text-lg text-gray-700 leading-relaxed mb-8">
              Plataforma líder mundial para coleta e gestão de dados de pesquisa clínica, 
              permitindo estudos multicêntricos seguros e conformes com regulamentações internacionais.
            </p>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
              {/* Funcionalidades Principais */}
              <div>
                <h3 className="text-xl font-semibold text-blue-900 mb-6">
                  ⚡ Funcionalidades Principais
                </h3>
                <div className="space-y-4">
                  <div className="flex items-start space-x-3">
                    <span className="text-blue-600 text-lg">🔒</span>
                    <div>
                      <span className="text-blue-800 font-medium text-sm block">Segurança HIPAA/GDPR</span>
                      <span className="text-blue-700 text-sm">Conformidade com regulamentações de privacidade</span>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <span className="text-blue-600 text-lg">🌐</span>
                    <div>
                      <span className="text-blue-800 font-medium text-sm block">Acesso Web</span>
                      <span className="text-blue-700 text-sm">Interface intuitiva, sem instalação</span>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <span className="text-blue-600 text-lg">📋</span>
                    <div>
                      <span className="text-blue-800 font-medium text-sm block">Formulários Dinâmicos</span>
                      <span className="text-blue-700 text-sm">Validação automática e lógica condicional</span>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <span className="text-blue-600 text-lg">🔄</span>
                    <div>
                      <span className="text-blue-800 font-medium text-sm block">API Integrada</span>
                      <span className="text-blue-700 text-sm">Sincronização com sistemas externos</span>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <span className="text-blue-600 text-lg">📊</span>
                    <div>
                      <span className="text-blue-800 font-medium text-sm block">Relatórios Automatizados</span>
                      <span className="text-blue-700 text-sm">Dashboards em tempo real</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Especificações Técnicas */}
              <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-6 rounded-lg border border-blue-200">
                <h3 className="text-xl font-semibold text-blue-900 mb-6">
                  🔧 Especificações Técnicas
                </h3>
                <div className="space-y-4">
                  <div className="flex items-start space-x-3">
                    <span className="text-blue-600 text-lg">🏗️</span>
                    <div>
                      <span className="text-blue-800 font-medium text-sm block">Arquitetura</span>
                      <span className="text-blue-700 text-sm">Web-based, MySQL, PHP, AJAX</span>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <span className="text-blue-600 text-lg">🎯</span>
                    <div>
                      <span className="text-blue-800 font-medium text-sm block">Hosting</span>
                      <span className="text-blue-700 text-sm">Nuvem institucional segura</span>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <span className="text-blue-600 text-lg">📱</span>
                    <div>
                      <span className="text-blue-800 font-medium text-sm block">Compatibilidade</span>
                      <span className="text-blue-700 text-sm">Desktop, tablet, smartphone</span>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <span className="text-blue-600 text-lg">🔐</span>
                    <div>
                      <span className="text-blue-800 font-medium text-sm block">Autenticação</span>
                      <span className="text-blue-700 text-sm">Multi-fator, SSO, LDAP</span>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <span className="text-blue-600 text-lg">💾</span>
                    <div>
                      <span className="text-blue-800 font-medium text-sm block">Backup</span>
                      <span className="text-blue-700 text-sm">Automático diário e versionamento</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Repositórios FAIR */}
        <section className="mb-16">
          <div className="bg-white rounded-2xl shadow-lg p-8 md:p-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-8">
              🗄️ Repositórios FAIR
            </h2>
            
            <p className="text-lg text-gray-700 leading-relaxed mb-8">
              Os repositórios FAIR garantem que os dados sejam Findable (Localizáveis), 
              Accessible (Acessíveis), Interoperable (Interoperáveis) e Reusable (Reutilizáveis).
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow">
                <h3 className="text-xl font-semibold text-gray-900 mb-3 flex items-center">
                  <span className="text-2xl mr-3">🔍</span>
                  Portal de Dados Abertos
                </h3>
                <p className="text-gray-600 mb-4">
                  Interface pública para acesso a dados agregados e anonimizados sobre doenças raras na CPLP.
                </p>
                <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors">
                  Acessar Portal
                </button>
              </div>

              <div className="border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow">
                <h3 className="text-xl font-semibold text-gray-900 mb-3 flex items-center">
                  <span className="text-2xl mr-3">🔬</span>
                  Repositório de Metadados
                </h3>
                <p className="text-gray-600 mb-4">
                  Catalogação padronizada de estudos, protocolos e recursos de pesquisa em doenças raras.
                </p>
                <button className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors">
                  Consultar Catálogo
                </button>
              </div>
            </div>
          </div>
        </section>

        {/* Plataformas de Colaboração */}
        <section className="mb-16">
          <div className="bg-white rounded-2xl shadow-lg p-8 md:p-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-8">
              🤝 Plataformas de Colaboração
            </h2>
            
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="bg-blue-50 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl">💬</span>
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Sistema de Messaging</h3>
                <p className="text-gray-600 text-sm">
                  Comunicação segura entre pesquisadores, clínicos e instituições da CPLP.
                </p>
              </div>

              <div className="text-center">
                <div className="bg-green-50 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl">📅</span>
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Agenda Colaborativa</h3>
                <p className="text-gray-600 text-sm">
                  Coordenação de eventos, reuniões e marcos do projeto entre países.
                </p>
              </div>

              <div className="text-center">
                <div className="bg-purple-50 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl">📊</span>
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Dashboard Analítico</h3>
                <p className="text-gray-600 text-sm">
                  Visualizações em tempo real de indicadores e métricas do projeto.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Ferramentas de Desenvolvimento */}
        <section className="mb-16">
          <div className="bg-white rounded-2xl shadow-lg p-8 md:p-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-8">
              ⚙️ Ferramentas de Desenvolvimento
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="bg-gray-50 p-6 rounded-lg text-center">
                <div className="text-2xl mb-3">⚛️</div>
                <h3 className="font-semibold text-gray-900 mb-2">React + TypeScript</h3>
                <p className="text-gray-600 text-sm">Frontend moderno e tipado</p>
              </div>

              <div className="bg-gray-50 p-6 rounded-lg text-center">
                <div className="text-2xl mb-3">🚀</div>
                <h3 className="font-semibold text-gray-900 mb-2">Next.js</h3>
                <p className="text-gray-600 text-sm">Framework full-stack</p>
              </div>

              <div className="bg-gray-50 p-6 rounded-lg text-center">
                <div className="text-2xl mb-3">🐳</div>
                <h3 className="font-semibold text-gray-900 mb-2">Docker</h3>
                <p className="text-gray-600 text-sm">Containerização e deploy</p>
              </div>

              <div className="bg-gray-50 p-6 rounded-lg text-center">
                <div className="text-2xl mb-3">☁️</div>
                <h3 className="font-semibold text-gray-900 mb-2">Vercel</h3>
                <p className="text-gray-600 text-sm">Hospedagem e CI/CD</p>
              </div>
            </div>
          </div>
        </section>

        {/* Call to Action */}
        <section className="text-center">
          <div className="bg-gradient-to-r from-blue-600 to-green-600 rounded-2xl shadow-lg p-8 md:p-12 text-white">
            <h2 className="text-3xl font-bold mb-6">
              🌍 Contribua com o Projeto CPLP-Raras
            </h2>
            <p className="text-xl opacity-90 max-w-3xl mx-auto leading-relaxed mb-8">
              Junte-se à nossa rede de pesquisadores, clínicos e instituições trabalhando 
              para melhorar o diagnóstico e tratamento de doenças raras na CPLP.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link 
                href="/sobre/equipe" 
                className="bg-white text-blue-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors"
              >
                Conheça a Equipe
              </Link>
              <Link 
                href="/contato" 
                className="border-2 border-white text-white px-8 py-3 rounded-lg font-semibold hover:bg-white hover:text-blue-600 transition-colors"
              >
                Entre em Contato
              </Link>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
