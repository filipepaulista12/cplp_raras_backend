# Configurações do Servidor SFTP para o novo domínio raras-cplp.org
# Este arquivo contém credenciais sensíveis e NÃO deve ser commitado

# Configurações do servidor para o novo domínio
$ServerIP = "200.144.254.4"
$ServerPort = "22"
$Username = "ubuntu"
$Password = "vFpyJS4FA"
$RemotePath = "/home/ubuntu/upload"  # Pasta temporária com permissões
$FinalURL = "https://raras-cplp.org/"

# ATENÇÃO: Este arquivo está no .gitignore
# Não compartilhe este arquivo publicamente!
