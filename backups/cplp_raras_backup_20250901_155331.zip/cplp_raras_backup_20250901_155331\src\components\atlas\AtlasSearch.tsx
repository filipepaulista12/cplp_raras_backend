'use client';

import { useState, useEffect } from 'react';
import { MagnifyingGlassIcon, FunnelIcon, XMarkIcon } from '@heroicons/react/24/outline';
import Link from 'next/link';
import diseasesData from '@/data/diseases.json';

interface Disease {
  id: string;
  name: { pt: string; en: string };
  acronym: string;
  synonyms: { pt: string[]; en: string[] };
  category: { pt: string; en: string };
  prevalence: string;
  ageOfOnset: { pt: string; en: string };
}

interface SearchFilters {
  query: string;
  category: string;
  ageGroup: string;
  country: string;
  letter: string;
}

export default function AtlasSearch() {
  const [language, setLanguage] = useState<'pt' | 'en'>('pt');
  const [diseases, setDiseases] = useState<Disease[]>([]);
  const [filteredDiseases, setFilteredDiseases] = useState<Disease[]>([]);
  const [showFilters, setShowFilters] = useState(false);
  const [filters, setFilters] = useState<SearchFilters>({
    query: '',
    category: '',
    ageGroup: '',
    country: '',
    letter: ''
  });

  // Carregar dados das doenças
  useEffect(() => {
    setDiseases(diseasesData.diseases as Disease[]);
    setFilteredDiseases(diseasesData.diseases as Disease[]);
  }, []);

  // Aplicar filtros
  useEffect(() => {
    let filtered = diseases;

    // Filtro de busca por texto
    if (filters.query) {
      const query = filters.query.toLowerCase();
      filtered = filtered.filter(disease => 
        disease.name[language].toLowerCase().includes(query) ||
        disease.acronym.toLowerCase().includes(query) ||
        disease.synonyms[language].some(synonym => 
          synonym.toLowerCase().includes(query)
        )
      );
    }

    // Filtro por categoria
    if (filters.category) {
      filtered = filtered.filter(disease => 
        disease.category[language] === filters.category
      );
    }

    // Filtro por idade de início
    if (filters.ageGroup) {
      filtered = filtered.filter(disease => 
        disease.ageOfOnset[language].includes(filters.ageGroup) ||
        disease.ageOfOnset[language] === filters.ageGroup
      );
    }

    // Filtro por letra inicial
    if (filters.letter) {
      filtered = filtered.filter(disease => 
        disease.name[language].charAt(0).toUpperCase() === filters.letter
      );
    }

    setFilteredDiseases(filtered);
  }, [filters, diseases, language]);

  const handleFilterChange = (key: keyof SearchFilters, value: string) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  const clearFilters = () => {
    setFilters({
      query: '',
      category: '',
      ageGroup: '',
      country: '',
      letter: ''
    });
  };

  const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');

  return (
    <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
      {/* Header com seletor de idioma */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 p-6">
        <div className="flex justify-between items-center">
          <div>
            <h2 className="text-2xl font-bold text-white mb-2">
              {language === 'pt' ? 'Pesquisar Doenças Raras' : 'Search Rare Diseases'}
            </h2>
            <p className="text-blue-100">
              {language === 'pt' 
                ? 'Base de dados colaborativa da CPLP'
                : 'CPLP collaborative database'
              }
            </p>
          </div>
          
          {/* Seletor de idioma */}
          <div className="flex bg-white bg-opacity-20 rounded-lg p-1">
            <button
              onClick={() => setLanguage('pt')}
              className={`px-3 py-1 rounded-md text-sm font-medium transition-colors ${
                language === 'pt' 
                  ? 'bg-white text-blue-600' 
                  : 'text-white hover:bg-white hover:bg-opacity-20'
              }`}
            >
              🇵🇹 PT
            </button>
            <button
              onClick={() => setLanguage('en')}
              className={`px-3 py-1 rounded-md text-sm font-medium transition-colors ${
                language === 'en' 
                  ? 'bg-white text-blue-600' 
                  : 'text-white hover:bg-white hover:bg-opacity-20'
              }`}
            >
              🇺🇸 EN
            </button>
          </div>
        </div>
      </div>

      <div className="p-6">
        {/* Barra de pesquisa principal */}
        <div className="relative mb-6">
          <div className="relative">
            <MagnifyingGlassIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
            <input
              type="text"
              placeholder={language === 'pt' 
                ? 'Digite o nome da doença, sigla ou sintoma...'
                : 'Type disease name, acronym or symptom...'
              }
              value={filters.query}
              onChange={(e) => handleFilterChange('query', e.target.value)}
              className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-gray-900 placeholder-gray-500"
            />
          </div>
        </div>

        {/* Botão de filtros */}
        <div className="flex justify-between items-center mb-6">
          <button
            onClick={() => setShowFilters(!showFilters)}
            className="flex items-center px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
          >
            <FunnelIcon className="h-4 w-4 mr-2" />
            {language === 'pt' ? 'Filtros Avançados' : 'Advanced Filters'}
          </button>
          
          {/* Contador de resultados */}
          <div className="text-sm text-gray-500">
            {language === 'pt' 
              ? `${filteredDiseases.length} doença(s) encontrada(s)`
              : `${filteredDiseases.length} disease(s) found`
            }
          </div>
        </div>

        {/* Filtros avançados */}
        {showFilters && (
          <div className="bg-gray-50 rounded-lg p-6 mb-6 border border-gray-200">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-medium text-gray-900">
                {language === 'pt' ? 'Filtros Avançados' : 'Advanced Filters'}
              </h3>
              <button
                onClick={clearFilters}
                className="text-sm text-red-600 hover:text-red-800 flex items-center"
              >
                <XMarkIcon className="h-4 w-4 mr-1" />
                {language === 'pt' ? 'Limpar' : 'Clear'}
              </button>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {/* Filtro por categoria */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {language === 'pt' ? 'Categoria' : 'Category'}
                </label>
                <select
                  value={filters.category}
                  onChange={(e) => handleFilterChange('category', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="">
                    {language === 'pt' ? 'Todas as categorias' : 'All categories'}
                  </option>
                  {diseasesData.categories[language].map((category) => (
                    <option key={category} value={category}>
                      {category}
                    </option>
                  ))}
                </select>
              </div>

              {/* Filtro por faixa etária */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {language === 'pt' ? 'Idade de Início' : 'Age of Onset'}
                </label>
                <select
                  value={filters.ageGroup}
                  onChange={(e) => handleFilterChange('ageGroup', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="">
                    {language === 'pt' ? 'Todas as idades' : 'All ages'}
                  </option>
                  {diseasesData.ageGroups[language].map((age) => (
                    <option key={age} value={age}>
                      {age}
                    </option>
                  ))}
                </select>
              </div>

              {/* Filtro por país */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {language === 'pt' ? 'País de Interesse' : 'Country of Interest'}
                </label>
                <select
                  value={filters.country}
                  onChange={(e) => handleFilterChange('country', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="">
                    {language === 'pt' ? 'Todos os países' : 'All countries'}
                  </option>
                  {diseasesData.countries[language].map((country) => (
                    <option key={country} value={country}>
                      {country}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Filtro alfabético */}
            <div className="mt-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {language === 'pt' ? 'Filtrar por Letra' : 'Filter by Letter'}
              </label>
              <div className="flex flex-wrap gap-2">
                <button
                  onClick={() => handleFilterChange('letter', '')}
                  className={`px-3 py-1 rounded text-sm font-medium transition-colors ${
                    filters.letter === '' 
                      ? 'bg-blue-600 text-white' 
                      : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                  }`}
                >
                  {language === 'pt' ? 'Todas' : 'All'}
                </button>
                {alphabet.map((letter) => (
                  <button
                    key={letter}
                    onClick={() => handleFilterChange('letter', letter)}
                    className={`px-3 py-1 rounded text-sm font-medium transition-colors ${
                      filters.letter === letter 
                        ? 'bg-blue-600 text-white' 
                        : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                    }`}
                  >
                    {letter}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Resultados da pesquisa */}
        <div className="space-y-4">
          {filteredDiseases.length === 0 ? (
            <div className="text-center py-12">
              <div className="text-6xl mb-4">🔍</div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                {language === 'pt' ? 'Nenhuma doença encontrada' : 'No diseases found'}
              </h3>
              <p className="text-gray-500">
                {language === 'pt' 
                  ? 'Tente ajustar os filtros ou usar termos diferentes'
                  : 'Try adjusting filters or using different terms'
                }
              </p>
            </div>
          ) : (
            filteredDiseases.map((disease) => (
              <div
                key={disease.id}
                className="border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow bg-white"
              >
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <div className="flex items-center mb-2">
                      <h3 className="text-xl font-semibold text-gray-900 mr-3">
                        {disease.name[language]}
                      </h3>
                      <span className="px-2 py-1 bg-blue-100 text-blue-800 text-sm font-medium rounded-full">
                        {disease.acronym}
                      </span>
                    </div>
                    
                    <div className="grid md:grid-cols-3 gap-4 mb-4">
                      <div>
                        <span className="text-sm font-medium text-gray-500">
                          {language === 'pt' ? 'Categoria:' : 'Category:'}
                        </span>
                        <p className="text-sm text-gray-700">{disease.category[language]}</p>
                      </div>
                      <div>
                        <span className="text-sm font-medium text-gray-500">
                          {language === 'pt' ? 'Prevalência:' : 'Prevalence:'}
                        </span>
                        <p className="text-sm text-gray-700">{disease.prevalence}</p>
                      </div>
                      <div>
                        <span className="text-sm font-medium text-gray-500">
                          {language === 'pt' ? 'Idade de Início:' : 'Age of Onset:'}
                        </span>
                        <p className="text-sm text-gray-700">{disease.ageOfOnset[language]}</p>
                      </div>
                    </div>

                    {disease.synonyms[language].length > 0 && (
                      <div className="mb-4">
                        <span className="text-sm font-medium text-gray-500">
                          {language === 'pt' ? 'Sinônimos:' : 'Synonyms:'}
                        </span>
                        <p className="text-sm text-gray-600">
                          {disease.synonyms[language].join(', ')}
                        </p>
                      </div>
                    )}
                  </div>

                  <Link
                    href={`/atlas/doenca/${disease.id}`}
                    className="ml-4 inline-flex items-center px-4 py-2 bg-gradient-to-r from-blue-600 to-purple-600 text-white text-sm font-medium rounded-lg hover:from-blue-700 hover:to-purple-700 transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                  >
                    {language === 'pt' ? 'Ver Detalhes' : 'View Details'}
                  </Link>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
