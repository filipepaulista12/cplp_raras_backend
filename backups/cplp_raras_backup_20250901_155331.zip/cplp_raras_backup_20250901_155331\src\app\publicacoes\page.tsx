import Link from 'next/link';
import { ArrowLeftIcon } from '@heroicons/react/24/outline';
import TopShare from '@/components/TopShare';

const publications = [
  {
    title: "Rare Diseases in CPLP Countries: A Systematic Review",
    authors: "Silva, A. et al.",
    journal: "Journal of Rare Diseases Research",
    year: "2024",
    type: "Article",
    status: "Published",
    doi: "10.1234/jrdr.2024.001"
  },
  {
    title: "Digital Health Platforms for Rare Disease Management",
    authors: "Santos, M. & Costa, P.",
    journal: "Digital Health International",
    year: "2024",
    type: "Review",
    status: "In Press",
    doi: "Pending"
  },
  {
    title: "CPLP-Raras: Methodology for Data Collection",
    authors: "Research Team CPLP-Raras",
    journal: "Methodology Reports",
    year: "2024",
    type: "Protocol",
    status: "Submitted",
    doi: "Under Review"
  }
];

const resources = [
  {
    title: "Protocolo de Coleta de Dados",
    description: "Documento técnico com diretrizes para coleta padronizada de dados sobre doenças raras",
    type: "PDF",
    size: "2.3 MB"
  },
  {
    title: "Manual REDCap CPLP-Raras",
    description: "Guia completo para utilização da plataforma REDCap no projeto",
    type: "PDF",
    size: "1.8 MB"
  },
  {
    title: "Relatório Preliminar - Mapeamento",
    description: "Primeiros resultados do mapeamento de recursos nos países da CPLP",
    type: "PDF",
    size: "4.1 MB"
  }
];

export default function Publications() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Breadcrumb */}
      <div className="bg-white border-b">
        <div className="mx-auto max-w-7xl px-4 py-4 sm:px-6 lg:px-8">
          <Link 
            href="/"
            className="inline-flex items-center text-blue-600 hover:text-blue-800 transition-colors"
          >
            <ArrowLeftIcon className="h-4 w-4 mr-2" />
            Voltar ao Início
          </Link>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        
        {/* Compartilhamento no topo */}
        <TopShare 
          title="Publicações e Recursos - CPLP-Raras"
          description="Publicações científicas, relatórios e recursos educativos produzidos pelo projeto CPLP-Raras"
        />
        
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            📚 Publicações e Recursos
          </h1>
          <div className="w-32 h-1 bg-gradient-to-r from-blue-600 to-green-600 mx-auto mb-8"></div>
          <p className="text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed">
            Acesse as publicações científicas, relatórios e recursos educativos produzidos pelo projeto CPLP-Raras.
          </p>
        </div>

        {/* Publicações Científicas */}
        <section className="mb-16">
          <div className="bg-white rounded-2xl shadow-lg p-8 md:p-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-8">
              📖 Publicações Científicas
            </h2>
            
            <div className="space-y-6">
              {publications.map((pub, index) => (
                <div key={index} className="border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <h3 className="text-xl font-semibold text-gray-900 mb-2">
                        {pub.title}
                      </h3>
                      <p className="text-gray-600 mb-2">
                        <strong>Autores:</strong> {pub.authors}
                      </p>
                      <p className="text-gray-600 mb-2">
                        <strong>Revista:</strong> {pub.journal} ({pub.year})
                      </p>
                      {pub.doi !== "Pending" && pub.doi !== "Under Review" && (
                        <p className="text-gray-600 mb-2">
                          <strong>DOI:</strong> {pub.doi}
                        </p>
                      )}
                    </div>
                    <div className="ml-4 text-right">
                      <span className={`inline-block px-3 py-1 rounded-full text-sm font-medium ${
                        pub.status === 'Published' ? 'bg-green-100 text-green-800' :
                        pub.status === 'In Press' ? 'bg-blue-100 text-blue-800' :
                        'bg-yellow-100 text-yellow-800'
                      }`}>
                        {pub.status}
                      </span>
                      <div className="mt-2">
                        <span className="text-sm text-gray-500">{pub.type}</span>
                      </div>
                    </div>
                  </div>
                  
                  {pub.status === 'Published' && (
                    <button className="text-blue-600 hover:text-blue-800 font-medium text-sm">
                      Acessar Publicação →
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Recursos e Documentos */}
        <section className="mb-16">
          <div className="bg-white rounded-2xl shadow-lg p-8 md:p-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-8">
              📋 Recursos e Documentos
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {resources.map((resource, index) => (
                <div key={index} className="border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow">
                  <div className="flex items-center mb-3">
                    <span className="text-2xl mr-3">📄</span>
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900">
                        {resource.title}
                      </h3>
                      <span className="text-sm text-gray-500">{resource.type} • {resource.size}</span>
                    </div>
                  </div>
                  
                  <p className="text-gray-600 mb-4 text-sm">
                    {resource.description}
                  </p>
                  
                  <button className="text-blue-600 hover:text-blue-800 font-medium text-sm">
                    Download →
                  </button>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Repositório de Dados */}
        <section className="mb-16">
          <div className="bg-white rounded-2xl shadow-lg p-8 md:p-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">
              🗄️ Repositório de Dados
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="text-center">
                <div className="bg-blue-100 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-4">
                  <span className="text-3xl">📊</span>
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">Dados Agregados</h3>
                <p className="text-gray-600 mb-4">
                  Acesse dados agregados e anonimizados sobre doenças raras nos países da CPLP.
                </p>
                <button className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors">
                  Acessar Dados
                </button>
              </div>

              <div className="text-center">
                <div className="bg-green-100 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-4">
                  <span className="text-3xl">🔗</span>
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">API FAIR</h3>
                <p className="text-gray-600 mb-4">
                  Interface programática para acesso aos dados seguindo princípios FAIR.
                </p>
                <button className="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 transition-colors">
                  Documentação API
                </button>
              </div>
            </div>
          </div>
        </section>

        {/* Estatísticas */}
        <section className="mb-16">
          <div className="bg-gradient-to-r from-blue-600 to-green-600 rounded-2xl p-8 text-white">
            <h2 className="text-2xl font-bold mb-8 text-center">
              📈 Estatísticas do Projeto
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6 text-center">
              <div>
                <div className="text-3xl font-bold mb-2">15+</div>
                <div className="text-blue-100">Publicações</div>
              </div>
              <div>
                <div className="text-3xl font-bold mb-2">1,200+</div>
                <div className="text-blue-100">Casos Registrados</div>
              </div>
              <div>
                <div className="text-3xl font-bold mb-2">5</div>
                <div className="text-blue-100">Países Ativos</div>
              </div>
              <div>
                <div className="text-3xl font-bold mb-2">50+</div>
                <div className="text-blue-100">Pesquisadores</div>
              </div>
            </div>
          </div>
        </section>

        {/* Call to Action */}
        <section className="text-center">
          <div className="bg-white rounded-2xl shadow-lg p-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              Contribua com o Conhecimento
            </h2>
            <p className="text-lg text-gray-600 mb-6">
              Tem interesse em publicar dados ou colaborar em pesquisas? Entre em contato conosco.
            </p>
            <Link
              href="/contato"
              className="inline-block bg-gradient-to-r from-blue-600 to-green-600 text-white px-8 py-3 rounded-lg font-semibold hover:opacity-90 transition-opacity"
            >
              Fale Conosco
            </Link>
          </div>
        </section>
      </div>
    </div>
  );
}
