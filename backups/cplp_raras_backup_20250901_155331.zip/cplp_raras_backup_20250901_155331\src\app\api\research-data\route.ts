import { NextResponse } from 'next/server';
import path from 'path';
import fs from 'fs';
import type { ResearchData } from '@/types/research-data';

export const dynamic = 'force-static';

export async function GET() {
  try {
    // Caminho para o arquivo de dados de pesquisa
    const dataPath = path.join(process.cwd(), 'src', 'data', 'research_data.json');
    
    // Verificar se o arquivo existe
    if (!fs.existsSync(dataPath)) {
      return NextResponse.json(
        { error: 'Dados de pesquisa não encontrados' }, 
        { status: 404 }
      );
    }

    // Ler o arquivo
    const fileContent = fs.readFileSync(dataPath, 'utf-8');
    const data: ResearchData = JSON.parse(fileContent);

    // Retornar os dados
    return NextResponse.json(data);

  } catch (error) {
    console.error('Erro ao carregar dados de pesquisa:', error);
    return NextResponse.json(
      { error: 'Erro interno do servidor' }, 
      { status: 500 }
    );
  }
}
