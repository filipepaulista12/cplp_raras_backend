'use client'

import { useHPOStore } from '@/store/hpoStore'
import { useEffect, useState } from 'react'
import { Chart as ChartJS, ArcElement, Tooltip, Legend, CategoryScale, LinearScale, BarElement, Title } from 'chart.js'
import { Pie, Bar } from 'react-chartjs-2'

ChartJS.register(ArcElement, Tooltip, Legend, CategoryScale, LinearScale, BarElement, Title)

export default function DashboardPage() {
  const { terms, translations, getStats, setTerms } = useHPOStore()
  const [isLoaded, setIsLoaded] = useState(false)
  const stats = getStats()
  
  useEffect(() => {
    if (terms.length === 0 && !isLoaded) {
      fetch('/hpo-sample.json')
        .then(res => res.json())
        .then(data => {
          setTerms(data.terms)
          setIsLoaded(true)
        })
        .catch(err => console.error('Erro ao carregar dados:', err))
    } else {
      setIsLoaded(true)
    }
  }, [terms.length, setTerms, isLoaded])
  
  // Dados para gráfico de status
  const statusData = {
    labels: ['Candidatos', 'Em Revisão', 'Oficiais'],
    datasets: [
      {
        data: [stats.candidate, stats.under_review, stats.official],
        backgroundColor: ['#6b7280', '#f59e0b', '#10b981'],
        borderColor: ['#4b5563', '#d97706', '#059669'],
        borderWidth: 1,
      },
    ],
  }
  
  // Dados para gráfico de categoria
  const categoryStats = terms.reduce((acc, term) => {
    const category = term.category || 'outros'
    acc[category] = (acc[category] || 0) + 1
    return acc
  }, {} as Record<string, number>)
  
  const categoryData = {
    labels: Object.keys(categoryStats),
    datasets: [
      {
        label: 'Termos por Categoria',
        data: Object.values(categoryStats),
        backgroundColor: 'rgba(59, 130, 246, 0.5)',
        borderColor: 'rgba(59, 130, 246, 1)',
        borderWidth: 1,
      },
    ],
  }
  
  // Estatísticas de Likert
  const likertStats = translations.reduce((acc, trans) => {
    if (trans.likert_score > 0) {
      acc[trans.likert_score] = (acc[trans.likert_score] || 0) + 1
    }
    return acc
  }, {} as Record<number, number>)
  
  const likertData = {
    labels: ['1 (Muito ruim)', '2 (Ruim)', '3 (Regular)', '4 (Boa)', '5 (Excelente)'],
    datasets: [
      {
        label: 'Avaliações Likert',
        data: [1, 2, 3, 4, 5].map(score => likertStats[score] || 0),
        backgroundColor: 'rgba(16, 185, 129, 0.5)',
        borderColor: 'rgba(16, 185, 129, 1)',
        borderWidth: 1,
      },
    ],
  }
  
  // Termos mais revisados
  const termReviewCounts = translations.reduce((acc, trans) => {
    acc[trans.term_id] = (acc[trans.term_id] || 0) + 1
    return acc
  }, {} as Record<string, number>)
  
  const mostReviewedTerms = Object.entries(termReviewCounts)
    .sort(([,a], [,b]) => b - a)
    .slice(0, 5)
    .map(([termId, count]) => {
      const term = terms.find(t => t.id === termId)
      return {
        id: termId,
        label: term?.label_en || 'Termo não encontrado',
        count
      }
    })
  
  if (!isLoaded) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="text-gray-500">Carregando dashboard...</div>
      </div>
    )
  }
  
  return (
    <div className="max-w-7xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">
          📊 Dashboard de Qualidade
        </h1>
        <p className="text-gray-600">
          Visualizações e métricas do processo de tradução colaborativa da HPO para português.
        </p>
      </div>
      
      {/* Cards de estatísticas principais */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6 mb-8">
        <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6 text-center">
          <div className="text-3xl font-bold text-blue-600 mb-2">
            {stats.total}
          </div>
          <div className="text-gray-600 text-sm">Total de Termos</div>
        </div>
        
        <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6 text-center">
          <div className="text-3xl font-bold text-gray-500 mb-2">
            {stats.candidate}
          </div>
          <div className="text-gray-600 text-sm">Candidatos</div>
        </div>
        
        <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6 text-center">
          <div className="text-3xl font-bold text-yellow-600 mb-2">
            {stats.under_review}
          </div>
          <div className="text-gray-600 text-sm">Em Revisão</div>
        </div>
        
        <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6 text-center">
          <div className="text-3xl font-bold text-green-600 mb-2">
            {stats.official}
          </div>
          <div className="text-gray-600 text-sm">Oficiais</div>
        </div>
        
        <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6 text-center">
          <div className="text-3xl font-bold text-purple-600 mb-2">
            {stats.avg_likert.toFixed(1)}
          </div>
          <div className="text-gray-600 text-sm">Média Likert</div>
        </div>
      </div>
      
      {/* Gráficos principais */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        {/* Gráfico de Status */}
        <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">
            Distribuição por Status
          </h3>
          <div className="h-64 flex items-center justify-center">
            <Pie 
              data={statusData} 
              options={{
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                  legend: {
                    position: 'bottom',
                  },
                },
              }}
            />
          </div>
        </div>
        
        {/* Gráfico de Categoria */}
        <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">
            Termos por Categoria Clínica
          </h3>
          <div className="h-64">
            <Bar 
              data={categoryData}
              options={{
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                  legend: {
                    display: false,
                  },
                },
                scales: {
                  y: {
                    beginAtZero: true,
                  },
                },
              }}
            />
          </div>
        </div>
      </div>
      
      {/* Gráfico de avaliações Likert */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">
            Distribuição das Avaliações Likert
          </h3>
          <div className="h-64">
            <Bar 
              data={likertData}
              options={{
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                  legend: {
                    display: false,
                  },
                },
                scales: {
                  y: {
                    beginAtZero: true,
                  },
                },
              }}
            />
          </div>
        </div>
        
        {/* Lista de termos mais revisados */}
        <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">
            Termos Mais Revisados
          </h3>
          <div className="space-y-3">
            {mostReviewedTerms.length > 0 ? (
              mostReviewedTerms.map((term, index) => (
                <div key={term.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="flex-shrink-0 w-6 h-6 bg-blue-100 text-blue-800 rounded-full flex items-center justify-center text-xs font-medium">
                      {index + 1}
                    </div>
                    <div>
                      <div className="text-sm font-medium text-gray-900">{term.id}</div>
                      <div className="text-sm text-gray-500 truncate max-w-xs">{term.label}</div>
                    </div>
                  </div>
                  <div className="text-sm font-medium text-blue-600">
                    {term.count} revisões
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center text-gray-500 py-8">
                Nenhuma revisão ainda
              </div>
            )}
          </div>
        </div>
      </div>
      
      {/* Estatísticas detalhadas */}
      <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">
          Estatísticas Detalhadas
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="text-center p-4 bg-blue-50 rounded-lg">
            <div className="text-2xl font-bold text-blue-600">
              {translations.length}
            </div>
            <div className="text-sm text-blue-800">Total de Revisões</div>
          </div>
          
          <div className="text-center p-4 bg-green-50 rounded-lg">
            <div className="text-2xl font-bold text-green-600">
              {Math.round((stats.official / stats.total) * 100)}%
            </div>
            <div className="text-sm text-green-800">Taxa de Conclusão</div>
          </div>
          
          <div className="text-center p-4 bg-yellow-50 rounded-lg">
            <div className="text-2xl font-bold text-yellow-600">
              {translations.length > 0 ? Math.round(translations.length / stats.total * 100) / 100 : 0}
            </div>
            <div className="text-sm text-yellow-800">Revisões por Termo</div>
          </div>
          
          <div className="text-center p-4 bg-purple-50 rounded-lg">
            <div className="text-2xl font-bold text-purple-600">
              {Object.keys(categoryStats).length}
            </div>
            <div className="text-sm text-purple-800">Categorias Ativas</div>
          </div>
        </div>
      </div>
    </div>
  )
}
