/**
 * 🚀 SETUP AVANÇADO POSTGRESQL - CPLP RARAS
 * =========================================
 * Script que resolve automaticamente problemas de autenticação PostgreSQL
 */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

class PostgreSQLSetup {
  constructor() {
    this.postgresPath = 'C:\\Program Files\\PostgreSQL\\17\\bin';
    this.serviceName = 'postgresql-x64-17';
    this.possiblePasswords = [
      'postgres', 'password', 'admin', 'root', '123456', 
      'password123', 'postgres123', '', 'qwerty', '12345',
      'cplp123', 'orphanet', 'raras'
    ];
  }

  async createDefaultPassword() {
    console.log('🔐 Configurando senha padrão para PostgreSQL...');
    
    try {
      // Método 1: Tentar usar psql com --set
      const newPassword = 'cplp_raras_2024';
      console.log(`📝 Definindo nova senha: ${newPassword}`);
      
      // Criar arquivo de configuração temporário
      const tempSqlFile = path.join(__dirname, 'reset-password.sql');
      const sqlContent = `ALTER USER postgres PASSWORD '${newPassword}';`;
      fs.writeFileSync(tempSqlFile, sqlContent);
      
      console.log('✅ Arquivo SQL de reset criado');
      
      // Tentar executar com diferentes métodos
      const methods = [
        () => {
          console.log('Método 1: Tentando conexão direta...');
          execSync(`"${this.postgresPath}\\psql.exe" -U postgres -h localhost -f "${tempSqlFile}"`, 
                  { stdio: 'inherit' });
        },
        () => {
          console.log('Método 2: Tentando com runuser...');
          execSync(`"${this.postgresPath}\\pg_ctl.exe" reload -D "C:\\Program Files\\PostgreSQL\\17\\data"`, 
                  { stdio: 'inherit' });
        }
      ];
      
      for (const method of methods) {
        try {
          method();
          console.log('✅ Método funcionou!');
          // Limpar arquivo temporário
          fs.unlinkSync(tempSqlFile);
          return newPassword;
        } catch (error) {
          console.log('❌ Método falhou, tentando próximo...');
        }
      }
      
      throw new Error('Todos os métodos falharam');
      
    } catch (error) {
      console.error('❌ Erro ao configurar senha:', error.message);
      return null;
    }
  }

  async setupAlternativeAuth() {
    console.log('🔧 Configurando autenticação alternativa...');
    
    try {
      // Criar configuração de autenticação trust temporária
      const pgHbaPath = 'C:\\Program Files\\PostgreSQL\\17\\data\\pg_hba.conf';
      const backupPath = pgHbaPath + '.backup';
      
      console.log('📋 Criando backup da configuração atual...');
      
      // Conteúdo para autenticação trust local
      const trustConfig = `
# TYPE  DATABASE        USER            ADDRESS                 METHOD
local   all             postgres                                trust
host    all             postgres        127.0.0.1/32            trust
host    all             postgres        ::1/128                 trust
local   all             all                                     trust
host    all             all             127.0.0.1/32            md5
host    all             all             ::1/128                 md5
`;

      const tempConfigFile = path.join(__dirname, 'pg_hba_temp.conf');
      fs.writeFileSync(tempConfigFile, trustConfig.trim());
      
      console.log('✅ Configuração temporária criada');
      console.log('⚠️  ATENÇÃO: Execute como Administrador para aplicar:');
      console.log(`   1. Pare o serviço: Stop-Service ${this.serviceName}`);
      console.log(`   2. Copie: Copy-Item "${tempConfigFile}" "${pgHbaPath}" -Force`);
      console.log(`   3. Reinicie: Start-Service ${this.serviceName}`);
      console.log(`   4. Conecte sem senha: psql -U postgres -h localhost`);
      
      return tempConfigFile;
      
    } catch (error) {
      console.error('❌ Erro na configuração alternativa:', error.message);
      return null;
    }
  }

  async createWindowsUser() {
    console.log('👤 Criando usuário PostgreSQL baseado no usuário Windows...');
    
    try {
      const windowsUser = process.env.USERNAME;
      console.log(`Usuário Windows detectado: ${windowsUser}`);
      
      // Criar script SQL para criar usuário
      const createUserSql = `
CREATE ROLE ${windowsUser} WITH LOGIN SUPERUSER CREATEDB CREATEROLE;
ALTER ROLE ${windowsUser} PASSWORD 'windows_user_123';
GRANT ALL PRIVILEGES ON DATABASE postgres TO ${windowsUser};
`;
      
      const userSqlFile = path.join(__dirname, 'create-windows-user.sql');
      fs.writeFileSync(userSqlFile, createUserSql);
      
      console.log(`✅ Script de usuário criado: ${userSqlFile}`);
      console.log(`📋 Para usar: psql -U postgres -f "${userSqlFile}"`);
      console.log(`🔑 Depois conecte: psql -U ${windowsUser} -h localhost`);
      
      return { username: windowsUser, password: 'windows_user_123' };
      
    } catch (error) {
      console.error('❌ Erro ao criar usuário Windows:', error.message);
      return null;
    }
  }

  async generateInstallationGuide() {
    console.log('📚 Gerando guia de instalação...');
    
    const guide = `# 🐘 GUIA DE CONFIGURAÇÃO POSTGRESQL - CPLP RARAS

## Problema Atual
❌ Senha do usuário 'postgres' não conhecida

## Soluções Disponíveis

### 🔐 Opção 1: Redefinir Senha (Recomendado)
\`\`\`powershell
# 1. Execute PowerShell como Administrador
# 2. Pare o serviço
Stop-Service ${this.serviceName}

# 3. Inicie PostgreSQL em modo single-user
cd "C:\\Program Files\\PostgreSQL\\17\\bin"
.\\postgres.exe --single -D "C:\\Program Files\\PostgreSQL\\17\\data" postgres

# 4. No prompt, digite:
ALTER USER postgres PASSWORD 'cplp_raras_2024';

# 5. Saia (Ctrl+C) e reinicie o serviço
Start-Service ${this.serviceName}
\`\`\`

### 🔧 Opção 2: Configuração Trust Temporária
\`\`\`powershell
# 1. Como Administrador, edite:
# C:\\Program Files\\PostgreSQL\\17\\data\\pg_hba.conf

# 2. Adicione no início:
local   all             postgres                                trust
host    all             postgres        127.0.0.1/32            trust

# 3. Reinicie o serviço
Restart-Service ${this.serviceName}

# 4. Conecte sem senha
psql -U postgres -h localhost

# 5. Defina nova senha:
ALTER USER postgres PASSWORD 'cplp_raras_2024';
\`\`\`

### 🆕 Opção 3: Reinstalar PostgreSQL
\`\`\`powershell
# 1. Desinstalar versão atual
# 2. Baixar: https://www.postgresql.org/download/windows/
# 3. Durante instalação, definir senha: cplp_raras_2024
\`\`\`

## Verificação
\`\`\`powershell
# Testar conexão
psql -h localhost -U postgres -d postgres

# Se funcionar, atualizar .env:
DATABASE_URL="postgresql://postgres:cplp_raras_2024@localhost:5432/orphanet_db"
\`\`\`

## Scripts Auxiliares Criados
- reset-password.sql: Redefinir senha
- pg_hba_temp.conf: Configuração trust
- create-windows-user.sql: Usuário baseado no Windows

Gerado em: ${new Date().toLocaleString()}
`;

    const guidePath = path.join(__dirname, '..', 'POSTGRESQL_SETUP_GUIDE.md');
    fs.writeFileSync(guidePath, guide);
    
    console.log(`✅ Guia salvo em: ${guidePath}`);
    return guidePath;
  }

  async runDiagnostics() {
    console.log('🔍 Executando diagnósticos PostgreSQL...\n');
    
    const diagnostics = {
      service: false,
      port: false,
      installation: false,
      version: null
    };
    
    try {
      // Verificar serviço
      console.log('1. Verificando serviço...');
      const serviceResult = execSync(`Get-Service ${this.serviceName} | Select-Object Status`, { encoding: 'utf8' });
      diagnostics.service = serviceResult.includes('Running');
      console.log(diagnostics.service ? '✅ Serviço rodando' : '❌ Serviço parado');
    } catch (error) {
      console.log('❌ Serviço não encontrado');
    }
    
    try {
      // Verificar versão
      console.log('2. Verificando instalação...');
      const versionResult = execSync(`"${this.postgresPath}\\pg_config.exe" --version`, { encoding: 'utf8' });
      diagnostics.version = versionResult.trim();
      diagnostics.installation = true;
      console.log(`✅ ${diagnostics.version}`);
    } catch (error) {
      console.log('❌ PostgreSQL não encontrado no PATH esperado');
    }
    
    try {
      // Verificar porta
      console.log('3. Verificando porta 5432...');
      const portResult = execSync('netstat -an | findstr "5432"', { encoding: 'utf8' });
      diagnostics.port = portResult.includes(':5432');
      console.log(diagnostics.port ? '✅ Porta 5432 em uso' : '❌ Porta 5432 livre');
    } catch (error) {
      console.log('❌ Não foi possível verificar porta');
    }
    
    return diagnostics;
  }

  async main() {
    console.log('🚀 SETUP POSTGRESQL CPLP-RARAS\n');
    
    // Diagnósticos
    await this.runDiagnostics();
    
    console.log('\n📋 Executando configurações...');
    
    // Gerar guia
    await this.generateInstallationGuide();
    
    // Criar configurações alternativas
    await this.setupAlternativeAuth();
    await this.createWindowsUser();
    
    console.log('\n✅ Setup concluído!');
    console.log('📄 Consulte POSTGRESQL_SETUP_GUIDE.md para instruções detalhadas');
  }
}

if (require.main === module) {
  const setup = new PostgreSQLSetup();
  setup.main().catch(console.error);
}

module.exports = PostgreSQLSetup;
