'use client';

import { 
  SparklesIcon, 
  AcademicCapIcon, 
  ChatBubbleLeftRightIcon,
  ExclamationTriangleIcon,
  EnvelopeIcon,
  GlobeAltIcon,
  ArrowTopRightOnSquareIcon
} from '@heroicons/react/24/outline';
import Link from 'next/link';

export default function GPTEducativoPage() {
  const features = [
    {
      icon: '🎓',
      title: 'Educação Médica Personalizada',
      description: 'Conteúdo adaptado ao nível de conhecimento do usuário, desde estudantes a especialistas'
    },
    {
      icon: '💬',
      title: 'Conversação Natural',
      description: 'Interface de chat intuitiva para perguntas e respostas sobre doenças raras'
    },
    {
      icon: '🌍',
      title: 'Multilíngue CPLP',
      description: 'Suporte completo para português brasileiro, europeu e outras variantes lusófonas'
    },
    {
      icon: '📚',
      title: 'Base de Conhecimento Atualizada',
      description: 'Treinado com literatura médica atual e protocolos específicos da CPLP'
    },
    {
      icon: '🔍',
      title: 'Casos Clínicos Interativos',
      description: 'Simulação de casos reais para aprendizado prático e tomada de decisão'
    },
    {
      icon: '📊',
      title: 'Progresso de Aprendizado',
      description: 'Acompanhamento do desenvolvimento de conhecimento e áreas de melhoria'
    }
  ];

  const useCases = [
    {
      title: 'Estudantes de Medicina',
      description: 'Aprendizado interativo sobre doenças raras com casos práticos'
    },
    {
      title: 'Residentes',
      description: 'Apoio ao diagnóstico diferencial e protocolos terapêuticos'
    },
    {
      title: 'Médicos Generalistas',
      description: 'Reconhecimento precoce de sinais e sintomas raros'
    },
    {
      title: 'Especialistas',
      description: 'Discussão de casos complexos e literatura atualizada'
    }
  ];

  const contacts = [
    {
      type: 'Email Principal',
      value: 'contato@cplp-raras.org',
      icon: EnvelopeIcon,
      href: 'mailto:contato@cplp-raras.org',
      color: 'text-blue-600'
    },
    {
      type: 'Website',
      value: 'www.cplp-raras.org',
      icon: GlobeAltIcon,
      href: 'https://www.cplp-raras.org',
      color: 'text-green-600'
    },
    {
      type: 'Redes Sociais',
      value: '@rarasporti',
      icon: ChatBubbleLeftRightIcon,
      href: '#',
      color: 'text-purple-600'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-orange-50 to-red-100">
      {/* Hero Section */}
      <section className="relative py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center">
            <div className="inline-flex items-center px-4 py-2 bg-green-100 text-green-700 rounded-full text-sm font-medium mb-6">
              <SparklesIcon className="h-4 w-4 mr-2" />
              ✨ Disponível Agora - Em Aprimoramento
            </div>
            
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              <span className="bg-gradient-to-r from-orange-600 via-red-600 to-pink-600 bg-clip-text text-transparent">
                Raras GPT Educativo
              </span>
            </h1>
            <p className="text-xl md:text-2xl text-gray-600 mb-8 max-w-3xl mx-auto">
              Assistente de inteligência artificial especializado em doenças raras para educação médica continuada da CPLP
            </p>

            {/* Chat Interface - Botão Integrado */}
            <div className="mb-12">
              <div className="text-center mb-8">
                <h3 className="text-2xl font-bold text-gray-900 mb-4">
                  💬 Acesse o GPT Educativo
                </h3>
                <p className="text-lg text-gray-600 max-w-2xl mx-auto mb-4">
                  Clique no botão abaixo para abrir o chat especializado em doenças raras da CPLP
                </p>
              </div>
              
              {/* Simulação de Interface de Chat */}
              <div className="max-w-5xl mx-auto">
                <div className="bg-white rounded-2xl shadow-2xl border border-gray-200 overflow-hidden">
                  {/* Header do chat */}
                  <div className="bg-gradient-to-r from-orange-500 to-red-600 px-6 py-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <div className="w-3 h-3 bg-white/30 rounded-full mr-2"></div>
                        <div className="w-3 h-3 bg-white/30 rounded-full mr-2"></div>
                        <div className="w-3 h-3 bg-white/30 rounded-full mr-4"></div>
                        <span className="text-white font-bold">GPT Educativo CPLP-Raras</span>
                      </div>
                      <div className="flex items-center text-white/80 text-sm">
                        <div className="w-2 h-2 bg-green-400 rounded-full mr-2 animate-pulse"></div>
                        Disponível
                      </div>
                    </div>
                  </div>
                  
                  {/* Área de demonstração */}
                  <div className="p-8 bg-gray-50 min-h-[400px] flex items-center justify-center">
                    <div className="text-center max-w-md">
                      <div className="mb-6">
                        <SparklesIcon className="h-20 w-20 text-orange-500 mx-auto mb-4" />
                        <h4 className="text-2xl font-bold text-gray-900 mb-3">
                          Pronto para Conversar!
                        </h4>
                        <p className="text-gray-600 mb-6">
                          Abra o GPT Educativo em uma nova janela para ter acesso completo ao chat especializado
                        </p>
                      </div>
                      
                      {/* Botão principal */}
                      <a
                        href="https://chatgpt.com/g/g-68682fab869481918d65a8815554bf92-raras-gpt-educativo-e-colaborativo-da-cplp"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center px-8 py-4 bg-gradient-to-r from-orange-600 to-red-600 text-white font-bold text-lg rounded-2xl shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300 mb-4"
                      >
                        <ChatBubbleLeftRightIcon className="h-6 w-6 mr-3" />
                        Abrir GPT Educativo
                        <ArrowTopRightOnSquareIcon className="h-5 w-5 ml-2" />
                      </a>
                      
                      <p className="text-sm text-gray-500">
                        Abre em nova janela • Gratuito • Histórico salvo na sua conta
                      </p>
                    </div>
                  </div>
                  
                  {/* Demonstração de conversa */}
                  <div className="p-6 bg-white border-t">
                    <div className="space-y-4 max-w-2xl mx-auto">
                      <div className="text-center mb-4">
                        <span className="text-sm text-gray-500">Exemplo de conversa:</span>
                      </div>
                      
                      {/* Mensagem do usuário */}
                      <div className="flex justify-end">
                        <div className="bg-blue-600 text-white rounded-2xl px-4 py-2 max-w-xs">
                          <p className="text-sm">Quais são os sintomas principais da síndrome de Marfan?</p>
                        </div>
                      </div>
                      
                      {/* Resposta do GPT */}
                      <div className="flex justify-start">
                        <div className="flex">
                          <div className="w-8 h-8 bg-gradient-to-r from-orange-500 to-red-600 rounded-full flex items-center justify-center mr-3 flex-shrink-0">
                            <SparklesIcon className="h-4 w-4 text-white" />
                          </div>
                          <div className="bg-gray-100 rounded-2xl px-4 py-2 max-w-md">
                            <p className="text-sm text-gray-800">
                              A síndrome de Marfan apresenta manifestações multissistêmicas: <br/>
                              🫀 Cardiovasculares: Dilatação aórtica<br/>
                              👁️ Oculares: Luxação do cristalino<br/>
                              🦴 Esqueléticas: Estatura alta, aracnodactilia...
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                
                {/* Cards informativos */}
                <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 text-center">
                    <div className="text-blue-600 text-2xl mb-2">🚀</div>
                    <div className="font-semibold text-blue-900 mb-1">Acesso Imediato</div>
                    <div className="text-blue-800">Clique e comece a conversar</div>
                  </div>
                  
                  <div className="bg-green-50 border border-green-200 rounded-lg p-4 text-center">
                    <div className="text-green-600 text-2xl mb-2">💾</div>
                    <div className="font-semibold text-green-900 mb-1">Histórico Salvo</div>
                    <div className="text-green-800">Conversas ficam na sua conta</div>
                  </div>
                  
                  <div className="bg-purple-50 border border-purple-200 rounded-lg p-4 text-center">
                    <div className="text-purple-600 text-2xl mb-2">🎯</div>
                    <div className="font-semibold text-purple-900 mb-1">Especializado</div>
                    <div className="text-purple-800">Focado em doenças raras CPLP</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <SparklesIcon className="h-16 w-16 text-orange-600 mx-auto mb-6" />
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Recursos Implementados
            </h2>
            <p className="text-lg text-gray-600">
              Funcionalidades ativas e em constante aprimoramento
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <div key={index} className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100 hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
                <div className="text-3xl mb-4">{feature.icon}</div>
                <h3 className="text-lg font-bold text-gray-900 mb-3">{feature.title}</h3>
                <p className="text-gray-600 leading-relaxed">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Use Cases */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-white/50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <AcademicCapIcon className="h-16 w-16 text-blue-600 mx-auto mb-6" />
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Casos de Uso</h2>
            <p className="text-lg text-gray-600">Para diferentes perfis profissionais</p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {useCases.map((useCase, index) => (
              <div key={index} className="bg-white rounded-2xl shadow-lg p-8 border border-gray-100">
                <h3 className="text-xl font-bold text-gray-900 mb-4">{useCase.title}</h3>
                <p className="text-gray-600 leading-relaxed">{useCase.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Technical Details */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="bg-gradient-to-r from-gray-800 to-gray-900 rounded-3xl shadow-2xl p-8 md:p-12 text-white">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">Especificações Técnicas</h2>
              <p className="text-xl opacity-90">Construído com tecnologia ChatGPT-4</p>
            </div>
            
            <div className="grid md:grid-cols-2 gap-12">
              <div>
                <h3 className="text-xl font-bold mb-6">🔧 Funcionalidades</h3>
                <ul className="space-y-3 text-gray-300">
                  <li>• Baseado em ChatGPT-4 da OpenAI</li>
                  <li>• Treinamento especializado em doenças raras</li>
                  <li>• Conhecimento contextual da CPLP</li>
                  <li>• Protocolos clínicos atualizados</li>
                  <li>• Literatura médica recente</li>
                </ul>
              </div>
              
              <div>
                <h3 className="text-xl font-bold mb-6">⚡ Acesso</h3>
                <ul className="space-y-3 text-gray-300">
                  <li>• Interface web do ChatGPT</li>
                  <li>• Disponível 24/7</li>
                  <li>• Sem necessidade de instalação</li>
                  <li>• Compatível com dispositivos móveis</li>
                  <li>• Histórico de conversas salvo</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-orange-100 to-red-100">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <ExclamationTriangleIcon className="h-16 w-16 text-orange-600 mx-auto mb-6" />
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Suporte e Feedback</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Encontrou algum problema ou tem sugestões? Entre em contato conosco para melhorar continuamente o GPT Educativo.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            {contacts.map((contact, index) => (
              <div key={index} className="bg-white rounded-2xl shadow-lg p-6 text-center border border-gray-100">
                <contact.icon className={`h-12 w-12 mx-auto mb-4 ${contact.color}`} />
                <h3 className="font-bold text-gray-900 mb-2">{contact.type}</h3>
                <p className="text-gray-600 mb-4">{contact.value}</p>
                <div className="mt-4">
                  <a
                    href={contact.href}
                    className={`text-sm font-medium ${contact.color} hover:underline`}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    Entre em Contato
                  </a>
                </div>
              </div>
            ))}
          </div>

          {/* Feedback Form */}
          <div className="mt-12 max-w-2xl mx-auto bg-white rounded-2xl shadow-lg p-8">
            <h3 className="text-xl font-bold text-gray-900 mb-6 text-center">Envie seu Feedback</h3>
            <form className="space-y-4">
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                  Email
                </label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  className="block w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  placeholder="seu@email.com"
                  required
                />
              </div>
              <div>
                <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-2">
                  Mensagem
                </label>
                <textarea
                  id="message"
                  name="message"
                  rows={4}
                  className="block w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  placeholder="Suas sugestões ou comentários"
                  required
                ></textarea>
              </div>
              <div className="flex justify-end">
                <button
                  type="submit"
                  className="px-6 py-3 bg-gradient-to-r from-orange-600 to-red-600 text-white font-medium rounded-lg hover:shadow-lg transition-all duration-200"
                >
                  Enviar Feedback
                </button>
              </div>
            </form>
          </div>
        </div>
      </section>

      {/* Footer CTA */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <div className="bg-gradient-to-r from-orange-600 to-red-600 rounded-3xl shadow-2xl p-8 md:p-12 text-white">
            <h2 className="text-3xl font-bold mb-6">🌟 Comece Agora</h2>
            <p className="text-xl opacity-90 mb-8">
              Explore o conhecimento especializado em doenças raras com inteligência artificial
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a
                href="https://chatgpt.com/g/g-68682fab869481918d65a8815554bf92-raras-gpt-educativo-e-colaborativo-da-cplp"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center px-8 py-4 bg-white text-orange-600 font-bold text-lg rounded-2xl shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300"
              >
                <ChatBubbleLeftRightIcon className="h-6 w-6 mr-3" />
                Acessar GPT Educativo
                <ArrowTopRightOnSquareIcon className="h-5 w-5 ml-2" />
              </a>
              
              <Link
                href="/sobre"
                className="inline-flex items-center px-8 py-4 border-2 border-white text-white font-bold text-lg rounded-2xl hover:bg-white hover:text-orange-600 transition-all duration-300"
              >
                Saiba Mais sobre CPLP-Raras
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
