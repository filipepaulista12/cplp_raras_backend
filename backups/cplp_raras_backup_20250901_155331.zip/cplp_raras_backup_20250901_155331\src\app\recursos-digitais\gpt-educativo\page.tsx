'use client';

import { 
  SparklesIcon, 
  AcademicCapIcon, 
  ChatBubbleLeftRightIcon,
  ExclamationTriangleIcon,
  ArrowTopRightOnSquareIcon,
  ShieldCheckIcon,
  UserGroupIcon
} from '@heroicons/react/24/outline';
import Link from 'next/link';
import { openEmailClient, getSpecificContact } from '@/lib/emailService';
import TopShare from '@/components/TopShare';

export default function GPTEducativoPage() {
  const handleContactClick = () => {
    const contact = getSpecificContact('gpt-educativo');
    openEmailClient(contact);
  };
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-orange-50 to-red-100">
      <TopShare 
        title="GPT Educativo CPLP-Raras"
        description="Assistente educacional gratuito com IA especializada em doenças raras para profissionais de saúde e pesquisadores da CPLP."
      />
      
      {/* Hero Section Simplificado */}
      <section className="relative py-24 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto text-center">
          {/* Badge de Status */}
          <div className="inline-flex items-center px-4 py-2 bg-green-100 text-green-700 rounded-full text-sm font-medium mb-8">
            <SparklesIcon className="h-4 w-4 mr-2" />
            ✨ Disponível Agora
          </div>
          
          {/* Título Principal */}
          <h1 className="text-5xl md:text-7xl font-bold mb-8">
            <span className="bg-gradient-to-r from-orange-600 via-red-600 to-pink-600 bg-clip-text text-transparent">
              GPT Educativo
            </span>
            <br />
            <span className="text-gray-700 text-3xl md:text-4xl">CPLP-Raras</span>
          </h1>
          
          {/* Descrição Concisa */}
          <p className="text-2xl md:text-3xl text-gray-600 mb-12 max-w-4xl mx-auto font-light">
            Assistente de IA especializado em doenças raras para a comunidade lusófona
          </p>

          {/* CTA Principal - SUPER DESTACADO */}
          <div className="mb-16">
            <div className="bg-white rounded-3xl shadow-2xl p-8 md:p-12 max-w-2xl mx-auto border-4 border-orange-200">
              <div className="mb-6">
                <div className="w-20 h-20 bg-gradient-to-r from-orange-500 to-red-600 rounded-full flex items-center justify-center mx-auto mb-4">
                  <ChatBubbleLeftRightIcon className="h-10 w-10 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-3">
                  Converse Agora com o GPT
                </h3>
                <p className="text-gray-600 text-lg">
                  Acesso direto ao assistente especializado
                </p>
              </div>
              
              {/* BOTÃO SUPER DESTACADO */}
              <a
                href="https://chatgpt.com/g/g-68682fab869481918d65a8815554bf92-raras-gpt-educativo-e-colaborativo-da-cplp"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center px-12 py-6 bg-gradient-to-r from-orange-600 to-red-600 text-white font-bold text-2xl rounded-2xl shadow-2xl hover:shadow-3xl transform hover:scale-110 transition-all duration-300 w-full justify-center"
              >
                <SparklesIcon className="h-8 w-8 mr-4" />
                Acessar GPT Educativo
                <ArrowTopRightOnSquareIcon className="h-6 w-6 ml-4" />
              </a>
              
              <p className="text-sm text-gray-500 mt-4">
                🆓 Gratuito • 💾 Histórico salvo • 🌐 Abre em nova janela
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Seção de Propósito - Simplificada */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-white/70">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            {/* Propósito */}
            <div>
              <div className="flex items-center mb-6">
                <UserGroupIcon className="h-12 w-12 text-blue-600 mr-4" />
                <h2 className="text-3xl font-bold text-gray-900">Para Quem é?</h2>
              </div>
              <div className="space-y-4 text-lg text-gray-700">
                <p>
                  <strong className="text-blue-600">✓ Profissionais da saúde</strong> - Apoio educativo e atualização
                </p>
                <p>
                  <strong className="text-green-600">✓ Estudantes</strong> - Aprendizado sobre doenças raras
                </p>
                <p>
                  <strong className="text-purple-600">✓ Gestores</strong> - Informações baseadas em evidências
                </p>
                <div className="bg-blue-50 border-l-4 border-blue-500 p-4 mt-6">
                  <p className="text-blue-800">
                    <strong>Foco CPLP:</strong> Adaptado às realidades dos países lusófonos
                  </p>
                </div>
              </div>
            </div>

            {/* Limitações */}
            <div>
              <div className="flex items-center mb-6">
                <ShieldCheckIcon className="h-12 w-12 text-orange-600 mr-4" />
                <h2 className="text-3xl font-bold text-gray-900">Importante Saber</h2>
              </div>
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6">
                <div className="space-y-4">
                  <div className="flex items-start space-x-3">
                    <span className="text-green-500 text-xl">✅</span>
                    <span className="text-gray-700">Informações educativas e baseadas em evidências</span>
                  </div>
                  <div className="flex items-start space-x-3">
                    <span className="text-green-500 text-xl">✅</span>
                    <span className="text-gray-700">Respeita realidades locais da CPLP</span>
                  </div>
                  <div className="flex items-start space-x-3">
                    <span className="text-red-500 text-xl">❌</span>
                    <span className="text-gray-700">NÃO fornece diagnósticos</span>
                  </div>
                  <div className="flex items-start space-x-3">
                    <span className="text-red-500 text-xl">❌</span>
                    <span className="text-gray-700">NÃO substitui consulta médica</span>
                  </div>
                </div>
                <div className="mt-6 p-4 bg-orange-100 rounded-lg">
                  <p className="text-orange-800 font-medium text-center">
                    ⚠️ Sempre consulte profissionais qualificados para decisões clínicas
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Recursos Principais - Simplificado */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Principais Recursos
            </h2>
            <p className="text-xl text-gray-600">
              O que você pode fazer com o GPT Educativo
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white rounded-2xl shadow-lg p-8 text-center hover:shadow-xl transition-shadow">
              <div className="text-4xl mb-4">🎓</div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Educação Personalizada</h3>
              <p className="text-gray-600">Conteúdo adaptado ao seu nível de conhecimento</p>
            </div>

            <div className="bg-white rounded-2xl shadow-lg p-8 text-center hover:shadow-xl transition-shadow">
              <div className="text-4xl mb-4">🌍</div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Foco CPLP</h3>
              <p className="text-gray-600">Especializado nos países lusófonos</p>
            </div>

            <div className="bg-white rounded-2xl shadow-lg p-8 text-center hover:shadow-xl transition-shadow">
              <div className="text-4xl mb-4">📚</div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Baseado em Evidências</h3>
              <p className="text-gray-600">Literatura médica atual e protocolos atualizados</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Secundário */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-orange-600 to-red-600">
        <div className="max-w-4xl mx-auto text-center text-white">
          <h2 className="text-4xl font-bold mb-6">Pronto para Começar?</h2>
          <p className="text-xl mb-8 opacity-90">
            Explore o conhecimento especializado em doenças raras com inteligência artificial
          </p>
          
          <div className="flex flex-col sm:flex-row gap-6 justify-center">
            <a
              href="https://chatgpt.com/g/g-68682fab869481918d65a8815554bf92-raras-gpt-educativo-e-colaborativo-da-cplp"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center px-10 py-4 bg-white text-orange-600 font-bold text-xl rounded-2xl shadow-xl hover:shadow-2xl transform hover:scale-105 transition-all duration-300"
            >
              <ChatBubbleLeftRightIcon className="h-6 w-6 mr-3" />
              Acessar Agora
              <ArrowTopRightOnSquareIcon className="h-5 w-5 ml-3" />
            </a>
            
            <Link
              href="/sobre"
              className="inline-flex items-center px-10 py-4 border-2 border-white text-white font-bold text-xl rounded-2xl hover:bg-white hover:text-orange-600 transition-all duration-300"
            >
              Saiba Mais sobre CPLP-Raras
            </Link>
          </div>
        </div>
      </section>

      {/* Footer Simples */}
      <section className="py-12 px-4 sm:px-6 lg:px-8 bg-gray-50">
        <div className="max-w-4xl mx-auto text-center">
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
            <ExclamationTriangleIcon className="h-8 w-8 text-blue-600 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-blue-900 mb-3">
              Dúvidas ou Sugestões?
            </h3>
            <p className="text-blue-800 mb-4">
              Entre em contato conosco para melhorar continuamente o GPT Educativo
            </p>
            <button
              onClick={handleContactClick}
              className="inline-flex items-center px-6 py-3 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 transition-colors"
            >
              📧 Entre em Contato
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}
