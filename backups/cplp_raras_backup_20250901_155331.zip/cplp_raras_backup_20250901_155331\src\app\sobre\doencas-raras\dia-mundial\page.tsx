import { Metadata } from 'next';
import { Card, CardContent } from "@/components/ui/card";
import Link from 'next/link';
import TopShare from '@/components/TopShare';

export const metadata: Metadata = {
  title: 'Dia Mundial das Doenças Raras | CPLP-Raras',
  description: 'Informações sobre o Dia Mundial das Doenças Raras, celebrado anualmente no último dia de fevereiro.',
  keywords: 'dia mundial doenças raras, 28 fevereiro, 29 fevereiro, conscientização',
};

export default function DiaMundialPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 via-purple-50 to-blue-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        
        {/* Breadcrumb */}
        <div className="mb-8 text-sm text-gray-600">
          <Link href="/sobre/doencas-raras" className="hover:text-blue-600">Doenças Raras</Link>
          <span className="mx-2">→</span>
          <span>Dia Mundial</span>
        </div>

        {/* Header */}
        <div className="text-center mb-12">
          <div className="text-6xl mb-4">🦓</div>
          <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-pink-600 via-purple-600 to-blue-600 bg-clip-text text-transparent mb-6">
            Dia Mundial das Doenças Raras
          </h1>
          <p className="text-xl text-gray-700 leading-relaxed">
            Celebrado anualmente no último dia de fevereiro
          </p>
        </div>

        {/* Data */}
        <Card className="mb-12 bg-gradient-to-r from-pink-100 to-purple-100">
          <CardContent className="p-8 text-center">
            <h2 className="text-3xl font-bold mb-4 text-gray-800">
              📅 28 ou 29 de Fevereiro
            </h2>
            <p className="text-lg text-gray-700 mb-4">
              O último dia de fevereiro foi escolhido simbolicamente por ser o dia mais "raro" do calendário.
            </p>
            <div className="grid md:grid-cols-2 gap-6 mt-6">
              <div className="bg-white p-4 rounded-lg">
                <h3 className="font-bold text-pink-600">Anos Comuns</h3>
                <p className="text-gray-700">28 de Fevereiro</p>
              </div>
              <div className="bg-white p-4 rounded-lg">
                <h3 className="font-bold text-purple-600">Anos Bissextos</h3>
                <p className="text-gray-700">29 de Fevereiro</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Objetivo */}
        <Card className="mb-12">
          <CardContent className="p-8">
            <h2 className="text-2xl font-bold mb-6 text-gray-800">🎯 Objetivos da Data</h2>
            <div className="space-y-4">
              <div className="flex items-start gap-4">
                <div className="text-2xl">🔍</div>
                <div>
                  <h3 className="font-semibold text-gray-800">Conscientização</h3>
                  <p className="text-gray-600">Aumentar a visibilidade das doenças raras na sociedade</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="text-2xl">🤝</div>
                <div>
                  <h3 className="font-semibold text-gray-800">Apoio</h3>
                  <p className="text-gray-600">Mostrar solidariedade aos pacientes e suas famílias</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="text-2xl">🏥</div>
                <div>
                  <h3 className="font-semibold text-gray-800">Pesquisa</h3>
                  <p className="text-gray-600">Promover investimento em pesquisa e desenvolvimento</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="text-2xl">⚖️</div>
                <div>
                  <h3 className="font-semibold text-gray-800">Políticas</h3>
                  <p className="text-gray-600">Influenciar políticas públicas de saúde</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* História */}
        <Card className="mb-12">
          <CardContent className="p-8">
            <h2 className="text-2xl font-bold mb-6 text-gray-800">📚 História da Data</h2>
            <div className="space-y-6">
              <div className="border-l-4 border-purple-400 pl-6">
                <h3 className="font-bold text-lg text-gray-800">2008 - Primeira Edição</h3>
                <p className="text-gray-600">
                  O primeiro Dia Mundial das Doenças Raras foi organizado pela EURORDIS 
                  (Organização Europeia de Doenças Raras) e celebrado em vários países europeus.
                </p>
              </div>
              <div className="border-l-4 border-blue-400 pl-6">
                <h3 className="font-bold text-lg text-gray-800">Expansão Global</h3>
                <p className="text-gray-600">
                  Rapidamente se expandiu para outros continentes, incluindo América, 
                  Ásia e Oceania, tornando-se verdadeiramente mundial.
                </p>
              </div>
              <div className="border-l-4 border-pink-400 pl-6">
                <h3 className="font-bold text-lg text-gray-800">Atualmente</h3>
                <p className="text-gray-600">
                  Mais de 100 países participam anualmente, organizando eventos, 
                  campanhas e atividades de conscientização.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Símbolos */}
        <Card className="mb-12">
          <CardContent className="p-8">
            <h2 className="text-2xl font-bold mb-6 text-gray-800">🦓 Símbolos e Cores</h2>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="bg-gradient-to-r from-black to-white p-6 rounded-lg text-center">
                <div className="text-4xl mb-4">🦓</div>
                <h3 className="font-bold text-gray-800 mb-2">Zebra</h3>
                <p className="text-sm text-gray-700">
                  Símbolo das doenças raras pela expressão médica "quando você ouve cascos, 
                  pense em cavalos, não em zebras" - representando o diagnóstico raro.
                </p>
              </div>
              <div className="bg-gradient-to-r from-purple-200 to-pink-200 p-6 rounded-lg text-center">
                <div className="text-4xl mb-4">🎨</div>
                <h3 className="font-bold text-gray-800 mb-2">Cores</h3>
                <p className="text-sm text-gray-700">
                  Roxo, rosa e azul são as cores oficiais, representando esperança, 
                  força e união da comunidade de doenças raras.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Como Participar */}
        <Card className="bg-gradient-to-r from-purple-100 to-pink-100">
          <CardContent className="p-8">
            <h2 className="text-2xl font-bold mb-6 text-gray-800 text-center">
              🌟 Como Participar
            </h2>
            <div className="grid md:grid-cols-3 gap-6 text-center">
              <div>
                <div className="text-3xl mb-3">📢</div>
                <h3 className="font-bold text-gray-800 mb-2">Divulgue</h3>
                <p className="text-sm text-gray-700">
                  Compartilhe informações nas redes sociais com #RareDiseaseDay
                </p>
              </div>
              <div>
                <div className="text-3xl mb-3">👕</div>
                <h3 className="font-bold text-gray-800 mb-2">Vista-se</h3>
                <p className="text-sm text-gray-700">
                  Use roupas roxas, rosas ou azuis para mostrar apoio
                </p>
              </div>
              <div>
                <div className="text-3xl mb-3">🎪</div>
                <h3 className="font-bold text-gray-800 mb-2">Participe</h3>
                <p className="text-sm text-gray-700">
                  Compareça a eventos locais e atividades de conscientização
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

      </div>
    </div>
  );
}
