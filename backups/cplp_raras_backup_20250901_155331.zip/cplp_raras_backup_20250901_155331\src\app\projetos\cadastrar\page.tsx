'use client'

import Link from 'next/link';
import { useState } from 'react';

export default function CadastrarProjeto() {
  const [formData, setFormData] = useState({
    titulo: '',
    instituicao: '',
    pais: '',
    responsavel: '',
    email: '',
    telefone: '',
    area_doenca: '',
    descricao: '',
    objetivos: '',
    metodologia: '',
    colaboradores: '',
    cronograma: '',
    financiamento: '',
    etica: '',
    resultados_esperados: '',
    divulgacao: 'sim'
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Aqui será integrado com REDCap futuramente
    setTimeout(() => {
      setIsSubmitting(false);
      setSubmitted(true);
    }, 2000);
  };

  if (submitted) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="mx-auto max-w-4xl px-4 py-12 sm:px-6 lg:px-8">
          <div className="bg-white rounded-2xl shadow-lg p-8 text-center">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <span className="text-3xl">✅</span>
            </div>
            <h1 className="text-3xl font-bold text-gray-900 mb-4">
              Projeto Cadastrado com Sucesso!
            </h1>
            <p className="text-lg text-gray-600 mb-8">
              Obrigado por cadastrar seu projeto. Nossa equipe entrará em contato em breve para 
              dar continuidade ao processo de integração à rede CPLP-Raras.
            </p>
            <div className="space-x-4">
              <Link 
                href="/projetos"
                className="inline-block bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors"
              >
                Ver Projetos Cadastrados
              </Link>
              <Link 
                href="/sobre/ferramentas"
                className="inline-block bg-gray-200 text-gray-800 px-6 py-3 rounded-lg font-semibold hover:bg-gray-300 transition-colors"
              >
                Voltar às Ferramentas
              </Link>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Breadcrumb */}
      <div className="bg-white border-b">
        <div className="mx-auto max-w-7xl px-4 py-4 sm:px-6 lg:px-8">
          <nav className="flex" aria-label="Breadcrumb">
            <ol className="inline-flex items-center space-x-1 md:space-x-3">
              <li className="inline-flex items-center">
                <Link href="/" className="text-blue-600 hover:text-blue-800">
                  Início
                </Link>
              </li>
              <li>
                <div className="flex items-center">
                  <span className="mx-2 text-gray-400">/</span>
                  <Link href="/projetos" className="text-blue-600 hover:text-blue-800">
                    Projetos
                  </Link>
                </div>
              </li>
              <li aria-current="page">
                <div className="flex items-center">
                  <span className="mx-2 text-gray-400">/</span>
                  <span className="text-gray-500">Cadastrar</span>
                </div>
              </li>
            </ol>
          </nav>
        </div>
      </div>

      <div className="mx-auto max-w-4xl px-4 py-12 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            🚀 Cadastrar Projeto
          </h1>
          <div className="w-32 h-1 bg-gradient-to-r from-blue-600 to-green-600 mx-auto mb-8"></div>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Registre seu projeto de pesquisa em doenças raras e faça parte da rede colaborativa da CPLP.
          </p>
        </div>

        {/* Formulário */}
        <div className="bg-white rounded-2xl shadow-lg p-8 md:p-12">
          <form onSubmit={handleSubmit} className="space-y-8">
            {/* Informações Básicas */}
            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-6 border-b border-gray-200 pb-3">
                📋 Informações Básicas do Projeto
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="titulo" className="block text-sm font-medium text-gray-700 mb-2">
                    Título do Projeto *
                  </label>
                  <input
                    type="text"
                    id="titulo"
                    name="titulo"
                    required
                    value={formData.titulo}
                    onChange={handleChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Digite o título do projeto"
                  />
                </div>
                
                <div>
                  <label htmlFor="area_doenca" className="block text-sm font-medium text-gray-700 mb-2">
                    Área/Doença Rara *
                  </label>
                  <input
                    type="text"
                    id="area_doenca"
                    name="area_doenca"
                    required
                    value={formData.area_doenca}
                    onChange={handleChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Ex: Mucopolissacaridoses, Doenças Metabólicas"
                  />
                </div>
              </div>
            </div>

            {/* Informações Institucionais */}
            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-6 border-b border-gray-200 pb-3">
                🏥 Informações Institucionais
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="instituicao" className="block text-sm font-medium text-gray-700 mb-2">
                    Instituição *
                  </label>
                  <input
                    type="text"
                    id="instituicao"
                    name="instituicao"
                    required
                    value={formData.instituicao}
                    onChange={handleChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Nome da instituição/universidade"
                  />
                </div>
                
                <div>
                  <label htmlFor="pais" className="block text-sm font-medium text-gray-700 mb-2">
                    País da CPLP *
                  </label>
                  <select
                    id="pais"
                    name="pais"
                    required
                    value={formData.pais}
                    onChange={handleChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="">Selecione o país</option>
                    <option value="brasil">Brasil</option>
                    <option value="portugal">Portugal</option>
                    <option value="angola">Angola</option>
                    <option value="mocambique">Moçambique</option>
                    <option value="cabo_verde">Cabo Verde</option>
                    <option value="guinea_bissau">Guiné-Bissau</option>
                    <option value="sao_tome">São Tomé e Príncipe</option>
                    <option value="timor_leste">Timor-Leste</option>
                    <option value="guiné_equatorial">Guiné Equatorial</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Contato do Responsável */}
            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-6 border-b border-gray-200 pb-3">
                👤 Responsável pelo Projeto
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                  <label htmlFor="responsavel" className="block text-sm font-medium text-gray-700 mb-2">
                    Nome Completo *
                  </label>
                  <input
                    type="text"
                    id="responsavel"
                    name="responsavel"
                    required
                    value={formData.responsavel}
                    onChange={handleChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Nome do pesquisador responsável"
                  />
                </div>
                
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                    E-mail *
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    required
                    value={formData.email}
                    onChange={handleChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="email@exemplo.com"
                  />
                </div>
                
                <div>
                  <label htmlFor="telefone" className="block text-sm font-medium text-gray-700 mb-2">
                    Telefone
                  </label>
                  <input
                    type="tel"
                    id="telefone"
                    name="telefone"
                    value={formData.telefone}
                    onChange={handleChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="+55 (11) 99999-9999"
                  />
                </div>
              </div>
            </div>

            {/* Descrição do Projeto */}
            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-6 border-b border-gray-200 pb-3">
                📄 Descrição do Projeto
              </h2>
              <div className="space-y-6">
                <div>
                  <label htmlFor="descricao" className="block text-sm font-medium text-gray-700 mb-2">
                    Resumo do Projeto *
                  </label>
                  <textarea
                    id="descricao"
                    name="descricao"
                    required
                    rows={4}
                    value={formData.descricao}
                    onChange={handleChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Descreva brevemente o objetivo e escopo do projeto..."
                  />
                </div>
                
                <div>
                  <label htmlFor="objetivos" className="block text-sm font-medium text-gray-700 mb-2">
                    Objetivos Principais
                  </label>
                  <textarea
                    id="objetivos"
                    name="objetivos"
                    rows={3}
                    value={formData.objetivos}
                    onChange={handleChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Liste os principais objetivos do projeto..."
                  />
                </div>
                
                <div>
                  <label htmlFor="metodologia" className="block text-sm font-medium text-gray-700 mb-2">
                    Metodologia
                  </label>
                  <textarea
                    id="metodologia"
                    name="metodologia"
                    rows={3}
                    value={formData.metodologia}
                    onChange={handleChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Descreva a metodologia que será utilizada..."
                  />
                </div>
              </div>
            </div>

            {/* Informações Adicionais */}
            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-6 border-b border-gray-200 pb-3">
                ℹ️ Informações Adicionais
              </h2>
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label htmlFor="colaboradores" className="block text-sm font-medium text-gray-700 mb-2">
                      Colaboradores/Parceiros
                    </label>
                    <textarea
                      id="colaboradores"
                      name="colaboradores"
                      rows={3}
                      value={formData.colaboradores}
                      onChange={handleChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      placeholder="Liste instituições e pesquisadores colaboradores..."
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="financiamento" className="block text-sm font-medium text-gray-700 mb-2">
                      Fonte de Financiamento
                    </label>
                    <textarea
                      id="financiamento"
                      name="financiamento"
                      rows={3}
                      value={formData.financiamento}
                      onChange={handleChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      placeholder="Agências de fomento, editais, etc..."
                    />
                  </div>
                </div>
                
                <div>
                  <label htmlFor="divulgacao" className="block text-sm font-medium text-gray-700 mb-2">
                    Autoriza divulgação pública do projeto?
                  </label>
                  <select
                    id="divulgacao"
                    name="divulgacao"
                    value={formData.divulgacao}
                    onChange={handleChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="sim">Sim, autorizo a divulgação</option>
                    <option value="parcial">Apenas informações básicas</option>
                    <option value="nao">Não autorizo divulgação</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Botões */}
            <div className="flex justify-end space-x-4 pt-8 border-t border-gray-200">
              <Link
                href="/sobre/ferramentas"
                className="px-6 py-3 border border-gray-300 rounded-lg text-gray-700 font-medium hover:bg-gray-50 transition-colors"
              >
                Cancelar
              </Link>
              <button
                type="submit"
                disabled={isSubmitting}
                className={`px-8 py-3 rounded-lg font-semibold transition-colors ${
                  isSubmitting
                    ? 'bg-gray-400 text-white cursor-not-allowed'
                    : 'bg-blue-600 text-white hover:bg-blue-700'
                }`}
              >
                {isSubmitting ? 'Cadastrando...' : 'Cadastrar Projeto'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
