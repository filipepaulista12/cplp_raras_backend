'use client';

import { useLanguage } from '@/contexts/LanguageContext';
import { ClockIcon, WrenchScrewdriverIcon, UserGroupIcon, DocumentTextIcon } from '@heroicons/react/24/outline';
import TopShare from '@/components/TopShare';

export default function SOFPage() {
  const { t } = useLanguage();

  const features = [
    {
      icon: '🔍',
      title: 'Sistema de Segunda Opnião Formativa',
      description: 'Orientação Diagnóstica Inteligente - Sistema baseado em algoritmos para auxiliar profissionais de saúde no processo diagnóstico de doenças raras'
    },
    {
      icon: '📋',
      title: 'Protocolos Padronizados',
      description: 'Acesso a protocolos clínicos validados e diretrizes terapêuticas específicas para doenças raras'
    },
    {
      icon: '🌐',
      title: 'Rede Colaborativa',
      description: 'Conexão entre profissionais especialistas nos países lusófonos para discussão de casos complexos'
    },
    {
      icon: '📊',
      title: 'Analytics e Relatórios',
      description: 'Dashboards com estatísticas de uso e relatórios epidemiológicos para gestores de saúde'
    }
  ];

  const timeline = [
    {
      quarter: 'Q1 2025',
      status: 'current',
      title: 'Pesquisa e Planejamento',
      description: 'Levantamento de requisitos e design da arquitetura do sistema'
    },
    {
      quarter: 'Q2 2025',
      status: 'upcoming',
      title: 'Desenvolvimento do MVP',
      description: 'Construção da versão mínima viável com funcionalidades essenciais'
    },
    {
      quarter: 'Q3 2025',
      status: 'upcoming',
      title: 'Testes Piloto',
      description: 'Testes com profissionais de saúde em hospitais selecionados'
    },
    {
      quarter: 'Q4 2025',
      status: 'upcoming',
      title: 'Lançamento Oficial',
      description: 'Disponibilização para toda a rede CPLP'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-purple-50 to-pink-100">
      {/* Hero Section */}
      <section className="relative py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          
          {/* Compartilhamento no topo */}
          <TopShare 
            title="Sistema SOF - CPLP-Raras"
            description="Sistema de Orientação diagnóstica para doenças raras destinado a profissionais de saúde da CPLP"
          />
          
          <div className="text-center">
            <div className="inline-flex items-center px-4 py-2 bg-orange-100 text-orange-700 rounded-full text-sm font-medium mb-6">
              <ClockIcon className="h-4 w-4 mr-2" />
              {t('common.coming-soon')} - Q2 2025
            </div>
            
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              <span className="bg-gradient-to-r from-purple-600 via-pink-600 to-red-600 bg-clip-text text-transparent">
                Sistema SOF
              </span>
            </h1>
            <p className="text-xl md:text-2xl text-gray-600 mb-8 max-w-3xl mx-auto">
              Sistema de Orientação diagnóstica para doenças raras destinado a profissionais de saúde da CPLP
            </p>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Funcionalidades Planejadas
            </h2>
            <p className="text-lg text-gray-600">
              O SOF será uma ferramenta completa para auxílio diagnóstico
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {features.map((feature, index) => (
              <div key={index} className="bg-white rounded-2xl shadow-lg p-8 border border-gray-100 hover:shadow-xl transition-all duration-300">
                <div className="flex items-center mb-4">
                  <div className="text-3xl mr-4">{feature.icon}</div>
                  <h3 className="text-xl font-bold text-gray-900">{feature.title}</h3>
                </div>
                <p className="text-gray-600 leading-relaxed">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Timeline */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-white/50">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <WrenchScrewdriverIcon className="h-16 w-16 text-purple-600 mx-auto mb-6" />
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Cronograma de Desenvolvimento
            </h2>
            <p className="text-lg text-gray-600">
              Acompanhe o progresso do desenvolvimento do SOF
            </p>
          </div>

          <div className="space-y-6">
            {timeline.map((item, index) => (
              <div key={index} className="flex items-center">
                <div className={`flex-shrink-0 w-32 text-right mr-8 ${
                  item.status === 'current' ? 'text-purple-600 font-bold' : 'text-gray-500'
                }`}>
                  {item.quarter}
                </div>
                <div className={`w-4 h-4 rounded-full mr-8 ${
                  item.status === 'current' ? 'bg-purple-600 animate-pulse' : 'bg-gray-300'
                }`}></div>
                <div className="flex-1 bg-white rounded-xl p-6 shadow-sm border border-gray-100">
                  <h3 className={`text-lg font-bold mb-2 ${
                    item.status === 'current' ? 'text-purple-600' : 'text-gray-900'
                  }`}>
                    {item.title}
                  </h3>
                  <p className="text-gray-600">{item.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <div className="bg-gradient-to-br from-purple-500 to-pink-600 rounded-2xl p-8 text-white">
            <UserGroupIcon className="h-16 w-16 mx-auto mb-6 opacity-90" />
            <h2 className="text-3xl font-bold mb-4">
              Quer Participar do Desenvolvimento?
            </h2>
            <p className="text-xl mb-8 opacity-90">
              Estamos buscando profissionais de saúde e especialistas em doenças raras para colaborar no desenvolvimento do SOF
            </p>
            <div className="space-y-4 sm:space-y-0 sm:space-x-4 sm:flex sm:justify-center">
              <a
                href="/contato"
                className="inline-block px-8 py-4 bg-white text-purple-600 font-bold rounded-xl hover:bg-gray-50 transition-all duration-200 transform hover:scale-105"
              >
                Entre em Contato
              </a>
              <a
                href="mailto:sof@cplp-raras.org"
                className="inline-block px-8 py-4 border-2 border-white text-white font-bold rounded-xl hover:bg-white hover:text-purple-600 transition-all duration-200"
              >
                sof@cplp-raras.org
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Newsletter */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gray-50">
        <div className="max-w-4xl mx-auto text-center">
          <DocumentTextIcon className="h-12 w-12 text-gray-600 mx-auto mb-4" />
          <h3 className="text-2xl font-bold text-gray-900 mb-4">
            Fique por Dentro das Novidades
          </h3>
          <p className="text-gray-600 mb-6">
            Receba atualizações sobre o desenvolvimento do SOF e outras ferramentas
          </p>
          <div className="max-w-md mx-auto flex">
            <input
              type="email"
              placeholder="Seu e-mail"
              className="flex-1 px-4 py-3 border border-gray-300 rounded-l-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent"
            />
            <button className="px-6 py-3 bg-purple-600 text-white font-medium rounded-r-xl hover:bg-purple-700 transition-colors">
              Inscrever
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}
