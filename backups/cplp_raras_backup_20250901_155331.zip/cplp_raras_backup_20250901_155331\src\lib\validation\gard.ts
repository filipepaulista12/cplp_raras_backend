// =====================================================================================
// SCHEMA DE VALIDAÇÃO ZOD PARA O SISTEMA GARD BRASILEIRO
// =====================================================================================
// Validações robustas para todas as entidades do sistema
// Compatível com formulários, APIs e validação de dados
// =====================================================================================

import { z } from 'zod';

// =====================================================================================
// 1. SCHEMAS BÁSICOS E ENUMS
// =====================================================================================

export const InfoStatusSchema = z.enum([
  'draft',
  'under_review', 
  'reviewed',
  'published',
  'needs_update',
  'archived'
]);

export const PrevalenceTypeSchema = z.enum([
  'point',
  'birth',
  'lifetime',
  'unknown'
]);

export const StudyTypeSchema = z.enum([
  'case_report',
  'clinical_trial',
  'review',
  'cohort_study',
  'case_control',
  'systematic_review',
  'meta_analysis'
]);

export const SpecialistTypeSchema = z.enum([
  'doctor',
  'center',
  'clinic',
  'hospital',
  'research_institute'
]);

export const OrganizationTypeSchema = z.enum([
  'patient_association',
  'research_foundation',
  'government_agency',
  'healthcare_provider',
  'advocacy_group'
]);

export const AvailabilityStatusSchema = z.enum([
  'available',
  'restricted',
  'unavailable',
  'unknown'
]);

// Validação para GARD-BR ID
export const GardBrIdSchema = z.string()
  .regex(/^GARD-BR-\d{4}$/, 'ID deve seguir o formato GARD-BR-XXXX');

// Validação para códigos médicos
export const OrphaCodeSchema = z.string()
  .regex(/^ORPHA:\d+$/, 'Código ORPHA deve seguir o formato ORPHA:XXXXXX')
  .optional();

export const IcdCodeSchema = z.string()
  .regex(/^[A-Z]\d{2}(\.\d{1,2})?$/, 'Código ICD deve seguir o formato correto')
  .optional();

export const OmimCodeSchema = z.string()
  .regex(/^\d{6}$/, 'Código OMIM deve ter 6 dígitos')
  .optional();

// =====================================================================================
// 2. SCHEMAS AUXILIARES
// =====================================================================================

export const ContactInfoSchema = z.object({
  email: z.string().email().optional(),
  phone: z.string().min(1).optional(),
  fax: z.string().optional(),
  website: z.string().url().optional(),
  contact_person: z.string().optional(),
  office_hours: z.string().optional()
});

export const SocialMediaInfoSchema = z.object({
  facebook: z.string().url().optional(),
  twitter: z.string().url().optional(),
  instagram: z.string().url().optional(),
  linkedin: z.string().url().optional(),
  youtube: z.string().url().optional()
});

export const AddressInfoSchema = z.object({
  street: z.string().optional(),
  city: z.string().optional(),
  state: z.string().optional(),
  postal_code: z.string().optional(),
  country: z.string().optional(),
  coordinates: z.object({
    lat: z.number().min(-90).max(90),
    lng: z.number().min(-180).max(180)
  }).optional()
});

// =====================================================================================
// 3. SCHEMAS PRINCIPAIS
// =====================================================================================

export const DiseaseCategorySchema = z.object({
  id: z.number().int().positive().optional(),
  code: z.string().min(1).max(50),
  name_pt: z.string().min(1).max(200),
  name_en: z.string().min(1).max(200),
  description: z.string().optional(),
  color_hex: z.string().regex(/^#[0-9A-Fa-f]{6}$/).optional(),
  icon: z.string().max(50).optional(),
  sort_order: z.number().int().min(0).default(0),
  created_at: z.date().default(() => new Date()),
  updated_at: z.date().default(() => new Date())
});

export const CPLPCountrySchema = z.object({
  id: z.number().int().positive().optional(),
  code: z.string().length(3),
  name: z.string().min(1).max(100),
  flag_emoji: z.string().max(10).optional(),
  population: z.number().int().positive().optional(),
  healthcare_system: z.string().optional(),
  rare_disease_policy: z.string().optional(),
  created_at: z.date().default(() => new Date())
});

export const InheritancePatternSchema = z.object({
  id: z.number().int().positive().optional(),
  code: z.string().min(1).max(50),
  name_pt: z.string().min(1).max(100),
  name_en: z.string().min(1).max(100),
  description: z.string().optional(),
  created_at: z.date().default(() => new Date())
});

// =====================================================================================
// 4. SCHEMA PRINCIPAL - DOENÇA
// =====================================================================================

export const DiseaseSchema = z.object({
  id: z.string().uuid().optional(),
  gard_br_id: GardBrIdSchema,
  gard_original_id: z.string().max(20).optional(),
  
  // Identificação
  name_pt: z.string().min(1).max(500),
  name_en: z.string().max(500).optional(),
  synonyms: z.array(z.string()).default([]),
  
  // Classificação
  category_id: z.number().int().positive().optional(),
  subcategory: z.string().max(200).optional(),
  
  // Códigos de referência
  orpha_code: OrphaCodeSchema,
  icd10_codes: z.array(IcdCodeSchema).default([]),
  icd11_codes: z.array(z.string()).default([]),
  omim_codes: z.array(OmimCodeSchema).default([]),
  
  // Informações epidemiológicas
  prevalence_value: z.string().max(200).optional(),
  prevalence_type: PrevalenceTypeSchema.default('point'),
  age_of_onset: z.string().max(200).optional(),
  
  // Genética
  inheritance_pattern_id: z.number().int().positive().optional(),
  genes_involved: z.array(z.string()).default([]),
  chromosomal_location: z.string().max(100).optional(),
  
  // Metadados
  info_status: InfoStatusSchema.default('draft'),
  quality_score: z.number().int().min(0).max(100).default(0),
  last_medical_review: z.date().optional(),
  next_review_due: z.date().optional(),
  
  // Auditoria
  created_at: z.date().default(() => new Date()),
  updated_at: z.date().default(() => new Date()),
  created_by: z.string().uuid().optional(),
  updated_by: z.string().uuid().optional()
});

// =====================================================================================
// 5. SCHEMA DE CONTEÚDO DETALHADO
// =====================================================================================

export const DiseaseContentSchema = z.object({
  id: z.string().uuid().optional(),
  disease_id: z.string().uuid(),
  
  // Conteúdo principal
  summary: z.string().optional(),
  detailed_description: z.string().optional(),
  
  // Seções estruturadas
  symptoms: z.array(z.string()).default([]),
  signs: z.array(z.string()).default([]),
  causes: z.string().optional(),
  pathophysiology: z.string().optional(),
  
  // Diagnóstico
  diagnostic_criteria: z.array(z.string()).default([]),
  diagnostic_tests: z.array(z.string()).default([]),
  differential_diagnosis: z.array(z.string()).default([]),
  
  // Tratamento
  treatment_options: z.array(z.string()).default([]),
  management_guidelines: z.string().optional(),
  medications: z.array(z.string()).default([]),
  therapies: z.array(z.string()).default([]),
  
  // Prognóstico
  prognosis: z.string().optional(),
  life_expectancy: z.string().max(200).optional(),
  quality_of_life_impact: z.string().optional(),
  
  // Recursos
  patient_resources: z.array(z.string()).default([]),
  family_resources: z.array(z.string()).default([]),
  professional_resources: z.array(z.string()).default([]),
  
  // Metadados
  content_version: z.number().int().positive().default(1),
  language_code: z.string().length(5).default('pt-BR'),
  medical_reviewer: z.string().max(200).optional(),
  reviewed_at: z.date().optional(),
  
  created_at: z.date().default(() => new Date()),
  updated_at: z.date().default(() => new Date())
});

// =====================================================================================
// 6. SCHEMAS PARA RELACIONAMENTOS
// =====================================================================================

export const DiseaseClinicalTrialSchema = z.object({
  id: z.string().uuid().optional(),
  disease_id: z.string().uuid(),
  
  trial_id: z.string().max(50),
  title: z.string().min(1).max(500),
  description: z.string().optional(),
  status: z.string().max(50),
  phase: z.string().max(20).optional(),
  location: z.string().max(200).optional(),
  country_code: z.string().length(3).optional(),
  contact_info: z.string().optional(),
  
  start_date: z.date().optional(),
  estimated_completion: z.date().optional(),
  last_updated: z.date().default(() => new Date()),
  
  source: z.string().max(100).optional(),
  source_url: z.string().url().optional()
});

export const DiseaseSupportOrganizationSchema = z.object({
  id: z.string().uuid().optional(),
  disease_id: z.string().uuid(),
  
  name: z.string().min(1).max(300),
  description: z.string().optional(),
  organization_type: OrganizationTypeSchema,
  
  contact_info: ContactInfoSchema.optional(),
  website: z.string().url().optional(),
  social_media: SocialMediaInfoSchema.optional(),
  
  country_id: z.number().int().positive().optional(),
  languages: z.array(z.string().length(2)).default([]),
  
  services_offered: z.array(z.string()).default([]),
  target_audience: z.string().max(100).optional(),
  
  verified: z.boolean().default(false),
  last_verified: z.date().optional(),
  
  created_at: z.date().default(() => new Date()),
  updated_at: z.date().default(() => new Date())
});

export const DiseasePublicationSchema = z.object({
  id: z.string().uuid().optional(),
  disease_id: z.string().uuid(),
  
  pubmed_id: z.string().max(20).optional(),
  doi: z.string().max(200).optional(),
  title: z.string().min(1).max(1000),
  authors: z.array(z.string()).default([]),
  journal: z.string().max(300).optional(),
  publication_date: z.date().optional(),
  abstract: z.string().optional(),
  
  study_type: StudyTypeSchema.optional(),
  evidence_level: z.number().int().min(1).max(5).optional(),
  language_code: z.string().length(5).optional(),
  
  is_open_access: z.boolean().default(false),
  full_text_url: z.string().url().optional(),
  
  created_at: z.date().default(() => new Date())
});

export const DiseaseSpecialistSchema = z.object({
  id: z.string().uuid().optional(),
  disease_id: z.string().uuid(),
  
  specialist_type: SpecialistTypeSchema,
  name: z.string().min(1).max(300),
  specialty: z.string().max(200).optional(),
  
  contact_info: ContactInfoSchema.optional(),
  address: AddressInfoSchema.optional(),
  country_id: z.number().int().positive().optional(),
  
  accepts_new_patients: z.boolean().default(true),
  languages: z.array(z.string().length(2)).default([]),
  telemedicine_available: z.boolean().default(false),
  
  verification_status: z.string().max(50).default('pending'),
  verified_by: z.string().max(200).optional(),
  verified_at: z.date().optional(),
  
  created_at: z.date().default(() => new Date()),
  updated_at: z.date().default(() => new Date())
});

// =====================================================================================
// 7. SCHEMAS PARA DADOS REGIONAIS
// =====================================================================================

export const DiseaseEpidemiologyCPLPSchema = z.object({
  id: z.string().uuid().optional(),
  disease_id: z.string().uuid(),
  country_id: z.number().int().positive(),
  
  estimated_cases: z.number().int().min(0).optional(),
  prevalence_per_100k: z.number().min(0).optional(),
  incidence_per_100k_year: z.number().min(0).optional(),
  
  data_source: z.string().max(200).optional(),
  data_quality: z.enum(['high', 'medium', 'low', 'estimated']).optional(),
  collection_date: z.date().optional(),
  
  notes: z.string().optional(),
  
  created_at: z.date().default(() => new Date()),
  updated_at: z.date().default(() => new Date())
});

export const DiseaseMedicationsAvailabilitySchema = z.object({
  id: z.string().uuid().optional(),
  disease_id: z.string().uuid(),
  country_id: z.number().int().positive(),
  
  medication_name: z.string().min(1).max(300),
  generic_name: z.string().max(300).optional(),
  
  availability_status: AvailabilityStatusSchema,
  regulatory_status: z.string().max(100).optional(),
  reimbursement_status: z.string().max(100).optional(),
  
  cost_info: z.string().optional(),
  access_conditions: z.array(z.string()).default([]),
  prescription_requirements: z.array(z.string()).default([]),
  
  last_updated: z.date().default(() => new Date()),
  data_source: z.string().max(200).optional()
});

// =====================================================================================
// 8. SCHEMAS PARA BUSCA E API
// =====================================================================================

export const DiseaseSearchParamsSchema = z.object({
  search_term: z.string().optional(),
  category_filter: z.number().int().positive().optional(),
  country_filter: z.number().int().positive().optional(),
  inheritance_filter: z.number().int().positive().optional(),
  status_filter: InfoStatusSchema.optional(),
  letter_filter: z.string().length(1).regex(/[A-Z0-9]/).optional(),
  limit: z.number().int().min(1).max(100).default(50),
  offset: z.number().int().min(0).default(0)
});

export const DiseaseSearchResultSchema = z.object({
  disease_id: z.string().uuid(),
  gard_br_id: z.string(),
  name_pt: z.string(),
  category_name: z.string().optional(),
  prevalence_value: z.string().optional(),
  rank: z.number().optional()
});

export const DiseaseSearchResponseSchema = z.object({
  diseases: z.array(DiseaseSearchResultSchema),
  total_count: z.number().int().min(0),
  page: z.number().int().min(1),
  per_page: z.number().int().min(1),
  total_pages: z.number().int().min(0),
  has_more: z.boolean()
});

// =====================================================================================
// 9. SCHEMAS PARA FORMS DE CRIAÇÃO/EDIÇÃO
// =====================================================================================

export const CreateDiseaseRequestSchema = z.object({
  name_pt: z.string().min(1).max(500),
  name_en: z.string().max(500).optional(),
  synonyms: z.array(z.string()).default([]),
  category_id: z.number().int().positive().optional(),
  orpha_code: OrphaCodeSchema,
  icd10_codes: z.array(IcdCodeSchema).default([]),
  prevalence_value: z.string().max(200).optional(),
  inheritance_pattern_id: z.number().int().positive().optional(),
  genes_involved: z.array(z.string()).default([])
});

export const UpdateDiseaseRequestSchema = CreateDiseaseRequestSchema.partial().extend({
  id: z.string().uuid()
});

export const CreateDiseaseContentRequestSchema = z.object({
  disease_id: z.string().uuid(),
  summary: z.string().optional(),
  symptoms: z.array(z.string()).default([]),
  causes: z.string().optional(),
  diagnostic_criteria: z.array(z.string()).default([]),
  treatment_options: z.array(z.string()).default([]),
  prognosis: z.string().optional(),
  language_code: z.string().length(5).default('pt-BR')
});

// =====================================================================================
// 10. SCHEMAS PARA VALIDAÇÃO DE BULK IMPORT
// =====================================================================================

export const BulkDiseaseImportSchema = z.object({
  diseases: z.array(CreateDiseaseRequestSchema),
  validate_only: z.boolean().default(false),
  update_existing: z.boolean().default(false),
  source: z.string().max(100).optional()
});

export const ImportResultSchema = z.object({
  success_count: z.number().int().min(0),
  error_count: z.number().int().min(0),
  errors: z.array(z.object({
    index: z.number().int(),
    disease_name: z.string().optional(),
    error_message: z.string(),
    field: z.string().optional()
  })),
  imported_ids: z.array(z.string())
});

// =====================================================================================
// 11. SCHEMAS PARA RELATÓRIOS E ESTATÍSTICAS
// =====================================================================================

export const DiseaseStatisticsSchema = z.object({
  total_diseases: z.number().int().min(0),
  by_category: z.record(z.string(), z.number().int().min(0)),
  by_country: z.record(z.string(), z.number().int().min(0)),
  by_status: z.record(InfoStatusSchema, z.number().int().min(0)),
  recent_additions: z.number().int().min(0),
  needs_review: z.number().int().min(0)
});

export const QualityMetricsSchema = z.object({
  diseases_with_content: z.number().int().min(0),
  reviewed_diseases: z.number().int().min(0),
  diseases_with_specialists: z.number().int().min(0),
  diseases_with_trials: z.number().int().min(0),
  average_quality_score: z.number().min(0).max(100)
});

// =====================================================================================
// 12. EXPORT DE TIPOS INFERIDOS
// =====================================================================================

export type Disease = z.infer<typeof DiseaseSchema>;
export type DiseaseContent = z.infer<typeof DiseaseContentSchema>;
export type DiseaseCategory = z.infer<typeof DiseaseCategorySchema>;
export type CPLPCountry = z.infer<typeof CPLPCountrySchema>;
export type InheritancePattern = z.infer<typeof InheritancePatternSchema>;

export type DiseaseClinicalTrial = z.infer<typeof DiseaseClinicalTrialSchema>;
export type DiseaseSupportOrganization = z.infer<typeof DiseaseSupportOrganizationSchema>;
export type DiseasePublication = z.infer<typeof DiseasePublicationSchema>;
export type DiseaseSpecialist = z.infer<typeof DiseaseSpecialistSchema>;

export type DiseaseEpidemiologyCPLP = z.infer<typeof DiseaseEpidemiologyCPLPSchema>;
export type DiseaseMedicationsAvailability = z.infer<typeof DiseaseMedicationsAvailabilitySchema>;

export type DiseaseSearchParams = z.infer<typeof DiseaseSearchParamsSchema>;
export type DiseaseSearchResult = z.infer<typeof DiseaseSearchResultSchema>;
export type DiseaseSearchResponse = z.infer<typeof DiseaseSearchResponseSchema>;

export type CreateDiseaseRequest = z.infer<typeof CreateDiseaseRequestSchema>;
export type UpdateDiseaseRequest = z.infer<typeof UpdateDiseaseRequestSchema>;
export type CreateDiseaseContentRequest = z.infer<typeof CreateDiseaseContentRequestSchema>;

export type DiseaseStatistics = z.infer<typeof DiseaseStatisticsSchema>;
export type QualityMetrics = z.infer<typeof QualityMetricsSchema>;

// =====================================================================================
// 13. FUNÇÕES UTILITÁRIAS DE VALIDAÇÃO
// =====================================================================================

export function validateGardBrId(id: string): boolean {
  return GardBrIdSchema.safeParse(id).success;
}

export function validateOrphaCode(code?: string): boolean {
  if (!code) return true;
  return OrphaCodeSchema.safeParse(code).success;
}

export function validateIcdCode(code?: string): boolean {
  if (!code) return true;
  return IcdCodeSchema.safeParse(code).success;
}

export function sanitizeDiseaseInput(input: any): CreateDiseaseRequest | null {
  const result = CreateDiseaseRequestSchema.safeParse(input);
  return result.success ? result.data : null;
}

export function validateCompleteDisease(disease: any): Disease | null {
  const result = DiseaseSchema.safeParse(disease);
  return result.success ? result.data : null;
}

// =====================================================================================
// COMENTÁRIOS FINAIS
// =====================================================================================

/*
Este arquivo de validação Zod fornece:

1. **Validação Robusta**: Todos os campos são validados com regras específicas
2. **Type Safety**: Tipos inferidos automaticamente dos schemas
3. **Consistência**: Validação uniforme em toda a aplicação
4. **Flexibilidade**: Schemas reutilizáveis para diferentes contextos
5. **Documentação**: Regras de validação auto-documentadas
6. **Performance**: Validação eficiente com Zod

Uso recomendado:
- Validar dados de formulários
- Validar requests de API
- Sanitizar inputs de usuário
- Validar dados de import/export
- Gerar documentação automática

Exemplo de uso:
```typescript
import { CreateDiseaseRequestSchema, validateGardBrId } from '@/lib/validation/gard';

const isValid = validateGardBrId('GARD-BR-0001');
const result = CreateDiseaseRequestSchema.safeParse(formData);

if (result.success) {
  // dados validados em result.data
} else {
  // erros em result.error
}
```
*/
