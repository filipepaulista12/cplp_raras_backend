import Link from 'next/link';
import { ArrowLeftIcon } from '@heroicons/react/24/outline';
import TopShare from '@/components/TopShare';

const events = [
  {
    title: "Webinar: Cooperação Científica em Doenças Raras",
    date: "15 de Setembro, 2024",
    time: "14:00 - 16:00 (UTC)",
    type: "Webinar",
    status: "upcoming",
    description: "Discussão sobre oportunidades de colaboração científica entre os países da CPLP na área de doenças raras.",
    speakers: ["Dr. Ana Silva (Brasil)", "Prof. João Santos (Portugal)", "Dra. Maria Costa (Angola)"],
    registration: true
  },
  {
    title: "Workshop: Uso de Plataformas REDCap",
    date: "22 de Agosto, 2024",
    time: "09:00 - 12:00 (UTC)",
    type: "Workshop",
    status: "completed",
    description: "Treinamento prático sobre utilização da plataforma REDCap para coleta de dados em pesquisas de doenças raras.",
    speakers: ["Equipe Técnica CPLP-Raras"],
    registration: false
  },
  {
    title: "1º Simpósio CPLP-Raras",
    date: "10-12 de Outubro, 2024",
    time: "Todo o dia",
    type: "Simpósio",
    status: "upcoming",
    description: "Evento principal do projeto com apresentação de resultados, palestras magistrais e sessões de pôster.",
    speakers: ["Especialistas internacionais", "Pesquisadores da CPLP"],
    registration: true
  }
];

const news = [
  {
    title: "Projeto CPLP-Raras Recebe Financiamento Adicional",
    date: "5 de Agosto, 2024",
    category: "Financiamento",
    summary: "Nova verba permitirá expansão das atividades para mais dois países da CPLP.",
    featured: true
  },
  {
    title: "Publicação de Protocolo de Coleta de Dados",
    date: "28 de Julho, 2024",
    category: "Pesquisa",
    summary: "Documento técnico estabelece diretrizes padronizadas para todos os países participantes.",
    featured: false
  },
  {
    title: "Primeira Reunião Virtual dos GTs",
    date: "15 de Julho, 2024",
    category: "Evento",
    summary: "Grupos de trabalho se reuniram para definir cronograma e metas do segundo semestre.",
    featured: false
  }
];

export default function Events() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Breadcrumb */}
      <div className="bg-white border-b">
        <div className="mx-auto max-w-7xl px-4 py-4 sm:px-6 lg:px-8">
          <Link 
            href="/"
            className="inline-flex items-center text-blue-600 hover:text-blue-800 transition-colors"
          >
            <ArrowLeftIcon className="h-4 w-4 mr-2" />
            Voltar ao Início
          </Link>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        
        {/* Compartilhamento no topo */}
        <TopShare 
          title="Eventos e Notícias - CPLP-Raras"
          description="Acompanhe os próximos eventos, workshops e as últimas novidades do projeto CPLP-Raras"
        />
        
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            📅 Eventos e Notícias
          </h1>
          <div className="w-32 h-1 bg-gradient-to-r from-blue-600 to-green-600 mx-auto mb-8"></div>
          <p className="text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed">
            Acompanhe os próximos eventos, workshops e as últimas novidades do projeto CPLP-Raras.
          </p>
        </div>

        {/* Próximos Eventos */}
        <section className="mb-16">
          <div className="bg-white rounded-2xl shadow-lg p-8 md:p-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-8">
              🎯 Próximos Eventos
            </h2>
            
            <div className="space-y-6">
              {events.filter(event => event.status === 'upcoming').map((event, index) => (
                <div key={index} className="border-l-4 border-blue-600 bg-blue-50 rounded-r-lg p-6">
                  <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-4">
                    <div>
                      <h3 className="text-xl font-semibold text-gray-900 mb-2">
                        {event.title}
                      </h3>
                      <div className="flex flex-wrap gap-4 text-sm text-gray-600">
                        <span>📅 {event.date}</span>
                        <span>⏰ {event.time}</span>
                        <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded">
                          {event.type}
                        </span>
                      </div>
                    </div>
                    {event.registration && (
                      <div className="mt-4 lg:mt-0">
                        <button className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors">
                          Inscrever-se
                        </button>
                      </div>
                    )}
                  </div>
                  
                  <p className="text-gray-700 mb-4">
                    {event.description}
                  </p>
                  
                  <div>
                    <strong className="text-gray-900">Palestrantes: </strong>
                    <span className="text-gray-600">{event.speakers.join(', ')}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Eventos Realizados */}
        <section className="mb-16">
          <div className="bg-white rounded-2xl shadow-lg p-8 md:p-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-8">
              ✅ Eventos Realizados
            </h2>
            
            <div className="space-y-6">
              {events.filter(event => event.status === 'completed').map((event, index) => (
                <div key={index} className="border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow">
                  <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-4">
                    <div>
                      <h3 className="text-xl font-semibold text-gray-900 mb-2">
                        {event.title}
                      </h3>
                      <div className="flex flex-wrap gap-4 text-sm text-gray-600">
                        <span>📅 {event.date}</span>
                        <span>⏰ {event.time}</span>
                        <span className="bg-gray-100 text-gray-800 px-2 py-1 rounded">
                          {event.type}
                        </span>
                      </div>
                    </div>
                    <div className="mt-4 lg:mt-0">
                      <button className="text-blue-600 hover:text-blue-800 font-medium">
                        Ver Gravação →
                      </button>
                    </div>
                  </div>
                  
                  <p className="text-gray-700">
                    {event.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Notícias Recentes */}
        <section className="mb-16">
          <div className="bg-white rounded-2xl shadow-lg p-8 md:p-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-8">
              📰 Notícias Recentes
            </h2>
            
            <div className="space-y-6">
              {news.map((article, index) => (
                <div key={index} className={`rounded-lg p-6 ${
                  article.featured 
                    ? 'bg-gradient-to-r from-blue-50 to-green-50 border-l-4 border-blue-600' 
                    : 'border border-gray-200'
                }`}>
                  <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-3">
                    <div>
                      <h3 className="text-xl font-semibold text-gray-900 mb-2">
                        {article.title}
                      </h3>
                      <div className="flex gap-4 text-sm text-gray-600">
                        <span>📅 {article.date}</span>
                        <span className="bg-gray-100 text-gray-800 px-2 py-1 rounded">
                          {article.category}
                        </span>
                        {article.featured && (
                          <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded">
                            Destaque
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                  
                  <p className="text-gray-700 mb-4">
                    {article.summary}
                  </p>
                  
                  <Link href="/noticias" className="text-blue-600 hover:text-blue-800 font-medium">
                    Leia mais →
                  </Link>
                </div>
              ))}
            </div>
            
            <div className="text-center mt-8">
              <Link
                href="/noticias"
                className="inline-block bg-gradient-to-r from-blue-600 to-green-600 text-white px-8 py-3 rounded-lg font-semibold hover:opacity-90 transition-opacity"
              >
                Ver Todas as Notícias
              </Link>
            </div>
          </div>
        </section>

        {/* Newsletter */}
        <section className="mb-16">
          <div className="bg-gradient-to-r from-blue-600 to-green-600 rounded-2xl p-8 text-white text-center">
            <h2 className="text-2xl font-bold mb-4">
              📧 Mantenha-se Atualizado
            </h2>
            <p className="text-xl mb-6 opacity-90">
              Receba notificações sobre novos eventos e notícias do projeto CPLP-Raras.
            </p>
            <div className="max-w-md mx-auto flex flex-col sm:flex-row gap-4">
              <input
                type="email"
                placeholder="Seu e-mail"
                className="flex-1 px-4 py-3 rounded-lg text-gray-900 focus:outline-none focus:ring-2 focus:ring-white"
              />
              <button className="bg-white text-blue-600 px-6 py-3 rounded-lg font-semibold hover:bg-blue-50 transition-colors">
                Inscrever
              </button>
            </div>
          </div>
        </section>

        {/* Calendário */}
        <section>
          <div className="bg-white rounded-2xl shadow-lg p-8 md:p-12 text-center">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              📆 Calendário de Eventos
            </h2>
            <p className="text-lg text-gray-600 mb-6">
              Acesse o calendário completo com todos os eventos programados para 2024.
            </p>
            <button className="bg-gradient-to-r from-blue-600 to-green-600 text-white px-8 py-3 rounded-lg font-semibold hover:opacity-90 transition-opacity">
              Ver Calendário Completo
            </button>
          </div>
        </section>
      </div>
    </div>
  );
}
