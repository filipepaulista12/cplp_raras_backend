import type { Metadata } from 'next';
import Link from 'next/link';

export const metadata: Metadata = {
  title: 'Declaração de Acessibilidade | CPLP-Raras',
  description: 'Informações sobre os recursos de acessibilidade implementados no site da rede CPLP-Raras para garantir acesso universal às informações sobre doenças raras.',
  keywords: 'acessibilidade, WCAG, doenças raras, inclusão digital, leitores de tela',
};

export default function Acessibilidade() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Breadcrumb */}
      <div className="bg-white border-b">
        <div className="mx-auto max-w-7xl px-4 py-4 sm:px-6 lg:px-8">
          <nav className="flex" aria-label="Navegação por migalhas de pão">
            <ol className="inline-flex items-center space-x-1 md:space-x-3" role="list">
              <li role="listitem">
                <Link href="/" className="text-blue-600 hover:text-blue-800 focus:outline-none focus:ring-2 focus:ring-blue-500 rounded-sm">
                  Início
                </Link>
              </li>
              <li role="listitem" aria-current="page">
                <div className="flex items-center">
                  <span className="mx-2 text-gray-400" aria-hidden="true">/</span>
                  <span className="text-gray-500">Acessibilidade</span>
                </div>
              </li>
            </ol>
          </nav>
        </div>
      </div>

      <div className="mx-auto max-w-4xl px-4 py-12 sm:px-6 lg:px-8">
        {/* Header */}
        <header className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            <span role="img" aria-label="Símbolo de acessibilidade" className="mr-3">♿</span>
            Declaração de Acessibilidade
          </h1>
          <div className="w-32 h-1 bg-gradient-to-r from-blue-500 to-purple-600 mx-auto mb-8"></div>
          <p className="text-xl text-gray-600 leading-relaxed">
            Estamos comprometidos em tornar este site acessível a todas as pessoas, 
            independentemente de suas habilidades ou tecnologias utilizadas.
          </p>
        </header>

        {/* Conformidade WCAG */}
        <section className="mb-12" aria-labelledby="conformidade-wcag">
          <div className="bg-gradient-to-r from-green-50 to-blue-50 rounded-2xl p-8 border border-green-200">
            <h2 id="conformidade-wcag" className="text-2xl font-bold text-gray-900 mb-6 flex items-center">
              <span role="img" aria-label="Verificado" className="mr-3">✅</span>
              Conformidade WCAG 2.1 AA
            </h2>
            <p className="text-gray-700 leading-relaxed mb-4">
              Este site foi desenvolvido seguindo as Diretrizes de Acessibilidade para Conteúdo Web (WCAG) 2.1 
              no nível AA, garantindo que seja perceptível, operável, compreensível e robusto para todos os usuários.
            </p>
            <div className="bg-white rounded-lg p-4 border-l-4 border-green-500">
              <p className="text-sm text-gray-600">
                <strong>Última avaliação:</strong> Dezembro 2024 | 
                <strong> Status:</strong> Conformidade AA verificada
              </p>
            </div>
          </div>
        </section>

        {/* Recursos Implementados */}
        <section className="mb-12" aria-labelledby="recursos-acessibilidade">
          <h2 id="recursos-acessibilidade" className="text-3xl font-bold text-gray-900 mb-8">
            Recursos de Acessibilidade Implementados
          </h2>
          
          <div className="grid md:grid-cols-2 gap-6">
            {/* Navegação por Teclado */}
            <div className="bg-white rounded-xl p-6 shadow-md border border-gray-200">
              <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                <span role="img" aria-label="Teclado" className="mr-3">⌨️</span>
                Navegação por Teclado
              </h3>
              <ul className="space-y-2 text-gray-600">
                <li>• Navegação completa sem mouse</li>
                <li>• Indicadores visuais de foco</li>
                <li>• Atalhos de teclado personalizados</li>
                <li>• Skip links para conteúdo principal</li>
              </ul>
            </div>

            {/* Leitores de Tela */}
            <div className="bg-white rounded-xl p-6 shadow-md border border-gray-200">
              <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                <span role="img" aria-label="Leitor de tela" className="mr-3">🔊</span>
                Compatibilidade com Leitores de Tela
              </h3>
              <ul className="space-y-2 text-gray-600">
                <li>• Estrutura semântica adequada</li>
                <li>• Textos alternativos para imagens</li>
                <li>• Rótulos descritivos</li>
                <li>• Anúncios de mudanças de estado</li>
              </ul>
            </div>

            {/* Controle Visual */}
            <div className="bg-white rounded-xl p-6 shadow-md border border-gray-200">
              <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                <span role="img" aria-label="Olho" className="mr-3">👁️</span>
                Controles Visuais
              </h3>
              <ul className="space-y-2 text-gray-600">
                <li>• Ajuste de tamanho de fonte</li>
                <li>• Modo de alto contraste</li>
                <li>• Suporte para daltonismo</li>
                <li>• Redução de movimento/animações</li>
              </ul>
            </div>

            {/* Estrutura do Conteúdo */}
            <div className="bg-white rounded-xl p-6 shadow-md border border-gray-200">
              <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                <span role="img" aria-label="Estrutura" className="mr-3">🏗️</span>
                Estrutura do Conteúdo
              </h3>
              <ul className="space-y-2 text-gray-600">
                <li>• Hierarquia clara de cabeçalhos</li>
                <li>• Landmarks ARIA</li>
                <li>• Navegação consistente</li>
                <li>• Linguagem clara e simples</li>
              </ul>
            </div>
          </div>
        </section>

        {/* Atalhos de Teclado */}
        <section className="mb-12" aria-labelledby="atalhos-teclado">
          <div className="bg-white rounded-2xl p-8 shadow-lg">
            <h2 id="atalhos-teclado" className="text-2xl font-bold text-gray-900 mb-6">
              Atalhos de Teclado Disponíveis
            </h2>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-semibold text-gray-900 mb-3">Navegação Geral</h3>
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Pular para conteúdo principal</span>
                    <kbd className="px-3 py-1 bg-gray-100 rounded border text-sm">Tab</kbd>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Fechar modais/painéis</span>
                    <kbd className="px-3 py-1 bg-gray-100 rounded border text-sm">Esc</kbd>
                  </div>
                </div>
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 mb-3">Controles de Fonte</h3>
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Aumentar fonte</span>
                    <kbd className="px-3 py-1 bg-gray-100 rounded border text-sm">Ctrl + +</kbd>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Diminuir fonte</span>
                    <kbd className="px-3 py-1 bg-gray-100 rounded border text-sm">Ctrl + -</kbd>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Restaurar padrão</span>
                    <kbd className="px-3 py-1 bg-gray-100 rounded border text-sm">Ctrl + 0</kbd>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Tecnologias Assistivas */}
        <section className="mb-12" aria-labelledby="tecnologias-assistivas">
          <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-2xl p-8 border border-blue-200">
            <h2 id="tecnologias-assistivas" className="text-2xl font-bold text-gray-900 mb-6">
              Tecnologias Assistivas Suportadas
            </h2>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="text-3xl mb-3" role="img" aria-label="NVDA">🖥️</div>
                <h3 className="font-semibold text-gray-900 mb-2">NVDA</h3>
                <p className="text-sm text-gray-600">Leitor de tela gratuito para Windows</p>
              </div>
              <div className="text-center">
                <div className="text-3xl mb-3" role="img" aria-label="JAWS">🔊</div>
                <h3 className="font-semibold text-gray-900 mb-2">JAWS</h3>
                <p className="text-sm text-gray-600">Leitor de tela profissional</p>
              </div>
              <div className="text-center">
                <div className="text-3xl mb-3" role="img" aria-label="VoiceOver">🍎</div>
                <h3 className="font-semibold text-gray-900 mb-2">VoiceOver</h3>
                <p className="text-sm text-gray-600">Leitor de tela nativo do macOS/iOS</p>
              </div>
            </div>
          </div>
        </section>

        {/* Feedback e Contato */}
        <section className="mb-12" aria-labelledby="feedback-acessibilidade">
          <div className="bg-gradient-to-r from-pink-50 to-purple-50 rounded-2xl p-8 border border-pink-200">
            <h2 id="feedback-acessibilidade" className="text-2xl font-bold text-gray-900 mb-6">
              Feedback e Suporte
            </h2>
            <p className="text-gray-700 leading-relaxed mb-6">
              Encontrou alguma barreira de acessibilidade? Sua opinião é fundamental para 
              continuarmos melhorando. Entre em contato conosco:
            </p>
            <div className="space-y-4">
              <div className="flex items-center">
                <span role="img" aria-label="Email" className="mr-3">📧</span>
                <span className="text-gray-600">
                  Email: <a href="mailto:cplp@raras.org.br" className="text-blue-600 hover:text-blue-800 underline">cplp@raras.org.br</a>
                </span>
              </div>
            {/*   <div className="flex items-center">
                <span role="img" aria-label="Telefone" className="mr-3">📞</span>
                <span className="text-gray-600">Telefone: +351 XXX XXX XXX</span>
              </div>*/}
            </div>
          </div>
        </section>

        {/* Compromisso Contínuo */}
        <section aria-labelledby="compromisso-continuo">
          <div className="bg-white rounded-2xl p-8 shadow-lg border-t-4 border-gradient-to-r from-blue-500 to-purple-600">
            <h2 id="compromisso-continuo" className="text-2xl font-bold text-gray-900 mb-6">
              Nosso Compromisso Contínuo
            </h2>
            <p className="text-gray-700 leading-relaxed mb-4">
              A acessibilidade é uma jornada contínua. Estamos constantemente trabalhando 
              para melhorar a experiência de todos os usuários, implementando novas tecnologias 
              e seguindo as melhores práticas de acessibilidade.
            </p>
            <p className="text-gray-700 leading-relaxed">
              Este site é revisado regularmente para garantir que continue atendendo 
              aos mais altos padrões de acessibilidade e usabilidade.
            </p>
          </div>
        </section>
      </div>
    </div>
  );
}
